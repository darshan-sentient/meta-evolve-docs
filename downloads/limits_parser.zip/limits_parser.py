"""Narrow the parser's evaluation budget while keeping its search declaration."""

import argparse
from dataclasses import replace
from pathlib import Path

import meta_evolve as meta
from openai_client import OpenAIClient
from parser import experiment, run_lesson


# --8<-- [start:declaration]
def declaration(client, evaluations=2):
    base = experiment(client)
    task = replace(base.task, budget=meta.Budget(evaluations=evaluations, trials=3))
    return replace(base, task=task)
# --8<-- [end:declaration]


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("directory", type=Path, help="new history directory")
    cli.add_argument("--evaluations", type=int, default=2)
    args = cli.parse_args()
    with OpenAIClient.from_environment() as client:
        run_lesson(client, args.directory, declaration=declaration(client, args.evaluations))
