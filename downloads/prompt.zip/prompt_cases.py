"""Curated fictional tickets. Expected labels belong to the evaluator."""

# --8<-- [start:policy]
POLICY = """Route each support ticket to exactly one team:
billing: charges, invoices, or refunds.
account: identity, access, or account changes.
technical: product malfunction.
For mixed requests, follow the explicitly requested primary action.
If no primary action resolves the tie, choose account before billing before technical.
Return only the lowercase label: billing, technical, or account."""
# --8<-- [end:policy]

DEVELOPMENT = (
    ("I was charged twice for this month. Please refund the duplicate.", "billing"),
    ("I lost my recovery codes. Help me regain access.", "account"),
    ("The dashboard freezes whenever I open the chart.", "technical"),
    # Requested action outranks a background symptom.
    ("I cannot sign in, but my priority is a refund for yesterday's charge.", "billing"),
    # Neither request takes priority: account wins over billing.
    ("Please reset my password and send a copy of my invoice.", "account"),
    # Neither request takes priority: billing wins over technical.
    ("Please fix the broken export and refund this month's charge.", "billing"),
    ("Where can I get a copy of last month's invoice?", "billing"),
    ("My receipt shows the wrong tax amount. Please correct it.", "billing"),
    ("Why is there a charge after my subscription ended?", "billing"),
    ("The advertised discount is missing from my invoice.", "billing"),
    ("Please explain the extra seat charge on our bill.", "billing"),
    ("The refund you approved has not reached my card.", "billing"),
    ("Can you put our purchase order number on the invoice?", "billing"),
    ("I need a breakdown of the usage fees on this statement.", "billing"),
    ("Please update the email address associated with my account.", "account"),
    ("Remove the former administrator's access to our workspace.", "account"),
    ("I forgot my password and need to reset it.", "account"),
    ("Please delete my account and its profile.", "account"),
    ("Transfer ownership of our workspace to my colleague.", "account"),
    ("My account is locked after too many sign-in attempts.", "account"),
    ("I replaced my phone and need to reset two-factor authentication.", "account"),
    ("Please change my display name on the account.", "account"),
    ("The search results page crashes for every query.", "technical"),
    ("The CSV export is missing the last row even though it is visible in the app.", "technical"),
    ("Attachments upload successfully but appear as blank files.", "technical"),
    ("The mobile app closes whenever I open a saved report.", "technical"),
    ("Notifications arrive an hour after the event. Please fix the delay.", "technical"),
    ("The report totals do not match the rows used to calculate them.", "technical"),
    ("Our webhook sends the same event three times. Please investigate.", "technical"),
    ("The dashboard layout overlaps the save button on a narrow screen.", "technical"),
    ("The export crashes. I mainly want a refund, not a repair investigation.", "billing"),
    ("My invoice looks wrong, but first help me recover my locked account.", "account"),
    ("I may need an email change later; for now fix the chart that will not render.", "technical"),
    ("The app crashes and I want a refund, but fixing the crash is my priority.", "technical"),
    ("Please change my account email and fix the broken report export.", "account"),
    ("I need an invoice correction and a password reset; both are equally urgent.", "account"),
    ("The dashboard is broken and I need a refund; neither request comes first.", "billing"),
    ("Please restore my login, correct my invoice, and fix the chart. All are equally urgent.", "account"),
    ("I was charged twice, but only help me change my account email today.", "account"),
    ("The invoice download button crashes; I only want the button fixed, not a copy of the bill.", "technical"),
)

# Imported by the driver only after selection. Never supplied to the proposer.
FINAL = (
    ("Please refund the unused credit that was charged to my card.", "billing"),
    ("The invoice currency does not match our agreement. Please correct the bill.", "billing"),
    ("I need a receipt for the payment made at the start of the quarter.", "billing"),
    ("I no longer control my old email address. Help me recover my account.", "account"),
    ("Revoke the access of a contractor who has left our team.", "account"),
    ("I would like to change the username on my profile.", "account"),
    ("The calendar view displays every appointment twice. Please fix it.", "technical"),
    ("The PDF export cuts off the rightmost column.", "technical"),
    ("I need access restored and a refund, but the refund is my main request.", "billing"),
    ("Please repair the file preview and remove an old administrator's access.", "account"),
    ("Please investigate the broken calendar and correct my invoice; both matter equally.", "billing"),
    ("I have a billing question, but my immediate request is to fix the blank PDF export.", "technical"),
)
