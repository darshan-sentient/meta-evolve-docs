"""Improve a routing prompt with model responses and independent Python grading.

Run --dry-run without credentials. See docs/learn/llm-prompt.md for the lesson.
"""

import argparse
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
import sys

import meta_evolve as meta
from meta_evolve.domain import InvalidOutput, RunId
from meta_evolve.errors import ExecutionAccountingUnknown

from prompt_cases import DEVELOPMENT, POLICY

# --8<-- [start:seed]
SEED = POLICY  # Start with the correct policy; improvement is not guaranteed.
# --8<-- [end:seed]


# --8<-- [start:evaluate]
def evaluate(prompt, client, *, cases=DEVELOPMENT):
    """Measure every ticket, or retain a typed failure without a partial score."""
    if not cases:
        raise ValueError("evaluation requires at least one ticket")
    if not isinstance(prompt, str) or not prompt.strip():
        return meta.EvaluationResult(
            failure=InvalidOutput(message="expected a nonempty prompt"),
        )
    usage, evidence, checks = meta.Resources(), [], []
    for ticket, expected in cases:
        try:
            response = client.generate(instructions=prompt, input=ticket)
        except ExecutionAccountingUnknown as error:
            error.receipt = {
                "request": getattr(error, "receipt", None), "ticket": ticket,
                "completed_usage": asdict(usage),
                "completed_evidence": [evidence_record(item) for item in evidence],
            }
            raise
        usage += response.usage
        evidence.extend(response.evidence)
        if response.failure is not None:
            evidence.append(meta.EvidenceDraft(kind="routing-unavailable", data={
                "input": ticket, "expected": expected, "failure": response.failure.kind,
            }))
            return meta.EvaluationResult(
                failure=response.failure, usage=usage, evidence=tuple(evidence),
            )
        check = meta.EvidenceDraft(kind="routing-case", data={
            "input": ticket, "expected": expected, "actual": response.candidate,
            "passed": response.candidate.strip() == expected,
        })
        checks.append(check)
        evidence.append(check)
    return meta.EvaluationResult(
        metrics={"score": sum(check.data["passed"] for check in checks) / len(cases)},
        usage=usage, evidence=tuple(evidence),
    )
# --8<-- [end:evaluate]


# --8<-- [start:experiment]
def experiment(client, *, seed=SEED, trials=3):
    def propose(parent, *, context):
        observations = [
            record for record in context.bundle.records
            if record.kind == "evidence" and record.value.kind == "routing-case"
        ]
        latest = max(
            (record.logical_step for record in observations), default=-1,
        )
        feedback = [dict(record.value.data) for record in observations
                    if record.logical_step == latest]
        return client.generate(
            instructions=(
                "Rewrite the routing prompt to follow this policy. "
                "Return only the prompt.\n" + POLICY
            ),
            input=json.dumps({"prompt": parent, "development_checks": feedback}),
        )

    return meta.Experiment(
        task=meta.Task(
            evaluator=lambda prompt: evaluate(prompt, client),
            objectives=(meta.Maximize("score", satisfy=1.0),),
            environment={"model": client.configuration, "lesson": lesson_identity()},
        ),
        seed=seed, proposer=propose, search=meta.Greedy(max_trials=trials),
        context=meta.AncestorsOnly(max_records=200, max_chars=64_000),
    )
# --8<-- [end:experiment]


def lesson_identity():
    root = Path(__file__).parent
    return {
        "sha256": sha256(b"".join((root / name).read_bytes() for name in
                                 ("prompt.py", "prompt_cases.py", "openai_client.py"))).hexdigest(),
        "python": sys.version,
    }


def evidence_record(item):
    return {"kind": item.kind, "data": dict(item.data)}


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, default=dict) + "\n", encoding="utf-8")


class RequestJournal:
    """Retain completed calls even if a later call prevents a history commit."""

    def __init__(self, client, path):
        self.client, self.path = client, path
        self.configuration = client.configuration

    def generate(self, *, instructions, input):
        result = self.client.generate(instructions=instructions, input=input)
        with self.path.open("a", encoding="utf-8") as journal:
            journal.write(json.dumps({
                "instructions": instructions, "input": input,
                "candidate": result.candidate,
                "failure": result.failure.kind if result.failure else None,
                "usage": asdict(result.usage),
                "evidence": [evidence_record(item) for item in result.evidence],
            }, default=dict) + "\n")
        return result


def show(result):
    for index, attempt in enumerate(result.trials()):
        outcome = attempt.failure.kind if attempt.failure else (
            f"{attempt.metrics['score']:.0%}" if attempt.metrics else "incomplete"
        )
        print(f"{'Seed' if index == 0 else 'Revision ' + str(index)}: {outcome}")
        checks = [item.data for item in attempt.evidence if item.kind == "routing-case"]
        if checks:
            row = next((row for row in checks if not row["passed"]), checks[0])
            print(f"  {row['input']!r} -> {row['actual']!r}; expected {row['expected']}")
    try:
        print("Best measured prompt:\n" + result.best().value)
    except meta.NoSuccessfulEvaluation:
        print("No successfully measured prompt.")
    usage = result.usage()
    spend = "unknown" if usage.spend_micros is None else f"{usage.spend_micros} micro-USD"
    print(f"Usage: {usage.trials} revisions, {usage.evaluations} evaluations")
    print(f"Tokens: {usage.tokens}; billed spend: {spend}")


def run_lesson(client, directory, *, seed=SEED, trials=3, budget=None):
    """Save the selected prompt, then perform one final check outside search."""
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=False)
    save_json(root / "configuration.json", {
        "model": client.configuration, "lesson": lesson_identity(), "trials": trials,
        "budget": asdict(budget) if budget else None,
    })
    client = RequestJournal(client, root / "requests.jsonl")
    phase = "development"
    with meta.Storage.durable(root / "history") as storage:
        try:
            result = meta.run(experiment(client, seed=seed, trials=trials), storage=storage, budget=budget)
            show(result)
            try:
                selected = result.best().value
            except meta.NoSuccessfulEvaluation:
                print("Separate final check: skipped; no successfully measured prompt.")
                return result.id
            (root / "selected.txt").write_text(selected, encoding="utf-8")
            from prompt_cases import FINAL

            phase = "final"
            final = evaluate(selected, client, cases=FINAL)
            save_json(root / "final.json", {
                "metrics": dict(final.metrics),
                "failure": ({"kind": final.failure.kind, "message": final.failure.message}
                            if final.failure else None),
                "evidence": [evidence_record(item) for item in final.evidence],
                "usage": asdict(final.usage),
            })
            print("Separate final check:", final.failure.kind if final.failure else
                  f"{round(final.metrics['score'] * len(FINAL))}/{len(FINAL)}")
            print(f"Final tokens: {final.usage.tokens}; see final.json for separate usage and evidence.")
            return result.id
        except ExecutionAccountingUnknown as error:
            save_json(root / "accounting-unknown.json", {
                "phase": phase, "reason": str(error), "receipt": getattr(error, "receipt", None),
            })
            raise
        finally:
            if storage.runs():
                (root / "run-id.txt").write_text(storage.runs()[0].value + "\n", encoding="utf-8")


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    modes = cli.add_mutually_exclusive_group(required=True)
    modes.add_argument("--dry-run", action="store_true", help="preview policy and cases; no model calls")
    modes.add_argument("--run", type=Path, metavar="DIRECTORY", help="save a new experiment and final check")
    modes.add_argument("--inspect", type=Path, metavar="DIRECTORY", help="read saved results; no model calls")
    args = cli.parse_args()
    if args.dry_run:
        from openai_client import configuration

        print("Dry run: no SDK requests; accuracy is not measured.")
        print(POLICY)
        for ticket, expected in DEVELOPMENT[:6]:
            print(f"{ticket!r} -> {expected}")
        print("Maximum requests: 163 development + 12 final = 175 (no retries).")
        print("Configuration:", json.dumps(configuration(), sort_keys=True))
    elif args.inspect:
        with meta.Storage.read_only(args.inspect / "history") as storage:
            if storage.runs():
                show(meta.Run(RunId((args.inspect / "run-id.txt").read_text().strip()), storage))
            else:
                print("No committed run. No successfully measured prompt.")
        for name in ("configuration.json", "final.json", "accounting-unknown.json"):
            path = args.inspect / name
            print(f"{name}:", path.read_text() if path.exists() else "not recorded")
    else:
        from openai_client import OpenAIClient

        try:
            with OpenAIClient.from_environment() as client:
                run_lesson(client, args.run)
        except (meta.CapabilityError, ExecutionAccountingUnknown) as error:
            cli.exit(2, f"{error}\n")


if __name__ == "__main__":
    main()
