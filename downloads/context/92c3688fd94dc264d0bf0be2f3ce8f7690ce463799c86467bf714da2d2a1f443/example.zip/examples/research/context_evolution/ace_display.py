"""Read-only HTML views of the ACE study, shared by the notebook and walkthrough."""

from html import escape
import json

from ace_outcomes import SplitOutcome
from ace_rollouts import rollouts_in
from playbook import Playbook
from playbook_codec import decode, encode


STYLE = """<style>
.ace-study { color: inherit; line-height: 1.65; margin: 1.1rem 0 1.7rem; overflow-wrap: anywhere; }
.ace-study * { box-sizing: border-box; }
.ace-study .ace-grid { display: grid; gap: .8rem;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 16rem), 1fr)); }
.ace-study .ace-card { border: 1px solid var(--me-border, #919a9560);
  border-radius: .3rem; padding: 1rem 1.1rem; min-width: 0; }
.ace-study .ace-retired { border-style: dashed; }
.ace-study .ace-label { font-size: .78em; letter-spacing: .04em;
  text-transform: uppercase; margin: 0 0 .5rem; }
.ace-study .ace-label code { text-transform: none; letter-spacing: normal; }
.ace-study p { margin: .4rem 0 .8rem; }
.ace-study p:last-child { margin-bottom: 0; }
.ace-study code { font-size: .85em; white-space: normal !important; overflow-wrap: anywhere; }
.ace-study .ace-caption { font-size: .88em; }
.ace-study .ace-change { border-inline-start: 3px solid var(--md-accent-fg-color, #538b80);
  padding-inline-start: 1rem; margin: 1rem 0; }
.ace-study .ace-before { text-decoration: line-through; }
.ace-study table { border-collapse: collapse; width: 100%; font-size: .9em; }
.ace-study th, .ace-study td { text-align: left; padding: .65rem .8rem;
  border-bottom: 1px solid var(--me-border, #919a9560); vertical-align: top; }
.ace-study .ace-selected { font-weight: 600; }
.ace-study details { margin: 1rem 0; }
.ace-study summary { cursor: pointer; }
.ace-study pre { overflow-x: auto; white-space: pre-wrap; overflow-wrap: anywhere; padding: .8rem; }
</style>"""


def _code(value: object) -> str:
    return f"<code>{escape(str(value))}</code>"


def _wrap(body: str) -> str:
    return '<div class="ace-study">' + body + "</div>"


def _details(label: str, text: str) -> str:
    return f"<details><summary>{escape(label)}</summary><pre>{escape(text)}</pre></details>"


def _table(headers, rows) -> str:
    head = "".join(f'<th scope="col">{escape(label)}</th>' for label in headers)
    body = "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f'<table class="ace-table"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>'


def entries(book: Playbook) -> str:
    """Show readable rules, their persistent identities, and their exact JSON."""
    cards = []
    for item in book.items:
        cards.append(
            f'<div class="ace-card ace-{escape(item.status)}">'
            f'<p class="ace-label">{escape(item.section)} · {escape(item.status)}</p>'
            f"<p>{escape(item.content)}</p><p>{_code(item.identity)}</p></div>"
        )
    raw = json.dumps(json.loads(str(encode(book))), indent=2)
    return STYLE + _wrap('<div class="ace-grid">' + "".join(cards) + "</div>"
                         + _details("Inspect the playbook JSON", raw))


def answers(outcome: SplitOutcome) -> str:
    """Read each final attempted answer, including wrong answers and missing evidence."""
    cards = []
    for task in rollouts_in(outcome.split):
        score = outcome.scores.get(task.name)
        fault = outcome.unfinished.get(task.name)
        verdict = (fault.kind if fault else "Not run") if score is None else (
            "Pass" if score == 1 else "Needs correction"
        )
        run = outcome.runs.get(task.name)
        attempt = list(run.trials())[-1] if run else None
        answer = (attempt.artifact.value.get(task.target) if attempt and attempt.artifact else None)
        cards.append(
            f'<div class="ace-card"><p class="ace-label">{escape(task.name)} · {escape(verdict)}</p>'
            f'<p class="ace-caption">Answer</p><p>{_code(answer.strip() if answer else "No answer")}</p>'
            f'<p class="ace-caption">Expected</p><p>{_code(task.answer.strip())}</p>'
            + _details("Read the task", str(task.source["README.md"])) + "</div>"
        )
    score = f"{outcome.solved:.0%} solved" if outcome.is_complete else "Incomplete · no aggregate score"
    return _wrap(f"<p><strong>{escape(outcome.split.capitalize())} · {score}</strong></p>"
                 + '<div class="ace-grid">' + "".join(cards) + "</div>")


def lessons_view(lessons) -> str:
    body = "".join(
        f'<div class="ace-change"><p class="ace-label">Published lesson · {_code(lesson.identity)}</p>'
        f"<p>{escape(lesson.content)}</p></div>" for lesson in lessons
    )
    return _wrap(body or "<p>No development lessons were published.</p>")


def changes(before: Playbook, after: Playbook) -> str:
    """Compare by item identity; retirement and removal remain distinct."""
    previous, current = before.by_identity(), after.by_identity()
    body = []
    for identity in dict.fromkeys((*previous, *current)):
        old, new = previous.get(identity), current.get(identity)
        if old == new:
            continue
        action = "Added" if old is None else "Pruned" if new is None else (
            "Retired" if old.status != new.status and new.status == "retired" else "Amended"
        )
        body.append(f'<div class="ace-change"><p class="ace-label">{action} · {_code(identity)}</p>')
        if old:
            body.append(f'<p class="ace-before">{escape(old.content)}</p>')
        if new and (old is None or old.content != new.content):
            body.append(f"<p>{escape(new.content)}</p>")
        body.append("</div>")
    return _wrap("".join(body) or "<p>No entries changed.</p>")


def revisions(run) -> str:
    attempts = list(run.trials())
    selected = run.best_trial().id if run.summary().primary_score is not None else None
    books, rows, diffs = {}, [], []
    for number, attempt in enumerate(attempts):
        label = "Seed" if number == 0 else f"Revision {number}"
        ranked = attempt.state == "evaluated"
        score = f"{attempt.metrics['solved']:.0%}" if ranked else "Unrankable"
        result = "Selected" if attempt.id == selected else "Evaluated" if ranked else attempt.state
        emphasis = ' class="ace-selected"' if attempt.id == selected else ""
        rows.append((escape(label), score, f'<span{emphasis}>{escape(result)}</span>'))
        if not ranked:
            if attempt.failure:
                diffs.append(_details(label + " failure", attempt.failure.message))
            continue
        book = decode(attempt.artifact.value)
        books[attempt.artifact.id] = book
        if attempt.parent_ids:
            parent = books[attempt.parent_ids[0]]
            diffs.append(f"<p><strong>{escape(label)}</strong></p>" + changes(parent, book))
    return _wrap(_table(("Version", "Private solved", "Result"), rows) + "".join(diffs))


def consolidation_view(decision) -> str:
    rows = []
    for label, outcome in (("Selected playbook", decision.before), ("Pruned playbook", decision.after)):
        score = "Not run" if outcome is None else (
            f"{outcome.solved:.0%}" if outcome.is_complete else "Incomplete · unrankable"
        )
        rows.append((label, score))
    result = "Accepted" if decision.accepted else "Kept the selected playbook"
    return _wrap(_table(("Matched private check", "Solved"), rows)
                 + f"<p><strong>{result} · {escape(decision.reason)}</strong></p>")
