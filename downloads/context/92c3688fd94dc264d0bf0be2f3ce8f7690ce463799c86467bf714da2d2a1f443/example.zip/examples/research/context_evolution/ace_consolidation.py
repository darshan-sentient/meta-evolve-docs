"""Whether a pruned playbook replaces the selected one, and on what evidence.

Consolidation is two separate things, and keeping them apart is the whole
point. ``playbook.consolidate`` says what a pruned playbook *looks like* -- a
representation operation with no authority. This module decides whether that
pruning is *kept*, by re-scoring on the private split under the same budget.
The candidate may mark an item retired; it does not get to shrink the thing it
is judged on.

Pruning is expected to be neutral, and by construction: ``render`` already
omits retired items, so removing them cannot change what any agent was told.
The re-score is therefore a guard rather than a judgement call -- it is what
would catch a future change that started rendering retired items, or a check
whose result depended on playbook length. Keeping it means the property is
verified on every run instead of argued for in a comment.
"""

from __future__ import annotations

from dataclasses import dataclass

import meta_evolve as meta

from ace_outcomes import SplitOutcome
from ace_rollouts import PRIVATE, rollouts_in
from ace_sessions import run_split
from inner_agent import InnerAgent
from playbook import Playbook, consolidate

class UnmatchedEvidence(Exception):
    """Two outcomes offered as a comparison that were not measured alike.

    Raised rather than returned as ``False``, because "not neutral" is a claim
    about pruning and this is not one: nothing was learned about pruning by
    comparing a development mean with a held-out mean. Reporting it as a
    regression would put a decision's name on a measurement error.
    """


def consolidation_is_neutral(before: SplitOutcome, after: SplitOutcome) -> bool:
    """Whether pruning cost nothing, under matched conditions and budget.

    "Matched" is enforced here rather than assumed, because this predicate is
    exported and the caller that happens to satisfy it is not the only one
    there will ever be. Two things have to hold before the means mean
    anything: the same split, and the same *declared* rollouts within it.

    Against the split's own membership, not against each other. Comparing the
    two outcomes' contents was the earlier version, and it could only ask
    whether they agreed -- two outcomes each holding one score out of a
    two-rollout split agreed perfectly, called themselves complete, and made
    pruning look neutral on exactly the half that would not have disagreed.
    Asking ``rollouts_in`` instead means the answer comes from the definition
    of the split rather than from the evidence being judged, which is the only
    version of this check that a partial pair cannot satisfy.
    """

    if before.split != after.split:
        raise UnmatchedEvidence(
            f"cannot compare a {before.split} outcome with a {after.split} one"
        )
    membership = tuple(rollout.name for rollout in rollouts_in(before.split))
    for side, outcome in (("before", before), ("after", after)):
        if outcome.declared != membership:
            raise UnmatchedEvidence(
                f"the {side} outcome declares {list(outcome.declared)}, but the "
                f"{before.split} split is {list(membership)}"
            )
    if before.condition != after.condition:
        raise UnmatchedEvidence("cannot compare outcomes measured under different conditions")
    if not (before.is_complete and after.is_complete):
        return False
    return after.solved >= before.solved


@dataclass(frozen=True, slots=True)
class Consolidation:
    """The pruning decision, and the matched evidence it was made on.

    Both outcomes are retained rather than only the deciding one. A reader who
    is told pruning was accepted and shown one score cannot check the
    comparison, and a reader told it was refused cannot tell a regression from
    a rollout that never finished -- which is what ``reason`` names.
    """

    playbook: Playbook
    pruned: Playbook
    accepted: bool
    reason: str
    before: SplitOutcome
    after: SplitOutcome | None

    @property
    def usage(self) -> meta.Usage:
        """Every rollout the decision cost, whichever way it went."""

        if self.after is None:
            return self.before.usage
        return self.before.usage + self.after.usage

    @property
    def sessions(self) -> int:
        """Wrapper sessions this decision opened, across both passes."""

        if self.after is None:
            return self.before.sessions
        return self.before.sessions + self.after.sessions


NOTHING_RETIRED = "nothing-retired"
NEUTRAL = "neutral"
REGRESSED = "regressed"
INCOMPLETE = "incomplete"
CONSOLIDATION_REASONS = (NOTHING_RETIRED, NEUTRAL, REGRESSED, INCOMPLETE)


def accept_consolidation(playbook: Playbook, agent: InnerAgent) -> Consolidation:
    """Prune retired items, and keep the pruning only if it costs nothing.

    Consolidation *acceptance* is the evaluator's call, never the candidate's:
    the candidate may mark an item retired, but whether the pruned playbook
    replaces the selected one is decided here, by re-scoring on the private
    split under the same budget.

    Pruning is expected to be neutral, and by construction: ``render`` already
    omits retired items, so removing them cannot change what any agent was
    told. The re-score is therefore a guard rather than a judgement call -- it
    is what would catch a future change that started rendering retired items,
    or a check whose result depended on playbook length. Keeping it means the
    property is verified on every run instead of argued for in a comment.
    """

    pruned = consolidate(playbook)
    before = run_split(PRIVATE, playbook, agent)
    if pruned == playbook:
        return Consolidation(
            playbook=playbook,
            pruned=pruned,
            accepted=False,
            reason=NOTHING_RETIRED,
            before=before,
            after=None,
        )
    after = run_split(PRIVATE, pruned, agent)
    accepted = consolidation_is_neutral(before, after)
    if accepted:
        reason = NEUTRAL
    elif before.is_complete and after.is_complete:
        reason = REGRESSED
    else:
        reason = INCOMPLETE
    return Consolidation(
        playbook=pruned if accepted else playbook,
        pruned=pruned,
        accepted=accepted,
        reason=reason,
        before=before,
        after=after,
    )


__all__ = [
    "CONSOLIDATION_REASONS",
    "Consolidation",
    "INCOMPLETE",
    "NEUTRAL",
    "NOTHING_RETIRED",
    "REGRESSED",
    "UnmatchedEvidence",
    "accept_consolidation",
    "consolidation_is_neutral",
]
