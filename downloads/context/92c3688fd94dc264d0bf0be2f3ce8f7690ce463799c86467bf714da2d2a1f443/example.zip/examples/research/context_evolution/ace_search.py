"""The outer run: one candidate per evaluation, scored on the private split.

One responsibility, kept apart from the lifecycle that calls it. ``ace_study``
owns the order the four phases are valid in; this owns what the search itself
is declared to be, including whether it is durable.
"""

from __future__ import annotations

import meta_evolve as meta

from ace_context import PLAYBOOK_BUDGET, PLAYBOOK_TRIALS, SEED_PLAYBOOK
from ace_episodes import playbook_suite
from inner_agent import InnerAgent
from playbook_codec import encode

def search(
    proposer,
    agent: InnerAgent,
    *,
    random_seed: int,
    storage: meta.Storage | None,
) -> meta.Run:
    """The outer run: one candidate per evaluation, scored on the private split.

    The proposer is passed in rather than built here, so the run and the
    declaration the study reports come from the same object. Two ``revise``
    calls would agree -- the version is derived from the manifest, not from the
    closure's identity -- but only because of a property no reader of this
    function can see.
    """

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=playbook_suite(agent),
            artifact=meta.Text,
            objectives=(meta.Maximize("solved", satisfy=1.0),),
            budget=PLAYBOOK_BUDGET,
        ),
        seed=encode(SEED_PLAYBOOK),
        proposer=proposer,
        search=meta.Greedy(max_trials=PLAYBOOK_TRIALS),
        random_seed=random_seed,
    )
    if storage is None:
        return meta.run(experiment)
    return meta.run(experiment, storage=storage)


__all__ = ["search"]
