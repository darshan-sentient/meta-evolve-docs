"""The whole ACE lifecycle, as one function that returns what it produced.

The four phases are not independent, and until this existed only three of them
were reachable from one call. ``evolve_playbook`` returned ``(run, lessons)``
and ``main.py`` separately performed consolidation and the held-out pass with
the fixture agent -- so the script and any other caller were each assembling
the lifecycle by hand, from memory, in the right order. A caller who forgot the
consolidation re-score, or ran held-out before selection, would have got a
plausible answer.

So the order lives here, once:

1. **Development.** Roll the seed over the development split. What it got wrong
   is the only thing a proposer may learn from. If any rollout did not finish,
   the study stops: a lesson manifest built from the subset that happened to
   complete would configure the search from a truncated view and record it as
   though it were whole.
2. **Search.** One outer run over the published lessons, whose proposer
   declares them.
3. **Consolidation.** The candidate marked items retired; whether the pruned
   playbook is kept is decided by re-scoring the private split, and both
   outcomes are retained.
4. **Held out.** Once, on the accepted playbook, after selection.

``PlaybookStudy`` holds every phase's evidence rather than a summary of it,
including the cost of the phases that happen outside the run -- a reader who
looked only at ``run.usage()`` would undercount the wrapper calls by the
development pass, two consolidation re-scores, and the held-out split.
``main.py`` is presentation over this and owns no ordering of its own.
"""

from __future__ import annotations

from dataclasses import dataclass

import meta_evolve as meta
from meta_evolve.domain import ComponentRef

from ace_consolidation import Consolidation, accept_consolidation
from ace_context import SEED_PLAYBOOK
from ace_curation import revise
from ace_episodes import development_lessons, held_out_report
from ace_outcomes import SplitOutcome
from ace_rollouts import DEVELOPMENT, Lesson
from ace_search import search
from ace_sessions import run_split
from inner_agent import InnerAgent
from playbook import Playbook
from playbook_codec import decode

# Why a study has no selected playbook. Both are ordinary outcomes rather than
# errors: a development split that did not finish, and a search in which every
# candidate faulted, are both things a live wrapper will eventually do.
DEVELOPMENT_INCOMPLETE = "development-incomplete"
NOTHING_SELECTED = "nothing-selected"
ABORT_REASONS = (DEVELOPMENT_INCOMPLETE, NOTHING_SELECTED)


@dataclass(frozen=True, slots=True)
class StudyFailure:
    """One typed thing that went wrong, and which phase it happened in."""

    phase: str
    name: str
    kind: str
    detail: str


@dataclass(frozen=True, slots=True)
class PlaybookStudy:
    """Every phase of one lifecycle, and the evidence each produced."""

    development: SplitOutcome
    lessons: tuple[Lesson, ...]
    curator: ComponentRef | None
    run: meta.Run | None
    selected: Playbook | None
    consolidation: Consolidation | None
    held_out: SplitOutcome | None
    aborted: str | None

    @property
    def playbook(self) -> Playbook | None:
        """The playbook this study ended up with, after consolidation."""

        if self.consolidation is not None:
            return self.consolidation.playbook
        return self.selected

    @property
    def usage(self) -> meta.Usage:
        """Every cost the lifecycle incurred, not only the run's.

        Three of the four phases happen outside ``meta.run``, so the run's own
        usage is not the study's. Adding them is the only way a reader can
        check the total against the declared wrapper-call ceiling.
        """

        total = self.development.usage
        if self.run is not None:
            total += self.run.usage()
        if self.consolidation is not None:
            total += self.consolidation.usage
        if self.held_out is not None:
            total += self.held_out.usage
        return total

    @property
    def sessions(self) -> int:
        """Every time the wrapper factory was called, across all four phases.

        The declared ceiling is what a live run is *budgeted* for; this is what
        it actually cost. The two diverge whenever a phase stopped early, which
        is exactly when a reader reconciling a bill most needs the real number.

        The search's splits happen inside evaluations, so their counts come off
        the retained evidence rather than being inferred from the ceiling.
        """

        total = self.development.sessions
        for attempt in self.run.trials() if self.run is not None else ():
            for item in attempt.evidence:
                total += int(dict(item.data).get("sessions", 0))
        if self.consolidation is not None:
            total += self.consolidation.sessions
        if self.held_out is not None:
            total += self.held_out.sessions
        return total

    @property
    def failures(self) -> tuple[StudyFailure, ...]:
        """Every typed failure, from every phase, in phase order.

        Assembled rather than accumulated as it goes, so it cannot disagree
        with the outcomes it is derived from.

        Both consolidation re-scores are read, not only the pruned one. The
        baseline pass is a real private split against a live wrapper, and a
        decision whose ``reason`` is ``incomplete`` because the *baseline*
        faulted would otherwise report no failure at all.
        """

        found = [
            StudyFailure(DEVELOPMENT, name, fault.kind, fault.detail)
            for name, fault in sorted(self.development.unfinished.items())
        ]
        found.extend(_search_failures(self.run))
        passes: tuple[tuple[str, SplitOutcome | None], ...] = (
            (("baseline", self.consolidation.before), ("pruned", self.consolidation.after))
            if self.consolidation is not None
            else ()
        )
        for label, outcome in passes:
            for name, fault in sorted((outcome.unfinished if outcome else {}).items()):
                found.append(
                    StudyFailure(
                        "consolidation", f"{name} ({label})", fault.kind, fault.detail
                    )
                )
        held_out = self.held_out.unfinished if self.held_out else {}
        for name, fault in sorted(held_out.items()):
            found.append(StudyFailure("held-out", name, fault.kind, fault.detail))
        return tuple(found)


def _search_failures(run: meta.Run | None) -> list[StudyFailure]:
    """Faulted trials, keeping the vocabulary the evaluator recorded.

    A trial whose private rollouts produced nothing carries the per-rollout
    attribution in ``unfinished_rollouts``, while the kernel wraps the whole
    evaluation as ``evaluator_failure``. Reading only the outer kind threw that
    attribution away at exactly the point the lifecycle exists to expose it:
    ``ace_outcomes`` decides whether a fault was the wrapper's, and the study
    reported ``evaluator_failure`` for every one of them, leaving the real kind
    to survive as prose inside a message.

    So the rollouts are unpacked and each reported with the kind it was given.
    A candidate refused outright -- not a playbook, or a broken transition --
    has a singular ``kind`` and no rollouts, because no rollout ran.
    """

    found: list[StudyFailure] = []
    for index, attempt in enumerate(run.trials() if run else ()):
        if attempt.state == "evaluated" or attempt.failure is None:
            continue
        details = dict(attempt.failure.details)
        faulted = dict(details.get("unfinished_rollouts") or {})
        if not faulted:
            found.append(
                StudyFailure(
                    "search",
                    f"trial {index}",
                    str(details.get("kind", attempt.failure.kind)),
                    attempt.failure.message,
                )
            )
            continue
        for name, fault in sorted(faulted.items()):
            entry = dict(fault)
            found.append(
                StudyFailure(
                    "search",
                    f"trial {index}/{name}",
                    str(entry["kind"]),
                    str(entry["detail"]),
                )
            )
    return found


def study_playbook(
    agent: InnerAgent, *, random_seed: int = 0, storage: meta.Storage | None = None
) -> PlaybookStudy:
    """Run all four phases in order, and return everything they produced.

    The development split is rolled out first, here, before the search exists.
    What it publishes is the *only* thing the proposer can see: ``revise`` is
    built over those lessons and closes over nothing else, so a private task or
    a held-out task has no path into proposal context.

    ``storage`` makes the *search* durable, and it is worth being exact about
    what that does and does not cover. Given a store, the search phase becomes
    reconstructable: ``meta.Run(run_id, storage)`` reopens it later, in another
    process, and answers every query from the recorded events without calling
    the wrapper again. The other three phases are not persisted by this
    example. Their evidence is retained on the value returned here, in memory,
    for as long as the caller holds it -- so a claim that this lifecycle
    replays end to end from durable state would be false, and
    ``test_context_evolution_replay`` is written to say exactly which half is
    which.
    """

    development = run_split(DEVELOPMENT, SEED_PLAYBOOK, agent)
    if not development.is_complete:
        # No usable development evidence means no manifest, so there is nothing
        # to configure a proposer with. Retained rather than raised: the faults
        # are the result.
        return PlaybookStudy(
            development=development,
            lessons=(),
            curator=None,
            run=None,
            selected=None,
            consolidation=None,
            held_out=None,
            aborted=DEVELOPMENT_INCOMPLETE,
        )

    lessons = development_lessons(development)
    proposer = revise(lessons)
    run = search(proposer, agent, random_seed=random_seed, storage=storage)
    incomplete = PlaybookStudy(
        development=development,
        lessons=lessons,
        curator=proposer.component,
        run=run,
        selected=None,
        consolidation=None,
        held_out=None,
        aborted=NOTHING_SELECTED,
    )
    try:
        run.best_trial()
    except meta.NoSuccessfulEvaluation:
        return incomplete

    selected = decode(run.best().value)
    consolidation = accept_consolidation(selected, agent)
    held_out = held_out_report(consolidation.playbook, agent)
    return PlaybookStudy(
        development=development,
        lessons=lessons,
        curator=proposer.component,
        run=run,
        selected=selected,
        consolidation=consolidation,
        held_out=held_out,
        aborted=None,
    )


__all__ = [
    "ABORT_REASONS",
    "DEVELOPMENT_INCOMPLETE",
    "NOTHING_SELECTED",
    "PlaybookStudy",
    "StudyFailure",
    "study_playbook",
]
