"""The playbook proposer: reflect on published lessons, then curate.

This is the candidate side of the boundary, and it is deliberately tiny and
model-free -- the same choice ``main.py``'s ``add_skill`` makes for the SkillSet
sibling. What matters here is not cleverness but *what it can see*: a proposer
is built over the development lessons the suite chose to publish, and over
nothing else. It is handed no private score, no held-out task, no evaluator,
and no budget, so the authority boundary is a property of the closure rather
than a rule someone has to remember.

One proposal does one thing, in a fixed order:

1. **Curate** -- if any active item contradicts the published lessons, amend
   the ones that can be brought into line and retire the ones nothing supports.
2. **Generate** -- otherwise, add an item for the first lesson that has none.
3. **Stop** -- otherwise, return the parent unchanged.

Curation before generation is what makes the mechanism legible: a playbook that
already says something wrong has to be fixed before it grows, or the wrong
entry keeps being rendered while the search congratulates itself on the new
one.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, ProposerFailure
from meta_evolve.ports import ProposalResult

from ace_episodes import Lesson
from declared_identity import CURATOR_COMPONENT, curator_version
from playbook import Playbook, PlaybookItem, PlaybookRejection, check_transition
from playbook_codec import decode, encode


def aligned_with(item: PlaybookItem, lessons: Sequence[Lesson]) -> Lesson | None:
    """The lesson this item already states, if any.

    Alignment is by marker rather than by identity: an item is doing its job
    when the phrasing the agent needs is actually present in its content, not
    when it merely has the right name.
    """

    for lesson in lessons:
        if lesson.section == item.section and lesson.marker in item.content:
            return lesson
    return None


def uncovered(playbook: Playbook, lessons: Sequence[Lesson]) -> tuple[Lesson, ...]:
    """Lessons no active item states yet, in published order."""

    covered = {
        lesson.identity
        for item in playbook.active()
        if (lesson := aligned_with(item, lessons)) is not None
    }
    return tuple(lesson for lesson in lessons if lesson.identity not in covered)


def curate(playbook: Playbook, lessons: Sequence[Lesson]) -> Playbook | None:
    """Amend items a lesson can rescue; retire the ones nothing supports.

    Returns ``None`` when every active item is already aligned, which is the
    signal to generate instead. Retired items are left in place rather than
    dropped: pruning them is consolidation's job, and consolidation acceptance
    belongs to the evaluator.
    """

    pending = list(uncovered(playbook, lessons))
    revised: list[PlaybookItem] = []
    changed = False
    for item in playbook.items:
        if item.status != "active" or aligned_with(item, lessons) is not None:
            revised.append(item)
            continue
        rescue = next(
            (lesson for lesson in pending if lesson.section == item.section), None
        )
        if rescue is not None:
            pending.remove(rescue)
            revised.append(item.amended(rescue.content))
        else:
            # Nothing published supports this entry, so stop telling the agent
            # it. Retiring keeps the record readable; deleting would not.
            revised.append(item.retired())
        changed = True
    return Playbook(tuple(revised)) if changed else None


def generate(playbook: Playbook, lessons: Sequence[Lesson]) -> Playbook | None:
    """Append an item for the first lesson the playbook does not state yet."""

    pending = uncovered(playbook, lessons)
    if not pending:
        return None
    lesson = pending[0]
    item = PlaybookItem(
        identity=lesson.identity, section=lesson.section, content=lesson.content
    )
    return Playbook(playbook.items + (item,))


def enforce_transitions(
    propose_playbook: Callable[..., Playbook],
) -> Callable[..., ProposalResult]:
    """Put the lifecycle rules on the real proposal path.

    ``check_transition`` states four invariants a successor must satisfy, and
    until this existed nothing called it outside the tests -- so a candidate
    that revived a retired item or dropped one would have been scored, and the
    invalid-transition outcome the representation advertises could not occur in
    a run. A rule enforced only where it is tested is a rule about the tests.

    A refused transition is a typed proposer failure carrying the rejection
    kind, not a raised exception: the kernel would record a raise as an
    unstructured proposer failure and the *reason* -- which invariant broke,
    and for which item -- would survive only as prose in a message.

    This wraps any playbook-to-playbook function, not just this module's, so a
    misbehaving proposer can be driven through an ordinary outer run and shown
    to be refused there rather than only by a direct call to the checker.
    """

    def propose(parent: meta.Text, *, context) -> ProposalResult:
        before = decode(parent)
        successor = propose_playbook(before, context=context)
        try:
            check_transition(before, successor)
        except PlaybookRejection as rejection:
            return ProposalResult(
                failure=ProposerFailure(
                    message=f"refused transition: {rejection}",
                    details={"kind": rejection.kind, **dict(rejection.details)},
                )
            )
        return ProposalResult(candidate=encode(successor))

    return propose


def revise(lessons: Sequence[Lesson]) -> Callable[..., ProposalResult]:
    """Build a proposer that can see the published lessons and nothing else.

    The returned callable is an ordinary proposer: text in, candidate out. It
    never touches an evaluator, a split, a score, or a budget -- there is
    nothing in this closure for it to reach.

    It *declares* the lessons it was built over. Without that, the reference is
    named by module and qualname alone, so two runs over two different lesson
    manifests recorded the same proposer and the same run id while producing
    different playbooks -- and ``compare`` would have ranked them as though the
    only difference were the search. The published manifest is the whole of
    what this closure captures, so it is the whole of what the version covers.
    """

    published = tuple(lessons)

    def curate_or_generate(playbook: Playbook, *, context) -> Playbook:
        successor = curate(playbook, published) or generate(playbook, published)
        return playbook if successor is None else successor

    propose = enforce_transitions(curate_or_generate)
    propose.component = ComponentRef.configured_local(
        "proposer",
        propose,
        name=CURATOR_COMPONENT,
        version=curator_version(published),
    )
    return propose


__all__ = [
    "aligned_with",
    "curate",
    "enforce_transitions",
    "generate",
    "revise",
    "uncovered",
]
