"""The task substrate: three splits, and how one rollout runs.

This module owns *what is measured* and nothing about *what it means*. It holds
the three splits, the tasks in each, the lesson each task can license, how an
active playbook renders into instructions, and how a single rollout executes as
an ordinary inner ``meta.run``.

What a rollout or a split *produced* -- scores, faults, and the refusal to
summarize a partial split -- belongs to ``ace_outcomes``. Deciding anything --
which lessons get published, what the objective is, whether consolidation is
accepted, what the evaluator declares -- belongs to ``ace_episodes``. Keeping the two apart is what lets the substrate be tested
without an evaluator and the evaluator be reasoned about without re-reading the
task list.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, EvaluatorFailure
from meta_evolve.ports import EvaluationResult

from ace_outcomes import (
    UNVERIFIABLE,
)
from declared_identity import digest
from playbook import Playbook

DEVELOPMENT = "development"
PRIVATE = "private"
HELD_OUT = "held-out"

ROLLOUT_TIMEOUT_SECONDS = 120.0
# One inner run per rollout: the seed evaluation plus a single agent proposal.
# The same shape the SkillSet sibling uses, declared separately so neither
# sibling's bound silently moves the other's.
ROLLOUT_BUDGET = meta.Budget(
    evaluations=2, trials=1, wall_seconds=ROLLOUT_TIMEOUT_SECONDS
)

# Deliberately minimal: it says what to do and nothing about how. Any hint of a
# house convention here would hand every candidate the playbook for free and
# flatten the search.
BASE_INSTRUCTIONS = "Read README.md and do what it asks."


@dataclass(frozen=True, slots=True)
class Lesson:
    """A convention the suite is willing to state out loud.

    A lesson is published only for a *development* rollout the agent got wrong.
    It carries the identity and section a playbook item would need, so the
    proposer's job is deciding where it belongs and what it supersedes -- not
    guessing the wording.
    """

    identity: str
    section: str
    marker: str
    content: str


# What the checking rule *is*, separately from what it reads. The manifest
# below covers every input a check has; this covers the rule itself, so a
# rewritten check over unchanged inputs still moves the declared evaluator.
# Bumped when the rule stopped scoring an absent target 0.0 and started
# refusing it, and again when the rollouts became filing disclosures rather
# than a repository's version and log-level strings.
CHECK_REVISION = "3"

# The two components an inner rollout declares. Both used to be name-only, so
# a run over one task said nothing about which playbook produced it.
ROLLOUT_CHECK_COMPONENT = "context-evolution:rollout-check"
ROLLOUT_SESSION_COMPONENT = "context-evolution:rollout-session"


@dataclass(frozen=True, slots=True)
class Rollout:
    """One task, in one split, checked by an ordinary local function.

    ``answer`` is declared rather than captured. The check used to hold the
    expected value in a closure, where the declared evaluator identity could
    not reach it: two suites expecting different answers for the same file
    declared the same evaluator. What a task accepts is configuration, so it
    lives where configuration is visible.
    """

    name: str
    split: str
    target: str
    answer: str
    source: meta.SourceTree
    check: Callable[[meta.SourceTree], float]
    lesson: Lesson


INTEREST_LESSON = Lesson(
    identity="interest-element",
    section="debt",
    marker="nwi:InterestPaidNetOfCapitalized",
    content=(
        "Cash interest disclosed net of capitalized interest is tagged with the "
        "filer's extension element nwi:InterestPaidNetOfCapitalized. "
        "us-gaap:InterestPaid is the gross standard element and is not what "
        "Northwind reports on this line."
    ),
)
LEASE_LESSON = Lesson(
    identity="lease-element",
    section="leases",
    marker="nwi:OperatingLeaseCostExcludingShortTerm",
    content=(
        "Operating lease cost stated excluding short-term leases is tagged with "
        "the filer's extension element "
        "nwi:OperatingLeaseCostExcludingShortTerm. us-gaap:LeaseCost is the "
        "total including finance leases, so it overstates this line."
    ),
)

# The two answers are *extension* elements rather than standard ones, and that
# is what makes them unguessable rather than merely obscure: a filer's taxonomy
# extension exists only in that filer's own tagging manual, so no amount of
# model capability supplies it and no amount of reading the workspace recovers
# it. Both wrong answers a guided agent avoids are the defensible standard
# element a careful analyst would otherwise reach for -- sensible, and wrong.
INTEREST_ANSWER = "nwi:InterestPaidNetOfCapitalized\n"
LEASE_ANSWER = "nwi:OperatingLeaseCostExcludingShortTerm\n"

# An untagged line, which is where a tagging review actually starts.
UNTAGGED = "untagged\n"

# The same two manual entries across every split, over different disclosures.
# That is the point, and it is why the notes are worded differently rather than
# renamed: an entry earns its keep by carrying one filer's policy from the note
# it was learned on to a note nobody has read yet. Private and held-out
# rollouts that were the development ones with new filenames would prove only
# that a lookup table works.
_TASKS = (
    ("debt-note", DEVELOPMENT, "note_09_debt.tag",
     "# Note 9 -- Debt\n\nCash paid for interest, net of $6 million capitalized,\n"
     "was $214 million.\n\nTag that amount: write the XBRL element name into\n"
     "note_09_debt.tag.\n", INTEREST_LESSON),
    ("lease-note", DEVELOPMENT, "note_14_leases.tag",
     "# Note 14 -- Leases\n\nOperating lease cost, excluding short-term leases,\n"
     "was $88 million.\n\nTag that amount: write the XBRL element name into\n"
     "note_14_leases.tag.\n", LEASE_LESSON),
    ("cash-flows", PRIVATE, "note_22_cash_flows.tag",
     "# Note 22 -- Supplemental cash flow information\n\nInterest paid during the "
     "year, net of $9 million capitalized,\ntotalled $187 million.\n\nTag that "
     "amount: write the XBRL element name into\nnote_22_cash_flows.tag.\n",
     INTEREST_LESSON),
    ("commitments", PRIVATE, "note_18_commitments.tag",
     "# Note 18 -- Commitments\n\nThe operating lease charge for the period, "
     "excluding leases of\nless than twelve months, was $71 million.\n\nTag that "
     "amount: write the XBRL element name into\nnote_18_commitments.tag.\n",
     LEASE_LESSON),
    ("borrowings", HELD_OUT, "note_07_borrowings.tag",
     "# Note 7 -- Borrowings\n\nCash interest paid, net of $4 million capitalized,\n"
     "was $96 million.\n\nTag that amount: write the XBRL element name into\n"
     "note_07_borrowings.tag.\n", INTEREST_LESSON),
    ("right-of-use", HELD_OUT, "note_11_right_of_use.tag",
     "# Note 11 -- Right-of-use assets\n\nOperating lease cost for the year, "
     "excluding short-term\narrangements, was $63 million.\n\nTag that amount: "
     "write the XBRL element name into\nnote_11_right_of_use.tag.\n", LEASE_LESSON),
)


def _build(name, split, target, readme, lesson) -> Rollout:
    answer = INTEREST_ANSWER if lesson is INTEREST_LESSON else LEASE_ANSWER

    def check(tree: meta.SourceTree) -> EvaluationResult:
        # An absent target is not a wrong answer, and the refusal belongs here
        # rather than in the caller. Returning 0.0 and letting ``run_split``
        # relabel the aggregate afterwards left the *inner* run recording a
        # successful evaluation of zero -- a rankable claim about the playbook
        # drawn from a candidate there was nothing left to judge, sitting in
        # the durable record underneath an outcome that said "unverifiable".
        if target not in tree:
            return EvaluationResult(
                failure=EvaluatorFailure(
                    message=f"{target} absent from the candidate",
                    details={
                        "kind": UNVERIFIABLE,
                        "reason": f"{target} absent from the candidate",
                        "target": target,
                    },
                )
            )
        return EvaluationResult(metrics={"solved": float(tree.get(target) == answer)})

    check.component = ComponentRef.configured_local(
        "evaluator",
        check,
        name=ROLLOUT_CHECK_COMPONENT,
        version=digest(
            CHECK_REVISION,
            {"revision": CHECK_REVISION, "target": target, "answer": answer},
        ),
    )
    return Rollout(
        name=name,
        split=split,
        target=target,
        answer=answer,
        source=meta.SourceTree({"README.md": readme, target: UNTAGGED}),
        check=check,
        lesson=lesson,
    )


ROLLOUTS = tuple(_build(*task) for task in _TASKS)


def rollouts_in(split: str) -> tuple[Rollout, ...]:
    return tuple(rollout for rollout in ROLLOUTS if rollout.split == split)


def render(playbook: Playbook) -> str:
    """Fold the active items into one instruction block, in reading order.

    Retired items are not rendered: retiring an item is how the mechanism says
    "stop telling the agent this", and rendering it anyway would make
    retirement decorative.
    """

    active = playbook.active()
    if not active:
        return ""
    body = "\n\n".join(f"## {item.section}\n{item.content}" for item in active)
    return f"\n\nApply this playbook:\n\n{body}"


def instructions_for(playbook: Playbook) -> str:
    return BASE_INSTRUCTIONS + render(playbook)


__all__ = [
    "BASE_INSTRUCTIONS",
    "CHECK_REVISION",
    "DEVELOPMENT",
    "HELD_OUT",
    "INTEREST_LESSON",
    "LEASE_LESSON",
    "Lesson",
    "PRIVATE",
    "ROLLOUTS",
    "ROLLOUT_BUDGET",
    "ROLLOUT_TIMEOUT_SECONDS",
    "Rollout",
    "UNTAGGED",
    "instructions_for",
    "render",
    "rollouts_in",
]
