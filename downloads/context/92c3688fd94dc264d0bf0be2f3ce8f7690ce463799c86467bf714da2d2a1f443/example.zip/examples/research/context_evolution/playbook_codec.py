"""The playbook's text boundary: canonical bytes in, typed rejection out.

Two rules make a playbook's identity worth trusting across a run, and both
live here rather than in ``playbook``, because both are about the serialized
form rather than the value:

* **Canonical bytes.** Equal playbooks serialize to equal bytes, so equal
  artifacts get equal digests and a replayed run recomputes the same identity.
  Two documents differing only in key order are the same playbook.
* **Typed rejection.** A document that is not a playbook, repeats an identity,
  or carries a field this schema does not define is refused with a named
  outcome. None of those is a low score.

``sort_keys`` is the load-bearing argument. Without it two equal playbooks
written by different code paths would produce different digests and be treated
as different candidates -- the exact failure that makes a lineage unreadable.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

import meta_evolve as meta

from playbook import (
    ACTIVE,
    ITEM_FIELDS,
    MALFORMED,
    PLAYBOOK_FIELDS,
    SCHEMA,
    UNKNOWN_FIELD,
    Playbook,
    PlaybookItem,
    PlaybookRejection,
)

# Required on every item. ``status`` is the one field with a default, so a
# document may omit it and mean "active".
REQUIRED_ITEM_FIELDS = ITEM_FIELDS - {"status"}


def encode(playbook: Playbook) -> meta.Text:
    """Serialize to canonical bytes."""

    payload = {
        "schema": SCHEMA,
        "items": [
            {
                "id": item.identity,
                "section": item.section,
                "content": item.content,
                "status": item.status,
            }
            for item in playbook.items
        ],
    }
    return meta.Text(json.dumps(payload, sort_keys=True, separators=(",", ":")))


def decode(text: str) -> Playbook:
    """Parse a playbook, refusing anything this schema does not define.

    ``Playbook`` itself raises the duplicate-identity rejection, so a repeated
    ``id`` is refused by the same rule whether it arrives as text or is built
    in Python.
    """

    try:
        payload = json.loads(str(text))
    except json.JSONDecodeError as error:
        raise PlaybookRejection(
            MALFORMED, f"playbook is not JSON: {error}", reason=str(error)
        ) from error

    if not isinstance(payload, dict):
        raise PlaybookRejection(
            MALFORMED, "playbook must be a JSON object", found=type(payload).__name__
        )
    reject_unknown(payload, PLAYBOOK_FIELDS, "playbook")
    if payload.get("schema") != SCHEMA:
        raise PlaybookRejection(
            MALFORMED, f"playbook schema must be {SCHEMA!r}", found=payload.get("schema")
        )
    raw_items = payload.get("items")
    if not isinstance(raw_items, list):
        raise PlaybookRejection(
            MALFORMED,
            "playbook items must be a JSON array",
            found=type(raw_items).__name__,
        )
    return Playbook(tuple(decode_item(raw, index) for index, raw in enumerate(raw_items)))


def decode_item(raw: Any, index: int) -> PlaybookItem:
    """Parse one item, reporting its position so feedback is actionable."""

    if not isinstance(raw, dict):
        raise PlaybookRejection(
            MALFORMED, f"playbook item {index} must be a JSON object", position=index
        )
    reject_unknown(raw, ITEM_FIELDS, f"playbook item {index}")
    missing = sorted(REQUIRED_ITEM_FIELDS - set(raw))
    if missing:
        raise PlaybookRejection(
            MALFORMED,
            f"playbook item {index} is missing {', '.join(missing)}",
            position=index,
            missing=tuple(missing),
        )
    try:
        return PlaybookItem(
            identity=raw["id"],
            section=raw["section"],
            content=raw["content"],
            status=raw.get("status", ACTIVE),
        )
    except (TypeError, ValueError) as error:
        raise PlaybookRejection(
            MALFORMED, f"playbook item {index} is invalid: {error}", position=index
        ) from error


def reject_unknown(
    mapping: Mapping[str, object], allowed: frozenset[str], where: str
) -> None:
    """Refuse fields this schema does not define, naming every one of them."""

    unknown = sorted(set(mapping) - allowed)
    if unknown:
        raise PlaybookRejection(
            UNKNOWN_FIELD,
            f"{where} carries unknown fields: {', '.join(unknown)}",
            where=where,
            unknown=tuple(unknown),
        )


__all__ = ["decode", "decode_item", "encode", "reject_unknown"]
