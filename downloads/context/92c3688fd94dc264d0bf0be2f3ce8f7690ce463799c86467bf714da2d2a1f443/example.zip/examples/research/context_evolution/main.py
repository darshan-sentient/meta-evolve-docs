"""Evolve an agent's context two ways, scoring both with an injected proposer.

Two siblings, one command. Both evolve what an agent is *told* rather than what
it is, both keep the candidate above the inner agent, and both are scored by an
evaluator that runs ordinary inner ``meta.run`` rollouts through a proposer the
caller supplies.

* **EvoSkill-inspired** -- the candidate is a ``meta.SkillSet``, one
  ``skills/<name>.md`` document per reusable skill. The outer proposer adds a
  whole document at a time. ``skill_context`` configures it and
  ``skill_episodes`` owns its episode suite.
* **ACE-inspired** -- the candidate is a ``meta.Text`` holding a canonical JSON
  playbook of separately addressable items. The outer proposer reflects on
  published development lessons and then amends, retires, or appends single
  items. ``ace_context`` configures it, ``ace_study`` owns the four-phase
  lifecycle, and ``ace_episodes`` owns the three splits.

The split is the point: a skill set is right for prose an agent reads whole, a
playbook for entries that need citing and retiring one at a time. Neither
representation needed a new artifact type.

This file is presentation. It owns the command line and what gets printed, and
no ordering of its own -- ``study_playbook`` is one call that runs all four ACE
phases in the one order they are valid in, and ``evolve_skills`` is one call for
the other sibling. Both take one ``InnerAgent``, so a live agent crosses the
identical boundary: any model SDK wrapped in an ordinary proposer callable,
owned and configured by the caller, travelling with the declaration that says
what it is.

These are mechanism demonstrations. Neither reproduces its paper's system,
benchmarks, transfer results, or reported gains.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import meta_evolve as meta

HERE = Path(__file__).parent
if str(HERE) not in sys.path:
    # Example modules are plain siblings, not an installed package: this is
    # what lets ``python examples/research/context_evolution/main.py`` work.
    sys.path.insert(0, str(HERE))

from ace_context import (  # noqa: E402 -- needs the path entry above
    PLAYBOOK_CALL_CEILING,
    PLAYBOOK_FIXTURE_AGENT,
)
from ace_outcomes import SplitOutcome  # noqa: E402
from ace_study import PlaybookStudy, study_playbook  # noqa: E402
from skill_context import (  # noqa: E402
    FIXTURE_AGENT,
    SKILL_CALL_CEILING,
    evolve_skills,
)
from skill_suite import session_count  # noqa: E402

def report_split(outcome: SplitOutcome) -> str:
    """A split's score, or its faults when there is no score to report.

    A partial split has no rankable summary, so printing one would be inventing
    a number: one success beside one timeout is not ``1.0``. The faults go out
    instead, named.
    """

    if outcome.is_complete:
        return str(outcome.solved)
    faults = ", ".join(
        f"{name}: {fault.kind}" for name, fault in sorted(outcome.unfinished.items())
    )
    return f"unrankable ({faults or 'nothing ran'})"


def report_cost(study: PlaybookStudy) -> None:
    """Every number the study retained about what the run cost.

    Printing a subset was the defect: the result kept charged spend, wall time,
    and the outer kernel's trial count, and the report showed tokens and
    evaluations. A wrapper reporting money therefore produced a transcript that
    named none of it -- and for the one kind of run where this matters, a paid
    one, the transcript is what a reader reconciles against a bill.

    Sessions are the *actual* wrapper calls beside the declared ceiling. The
    ceiling alone answers "what could this have cost"; only the count answers
    "what did it", and they part company exactly when a phase stopped early.

    Each number is labelled with its own field name -- ``wall_seconds``, not
    "wall seconds" -- so the transcript and the result object can be compared
    literally, and the parity test can enumerate ``Usage`` rather than
    restating a list that would go stale the next time a field is added.
    """

    cost = study.usage
    print(
        f"reported cost: {cost.tokens} tokens, {cost.spend_micros} spend_micros, "
        f"{cost.wall_seconds} wall_seconds"
    )
    print(f"outer kernel: {cost.evaluations} evaluations, {cost.trials} trials")
    print(f"wrapper calls: {study.sessions} of at most {PLAYBOOK_CALL_CEILING}")


def report_failures(study: PlaybookStudy) -> None:
    """Every fault the study retained, whichever phase produced it.

    Printed for a study that finished, not only one that gave up. A study can
    select, consolidate, and hold out successfully while a rollout inside any
    of those phases faulted, and the result keeps those faults -- so printing
    them only on the way out told a reader the run was clean whenever it had a
    winner. What they saw instead was a ``-`` in the trial scores, which says
    that something happened rather than what, and for a faulted consolidation
    baseline only ``consolidated: False (incomplete)``, which does not even say
    that much.

    One block rather than a line beside each phase, so a reader has one place
    to look and cannot miss the phase they forgot existed. It is the same list
    ``PlaybookStudy.failures`` returns, in the same order, which is what makes
    the report and the callable result unable to disagree.
    """

    if not study.failures:
        return
    print(f"failures retained: {len(study.failures)}")
    for failure in study.failures:
        print(f"  {failure.phase}/{failure.name}: {failure.kind} ({failure.detail})")


def report_failure(result: meta.Run, what: str) -> None:
    """Name the fault on every trial rather than leave a reader guessing."""

    print(f"no candidate scored: every {what} failed before producing one")
    for attempt in result.trials():
        fault = attempt.failure
        if fault is not None:
            print(f"  {fault.kind}: {fault.message} {dict(fault.details)}")


def run_skills() -> None:
    """The EvoSkill-inspired sibling: a SkillSet over its episode suite."""

    result = evolve_skills(FIXTURE_AGENT)
    print("== evoskill: skill documents ==")
    try:
        trial = result.best_trial()
    except meta.NoSuccessfulEvaluation:
        report_skill_cost(result)
        report_failure(result, "episode")
        raise SystemExit(1)
    print(f"skills: {list(result.best().value)}")
    print(f"solved: {trial.metrics['solved']}")
    report_skill_cost(result)


def report_skill_cost(result: meta.Run) -> None:
    """The complete outer usage and actual EvoSkill wrapper calls."""

    cost = result.usage()
    print(
        f"reported cost: {cost.tokens} tokens, {cost.spend_micros} spend_micros, "
        f"{cost.wall_seconds} wall_seconds"
    )
    print(f"outer kernel: {cost.evaluations} evaluations, {cost.trials} trials")
    print(f"wrapper calls: {session_count(result)} of at most {SKILL_CALL_CEILING}")


def report_study(study: PlaybookStudy) -> None:
    """Print one lifecycle, in the order it happened.

    Everything here is read off the study. Nothing is recomputed, so the report
    and the callable result cannot disagree about what happened -- which they
    could when this file drove consolidation and the held-out pass itself.
    """

    print(f"development solved: {report_split(study.development)}")
    print(f"lessons published: {[lesson.identity for lesson in study.lessons]}")

    if study.aborted is not None:
        print(f"no playbook selected: {study.aborted}")
        # Cost first, then faults. A study that gave up still spent whatever it
        # spent getting there, and a reader reconciling a bill needs that on
        # the way out at least as much as on the way through.
        report_cost(study)
        report_failures(study)
        raise SystemExit(1)

    assert study.run is not None and study.selected is not None
    assert study.consolidation is not None and study.held_out is not None
    # Every trial, in order, so a reader sees the negatives and the ties the
    # search climbed through rather than only the winner.
    scores = [
        "-" if attempt.state != "evaluated" else f"{attempt.metrics['solved']}"
        for attempt in study.run.trials()
    ]
    print(f"items: {list(study.selected.identities)}")
    print(f"active: {[item.identity for item in study.selected.active()]}")
    print(f"trial scores: {scores}")
    print(f"solved: {study.run.best_trial().metrics['solved']}")
    report_cost(study)
    print(
        f"consolidated: {study.consolidation.accepted} "
        f"({study.consolidation.reason}) -> "
        f"{[item.identity for item in study.consolidation.playbook.items]}"
    )
    print(f"held-out solved: {report_split(study.held_out)}")
    report_failures(study)


def run_playbook() -> None:
    """The ACE-inspired sibling: a canonical playbook over three splits."""

    print("== ace: context playbook ==")
    report_study(study_playbook(PLAYBOOK_FIXTURE_AGENT))


SIBLINGS = {"evoskill": run_skills, "ace": run_playbook}


def main(argv: list[str] | None = None) -> None:
    # Credential-free by construction: the fixture agents are the injected
    # proposers. Swap in your own build_agent(instructions) factory to drive
    # either search with a live SDK wrapper -- README.md walks through the
    # boundary and the worst-case call count before anything costs money.
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--sibling",
        choices=sorted(SIBLINGS),
        help="run one representation instead of both",
    )
    arguments = parser.parse_args(argv)
    chosen = [arguments.sibling] if arguments.sibling else ["evoskill", "ace"]
    for index, name in enumerate(chosen):
        if index:
            print()
        SIBLINGS[name]()


if __name__ == "__main__":
    main()
