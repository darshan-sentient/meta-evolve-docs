"""A structured context playbook: what it is, and what it refuses to become.

The sibling in ``main.py`` evolves a ``meta.SkillSet`` -- one markdown document
per skill, where the filename is the identity. That shape is right for prose an
agent reads whole, and wrong for a playbook whose individual entries need to be
cited, amended, and retired one at a time.

So this module holds the other representation ACE-style context evolution
needs: an ordered list of small, separately addressable items, each carrying a
**stable logical identity that survives both content edits and reordering**.
The identity is what a later consolidation step and the causal-derivation trail
key on; an item that changes position is still the same item, and an item whose
content is amended keeps its history.

This module owns *shape* and *lifecycle*. ``playbook_codec`` owns the text
boundary. Neither owns scoring, acceptance, or budgets: those belong to the
evaluator, which is why nothing here imports anything that could rank a
candidate.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, replace

SCHEMA = "context-playbook-v1"

# Every field this schema defines. An unknown key is refused rather than
# ignored: silently dropping it would let a candidate believe it had recorded
# something the evaluator never sees.
PLAYBOOK_FIELDS = frozenset({"schema", "items"})
ITEM_FIELDS = frozenset({"id", "section", "content", "status"})

ACTIVE = "active"
RETIRED = "retired"
STATUSES = frozenset({ACTIVE, RETIRED})

# The four ways a document is refused. Each is a distinct outcome with its own
# evidence, not one generic error, because a proposer that repeats an identity
# needs different feedback from one that emits unparseable text.
MALFORMED = "playbook-malformed"
DUPLICATE_IDENTITY = "playbook-duplicate-identity"
UNKNOWN_FIELD = "playbook-unknown-field"
INVALID_TRANSITION = "playbook-invalid-transition"

REJECTION_KINDS = (MALFORMED, DUPLICATE_IDENTITY, UNKNOWN_FIELD, INVALID_TRANSITION)


class PlaybookRejection(Exception):
    """A document that is not an acceptable playbook, and why.

    This carries a ``kind`` and inspectable ``details`` and no number of any
    sort. A rejection is not a ranking: an evaluator translates one into a
    typed failure, never into a score that would let an invalid playbook
    compete with a valid one.
    """

    __slots__ = ("kind", "details")

    def __init__(self, kind: str, message: str, **details: object) -> None:
        super().__init__(message)
        self.kind = kind
        self.details: Mapping[str, object] = dict(details)


@dataclass(frozen=True, slots=True)
class PlaybookItem:
    """One separately addressable entry.

    ``identity`` is the logical name and never changes. ``section`` groups
    items for the reader and is equally fixed -- moving an item to another
    section makes it a different item, and pretending otherwise would break the
    derivation trail. ``content`` is the part an amendment edits.
    """

    identity: str
    section: str
    content: str
    status: str = ACTIVE

    def __post_init__(self) -> None:
        for name in ("identity", "section", "content", "status"):
            if not isinstance(getattr(self, name), str):
                raise TypeError(f"playbook item {name} must be a string")
        if not self.identity:
            raise ValueError("playbook item identity must not be empty")
        if self.status not in STATUSES:
            raise ValueError(f"playbook item status must be one of {sorted(STATUSES)}")

    def amended(self, content: str) -> PlaybookItem:
        """Return the same item with new content, keeping its identity."""

        return replace(self, content=content)

    def retired(self) -> PlaybookItem:
        """Return the same item marked retired, keeping its identity."""

        return replace(self, status=RETIRED)


@dataclass(frozen=True, slots=True)
class Playbook:
    """An ordered tuple of uniquely identified items.

    Order is meaningful -- it is the reading order an agent receives -- and it
    is preserved exactly through serialization. Identity is independent of it.
    """

    items: tuple[PlaybookItem, ...] = ()

    def __post_init__(self) -> None:
        seen: dict[str, int] = {}
        for index, item in enumerate(self.items):
            if not isinstance(item, PlaybookItem):
                raise TypeError("playbook items must be PlaybookItem values")
            if item.identity in seen:
                raise PlaybookRejection(
                    DUPLICATE_IDENTITY,
                    f"identity {item.identity!r} appears more than once",
                    identity=item.identity,
                    positions=(seen[item.identity], index),
                )
            seen[item.identity] = index

    def __iter__(self) -> Iterator[PlaybookItem]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)

    @property
    def identities(self) -> tuple[str, ...]:
        """Logical names in reading order."""

        return tuple(item.identity for item in self.items)

    def by_identity(self) -> Mapping[str, PlaybookItem]:
        return {item.identity: item for item in self.items}

    def active(self) -> tuple[PlaybookItem, ...]:
        return tuple(item for item in self.items if item.status == ACTIVE)


def check_transition(parent: Playbook, successor: Playbook) -> None:
    """Refuse a successor that breaks an item's lifecycle.

    Four invariants, all checkable without consulting an evaluator:

    * No item disappears. Dropping one is how a candidate would erase the
      record of something evidence argued against, which is exactly what
      retirement exists to avoid -- and pruning is not the candidate's call.
      Only an independently accepted consolidation removes items.
    * A retired item stays retired. Revival would let a candidate quietly
      resurrect an entry that evidence had already argued against.
    * A retired item's content is frozen, so the record of what was retired
      stays readable.
    * An item never changes section, because section is part of what makes it
      that item rather than a new one.

    Adding items, amending active ones, retiring active ones, and reordering
    are all ordinary and pass.
    """

    before = parent.by_identity()
    after = successor.by_identity()
    # Checked first, and over the *parent's* identities: iterating the
    # successor alone can only ever see items that are still there, so a
    # candidate that dropped an entry passed every other check by having
    # nothing left to check.
    dropped = tuple(identity for identity in parent.identities if identity not in after)
    if dropped:
        raise PlaybookRejection(
            INVALID_TRANSITION,
            f"items dropped rather than retired: {', '.join(dropped)}",
            identities=dropped,
        )
    for identity, item in after.items():
        previous = before.get(identity)
        if previous is None:
            continue
        if previous.section != item.section:
            raise PlaybookRejection(
                INVALID_TRANSITION,
                f"item {identity!r} changed section",
                identity=identity,
                was=previous.section,
                now=item.section,
            )
        if previous.status == RETIRED and item.status == ACTIVE:
            raise PlaybookRejection(
                INVALID_TRANSITION,
                f"retired item {identity!r} cannot be revived",
                identity=identity,
            )
        if previous.status == RETIRED and previous.content != item.content:
            raise PlaybookRejection(
                INVALID_TRANSITION,
                f"retired item {identity!r} cannot be edited",
                identity=identity,
            )


def consolidate(playbook: Playbook) -> Playbook:
    """Drop retired items, preserving the order and identities of the rest.

    This is a representation operation, not an acceptance decision: it says
    what a pruned playbook looks like, never whether pruning was earned. The
    evaluator decides when consolidation happens and whether the result is
    better.
    """

    return Playbook(playbook.active())


def playbook_of(items: Iterable[tuple[str, str, str]]) -> Playbook:
    """Build a playbook from ``(identity, section, content)`` triples."""

    return Playbook(tuple(PlaybookItem(*triple) for triple in items))


__all__ = [
    "ACTIVE",
    "DUPLICATE_IDENTITY",
    "INVALID_TRANSITION",
    "ITEM_FIELDS",
    "MALFORMED",
    "PLAYBOOK_FIELDS",
    "Playbook",
    "PlaybookItem",
    "PlaybookRejection",
    "REJECTION_KINDS",
    "RETIRED",
    "SCHEMA",
    "STATUSES",
    "UNKNOWN_FIELD",
    "check_transition",
    "consolidate",
    "playbook_of",
]
