"""What this run declares itself to be, and nothing about what it does.

Two components, each a name and a version, and under each a manifest naming
every module whose text can change what the component produces. ``command.py``
holds the order things happen in; this holds the claims that order is made
under, because they are separately true and separately tested -- the manifests
are what a durable replay verifies, and they have to be readable without the
command's control flow around them.

Dependency hashing is deliberately not transitive. Every module named here is
named because something in it decides an outcome, and every omission has been a
defect: ``confinement.py`` and ``landlock.py`` were reached through
``handoff.py`` and unnamed; the two shipped adapters underneath both halves were
unnamed after that; and ``_posix_process.py`` -- the module those adapters run
every process through -- was unnamed after *that*, because "the two adapters" had
become the phrase this file described itself with. A test now derives the answer
instead: every sibling module a declared adapter imports has to be declared too.
"""

from __future__ import annotations

# ``_posix_process`` is private and ``adapters/__init__.py`` does not export it.
# Reaching past the public surface is deliberate and it is the manifest that
# forces it: dependency hashing is not transitive, so the only way this example
# can bind the code that decides what a timeout and an exit status mean is to
# name the module that holds it. A public re-export would be the tidier fix and
# is the kernel's call, not an example's; until then, an example declaring less
# than it runs on is the worse of the two.
import meta_evolve as meta
from meta_evolve.adapters import _posix_process as process_module
from meta_evolve.adapters import development_subprocess as sandbox_module
from meta_evolve.adapters import directory_workspaces as workspaces_module
from meta_evolve.domain import ComponentRef

from . import bounds as bounds_module
from . import confinement as confinement_module
from . import execution as execution_module
from . import handoff as handoff_module
from . import identity as identity_module
from . import landlock as landlock_module
from . import outcomes as outcomes_module
from . import plan as plan_module
from . import propose as propose_module
from . import proposals as proposals_module
from . import reports as reports_module
from . import schedulers as schedulers_module
from . import simulator as simulator_module
from . import surface as surface_module
from . import verifier as verifier_module
from . import workloads as workloads_module
from .execution import evaluate_development
from .identity import configuration_version, evaluator_configuration
from .proposals import PLAN, ProposerSpec, propose_scheduler, proposer_configuration


# Version 2 because the proposer's declared configuration moved: the decision is
# now made in a kernel-confined process, and a ``ComponentRef`` that stayed at 1
# would let two runs that proposed under different authority claim one identity.
FIXTURE_PROPOSER = ProposerSpec(
    name="systems-optimization:scheduler-plan",
    version="2",
    propose=propose_scheduler,
    max_trials=len(PLAN),
    # Every module whose source or globals the proposal path executes. Dependency
    # hashing is deliberately *not* transitive -- the kernel will not guess an
    # import graph -- so a module reached through another has to be named here or
    # its edits do not move the proposer's manifest. ``confinement.py`` and
    # ``landlock.py`` were missing, which meant the boundary the proposal is made
    # behind could change under a fixed proposer identity; ``bounds.py`` supplies
    # the timeout and flags it applies and ``surface.py`` the file name it writes,
    # so both are part of the implementation on the same argument.
    #
    # ``workloads.py`` is emphatically absent, and a test asserts it: the proposal
    # path never touches it, which is the whole point of the boundary.
    #
    # The last three are the shipped adapters this proposal is actually built on:
    # ``handoff.py`` materializes the confined workspace through one and runs the
    # proposer through another, and that one runs every process through the third.
    # They were in no manifest, so workspace or subprocess semantics could change
    # between an interrupt and a durable resume with the proposer's identity
    # unmoved -- the same omission as ``confinement`` and ``landlock``, one layer
    # out.
    dependencies=(
        bounds_module,
        confinement_module,
        handoff_module,
        landlock_module,
        plan_module,
        propose_module,
        proposals_module,
        schedulers_module,
        surface_module,
        sandbox_module,
        workspaces_module,
        process_module,
    ),
    configuration=proposer_configuration(),
)

# Every module whose text decides what a number means. Declared to the registry
# so the evaluator's manifest covers its whole implementation, not only the file
# the registered function happens to live in -- see ``identity.py`` for the
# other half of the same idea, which puts a digest of these in the version.
#
# The three adapters end the list because they are the only entries that half
# cannot reach: ``identity.EVALUATOR_SOURCES`` digests files in *this* directory,
# and these live in the kernel's package, so the manifest is the whole of their
# declaration. ``execution.py`` runs every scenario through the first two, and
# ``_posix_process.py`` is what the sandbox spawns, waits on, and kills through --
# the code that decides what a timeout and an exit status mean.
EVALUATOR_NAME = "systems-optimization:development-scenarios"

EVALUATOR_MODULES = (
    confinement_module,
    execution_module,
    identity_module,
    landlock_module,
    outcomes_module,
    reports_module,
    simulator_module,
    surface_module,
    verifier_module,
    workloads_module,
    sandbox_module,
    workspaces_module,
    process_module,
)


def build_registry() -> tuple[meta.Registry, ComponentRef, ComponentRef]:
    """Declare both components, so two differently configured runs cannot rank.

    The evaluator's version is a digest over everything it was configured with
    *and* over the source of every module that decides what a number means.
    Change the simulator's arithmetic, the verifier's classification, the
    protocol, the failure map, a workload, a process bound, or the confinement
    policy, and ``Run.compare`` refuses the comparison instead of quietly
    picking a winner across a moved goalpost.

    One proposer, and it is the committed fixture. Accepting any ``ProposerSpec``
    here, or offering a second live-only mode for proposers that cannot promise
    reproducibility, would make the API itself authority to reach later facts: a
    supplied proposer is ordinary Python in *this* process, which has imported
    both later splits.

    Removing it was necessary and not sufficient. The fixture that remains no
    longer runs here either -- ``proposals.py`` hands its
    context to a kernel-confined process that cannot open the committed copy of
    the later splits. That is the file route; #195's "held-out facts cannot reach
    proposal context" is established by sequencing, by a payload closed to
    development records, and by this proposer being the only one. The proposer's
    own declaration carries the confinement policy, so a run made without it
    could not claim this one's identity.
    """

    registry = meta.Registry()
    proposer_ref = registry.register_proposer(
        FIXTURE_PROPOSER.name,
        FIXTURE_PROPOSER.version,
        FIXTURE_PROPOSER.propose,
        deterministic=FIXTURE_PROPOSER.deterministic,
        retry_safe=FIXTURE_PROPOSER.retry_safe,
        dependencies=FIXTURE_PROPOSER.dependencies,
        configuration=dict(FIXTURE_PROPOSER.configuration),
    )
    evaluator_ref = registry.register_evaluator(
        EVALUATOR_NAME,
        configuration_version("development"),
        evaluate_development,
        deterministic=True,
        retry_safe=True,
        dependencies=EVALUATOR_MODULES,
        configuration=evaluator_configuration("development"),
    )
    return registry, proposer_ref, evaluator_ref


__all__ = [
    "EVALUATOR_MODULES",
    "EVALUATOR_NAME",
    "FIXTURE_PROPOSER",
    "build_registry",
]
