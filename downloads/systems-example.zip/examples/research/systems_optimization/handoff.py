"""What crosses the proposer's boundary, in both directions, and what is checked.

``plan.py`` decides what to propose and ``propose.py`` runs it in a process
``confinement.py`` has kept away from this repository. This module is the
crossing itself: it serializes the context in, runs the confined process under
the same declared bounds the evaluator's scenario runs use, and validates the
payload that comes back before ``proposals.py`` turns it into a
``meta.ProposalResult``.

Three properties are worth stating plainly, because they are what make the
boundary mean something rather than look like one.

* **Nothing is filtered on the way in.** Every record the run's context policy
  authorized is serialized, unread. *Which* observation to propose from is
  ``plan.observation``'s decision, made on the far side -- so the choice happens
  inside the confinement rather than being handed in pre-made.
* **The way out is one JSON object on stdout.** Anything else -- a crash, a
  timeout, noise -- becomes a refusal, and a refusal becomes a typed proposer
  failure. A confined process that could not answer must not be answered *for*.
* **The two halves are cross-checked, numbers and types included.** The confined
  side states which parent it edited, which observation it read, and the three
  numbers it read off it; every one is re-derived here against the payload that
  actually crossed, and every field has to arrive as the JSON type it claims. This
  is not a defence against a hostile payload -- the far side is proposer-owned code
  -- it is the check that a wrong parent, a record never given, a metric matching
  nothing, or a value that only survives coercion ends as a refusal instead of
  evidence nobody can trust.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: this
is one crossing, and both directions of it have to be read together. What is
serialized in decides what the far side may cite, and ``rejection`` compares the
two halves of that same exchange -- a wrong parent, a record never given, a
metric matching nothing. Splitting the way in from the way out would put each
half of every one of those comparisons in a different file, and the whole reason
this module exists is that they are checked against each other rather than
re-derived into agreement. Most of the length is the reasoning behind the type
checks, which is the part that is easy to get wrong and hard to see wrong.
"""

from __future__ import annotations

import json
import logging
import math
import sys
from pathlib import Path

import meta_evolve as meta
from meta_evolve.adapters import DirectoryWorkspaces
from meta_evolve.adapters.development_subprocess import DevelopmentSubprocessSandbox
from meta_evolve.domain import (
    Evaluation,
    Failure,
    InfrastructureFailure,
    SourceTree,
    Usage,
)
from meta_evolve.ports import ProcessResult

from . import confinement
from .bounds import INTERPRETER_FLAGS, OUTPUT_LIMIT, PROCESS_TIMEOUT_SECONDS
from .plan import FIXTURE_DECLARATION, PLAN_BY_NAME, digest_of
from .propose import CONTEXT_FILE
from .surface import SURFACE


HERE = Path(__file__).parent
PROPOSE_FILE = "_propose.py"

# workspace path -> the proposer-owned module copied into it. Underscored so
# nothing here can collide with the declared surface, exactly as
# ``execution.INJECTED`` does for the evaluator's side of the run.
INJECTED = {
    PROPOSE_FILE: "propose.py",
    "_plan.py": "plan.py",
    "_schedulers.py": "schedulers.py",
}
HARNESS = SourceTree(
    {
        path: (HERE / name).read_text(encoding="utf-8")
        for path, name in INJECTED.items()
    }
)

# Everything a proposal payload has to carry, grouped by the JSON type it has to
# arrive as. Coercion is not validation: ``int(0.9)`` is ``0``, ``int(False)`` is
# ``0``, ``float("0.5")`` is ``0.5``, and a check written as ``int(...)`` accepts
# all three. The *original* value is what the evidence retains, so a proposal
# quoting the string ``"0.5"`` would be accepted on its coerced value and durably
# recorded as a string.
TEXT = ("declaration", "exhibits", "hypothesis", "parent_digest", "plan_step")
COUNTS = ("observed_step", "observed_sequence", "parent_bytes")
NUMBERS = ("observed_quality", "observed_imbalance", "observed_work")
REQUIRED = (*TEXT, *COUNTS, *NUMBERS, "files")


def _counted(value: object) -> bool:
    """A JSON integer. ``bool`` is an ``int`` in Python and is not one here."""

    return isinstance(value, int) and not isinstance(value, bool)


def _measured(value: object) -> bool:
    """A finite JSON number, asked in an order that cannot itself fail.

    Integers are finite by construction and treated that way: an arbitrarily large
    one is a legal ``int`` that ``math.isfinite`` cannot convert, so asking raised
    ``OverflowError`` past this function's own caller -- the one thing a validator
    must never do. Only floats need the check, and they need it, because
    ``Infinity`` and ``NaN`` both survive ``json.loads``. A huge integer is still
    refused one check further down, for quoting a number no record reported."""

    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    return isinstance(value, float) and math.isfinite(value)


def _mistyped(proposed: dict) -> str | None:
    """The first field that did not arrive as the type it has to be."""

    for group, wanted, accepts in (
        (TEXT, "text", lambda value: isinstance(value, str)),
        (COUNTS, "a whole number", _counted),
        (NUMBERS, "a finite number", _measured),
    ):
        for key in group:
            if not accepts(proposed[key]):
                sent = f"{proposed[key]!r:.40}"
                return f"the confined proposal sends {key} as {sent}, not {wanted}"
    return None


def _metrics_of(record: object) -> dict[str, float]:
    """The metrics one context record carries, decided by its *kind*.

    Asking the object -- ``getattr(record.value, "metrics", {})`` -- cannot tell
    "this record has no metrics" from "reading its metrics raised": ``getattr``
    with a default swallows *any* ``AttributeError`` raised while evaluating the
    attribute, including one from a genuine bug inside a property, and hands back
    the default as though the attribute were simply absent. A sentinel default
    only avoids ``hasattr``'s other problem of running the property twice. So the
    shape of the object is not probed at all.

    ``record.kind`` is what decides, which is the same field ``plan.observation``
    branches on at the other end of this crossing. Only an ``"evaluation"``
    record is expected to carry metrics -- and the label claiming so is not
    enough on its own, so the value is type-checked against the domain type an
    evaluation record actually holds.

    Past that check nothing else is validated, deliberately.
    ``Evaluation.__post_init__`` has already made ``metrics`` a ``FrozenMap``
    whose every value is numeric and finite, so a shape check here would be
    unreachable code asserting something the kernel guarantees -- and
    unreachable guards are what this review campaign is mostly about. If
    ``Evaluation`` ever stops making that guarantee, the ``float()`` below
    raises, which is the right way for a broken invariant to arrive: loudly,
    naming its own type, rather than absorbed into an empty mapping.
    """

    if record.kind != "evaluation":
        return {}
    if not isinstance(record.value, Evaluation):
        raise ValueError(
            f"an evaluation record's value is {type(record.value).__name__}, not "
            "an evaluation; the crossing would serialize metrics it cannot read"
        )
    return {str(name): float(value) for name, value in record.value.metrics.items()}


def context_payload(parent: SourceTree, context: meta.ProposerContext) -> dict:
    """Everything that crosses into the confined process, and nothing else.

    A record of any other kind serializes with no metrics, so a future context
    policy pushing a different kind of experience here cannot break the boundary
    by breaking the serializer. What it can no longer do is push an *evaluation*
    record that is not one and have that pass unnoticed: ``_metrics_of`` raises
    ``ValueError``, and ``proposals.propose_scheduler`` -- which runs this on the
    harness side, before the confined process is launched -- turns it into the
    one typed failure that module promises.
    """

    return {
        "declaration": FIXTURE_DECLARATION,
        "step": context.step,
        "surface": SURFACE[0],
        "parent": parent[SURFACE[0]],
        "objectives": [objective.metric for objective in context.objectives],
        "records": [
            {
                "kind": record.kind,
                "logical_step": record.logical_step,
                "event_sequence": record.event_sequence,
                "metrics": _metrics_of(record),
            }
            for record in context.bundle.records
        ],
    }


def proposal_spec(workspace: Path) -> meta.ProcessSpec:
    """The one process request a proposal makes, bounds and all.

    The same three bounds the evaluator's ``scenario_spec`` applies, and declared
    the same way in ``proposals.proposer_configuration``: a bound applied but not
    declared makes a proposal truncated at a different ceiling into a different
    proposal that claims to be the same one. A function rather than an inline
    value so a test can read what was applied.
    """

    return meta.ProcessSpec(
        argv=(
            *confinement.launcher(workspace),
            sys.executable,
            *INTERPRETER_FLAGS,
            PROPOSE_FILE,
        ),
        environment={},
        timeout_seconds=PROCESS_TIMEOUT_SECONDS,
        stdout_limit=OUTPUT_LIMIT,
        stderr_limit=OUTPUT_LIMIT,
    )


def _dispose(workspaces: DirectoryWorkspaces, workspace: object) -> OSError | None:
    """Give the proposer's workspace back; report the failure, do not judge it.

    Called from one ``finally``, exactly once, whatever the run did. The error is
    returned rather than absorbed: ``confined_proposal`` turns it into a typed
    ``InfrastructureFailure`` and commits nothing from that process, because
    cleanup precedes commitment -- a boundary that could not complete its own
    lifecycle has not established the conditions the reply was produced under.
    It is logged as well, since a leaked directory on a machine where every
    workspace and the durable store live under one temporary tree should be
    findable by whoever notices the disk first.

    **Not shared with the evaluator's copy, and that is a decision.** Sharing
    would mean ``handoff.py`` importing ``execution.py``, which puts the
    evaluator in the proposer's declared dependencies and moves the proposer's
    identity whenever the evaluator's scoring changes. That separation is worth
    more than the duplication costs. What keeps the two from drifting is a test
    that drives both and requires the same observable outcome -- one disposal
    attempt, no commitment, the usage kept -- which is the protection the shared
    function would have bought.
    """

    try:
        workspaces.dispose(workspace)
    except OSError as error:
        logging.getLogger(__name__).warning(
            "could not dispose of proposer workspace %s: %s", workspace.root, error
        )
        return error
    return None



def _cleanup_failure(
    completed: ProcessResult, error: OSError
) -> InfrastructureFailure:
    """The disposal failure, carrying whatever the run had already decided.

    Overriding an outcome is not the same as forgetting it. A proposal that
    timed out *and* left a directory behind is two facts, and the one somebody
    debugging the proposer needs is the first. So the prior classification
    travels in the details, with its message and its own details when there was
    one -- the same fields, under the same names, that
    ``CommandEvaluator._cleanup_failure`` retains, because two sides of one
    boundary describing one situation differently is how a reader comes to
    trust whichever they happened to read.
    """

    prior = completed.failure
    details: dict[str, object] = {
        "stage": "cleanup",
        "exception_type": type(error).__name__,
        "exit_code": completed.exit_code,
        "prior_classification": "completed" if prior is None else prior.kind,
    }
    if prior is not None:
        details["prior_failure_message"] = prior.message
        details["prior_failure_details"] = dict(prior.details)
    return InfrastructureFailure(
        message=f"could not dispose of proposer workspace: {error}",
        details=details,
    )


def confined_proposal(
    payload: dict,
    *,
    workspaces: DirectoryWorkspaces | None = None,
    sandbox: DevelopmentSubprocessSandbox | None = None,
) -> tuple[dict, Usage, Failure | None]:
    """Run one proposal in a confined process and hand back what it said.

    The providers are arguments for the same reason ``execution.run_scenario``
    takes them: a test needs to drive a broken boundary without breaking a
    machine.
    """

    workspaces = workspaces or DirectoryWorkspaces()
    sandbox = sandbox or DevelopmentSubprocessSandbox()
    try:
        workspace = workspaces.materialize(
            SourceTree({**HARNESS, CONTEXT_FILE: json.dumps(payload, sort_keys=True)})
        )
    except OSError as error:
        return {}, Usage(), InfrastructureFailure(message=str(error))
    try:
        completed = sandbox.run(proposal_spec(workspace.root), workspace)
    finally:
        undisposed = _dispose(workspaces, workspace)
    if undisposed is not None:
        # Cleanup precedes commitment, the same rule ``execution.run_scenario``
        # follows and for the same reason: a boundary that could not complete
        # its own lifecycle has not established the conditions the reply was
        # produced under, so no successor may be committed from it.
        return {}, completed.usage, _cleanup_failure(completed, undisposed)
    if completed.failure is not None:
        return {}, completed.usage, completed.failure
    if completed.exit_code != 0:
        last = (completed.stderr.strip().splitlines() or ["no output on stderr"])[-1]
        # Bounded here, so the exit code survives. This sentence goes through
        # ``_refusal_text``, which replaces anything over ``REFUSAL_LIMIT`` with
        # a fixed message whole -- correct for a refusal the *proposer* wrote,
        # since quietly cutting somebody else's words is how a record comes to
        # say something they did not. But this sentence is composed here, and
        # the half worth keeping is the one this module put in it: a process
        # that died with a five-kilobyte traceback on stderr would otherwise
        # report no exit code at all.
        room = REFUSAL_LIMIT - len(_EXITED.format(code=completed.exit_code, tail=""))
        tail = last if len(last) <= room else f"{last[: room - 1]}…"
        return {
            "refusal": _EXITED.format(code=completed.exit_code, tail=tail)
        }, completed.usage, None
    # Exactly one line, not the last of several. Reading only the last line let
    # arbitrary output through in front of a valid payload, which the contract
    # above says is a refusal -- and a proposer printing anything else is a
    # proposer doing something this example did not ask it to do.
    lines = completed.stdout.splitlines()
    if len(lines) != 1:
        return {
            "refusal": (
                f"the confined proposer wrote {len(lines)} lines on stdout, not one"
            )
        }, completed.usage, None
    # ``RecursionError`` beside ``ValueError``: ``json`` gives up on nesting at a
    # depth belonging to the interpreter, not to this protocol, and a confined
    # process can write ten thousand open brackets in one line well under the
    # declared stdout ceiling. Uncaught it escaped ``propose_scheduler``
    # entirely, past the ``completed.usage`` this line is the last place holding
    # -- so the measured cost of a process that really ran was lost with it. The
    # subprocess bounds the reply's size and its wall clock; they do not bound
    # what the host decoder will do with it.
    try:
        proposed = json.loads(lines[0])
    except (ValueError, RecursionError):
        return {"refusal": "the confined proposer wrote no proposal on stdout"}, completed.usage, None
    if not isinstance(proposed, dict):
        return {"refusal": "the confined proposer wrote something that is not one"}, completed.usage, None
    return proposed, completed.usage, None


# How long a refusal from the confined side may be before this module stops
# repeating it. Generous, because a real refusal explains itself; bounded,
# because whatever it says ends up in a ``ProposerFailure`` message and then in
# the record, and the confined process may write up to the declared stdout
# ceiling.
REFUSAL_LIMIT = 2_000

# The one thing said instead when the refusal itself is unusable. Fixed text
# rather than anything derived from the payload, and written to satisfy
# ``ProposerFailure``'s own rules -- non-empty, no outer whitespace -- so
# constructing the failure downstream cannot fail for this reason.
UNUSABLE_REFUSAL = "the confined proposer returned an unusable refusal"
# The sentence a non-zero exit becomes, with room reserved for the code. Written
# as one template so the length calculation and the message cannot disagree.
_EXITED = "the confined proposer exited {code}: {tail}"


def _refusal_text(refusal: object) -> str:
    """One refusal, normalized, or a fixed sentence saying it was not usable.

    ``str(refusal)`` would be the same mistake the rest of this module exists to
    avoid: coercion is not validation. An ``int``, a ``list``, or a ``dict`` sent
    where a sentence belonged would each become plausible-looking text and travel
    into a durable record as though the proposer had explained itself. A wrong
    type is not a message; it is evidence the payload is not the shape this
    crossing accepts, and the record should say that rather than quote a rendered
    Python repr.

    Type first, then whitespace, then length -- in that order, because stripping
    a non-string raises and truncating an oversized one would put the first two
    thousand characters of untrusted text in the record while implying the rest
    said nothing. An oversized refusal falls back to the fixed sentence whole.
    Only these three concerns are handled; there is deliberately no broad
    ``except`` here, since anything else going wrong is a bug rather than a
    payload this function should absorb.
    """

    if isinstance(refusal, str):
        text = refusal.strip()
        if text and len(text) <= REFUSAL_LIMIT:
            return text
    return UNUSABLE_REFUSAL


# The three numbers a proposal quotes from the record it cites, against the names
# they carry in the serialized context. Quoted rather than derived, so each one
# has to be checked against what actually crossed.
QUOTED = (
    ("observed_quality", "quality"),
    ("observed_imbalance", "imbalance"),
    ("observed_work", "work"),
)


def rejection(proposed: dict, parent: SourceTree, crossing: dict) -> str | None:
    """Why this payload cannot be recorded as a proposal, or ``None``.

    ``crossing`` is the payload that went *in*, so every check below compares the
    two halves of one exchange rather than the far side against a fresh reading of
    the context. Verifying only that the cited step exists is not enough: all
    three quoted numbers could then be ``999.0`` and still become durable
    ``proposal-basis`` evidence, which is exactly the causal evidence #195 asks
    for, fabricated.
    """

    refusal = proposed.get("refusal")
    if refusal is not None:
        return _refusal_text(refusal)
    missing = sorted(key for key in REQUIRED if key not in proposed)
    if missing:
        return f"the confined proposal is missing {missing}"
    mistyped = _mistyped(proposed)
    if mistyped is not None:
        return mistyped
    if proposed["declaration"] != FIXTURE_DECLARATION:
        return f"the confined proposal declares {proposed['declaration']!r}"
    if proposed["plan_step"] not in PLAN_BY_NAME:
        return f"the confined proposal names no plan step: {proposed['plan_step']!r}"
    files = proposed["files"]
    if not isinstance(files, dict) or not all(
        isinstance(name, str) and isinstance(text, str) for name, text in files.items()
    ):
        return "the confined proposal wrote something that is not source text"
    if SURFACE[0] not in files:
        return f"the confined proposal wrote nothing to {SURFACE[0]}"
    # A proposal writing *outside* the surface is deliberately not refused here.
    # ``surface.check_surface`` is the authority on what is on the surface, and
    # ``execution.run_scenario`` asks it before materializing anything, so such a
    # candidate is refused either way. What differs is which refusal reaches the
    # record: from here a ``ProposerFailure``, from there a named ``off-surface``
    # outcome typed as a policy violation -- the one a reader can act on, and the
    # one the committed plan's off-surface step exists to exhibit. Checking it
    # here as well makes that outcome unreachable.
    if not proposed["hypothesis"] or proposed["hypothesis"].strip() != proposed["hypothesis"]:
        return "the confined proposal hypothesis must be non-empty without outer whitespace"
    source = parent[SURFACE[0]]
    if proposed["parent_digest"] != digest_of(source):
        return "the confined proposal edited a parent this run did not hand it"
    if proposed["parent_bytes"] != len(source.encode("utf-8")):
        return "the confined proposal misreports the parent it edited"
    # Read, not coerced: ``_mistyped`` has already refused anything that is not
    # the type it claims to be, so nothing here normalizes a value on its way into
    # evidence that will outlive this process.
    step = proposed["observed_step"]
    observed_sequence = proposed["observed_sequence"]
    served = {
        (record["logical_step"], record["event_sequence"]): record["metrics"]
        for record in crossing["records"]
        if record.get("kind") == "evaluation"
    }
    occurrence = (step, observed_sequence)
    if occurrence not in served:
        return "the confined proposal cites an observation it was not given"
    for key, metric in QUOTED:
        quoted = proposed[key]
        if metric not in served[occurrence] or quoted != served[occurrence][metric]:
            # Truncated, because the quoted value is the proposer's text and a
            # legal JSON integer can be as long as the declared stdout ceiling
            # allows. A refusal that repeated all of it would put it in the record.
            return (
                f"the confined proposal quotes {metric}={quoted!r:.40} for step "
                f"{step}/{observed_sequence}, which reported {served[occurrence].get(metric)}"
            )
    return None


__all__ = [
    "COUNTS",
    "HARNESS",
    "INJECTED",
    "NUMBERS",
    "PROPOSE_FILE",
    "QUOTED",
    "REFUSAL_LIMIT",
    "REQUIRED",
    "TEXT",
    "UNUSABLE_REFUSAL",
    "confined_proposal",
    "context_payload",
    "proposal_spec",
    "rejection",
]
