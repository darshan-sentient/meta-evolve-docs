"""The selection rule, declared once, consumed by both the ranking and the record.

The evaluator's identity is ``identity.py``'s business: it moves when anything
that decides what a *number* means moves. But the selected winner is not chosen by
a number alone. Two candidates can tie on quality, and then the tie-break decides
-- and a tie-break is a judgement, not a measurement.

Leaving that judgement in two places -- the ordering in ``Attempt.key``, the
words describing it in ``record.py`` -- lets the implementation be edited into a
different winner while every declared identity in the record stays exactly the
same, and a reader comparing two historical records has nothing to explain the
change with. A rule that can move a winner needs a version.

So the rule is executable data here. ``ranking_key`` interprets the declaration
retained by each record, ``TIE_BREAK`` renders the current rule in words, and
``selection_version`` folds both with the implementation sources. It is
*retained* rather than replaced by today's declaration, so an older record still
derives the winner chosen under its historical ordering.

What the version cannot do is make the rule right. It makes a change in the rule
visible, which is all a declaration ever does.

**The fold is over canonical bytes, and that is not a detail.** A version is a
function of the basis beside it, so a reader holding a record can recompute it
and find out whether the two agree -- which is what turns the declaration from a
label into a claim. Folding ``repr(sorted(basis.items()))`` would not survive
that: a ``repr`` is a shape of
Python objects rather than a shape the record stores, and JSON sorts the keys of
each ranking term on the way out, so the retained declaration reproduces a
*different* ``repr`` and therefore a different version. Recomputation being
impossible is how restating the policy name in a written record comes to move
nothing a reader can check. ``canonical`` is the serialization the
record is written in, so folding it means the value on disk folds to the value on
disk. ``invariants.py`` makes the comparison.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: two
thirds of it is the comment above ``SELECTION_SOURCES``, which records why each
module is in that tuple and -- more importantly -- where the line stops, so the
next reader can check the partition rather than re-derive it. That reasoning belongs beside the tuple it justifies; moving
it would leave a bare list of nine filenames, which is exactly the shape that
let ``record_io.py`` be split out of ``record.py`` without the declaration
following it across.
"""

from __future__ import annotations

from collections.abc import Mapping
from hashlib import sha256
from pathlib import Path
from typing import Protocol

from .record_io import canonical, retained_mapping, retained_sequence


HERE = Path(__file__).parent

SELECTION_POLICY = "published-selection-quality-then-work-then-step"

# Which fold produced a version, so a record can say so. The scheme moved from
# ``1+`` when the basis stopped being folded as a ``repr`` and started being
# folded as the bytes the record is written in; a ``1+`` version was computed by
# a formula that is no longer here, and re-deriving it under this one would
# refuse every record written before the change. So the prefix is what
# ``invariants.py`` asks before it recomputes anything, and a version claiming
# any other scheme is retained and left alone -- the same bargain
# ``RECORD_VERSION`` makes, one level down.
VERSION_SCHEME = "2+"

# The same rule as ``ranking_key``, in words, so a reader of the record can
# reconstruct why a tie went the way it did without reading this module.
TIE_BREAK = (
    "higher selection quality",
    "lower scheduling work",
    "earlier logical step",
)

# Executable data, not prose beside an unrelated implementation. A historical
# record retains this tuple and the reader applies that retained rule even after
# the repository's current rule changes.
RANKING = (
    {"field": "quality", "direction": "descending"},
    {"field": "work", "direction": "ascending"},
    {"field": "logical_step", "direction": "ascending"},
)

# Every module whose text can change which candidate is selected -- and, since
# ``invariants.py`` joined them, every module that decides which selections a
# record may present as one. A refusal that stops being made is a winner that
# can be forged, so weakening one belongs in this version for the same reason
# reordering the ranking does.
#
# ``record_io.py`` is here because the tamper evidence has to be inside the
# thing it makes evidence of. It holds ``canonical``, ``digest_of`` and the
# "exactly one record" refusal in ``locate`` -- weaken any of them and a forged
# selection reads back clean while every declared version stays byte-identical.
# It was split out of ``record.py``, which was already listed, and a split the
# declaration does not follow across is how this tuple goes stale.
#
# ``audit.py`` and ``development.py`` are here for the same reason, one step
# further out. ``audit.replay`` is the
# cross-check that carries the store's authority into the record -- the one
# refusal in this example that comes from outside it -- so weakening
# ``_attempts_agree`` or ``_best_agrees`` is a refusal that stops being made.
# ``development.py`` is worse than that: ``attempt_from_trial`` builds the
# record's development section in ``command.py`` *and* the expected values
# ``audit._attempts_agree`` compares that section against, so an edit moves both
# sides of the comparison at once and the cross-check cannot see it. That is
# exactly the shape ``record_io.py`` was listed for.
#
# ``observations.py`` is here because ``record.read_retained`` rebuilds that
# section through it, so weakening ``Observations.from_payload`` is a refusal
# that stops being made. Its old reason for being absent was wrong: the digest
# is over module *source*, so it cannot make two fixed-seed commands disagree.
#
# **Where the line stops, so the next reader can check it rather than derive
# it.** Declared here is what decides the winner, what a record may claim, or
# what may refuse a record. Absent, deliberately: ``command.py`` and
# ``declarations.py`` assemble the run, but everything they assemble is refused
# by ``invariants.py`` at construction and cross-checked by ``audit.py`` against
# a store they did not write, and both of those are listed; ``main.py`` chooses
# what runs; ``reporting.py`` prints, and a reader who distrusts its exit code
# can re-run the replay over the directory itself. The partition is pinned over
# the directory in ``test_systems_optimization_declarations.py``.
#
# Not the evaluator's sources -- those are ``identity.EVALUATOR_SOURCES``, and
# the two declarations are deliberately separate: one says what a measurement
# is, this one says what was done with the measurements.
SELECTION_SOURCES = (
    "audit.py",
    "decision.py",
    "development.py",
    "invariants.py",
    "observations.py",
    "policy.py",
    "record.py",
    "record_io.py",
    "selection.py",
)


class Ranked(Protocol):
    """What ``ranking_key`` needs. ``decision.Attempt`` is the one that has it."""

    @property
    def quality(self) -> float: ...

    @property
    def work(self) -> float: ...

    @property
    def logical_step(self) -> int: ...


# The metric keys ``ranking_key`` reads below. ``decision.Attempt`` refuses to
# construct without them, and it asks here rather than restating the set, so a
# ranking term over a new field cannot outlive the refusal that guarantees it.
RANKED_FIELDS = frozenset({"quality", "work"})


def ranking_key(
    attempt: Ranked, *, declaration: Mapping[str, object] | None = None
) -> tuple[float, ...]:
    """Apply the rule retained with this decision, not today's global rule.

    The interpreter is intentionally small. Unknown fields or directions are a
    record error rather than an invitation to guess what a historical policy
    meant -- and neither is an *empty* declaration. ``is None`` rather than
    truthiness because a record retaining ``{}`` is a record that declared
    nothing, and falling back to today's global for it would make the retained
    rule track the current one: exactly the drift this module exists to stop.
    An empty declaration falls through to the refusal at the bottom instead.
    """

    retained = {"ranking": RANKING} if declaration is None else declaration
    values = {
        "quality": float(attempt.quality),
        "work": float(attempt.work),
        "logical_step": float(attempt.logical_step),
    }
    key = []
    # Through the same two doors every other retained container is read through.
    # A ``ranking`` that is a number answered ``'int' object is not iterable``
    # and one holding numbers answered ``'int' object has no attribute 'get'`` --
    # both from inside this loop, both naming a Python type rather than the field
    # of the record that is wrong. The record is untrusted input here by
    # construction: this function exists to apply a rule *a stored decision
    # retained*, which is the one place a historical file decides what runs.
    for term in retained_sequence(retained.get("ranking", ()), "selection ranking"):
        rule = retained_mapping(term, "selection ranking term")
        field = str(rule.get("field", ""))
        direction = str(rule.get("direction", ""))
        if field not in values:
            raise ValueError(f"unknown selection field: {field!r}")
        if direction not in {"ascending", "descending"}:
            raise ValueError(f"unknown selection direction: {direction!r}")
        value = values[field]
        key.append(-value if direction == "descending" else value)
    if not key:
        raise ValueError("selection policy has no ranking terms")
    return tuple(key)


def selection_digest(*, root: Path | None = None) -> str:
    """One digest over the source of every module that implements the rule.

    ``root`` is a parameter for the same reason ``identity.evaluator_digest``
    has one: a test can point it at a copy of the example with the ordering
    edited and watch the declared version move, which is the only way to show
    the declaration is doing work.
    """

    directory = root or HERE
    payload = sha256()
    for name in SELECTION_SOURCES:
        payload.update(name.encode("utf-8"))
        payload.update(b"\0")
        payload.update((directory / name).read_bytes())
        payload.update(b"\0")
    return payload.hexdigest()[:16]


def _basis(root: Path | None) -> dict[str, object]:
    """The rule itself: the name, the words, and the source that implements it."""

    return {
        "policy": SELECTION_POLICY,
        "tie_break": list(TIE_BREAK),
        "ranking": [dict(item) for item in RANKING],
        "sources": selection_digest(root=root),
    }


def restated_version(declaration: Mapping[str, object]) -> str:
    """The version a declaration implies, folded from its own retained basis.

    The read counterpart of ``selection_version`` below, and the same
    computation: both fold the four fields that are the rule, and the version is
    excluded because it is the answer rather than part of the question. One
    implementation with two callers, for the reason ``invariants.counted`` is one
    -- a rule written twice is a rule that agrees until it does not, and here the
    two copies would be the writer and the reader of the same file.
    """

    basis = {key: value for key, value in declaration.items() if key != "version"}
    return VERSION_SCHEME + sha256(canonical(basis).encode("utf-8")).hexdigest()[:16]


def selection_version(*, root: Path | None = None) -> str:
    """A version that moves whenever the rule or its implementation moves."""

    return restated_version(_basis(root))


def check_declaration(declaration: Mapping[str, object]) -> None:
    """Refuse a retained rule whose version is not the version of that rule.

    Here and not in ``invariants.py`` because this is a claim *within* one field
    while that module owns the claims *between* sections, and because a fold and
    its recomputation are one subject.

    Without it the policy name in a written record can be restated, both digests
    resealed and the file renamed, and ten replay checks still come back true --
    likewise for the tie-break prose and the source digest. The labels a reader
    explains a historical winner with would be decoration. This makes them a
    claim, in the shape of the ``winner`` rule in ``record.py``: stored *and*
    re-derived, refused when the two disagree.

    Bounded deliberately. Only a declaration claiming ``VERSION_SCHEME`` is
    recomputed, because the formula behind any other scheme is not in this
    repository, and refusing a historical record over a version this code cannot
    compute would destroy the evidence a retained rule exists to preserve. A
    version that is not a string claims no scheme either. So a forger may still
    restate the declaration consistently or under a scheme nothing here
    implements; ``record.py`` lists that with the other gaps.
    """

    version = declaration.get("version")
    if not isinstance(version, str) or not version.startswith(VERSION_SCHEME):
        return
    implied = restated_version(declaration)
    if version != implied:
        raise ValueError(
            f"the retained selection policy declares version {version!r}, but the "
            f"rule beside it folds to {implied!r}; a version that is not the "
            "version of the rule it travels with explains nothing"
        )


def declaration(*, root: Path | None = None) -> dict[str, object]:
    """Exactly what the record retains about the rule that chose the winner.

    The version *and* the rule it was computed from, together. A version alone
    would tell a reader that two records were selected differently without
    telling them how, which is the half of the story that is actually useful
    when a historical winner needs explaining.
    """

    return {**_basis(root), "version": selection_version(root=root)}


__all__ = [
    "RANKED_FIELDS",
    "SELECTION_POLICY",
    "SELECTION_SOURCES",
    "RANKING",
    "TIE_BREAK",
    "VERSION_SCHEME",
    "check_declaration",
    "declaration",
    "ranking_key",
    "restated_version",
    "selection_digest",
    "selection_version",
]
