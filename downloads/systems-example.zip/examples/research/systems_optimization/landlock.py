"""Restrict this process to an allow-list of paths, then become the real command.

The Linux half of ``confinement.py``: check the platform and ABI, create a
ruleset, add a rule per allowed path, set no-new-privileges, restrict this
process, close the descriptors, and ``execv`` the real command.

**How it is run.** ``confinement.launcher`` prefixes the real argv with
``python -I -B <this file> <readable> <writable>``. This process starts
unconfined, applies the ruleset to itself, then becomes what it was asked to
run. Landlock is inherited across ``exec`` and cannot be undone, which is what
makes a prefix sufficient: the process that ends up holding candidate code never
had the authority to give up. ``-B`` costs nothing here -- CPython does not cache
a ``__main__`` script -- but a sibling import added to this file later would be
cached, and that write would land in this example's own directory *before* the
restriction that would have prevented it.

**Standard library only, on purpose.** Nothing here imports ``meta_evolve`` or
its own package. It is executed as a loose script, so a relative import would
not resolve; and it runs before the restriction is applied, so whatever it loads
runs with full authority. The less of that, the better.

**Nothing happens on import.** Every syscall is inside a function and the entry
point is guarded, so importing this module -- which ``confinement.py`` does, to
ask the kernel its ABI without writing the query twice -- restricts nothing.

**Failure is fatal, never degraded.** Every refusal below returns a message that
``main`` turns into a non-zero exit before ``execv``, because a process that ran
the command without the ruleset is indistinguishable, from the outside, from one
that was confined.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: the
executable part is about seventy lines of ``ctypes``, and the rest is why each
number is that number -- which ABI a right arrives in, why execute is absent, why
a rule for a file may not name a directory right. Splitting it would put the
constants in one file and the syscall that means nothing without them in
another, and would break the property the paragraphs above rest on: a single
loose script, run by path before any restriction is applied, importing nothing
but the standard library.
"""

from __future__ import annotations

import ctypes
import os
import sys


# The three syscalls, by number: ``landlock_create_ruleset``,
# ``landlock_add_rule``, ``landlock_restrict_self``. Numbers rather than names
# because there is no libc wrapper for any of them.
CREATE_RULESET, ADD_RULE, RESTRICT_SELF = 444, 445, 446
RULE_PATH_BENEATH = 1
PR_SET_NO_NEW_PRIVS = 38

# Filesystem access rights. ``READ_FILE`` alone leaves a workload file openable
# for writing, and ``READ_DIR`` is what makes Linux match macOS, whose
# ``file-read-data`` denial also refuses directory enumeration. ``WRITE`` is bits
# 1 and 4 through 12: write, both removes, and the seven make-a-node rights.
# Execute remains deliberately absent so the confined interpreter can start.
WRITE_FILE = 1 << 1
READ_FILE = 1 << 2
READ_DIR = 1 << 3
WRITE = WRITE_FILE | (((1 << 9) - 1) << 4)
REFER = 1 << 13
TRUNCATE = 1 << 14
IOCTL_DEV = 1 << 15

# The rights a *file* can hold. Landlock refuses a rule that names a
# directory-only right on something that is not a directory, so a rule for
# ``/dev/null`` -- the one file outside its workspace a confined process writes --
# has to be the handled set narrowed to these. Granting the directory ``/dev``
# instead was the alternative, and it hands over ``/dev/shm``: a mode-1777 tmpfs,
# which is the shared writable directory this boundary exists to not have.
FILE_RIGHTS = WRITE_FILE | READ_FILE | TRUNCATE

# The ABI this boundary needs before it will call a Linux kernel one.
# ``LANDLOCK_ACCESS_FS_TRUNCATE`` arrives in ABI 3, and without it ``truncate(2)``
# is not governed at all: a candidate on ABI 1 or 2 could not open
# ``workloads.py`` for writing, but could still empty it.
#
# It lives here rather than in ``confinement.py`` because this is the module that
# has to hold the line: a selector that refuses ABI 1 and 2 does nothing for a
# ``restrict`` run by path, which must guard itself. ``confinement`` imports it,
# so the floor the selector applies and the floor the enforcer applies are one.
MINIMUM_LANDLOCK_ABI = 3

_QUERY = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32]
_ADD = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
_RESTRICT = [ctypes.c_int, ctypes.c_uint32]


class _Ruleset(ctypes.Structure):
    _fields_ = [("handled_access_fs", ctypes.c_uint64)]


class _Beneath(ctypes.Structure):
    _pack_ = 1
    _fields_ = [("allowed_access", ctypes.c_uint64), ("parent_fd", ctypes.c_int32)]


def libc() -> ctypes.CDLL:
    """The C library, with both symbols this boundary calls typed and resolved.

    ``prctl`` is looked up here rather than at its call site, so a C library
    missing either symbol fails in one place and both callers have one thing to
    guard. ``ctypes`` reports a missing symbol through ``CDLL.__getattr__``, which
    raises ``AttributeError`` -- not ``OSError`` -- which is why the guards around
    this call name both.

    That makes this function Linux-only rather than portable: ``prctl`` is a Linux
    call, so on macOS the lookup fails here. That is the honest shape for a helper
    in this module, and it costs nothing -- ``restrict`` and
    ``confinement.landlock_abi`` are the only callers and both check the platform
    before asking. It also gives the failure a real machine instead of a stub.
    """

    handle = ctypes.CDLL(None, use_errno=True)
    handle.syscall.restype = ctypes.c_long
    handle.prctl.restype = ctypes.c_int
    return handle


def _call(handle: ctypes.CDLL, number: int, *arguments: object, types: list) -> tuple:
    handle.syscall.argtypes = [ctypes.c_long, *types]
    return handle.syscall(number, *arguments), ctypes.get_errno()


def abi(handle: ctypes.CDLL) -> tuple[int, int]:
    """The kernel's Landlock ABI version and errno. Negative means no Landlock.

    ``confinement.landlock_abi`` asks through here rather than repeating the
    query, so the number that decides whether this machine is supported and the
    number that decides which rights to handle come from one implementation.
    """

    return _call(
        handle,
        CREATE_RULESET,
        None,
        ctypes.c_size_t(0),
        ctypes.c_uint32(1),
        types=_QUERY,
    )


def handled_for(version: int) -> int:
    """Every right the ruleset takes charge of, for the ABI actually reported.

    Naming a right the running kernel does not know makes
    ``landlock_create_ruleset`` fail outright rather than degrade, so this is
    computed from the reported version instead of assumed. ``REFER`` -- rename and
    link across directories -- arrives in ABI 2, and ``TRUNCATE`` in ABI 3. A right
    that is *handled* and never granted is denied everywhere, which is the point:
    the allow-list below grants writes on the workspace and scratch only.
    """

    handled = READ_FILE | READ_DIR | WRITE
    if version >= 2:
        handled |= REFER
    if version >= 3:
        handled |= TRUNCATE
    if version >= 5:
        handled |= IOCTL_DEV
    return handled


def rules_for(
    readable: list[str], writable: list[str], handled: int
) -> list[tuple[str, int]]:
    """The exact rights granted to each allow-listed path.

    Readable paths may open files and enumerate directories but never mutate
    them. Writable paths receive every right the ruleset handles. A path that is
    not a directory receives only the subset a file can hold, because naming a
    directory-only right on a file makes ``landlock_add_rule`` fail -- and a rule
    that fails to be added is confinement that is not applied.

    ``os.path.isdir`` is the only thing here that touches the filesystem, and it
    is a question about the path rather than about Landlock -- so this stays
    testable on any platform by handing it a real directory and a real file.
    """

    def granted(rights: int, path: str) -> int:
        return rights if os.path.isdir(path) else rights & FILE_RIGHTS

    rules = [(path, granted(READ_FILE | READ_DIR, path)) for path in readable]
    rules.extend((path, granted(handled, path)) for path in writable)
    return rules


def restrict(readable: list[str], writable: list[str]) -> str | None:
    """Apply the ruleset to this process, or say why it could not.

    A message rather than an exception, because the caller's job is to exit with
    it: failing to confine has to be loud and fatal, never a warning that leaves
    a process running with authority the record says it did not have.
    """

    # A real guard, not a formality. Landlock is Linux-only, syscall numbers are
    # not portable, and 444 means something else elsewhere -- so a module anyone can
    # now run by path must refuse before it issues one. ``confinement.mechanism``
    # only ever selects this on Linux; this is the check that does not rely on it.
    if sys.platform != "linux":
        return f"landlock is a Linux facility; this is {sys.platform!r}"
    # A message here too, for the same reason the platform guard returns one: a
    # C library with no ``syscall`` symbol has to leave here as the refusal this
    # docstring promises rather than as a traceback. ``confinement.landlock_abi``
    # catches the same pair around the same call, so the selector and the
    # enforcer fail identically.
    try:
        handle = libc()
    except (AttributeError, OSError) as unusable:
        return f"landlock is unavailable: this libc cannot be called ({unusable})"
    version, errno = abi(handle)
    if version < 1:
        return f"landlock is unavailable: ABI query returned {version} errno {errno}"
    if version < MINIMUM_LANDLOCK_ABI:
        return (
            f"landlock ABI {version} is below the {MINIMUM_LANDLOCK_ABI} this "
            "boundary requires: without TRUNCATE a file can still be emptied"
        )
    handled = handled_for(version)
    attribute = _Ruleset(handled_access_fs=handled)
    ruleset, errno = _call(
        handle,
        CREATE_RULESET,
        ctypes.byref(attribute),
        ctypes.c_size_t(ctypes.sizeof(attribute)),
        ctypes.c_uint32(0),
        types=_QUERY,
    )
    if ruleset < 0:
        return f"landlock_create_ruleset failed with errno {errno}"
    try:
        for path, rights in rules_for(readable, writable, handled):
            if not path:
                continue
            try:
                os.stat(path)
            except FileNotFoundError:
                continue
            except OSError as error:
                return f"cannot inspect Landlock path {path}: {error}"
            try:
                parent = os.open(path, os.O_PATH | os.O_CLOEXEC)
            except OSError as error:
                return f"cannot open Landlock path {path}: {error}"
            try:
                rule = _Beneath(allowed_access=rights, parent_fd=parent)
                added, errno = _call(
                    handle,
                    ADD_RULE,
                    ctypes.c_int(ruleset),
                    ctypes.c_int(RULE_PATH_BENEATH),
                    ctypes.byref(rule),
                    ctypes.c_uint32(0),
                    types=_ADD,
                )
            finally:
                os.close(parent)
            if added:
                return f"landlock_add_rule({path}) failed with errno {errno}"
        # Without this, ``landlock_restrict_self`` refuses for an unprivileged caller.
        if handle.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0):
            return f"prctl(PR_SET_NO_NEW_PRIVS) failed with errno {ctypes.get_errno()}"
        applied, errno = _call(
            handle, RESTRICT_SELF, ctypes.c_int(ruleset), ctypes.c_uint32(0),
            types=_RESTRICT,
        )
        if applied:
            return f"landlock_restrict_self failed with errno {errno}"
        return None
    finally:
        os.close(ruleset)


def main(argv: list[str]) -> int:
    """``<readable> <writable> <argv...>``: restrict this process, then become argv.

    The two lists arrive ``os.pathsep``-joined, which is why
    ``confinement.launcher`` refuses a path containing the separator: it would
    arrive here as two that do not exist, and ``restrict`` skips what is absent.

    That refusal belongs to the sender, and this module is one anyone can run by
    path -- so the shape is checked again on arrival, and every declared path has
    to be absolute. It is deliberately the weaker of the two checks: a separator
    *between* two absolute paths is a correct join, and no receiver can tell that
    from one path holding a separator. What it does catch is the ordinary case,
    where splitting a path leaves a relative tail that ``restrict`` would skip as
    merely absent. With this, the three things this module refuses on its own --
    the platform, the ABI, and the argument shape -- are all checked here rather
    than trusted from the caller.
    """

    if len(argv) < 3:
        sys.exit(f"usage: {sys.argv[0]} <readable> <writable> <argv...>")
    readable, writable = argv[0].split(os.pathsep), argv[1].split(os.pathsep)
    relative = [path for path in (*readable, *writable) if not os.path.isabs(path)]
    if relative:
        sys.exit(
            f"every path to declare has to be absolute, and {relative} is not: "
            f"a path holding {os.pathsep!r} arrives here as two that do not exist"
        )
    failure = restrict(readable, writable)
    if failure is not None:
        sys.exit(failure)
    os.execv(argv[2], argv[2:])
    return 1  # pragma: no cover - ``execv`` replaced this process, or raised


if __name__ == "__main__":  # pragma: no cover - exercised as a subprocess
    raise SystemExit(main(sys.argv[1:]))


__all__ = [
    "ADD_RULE", "CREATE_RULESET", "FILE_RIGHTS", "IOCTL_DEV", "MINIMUM_LANDLOCK_ABI",
    "READ_DIR", "READ_FILE", "REFER", "RESTRICT_SELF", "TRUNCATE", "WRITE",
    "WRITE_FILE", "abi", "handled_for", "libc", "main", "restrict", "rules_for",
]
