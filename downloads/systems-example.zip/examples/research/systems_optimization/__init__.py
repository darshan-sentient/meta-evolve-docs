"""Evolve one load-balancing scheduler against a fixed simulator and published suites.

A real package rather than a directory of sibling scripts, and that is a
correctness property rather than tidiness. Example modules imported by bare name
share one ``sys.modules`` namespace with every other example in the repository,
so a second ``evaluation.py`` or ``experiment.py`` anywhere under ``examples/``
silently wins or loses depending on import order. Everything here imports its
neighbours relatively and is reachable only as
``examples.research.systems_optimization.<module>``.

``main.py`` is the one entry point and is deliberately thin: it puts the
repository root on ``sys.path`` -- so ``python
examples/research/systems_optimization/main.py`` works from a checkout with
nothing installed -- and then calls into ``command.py``, which holds the driver.

Described as what it is rather than as what it becomes. The slice below this one
has no ``command.py`` beside it and ``main.py`` holds the whole driver, so the
sentence above is true only here; it moves down with the code rather than
describing a tree this file has not shipped in.
"""
