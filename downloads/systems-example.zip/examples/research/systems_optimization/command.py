"""What one command runs, in what order, and what it leaves behind.

The mechanism, in the order it happens:

1. **Search on public feedback.** The candidate is a ``meta.SourceTree`` holding
   one file, ``scheduler.py``. Each candidate is executed once per development
   scenario, in its own workspace, through the shipped bounded subprocess
   sandbox -- and inside that, in a process split from the one that measures it.
   The resulting per-scenario numbers are pushed to the proposer as ordinary
   context: it proposes from what it can see and cites the record.
2. **Select on published later workloads.** Every candidate the fixture search
   scored is re-scored after ``meta.run`` returns. Every outcome is retained,
   including the ones that produced no metric.
3. **Compare on the published final suite.** The baseline and the selected
   candidate are scored exactly once each, after selection. If
   either is unrankable there is no number and no verdict.
4. **Write the record, then read it back from the directory alone.** One
   content-addressed file holds every attempt, both content identities, the
   executable retained selection policy, timing observations, counts, and the
   verdict. Replay is handed nothing but the output directory:
   it reads the durable store the kernel wrote and the record this command
   wrote, verifies the record against its own digest, and reports where the two
   independently-written things agree -- without running a simulator, a
   subprocess, or this example's evaluator.

Promotion is external. This script reports a verdict and exports nothing.

What the two components *claim* to be -- their names, versions and the
manifests a durable replay verifies -- is in ``declarations.py``, and is
re-exported here because that is the name every caller already used.
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path
from tempfile import mkdtemp

import meta_evolve as meta
from meta_evolve.domain import SourceTree

from . import record as record_module
from .audit import replay
from .bounds import budget_for, ceiling_for, require_splits
from .declarations import (
    EVALUATOR_MODULES,
    EVALUATOR_NAME,
    FIXTURE_PROPOSER,
    build_registry,
)
from .development import development_attempts, development_timings
from .identity import configuration_version
from .record import Decision, Outcome
from .reporting import finish
from .selection import account, compare, observations, select
from .simulator import Scenario
from .surface import BASELINE
from .workloads import HELD_OUT, PRIVATE


def search(
    root: Path,
    *,
    random_seed: int = 0,
    seed: SourceTree = BASELINE,
) -> meta.Run:
    """Run the committed fixture's development-only search, and nothing else.

    One path, deterministic, recorded in ``durable-local`` mode: every component
    is registered and manifest-verified, and a replay can re-derive the search
    from the store. The kernel would refuse this mode for a component that did
    not declare itself deterministic and retry-safe, which is the guarantee
    ``audit.replay`` rests on.

    **No supplied proposer, and the fixture is confined too.** There is no
    ``ProposerSpec`` parameter here and no live-only mode beside it for proposers
    that cannot promise reproducibility: a supplied proposer would be ordinary
    Python in this process, which has imported both later splits. Removing the
    parameter closes the API and not the authority, so the fixture's own decision
    happens in a confined process as well: see ``handoff.py``,
    which serializes the development context across and validates what comes
    back. ``README.md`` says the same.
    """

    registry, proposer_ref, evaluator_ref = build_registry()
    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=evaluator_ref,
            artifact=meta.SourceTree,
            # One declared objective over two measured components. ``quality``
            # is the aggregate the search ranks on; ``imbalance`` and ``work``
            # are reported beside it because a reader needs to see which half a
            # candidate bought its score with, not because the search weighs
            # them separately.
            objectives=(meta.Maximize("quality"),),
            budget=budget_for(FIXTURE_PROPOSER.max_trials),
        ),
        seed=seed,
        proposer=proposer_ref,
        search=meta.Greedy(max_trials=FIXTURE_PROPOSER.max_trials),
        # Public development feedback is the fixture's only declared context
        # channel. Arbitrary Python authority is explicitly out of scope.
        context=meta.AncestorsOnly(max_records=30),
        random_seed=random_seed,
        registry=registry,
    )
    return meta.run(
        experiment,
        storage=meta.Storage.durable(root / "search"),
        mode="durable-local",
    )


def run_example(
    root: Path,
    *,
    random_seed: int = 0,
    private: tuple[Scenario, ...] = PRIVATE,
    held_out: tuple[Scenario, ...] = HELD_OUT,
) -> Outcome:
    """Search, select, compare once, record, and replay -- in that order, always.

    Durable and fixture-only, and confined on both sides. A run launches exactly
    two processes through ``confinement.py``: the proposer, from
    ``handoff.confined_proposal``, and the evaluator, from
    ``execution.run_scenario``. Each is restricted to its own workspace and can
    neither read nor write this repository. The process that holds candidate code
    is a third, ``agent.py``, which ``verifier.py`` spawns *inside* the
    evaluator's confinement -- it inherits that restriction rather than being
    launched under its own.

    **This function's own process is not confined, and is the one that reads the
    questions.** The later *questions* are committed literals in ``workloads.py``
    -- that is what makes the example checkable by a reader -- and this driver
    imports them, because somebody has to. What the boundary says is that neither
    confined process can open that file. What crosses to the evaluator is one
    scenario, serialized into its workspace; what reaches the candidate is
    narrower still, a worker count at the handshake and one task size at a time.

    Which is the file route and not every route. The literals are public and
    egress is confined on neither platform, so "nothing inside a run can reach
    them" would claim more than the four mechanisms make good on.
    ``workloads.py`` and the README both name the socket as the route this
    boundary does not cover, and this sentence has to agree with them.
    """

    require_splits(private, held_out)
    result = search(root, random_seed=random_seed)
    development = development_attempts(result)
    development_clock = development_timings(result)
    selection, winner = select(result, split=private)
    # No winner is a terminal outcome this command records rather than an
    # exception it lets escape. Held-out budget is deliberately not spent: there
    # is nothing to compare a baseline against, and inventing a candidate to
    # measure would be the one thing a held-out split exists to prevent. What is
    # written is every private attempt, its typed failure and its clock -- work
    # that happened after ``meta.run`` and that the durable store therefore does
    # not hold a copy of.
    comparison = None if winner is None else compare(selection, winner, split=held_out)
    decision = Decision(
        search_run=str(result.id),
        random_seed=random_seed,
        proposer=FIXTURE_PROPOSER.label,
        development_evaluator=configuration_version("development"),
        selection_policy=dict(selection.policy_declaration),
        development=development,
        selection=selection,
        comparison=comparison,
        accounting=account(
            development, selection, comparison,
            ceiling=ceiling_for(private, held_out),
        ),
    )
    observed = observations(result, development_clock, selection, comparison)
    path, decision_digest, record_digest = record_module.write(decision, observed, root)
    # ``replay`` is handed the directory and nothing else, which is what makes
    # its checks mean something to a reader who was not here. The one comparison
    # against the live decision is made here instead, because this is the only
    # place that legitimately holds both halves.
    reconstructed, agreed = replay(root)
    return Outcome(
        search=result,
        decision=decision,
        observations=observed,
        record=path,
        decision_digest=decision_digest,
        record_digest=record_digest,
        replayed={**agreed, "live decision matches": reconstructed == decision},
    )


def main(argv: list[str] | None = None) -> int:
    description = (__doc__ or "Run the systems optimization example.").splitlines()[0]
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--output",
        type=Path,
        help="keep the durable store and the decision record here",
    )
    arguments = parser.parse_args(argv)
    if arguments.output is not None:
        arguments.output.mkdir(parents=True, exist_ok=True)
        if any(arguments.output.iterdir()):
            parser.error(f"output directory is not empty: {arguments.output}")
        return finish(run_example(arguments.output))
    return _in_a_temporary_directory()


def _in_a_temporary_directory() -> int:
    """Run once in a directory nobody asked to keep, and always give it back.

    Three rules, and each pair of them pulls against the third.

    **The directory is always removed.** In a ``finally``, so a run that raised
    litters no more than one that returned.

    **A cleanup fault never discards a determined outcome.** ``TemporaryDirectory``
    as a context manager raises from ``cleanup``, which would turn a completed
    run -- searched, recorded, replayed -- into a traceback about housekeeping.
    So the status decision is made after the removal, not by it.

    **And a cleanup fault is never silent.** ``_remove`` reports the directory it
    could not delete rather than handing the error back, because on the
    exceptional path there is no caller left to report it: the original exception
    is what propagates, and masking it with a housekeeping complaint is the same
    mistake one layer out. What the fault costs on the *successful* path is a
    zero exit, litter being the only thing left to report.
    """

    temporary = Path(mkdtemp(prefix="systems-optimization-"))
    unremoved: OSError | None = None
    try:
        status = finish(run_example(temporary))
    finally:
        unremoved = _remove(temporary)
    if unremoved is not None:
        # A real failure keeps its own status; a clean run that littered becomes
        # one, because the litter is the only thing left to report.
        return status or 1
    return status


def _remove(directory: Path) -> OSError | None:
    """Delete the directory, or say on stderr which one is still there.

    Never raises, and that is the whole reason it is a function. It runs in a
    ``finally`` that may be unwinding an exception from the run itself, so
    anything raised here would *replace* that exception -- and a report about a
    temporary directory is not a better thing to hand a caller than the reason
    the run failed. Only ``OSError`` is absorbed, which is what ``rmtree``
    raises; anything else is a bug in this function and should be loud, even at
    that price.
    """

    try:
        shutil.rmtree(directory)
    except OSError as error:
        print(f"could not remove the workspace {directory}: {error}", file=sys.stderr)
        return error
    return None


__all__ = [
    "EVALUATOR_MODULES",
    "EVALUATOR_NAME",
    "FIXTURE_PROPOSER",
    "build_registry",
    "main",
    "run_example",
    "search",
]
