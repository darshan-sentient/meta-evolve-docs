"""Reading one verifier report, and refusing to believe an inconsistent one.

The report is built by ``verifier.py``, and the candidate never writes it. The
candidate runs in ``agent.py``, which is the verifier's own child inside the
same confinement rather than a process beyond its reach -- what separates them
is ``protocol``, not an operating-system boundary. The verifier sends a worker
count at the handshake and one task size at a time; the only thing the child
can say back is *which worker*. It holds no simulator state, and its stderr is
discarded rather than inherited, so there is no channel on which it could put a
number into the report. The numbers are the evaluator's own measurements rather
than a claim the candidate made about itself. This module re-checks them anyway.

That is not redundancy for its own sake. The process split is an argument, and
arguments can be wrong: a future edit to the verifier, a partially written line,
a truncated stream, or a scenario handed to the wrong workspace would each
produce a well-formed report that does not describe what was asked for. Every
invariant that can be re-derived from the scenario alone is re-derived here --
identity, cluster shape, conservation of total work, task count, probe ceiling
-- and a report that fails one is refused rather than scored.

A refusal here is ``report-rejected``, typed as an *evaluator* failure. Blaming
the candidate for a measurement the evaluator cannot stand behind is how a
broken harness turns into a finding.
"""

from __future__ import annotations

import json

from meta_evolve.ports import ProcessResult

from .outcomes import ScenarioReport, quality, sandbox_outcome
from .protocol import DETAIL_LIMIT, PROTOCOL_VERSION, detail_of
from .simulator import SIMULATOR_VERSION, Scenario, Trace


# Exactly the outcomes ``verifier.py`` is entitled to name. Anything else on
# that stream is the harness misbehaving, not the candidate.
VERIFIER_OUTCOMES = frozenset(
    {
        "completed",
        "malformed-source",
        "construction-failed",
        "execution-failed",
        "invalid-schedule",
        "constraint-violated",
        "protocol-violated",
        "abandoned",
        "timed-out",
        "verifier-failed",
    }
)


def _identity_mismatch(report: dict[str, object], scenario: Scenario) -> str | None:
    """Refuse a report that does not describe what this evaluator asked for."""

    for key, expected in (
        ("protocol", PROTOCOL_VERSION),
        ("simulator", SIMULATOR_VERSION),
        ("scenario", scenario.name),
        ("scenario_digest", scenario.digest),
        ("workers", scenario.workers),
    ):
        if report.get(key) != expected:
            return f"report {key} is {report.get(key)!r}, expected {expected!r}"
    return None


def _measurement_mismatch(report: dict[str, object], scenario: Scenario) -> str | None:
    """Re-derive every invariant a completed report has to satisfy."""

    loads = report.get("loads")
    if not isinstance(loads, list) or len(loads) != scenario.workers:
        return f"loads must be a list of {scenario.workers} entries"
    if any(isinstance(load, bool) or not isinstance(load, int) for load in loads):
        return "loads must be integers"
    if any(load < 0 for load in loads):
        return "loads must not be negative"
    tasks, probes, total = (report.get(key) for key in ("tasks", "probes", "total"))
    if tasks != len(scenario.sizes):
        return f"tasks is {tasks!r}, expected {len(scenario.sizes)}"
    if isinstance(probes, bool) or not isinstance(probes, int) or probes < 0:
        return f"probes must be a non-negative integer, not {probes!r}"
    ceiling = scenario.probe_budget * len(scenario.sizes)
    if probes > ceiling:
        return f"probes is {probes}, above the per-scenario ceiling of {ceiling}"
    # Conservation: a scheduler moves work between workers and cannot create or
    # destroy any. This is the invariant a forged report is least likely to hold.
    if sum(loads) != sum(scenario.sizes):
        return f"placed work sums to {sum(loads)}, expected {sum(scenario.sizes)}"
    if total != sum(loads):
        return f"reported total is {total!r}, expected {sum(loads)}"
    placements = report.get("placements")
    if not isinstance(placements, list) or len(placements) != len(scenario.sizes):
        return f"placements must be a list of {len(scenario.sizes)} entries"
    if any(
        isinstance(worker, bool)
        or not isinstance(worker, int)
        or not 0 <= worker < scenario.workers
        for worker in placements
    ):
        return "placements must name workers"
    reconstructed = [0] * scenario.workers
    for size, worker in zip(scenario.sizes, placements, strict=True):
        reconstructed[worker] += size
    if loads != reconstructed:
        return "loads do not arise from the scenario tasks and reported placements"
    return None


#: What ``_last_report`` returns when the final line of stdout is not JSON at
#: all. Distinct from ``None``, which a well-formed report can legitimately
#: parse to, and from a parsed non-object, which is a third answer again.
UNPARSEABLE = object()


def _last_report(stdout: str) -> object:
    """Parse the final line of stdout once, or say it could not be parsed.

    One parse for both readers below, so the rule cannot hold on one path and
    not the other. ``RecursionError`` counts as unparseable for the reason it
    does in ``protocol.decode``: this module's promise is that a malformed
    report is refused rather than raised out of.
    """

    try:
        return json.loads(stdout.splitlines()[-1])
    except (IndexError, ValueError, RecursionError):
        return UNPARSEABLE


def _reported_detail(stdout: str) -> str | None:
    """The free text of a report the verifier wrote before exiting non-zero.

    There is exactly one such report: ``verifier.py`` prints
    ``{"outcome": "verifier-failed", "detail": repr(error)}`` on **stdout** and
    returns 3 when the scenario file cannot be read at all. Its stderr is empty,
    so without this the diagnosis is "no usable report on stdout" -- printed
    next to the one string that says what actually went wrong.

    Read for its ``detail`` and nothing else. The exit code still decides the
    outcome, because a non-zero exit beside a report is precisely the
    inconsistency ``read_report`` refuses to score.

    ``None`` and ``""`` are different answers and the caller renders them
    differently: ``None`` is "nothing on stdout parsed as a report", ``""`` is
    "a report reached stdout carrying no detail". Collapsing them announces a
    well-formed report as no report at all.
    """

    report = _last_report(stdout)
    return detail_of(report) if isinstance(report, dict) else None


def _diagnosis(completed: ProcessResult) -> str:
    """What the failing process actually said, not a sentence about it.

    Prefers the last line of stderr -- where the confinement launcher and an
    unhandled traceback both land -- then the detail of a report on stdout, and
    falls back to naming the exit code when the process died silently. Whether a
    report reached stdout is stated rather than assumed, because "with a report"
    was asserted unconditionally before -- and a report that reached stdout
    saying nothing is a third answer, not the same as none arriving.
    """

    exited = f"verifier exited {completed.exit_code}"
    last = (completed.stderr.strip().splitlines() or [""])[-1]
    if last:
        return f"{exited}: {last[:DETAIL_LIMIT]}"
    if not completed.stdout.strip():
        return f"{exited} with nothing on stdout or stderr"
    reported = _reported_detail(completed.stdout)
    if reported:
        return f"{exited}: {reported}"
    if reported is not None:
        return f"{exited} with a report that carried no detail"
    return f"{exited} with no usable report on stdout"


def read_report(completed: ProcessResult, scenario: Scenario) -> ScenarioReport:
    """Turn one process result into one scenario report and nothing else."""

    usage = completed.usage.without_counts

    def refuse(outcome: str, detail: str) -> ScenarioReport:
        return ScenarioReport(
            scenario=scenario.name, outcome=outcome, detail=detail, usage=usage
        )

    if completed.failure is not None:
        return refuse(sandbox_outcome(completed.failure), completed.failure.message)
    if completed.exit_code != 0:
        # ``verifier.py`` documents exit 3 as "no report could be produced at
        # all", and returns 0 in every case where one was. Enforcing that here
        # rather than trusting it is the difference between a contract and a
        # comment: a verifier that dies after writing a partial line, or a
        # future edit that returns non-zero beside a report, would otherwise be
        # parsed and -- if the numbers happened to be self-consistent -- scored.
        #
        # The refusal stands; what changed is that it now says what actually
        # happened. The old text asserted "with a report" whether one existed or
        # not, and dropped stderr on the floor -- so a confinement layer refusing
        # to start and a verifier dying mid-run produced the same sentence, and
        # neither carried the diagnostic that would tell them apart.
        # ``handoff.py`` has read stderr this way all along.
        return refuse("verifier-failed", _diagnosis(completed))
    report = _last_report(completed.stdout)
    if report is UNPARSEABLE:
        return refuse("verifier-failed", _diagnosis(completed))
    # The type check has to come *before* the membership test: a list or dict
    # ``outcome`` reaches the set lookup unhashable and raises ``TypeError``
    # out of the function whose job is refusing malformed reports. A name that
    # is not a string is not a name this vocabulary holds, which is the answer
    # an unknown string already gets, so both arrive at one refusal.
    unnamed = f"unnamed outcome in {completed.stdout[:200]}"
    if not isinstance(report, dict):
        return refuse("verifier-failed", unnamed)
    outcome = report.get("outcome")
    if not isinstance(outcome, str) or outcome not in VERIFIER_OUTCOMES:
        return refuse("verifier-failed", unnamed)
    mismatch = _identity_mismatch(report, scenario)
    if mismatch is not None:
        return refuse("report-rejected", mismatch)
    if outcome != "completed":
        # ``detail_of`` rather than a bare ``str(...)``: this was the one detail
        # path in the module that copied the candidate-influenced text out at
        # whatever length it arrived, while every other path -- ``_diagnosis``
        # above, and ``detail_of`` everywhere else -- bounds it at
        # ``DETAIL_LIMIT``. An unbounded detail here goes on to be a durable
        # evidence row, so the ceiling belongs on this path too.
        return refuse(outcome, detail_of(report))
    mismatch = _measurement_mismatch(report, scenario)
    if mismatch is not None:
        return refuse("report-rejected", mismatch)
    # ``simulator.Trace`` stays the one authority for what imbalance and work
    # mean: the report carries raw counts and the derived numbers are computed
    # here from them. Recomputing the imbalance beside this drifts from the
    # simulator the moment the normalization changes.
    trace = Trace(
        loads=tuple(int(value) for value in report["loads"]),
        placements=tuple(int(value) for value in report["placements"]),
        probes=int(report["probes"]),
        tasks=int(report["tasks"]),
    )
    return ScenarioReport(
        scenario=scenario.name,
        outcome="completed",
        imbalance=trace.imbalance,
        work=trace.work,
        quality=quality(trace.imbalance, trace.work),
        loads=trace.loads,
        usage=usage,
    )


__all__ = ["VERIFIER_OUTCOMES", "read_report"]
