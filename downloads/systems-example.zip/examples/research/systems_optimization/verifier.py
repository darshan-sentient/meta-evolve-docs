"""The evaluator's half of the process split: it measures, and it decides.

``execution.py`` materializes a workspace holding the candidate's
``scheduler.py`` beside evaluator-owned copies of this module, ``simulator.py``,
``protocol.py``, ``agent.py``, and one scenario file, then runs
``python _verifier.py <deadline>`` in it through the shipped bounded subprocess
sandbox.

This process owns the ``simulator.Session`` -- the loads, the probe counter, the
task stream, and the scenario -- and never imports candidate code. It spawns
``_agent.py`` as a child, which does, and talks to it in ``protocol`` messages.
Every number in the report is read off this side's ``Session``. There is no
message the child can send that carries a measurement, so the report is the
evaluator's statement about the candidate rather than the candidate's statement
about itself.

Three details are the whole security argument, and each is load-bearing:

* **The scenario file is read and deleted before the child exists.** The task
  stream is therefore not in the child's argv, not in its environment, not on
  disk, and not reachable through this process's command line. A scheduler can
  see one task size at a time, which is the observation it is supposed to have.
* **The child's descriptors 0, 1, and 2 are pipes this process owns**, and
  ``agent.py`` blinds them before importing anything. The sandbox's stdout --
  the channel ``execution.py`` parses -- is not inherited at all.
* **Diagnosis happens next to the failure, classification here.** The child
  names what went wrong with the candidate; this module decides which named
  outcome that is, and ``outcomes.py`` maps the name onto a typed failure. What
  it never names is what went wrong with the *evaluator*: that is the process
  holding candidate code, so a claim about this side is one a candidate can
  write. This side holds itself to its own contract instead, before it sends.

Classification is a closed vocabulary. Anything this module cannot place is
``verifier-failed``, which is an evaluator failure -- unrankable, and reported
as the evaluator's problem rather than the candidate's.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines:
the pipe, the conversation, and the classification are one responsibility here
-- this process's whole job -- and splitting the reader or the conversation out
would mean materializing another module into every candidate workspace and
adding it to the injected map, so a reader chasing "what happened to this
candidate" would follow the answer across three files instead of one. The
tests are split by responsibility instead: ``_pipe`` for the descriptor
mechanics, ``_observe`` for the naming, ``_agent`` for the real child.
"""

from __future__ import annotations

import fcntl
import json
import os
import select
import subprocess
import sys
import time

try:  # the example package: importable, reviewable, and unit-testable
    from . import protocol, simulator
except ImportError:  # a workspace copy: plain sibling modules, no package
    import _protocol as protocol  # type: ignore[no-redef]
    import _simulator as simulator  # type: ignore[no-redef]


SCENARIO_FILE = "_scenario.json"
AGENT_FILE = "_agent.py"
# Interpreter flags for the child: no bytecode, and no ambient ``PYTHON*``
# variable can change how it behaves. Not ``-I``, which would also drop the
# script's directory from ``sys.path`` and leave ``scheduler`` unimportable.
AGENT_FLAGS = ("-B", "-E")
# The largest single message this side will accept. One protocol message is a
# few dozen bytes, so the ceiling is generous; what it buys is that a child
# which streams without ever sending a newline is a bounded protocol violation
# rather than unbounded memory in this process. It bounds each *message*, not
# the buffer, so a burst of short messages arriving in one read is fine and an
# oversized one is refused whether or not it arrived whole.
LINE_LIMIT = 8_192


class Deadline(Exception):
    """The child did not answer inside the wall clock the evaluator granted."""


class Abandoned(Exception):
    """The child stopped talking before the schedule was finished."""


class _Reader:
    """Newline-delimited reads from one raw pipe, under one wall-clock deadline.

    Deliberately not a buffered file object: ``select`` and buffered reads
    disagree about whether data is available, and the disagreement shows up as
    a hang rather than an error.
    """

    __slots__ = ("_buffer", "_deadline", "_fd")

    def __init__(self, fd: int, deadline: float) -> None:
        self._fd = fd
        self._buffer = b""
        self._deadline = deadline

    def readline(self) -> bytes:
        """One message, bounded by ``LINE_LIMIT`` however the pipe delivers it.

        The bound applies to each frame, finished or not, and that is the whole
        content of this method. Bounding the *buffer* refuses a legal burst of
        short messages that arrived together; bounding only the *unfinished*
        tail measures a frame only while it is still a prefix, so an oversized
        message is refused or accepted according to how ``os.read`` happened to
        split it. Neither is a property of what the candidate said.
        """

        while True:
            frame, newline, rest = self._buffer.partition(b"\n")
            if newline:
                self._buffer = rest
                if len(frame) > LINE_LIMIT:
                    raise protocol.ProtocolError(
                        f"agent wrote a {len(frame)} byte message, over the "
                        f"{LINE_LIMIT} byte limit"
                    )
                return frame
            if len(frame) > LINE_LIMIT:
                raise protocol.ProtocolError(
                    f"agent wrote {len(frame)} bytes with no message in them"
                )
            remaining = self._deadline - time.monotonic()
            if remaining <= 0:
                raise Deadline("the candidate ran out of wall clock")
            ready, _, _ = select.select([self._fd], [], [], remaining)
            if not ready:
                raise Deadline("the candidate ran out of wall clock")
            chunk = os.read(self._fd, 65_536)
            if not chunk:
                raise Abandoned("the candidate closed the channel")
            self._buffer += chunk


class Conversation:
    """One live child process, and the only way this module talks to one."""

    __slots__ = ("_deadline", "_process", "_reader")

    def __init__(self, deadline: float) -> None:
        self._deadline = deadline
        self._process = subprocess.Popen(  # noqa: S603 - argv is evaluator-owned
            (sys.executable, *AGENT_FLAGS, AGENT_FILE),
            cwd=os.getcwd(),
            env={},
            shell=False,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            # Discarded rather than captured: the child reports what went wrong
            # on the channel, and an inherited stderr would be a second,
            # unvalidated way for candidate output to reach the evaluator.
            stderr=subprocess.DEVNULL,
            close_fds=True,
            bufsize=0,
        )
        assert self._process.stdout is not None
        self._reader = _Reader(self._process.stdout.fileno(), deadline)
        # Non-blocking, which is what makes ``send``'s deadline reachable at
        # all: on a blocking descriptor ``select`` only promises *some* space,
        # and the ``os.write`` after it then blocks until the whole payload is
        # accepted, so a child that never reads holds this process inside one
        # write with the clock unconsulted. Select-gating alone looked like a
        # fix and was not -- measured at 29.7s against a 1.5s deadline.
        assert self._process.stdin is not None
        stdin_fd = self._process.stdin.fileno()
        fcntl.fcntl(
            stdin_fd,
            fcntl.F_SETFL,
            fcntl.fcntl(stdin_fd, fcntl.F_GETFL) | os.O_NONBLOCK,
        )

    def send(self, op: str, **fields: object) -> None:
        payload = protocol.encode(op, **fields)
        stdin = self._process.stdin
        assert stdin is not None
        try:
            fd = stdin.fileno()
            sent = 0
            while sent < len(payload):
                remaining = self._deadline - time.monotonic()
                if remaining <= 0:
                    raise Deadline("the candidate ran out of wall clock")
                _, writable, _ = select.select([], [fd], [], remaining)
                if not writable:
                    raise Deadline("the candidate ran out of wall clock")
                try:
                    sent += os.write(fd, payload[sent:])
                except BlockingIOError:
                    # Filled between ``select`` and the write: no progress, no
                    # error, go back and consult the clock.
                    continue
        except (BrokenPipeError, ValueError) as error:
            raise Abandoned(f"the candidate stopped reading: {error}") from error

    def receive(self) -> dict[str, object]:
        return protocol.decode(self._reader.readline())

    def close(self) -> int | None:
        """Halt the child and reap it. Always safe to call, always called.

        ``Deadline`` is in the handler because this runs in ``observe``'s
        ``finally`` with a clock that has usually *already* expired: once
        ``send`` grew a deadline, the courtesy ``HALT`` began raising on the
        path that had just classified a timed-out run, discarding its report so
        ``main`` recorded ``verifier-failed`` -- the evaluator taking the blame
        for a candidate fault. Halting is best-effort anyway; the child is
        killed below regardless.
        """

        try:
            self.send(protocol.HALT, reason="finished")
        except (Abandoned, Deadline, OSError):
            pass
        for stream in (self._process.stdin, self._process.stdout):
            if stream is not None:
                try:
                    stream.close()
                except OSError:
                    pass
        self._process.kill()
        try:
            return self._process.wait(timeout=5.0)
        except subprocess.TimeoutExpired:  # pragma: no cover - kill(2) does not fail
            return None


class _Raised(Exception):
    """The candidate's own code raised. A broken program, not a bad placement."""


def _place_one_task(
    conversation: Conversation, session: simulator.Session, size: int
) -> None:
    """Answer questions until the candidate names a worker for this task."""

    conversation.send(protocol.TASK, size=protocol.as_count(size, "size"))
    while True:
        message = conversation.receive()
        op = message["op"]
        if op == protocol.PROBE:
            conversation.send(protocol.LOAD, value=session.probe(message.get("worker")))
        elif op == protocol.PICK:
            conversation.send(protocol.INDEX, value=session.pick())
        elif op == protocol.PLACE:
            session.place(message.get("worker"))
            return
        elif op == protocol.RAISED:
            raise _Raised(protocol.detail_of(message))
        else:
            raise protocol.ProtocolError(f"unexpected {op!r} while placing a task")


def observe(scenario: simulator.Scenario, deadline: float) -> dict[str, object]:
    """Run one scenario against one candidate and return one report."""

    session = simulator.Session(scenario)
    conversation = Conversation(deadline)
    try:
        conversation.send(
            protocol.BEGIN, workers=protocol.as_count(session.workers, "workers")
        )
        opening = conversation.receive()
        if opening["op"] == protocol.UNUSABLE:
            reason = str(opening.get("reason", ""))
            if reason not in protocol.UNUSABLE_REASONS:
                raise protocol.ProtocolError(f"unusable claimed {reason!r}")
            return _report(scenario, reason, detail=protocol.detail_of(opening))
        if opening["op"] != protocol.READY:
            raise protocol.ProtocolError(f"unexpected {opening['op']!r} at handshake")
        while (size := session.next_task()) is not None:
            _place_one_task(conversation, session, size)
        trace = session.trace()
        return _report(
            scenario,
            "completed",
            loads=list(trace.loads),
            placements=list(trace.placements),
            probes=trace.probes,
            tasks=trace.tasks,
            total=sum(trace.loads),
        )
    except simulator.ProbeBudgetExceeded as error:
        return _report(scenario, "constraint-violated", detail=str(error))
    except simulator.InvalidPlacement as error:
        return _report(scenario, "invalid-schedule", detail=str(error))
    except _Raised as error:
        return _report(scenario, "execution-failed", detail=str(error))
    except protocol.NotACount as error:
        # ``verifier-failed`` and not any candidate outcome: the only counts this
        # handler can see are the two this process was about to send, so what is
        # wrong is this process's own message. Typing that as a candidate fault
        # is the failure mode ``outcomes.py`` names outright.
        return _report(scenario, "verifier-failed", detail=f"unsendable: {error}")
    except protocol.ProtocolError as error:
        return _report(scenario, "protocol-violated", detail=str(error))
    except Deadline as error:
        return _report(scenario, "timed-out", detail=str(error))
    except Abandoned as error:
        placed = f"{session.placed} of {len(scenario.sizes)}"
        return _report(scenario, "abandoned", detail=f"{error} after {placed} tasks")
    finally:
        conversation.close()


def _report(
    scenario: simulator.Scenario, outcome: str, **fields: object
) -> dict[str, object]:
    """Name one outcome, beside the identity of everything that produced it.

    The evaluator re-checks each of these against what it asked for, so a
    report that does not describe the scenario it was sent is refused rather
    than scored.
    """

    return {
        "outcome": outcome,
        "protocol": protocol.PROTOCOL_VERSION,
        "simulator": simulator.SIMULATOR_VERSION,
        "scenario": scenario.name,
        "scenario_digest": scenario.digest,
        "workers": scenario.workers,
        **fields,
    }


def main(argv: list[str]) -> int:
    """Print exactly one JSON report line and exit zero having produced it.

    Exit 3 means no report could be produced at all, which is the evaluator's
    signal that its own harness -- not the candidate -- is what broke.
    """

    try:
        deadline = time.monotonic() + float(argv[1])
        with open(SCENARIO_FILE, encoding="utf-8") as handle:
            payload = json.load(handle)
        scenario = simulator.Scenario.from_payload(payload)
        # Gone before the child that could read it exists. From here the task
        # stream lives only in this process's memory.
        os.unlink(SCENARIO_FILE)
    except Exception as error:  # pragma: no cover - the harness owns all of it
        print(json.dumps({"outcome": "verifier-failed", "detail": repr(error)}))
        return 3

    try:
        report = observe(scenario, deadline)
    # ``Exception``, not ``BaseException``, because ``return 0`` follows: an
    # interrupt caught here was printed as a finished report beside a zero
    # exit, indistinguishable from a verifier that ran to a conclusion. Letting
    # it propagate exits non-zero, which ``read_report`` refuses to score. The
    # block above keeps its broad catch: it already returns 3.
    except Exception as error:
        report = _report(scenario, "verifier-failed", detail=repr(error))
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
