"""The fixture's plan, and the whole proposal decision, in stdlib-only Python.

This module is the *decision*: given serialized development context, which plan
step comes next, which observation prompted it, and what source text it writes.
It is separate from ``proposals.py`` for one reason, and the reason is the
boundary. ``propose.py`` runs this in a kernel-confined process that cannot read
this repository's own files, so everything in here imports from the standard
library and from ``schedulers.py`` alone. In particular **not** ``meta_evolve``:
in a development checkout it is installed from this repository's ``src``, which
the confinement denies, and depending on that being true of every install layout
is the kind of assumption that fails in a detached worktree. ``proposals.py``
keeps the kernel-facing half -- it serializes the context in, validates the
payload out, and turns it into a ``ProposalResult`` -- and ``bounds.py`` reads
``PLAN`` to derive the ceilings this example declares.

**The order of the plan is scripted, and that is a fixture decision, not a
finding.** A live proposer choosing from the same observations would pick its own
edits and would not helpfully produce one of each outcome class. The plan exists
so that a single command exhibits every outcome this example claims to keep
inspectable -- a negative, a tie, a selected candidate, an invalid schedule, an
off-surface refusal, a constraint violation, and malformed source -- instead of
describing them in prose and hoping.

What is *not* scripted is the scoring. Every number attached to these schedulers
comes from running them.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: most
of it is ``PLAN`` itself -- eight committed edits, each carrying the hypothesis a
proposer would have written and the outcome class it exists to exhibit -- which
is data, not logic, and is the fixture this example's one command is *for*.
Moving it to a sibling would put the eight hypotheses in one file and the four
functions that read them in another, and this module's whole constraint is that
it imports nothing but the standard library and ``schedulers.py``.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from hashlib import sha256

try:  # the example package: importable, reviewable, and unit-testable
    from .schedulers import (
        HELPER,
        LEAST_LOADED_MIN_KEY,
        LEAST_LOADED_SCAN,
        MALFORMED,
        MOST_LOADED_OF_TWO,
        OFF_THE_CLUSTER,
        PAST_THE_BUDGET,
        POWER_OF_TWO,
        WITH_HELPER,
    )
except ImportError:  # a workspace copy: a plain sibling module, no package
    from _schedulers import (  # type: ignore[no-redef]
        HELPER,
        LEAST_LOADED_MIN_KEY,
        LEAST_LOADED_SCAN,
        MALFORMED,
        MOST_LOADED_OF_TWO,
        OFF_THE_CLUSTER,
        PAST_THE_BUDGET,
        POWER_OF_TWO,
        WITH_HELPER,
    )


FIXTURE_DECLARATION = "deterministic-scheduler-plan-v1"


@dataclass(frozen=True, slots=True, kw_only=True)
class Edit:
    """One scheduler rewrite, and why the fixture would write it."""

    name: str
    hypothesis: str
    source: str
    exhibits: str
    extra: tuple[tuple[str, str], ...] = ()

    def files(self, surface: str) -> dict[str, str]:
        """The proposed tree as plain text. ``extra`` is an off-surface edit.

        The surface file's *name* arrives as an argument rather than being
        restated here, because ``surface.py`` owns it and ``surface.py`` imports
        ``meta_evolve``. A second copy of the name in this module would be a
        second thing to keep in step with the declared surface.

        ``extra`` is spread second, so an ``extra`` entry naming the surface file
        would *replace* the proposed source and the plan would silently propose
        something other than its own ``source`` -- with ``exhibits`` still
        claiming the outcome the source was written for. Every fixture here is
        supposed to exhibit one named thing, so a collision is a broken fixture
        rather than a precedence question, and it is refused.
        """

        extra = dict(self.extra)
        if surface in extra:
            raise ValueError(
                f"the edit {self.name!r} carries an extra file named {surface!r}, "
                "which is the surface it also proposes a source for; one of the "
                "two would silently win"
            )
        if len(extra) != len(self.extra):
            raise ValueError(
                f"the edit {self.name!r} carries the same extra path twice: "
                f"{[path for path, _ in self.extra]}"
            )
        return {surface: self.source, **extra}


PLAN = (
    Edit(
        name="most-loaded-of-two",
        hypothesis="Comparing two workers before placing should beat placing blind.",
        source=MOST_LOADED_OF_TWO,
        exhibits="a negative: a valid schedule that is worse than the baseline",
    ),
    Edit(
        name="least-loaded-scan",
        hypothesis="Placing on the least loaded worker should remove the imbalance.",
        source=LEAST_LOADED_SCAN,
        exhibits="an improvement bought at the highest possible scheduling cost",
    ),
    Edit(
        name="least-loaded-min-key",
        hypothesis="The same placement written shorter should score the same.",
        source=LEAST_LOADED_MIN_KEY,
        exhibits="a tie: the same probes in the same order and the same placement",
    ),
    Edit(
        name="power-of-two-choices",
        hypothesis=(
            "Two probes should buy most of the balance for a fraction of the cost."
        ),
        source=POWER_OF_TWO,
        exhibits="the selected candidate",
    ),
    Edit(
        name="places-off-the-cluster",
        hypothesis="Indexing from one instead of zero would simplify the loop.",
        source=OFF_THE_CLUSTER,
        exhibits="an invalid schedule, unrankable",
    ),
    Edit(
        name="refactor-into-a-helper",
        hypothesis="Extracting the scan into a helper module would be tidier.",
        source=WITH_HELPER,
        exhibits="an off-surface refusal, unrankable",
        extra=(("helpers.py", HELPER),),
    ),
    Edit(
        name="scan-past-the-budget",
        hypothesis="One more probe than the budget allows should still be worth it.",
        source=PAST_THE_BUDGET,
        exhibits="a declared-constraint violation, unrankable",
    ),
    Edit(
        name="unparseable-rewrite",
        hypothesis="A tighter signature would read better.",
        source=MALFORMED,
        exhibits="malformed source, unrankable",
    ),
)


def by_name(edits: tuple[Edit, ...]) -> dict[str, Edit]:
    """Index edits by step name, refusing a name that would shadow another.

    A plain comprehension keeps the *last* of two edits sharing a name, so the
    earlier one becomes unreachable through the lookup while ``PLAN`` still runs
    it and the record still carries its ``plan_step``. Whoever resolves that name
    afterwards -- which is the only thing the lookup is for -- gets the wrong
    hypothesis and the wrong ``exhibits`` for the source that actually ran.

    A function rather than a check beside the assignment below, so it can be
    handed a duplicate and observed refusing one. The plan is a committed
    literal, so in production this can only fire on an editing mistake, and
    firing at import is the point: such a mistake cannot ship.
    """

    counts = Counter(edit.name for edit in edits)
    shared = sorted(name for name, count in counts.items() if count > 1)
    if shared:
        raise ValueError(
            f"two plan steps share a name ({shared}); the step name is what the "
            "record carries and what a reader resolves an attempt by"
        )
    return {edit.name: edit for edit in edits}


PLAN_BY_NAME = by_name(PLAN)


def _counted(value: object) -> bool:
    """A whole number. ``bool`` is an ``int`` in Python and is not one here.

    The same rule ``handoff._counted`` applies to the payload coming back, and
    for the same reason: ``True`` would order as ``1`` and identify an occurrence
    that is not the one it names.
    """

    return isinstance(value, int) and not isinstance(value, bool)


def digest_of(source: str) -> str:
    """Name a candidate by its content, for evidence that reads on its own."""

    return sha256(source.encode("utf-8")).hexdigest()[:16]


def position(step: int) -> int:
    """How far through the plan this proposal is.

    ``step`` is the kernel's logical step for the trial being proposed: zero is
    the seed, so the first proposal is one. Reading it rather than keeping a
    counter is what keeps this a pure function of what it was handed -- which is
    what lets the proposer be registered as deterministic and be replayed.
    Counting *ancestors* would not work: a search that keeps its parent through a
    failed trial has no new ancestor to count.
    """

    return step - 1


# Every field this plan reads off an observation. Named once because the filter
# below, the refusal beside it, and the payload at the bottom of this module have
# to agree about what "usable" means, and there are two ways for them to drift:
# a filter wanting ``quality`` alone while the payload reads three metrics, and a
# payload reading ``event_sequence`` while the filter asks only for
# ``logical_step``. Either lets a record without one past the gate to raise a
# bare ``KeyError`` out of the confined process, where an exception is a lost
# proposal rather than a refusal that explains itself.
REQUIRED_METRICS = ("quality", "imbalance", "work")

# The two that identify *which* occurrence was read. Both, because a logical step
# is not unique: a search that re-evaluates the same step -- a retried trial --
# produces two records under one number, and only the event sequence tells them
# apart. Ordering by the pair is what makes "the most recent observation"
# well-defined instead of whichever of a tie ``max`` happened to keep.
REQUIRED_FIELDS = ("logical_step", "event_sequence")


def observation(records: list[dict]) -> dict | None:
    """The most recent scored development evaluation in the serialized context.

    This is the *only* channel into the plan. The private and held-out splits are
    scored in ``command.py`` after the search has returned, so there is no moment
    at which one of their results could be in this list -- and the process that
    reads it could not open the file they live in even if there were.
    """

    scored = [
        record
        for record in records
        if record.get("kind") == "evaluation"
        and isinstance(record.get("metrics"), dict)
        and all(key in record["metrics"] for key in REQUIRED_METRICS)
        and all(_counted(record.get(field)) for field in REQUIRED_FIELDS)
    ]
    if not scored:
        return None
    return max(scored, key=lambda record: tuple(record[f] for f in REQUIRED_FIELDS))


def unusable(records: list[dict]) -> str:
    """Why nothing in this context could be proposed from.

    The refusal was one fixed sentence -- "no authorized development observation
    to propose from" -- for every reason there might not be one, and it reads as
    a claim about *authority*: it sends whoever hits it
    to look at the split boundary, which is the one thing that is working. The
    ordinary cause is a record missing a field this filter reads, which is a
    serialization question, and the two deserve to be told apart because only
    one of them would be a finding.

    What is named is the shape -- which keys are absent, what type arrived --
    never a metric's value. This runs on the confined side and its return travels
    back in a refusal, so it says what is wrong with the context rather than what
    was in it.
    """

    evaluations = [record for record in records if record.get("kind") == "evaluation"]
    if not evaluations:
        kinds = sorted({str(record.get("kind")) for record in records})
        return (
            f"{len(records)} records carrying {kinds or ['nothing']} and not one "
            "evaluation among them"
        )
    faults: list[str] = []
    for index, record in enumerate(evaluations):
        metrics = record.get("metrics")
        if not isinstance(metrics, dict):
            faults.append(f"[{index}] metrics is {type(metrics).__name__}, not an object")
        elif missing := [key for key in REQUIRED_METRICS if key not in metrics]:
            faults.append(f"[{index}] metrics lacks {missing}")
        for field in REQUIRED_FIELDS:
            value = record.get(field)
            if not _counted(value):
                faults.append(
                    f"[{index}] {field} is {type(value).__name__}, not a whole number"
                )
    return (
        f"{len(evaluations)} evaluation records and none usable: "
        + "; ".join(faults)
    )


def proposal(context: dict) -> dict:
    """The next proposal as plain data, or a refusal naming why there is none."""

    records = list(context.get("records", ()))
    observed = observation(records)
    if observed is None:
        return {
            "refusal": "no authorized development observation to propose from: "
            + unusable(records)
        }
    index = position(int(context["step"]))
    if not 0 <= index < len(PLAN):
        return {"refusal": "the fixture plan is exhausted"}
    edit = PLAN[index]
    parent = str(context["parent"])
    metrics = observed["metrics"]
    return {
        "declaration": FIXTURE_DECLARATION,
        "plan_step": edit.name,
        "hypothesis": edit.hypothesis,
        "exhibits": edit.exhibits,
        "files": edit.files(str(context["surface"])),
        # The parent named by content, so the evidence identifies it without
        # needing the run's own artifact index. Computed here, on the confined
        # side, and re-checked in ``proposals.py`` against the parent that was
        # actually serialized -- two independent statements about one artifact.
        "parent_digest": digest_of(parent),
        "parent_bytes": len(parent.encode("utf-8")),
        "observed_step": int(observed["logical_step"]),
        "observed_sequence": int(observed["event_sequence"]),
        "observed_quality": float(metrics["quality"]),
        "observed_imbalance": float(metrics["imbalance"]),
        "observed_work": float(metrics["work"]),
    }


__all__ = [
    "Edit",
    "FIXTURE_DECLARATION",
    "PLAN",
    "PLAN_BY_NAME",
    "REQUIRED_FIELDS",
    "REQUIRED_METRICS",
    "by_name",
    "digest_of",
    "observation",
    "position",
    "proposal",
    "unusable",
]
