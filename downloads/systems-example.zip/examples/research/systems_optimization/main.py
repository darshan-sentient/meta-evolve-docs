"""Entry point: put the repository root on the path, then run the command.

Deliberately the only file in this example that is not an ordinary module. The
rest of it is a package whose modules import each other relatively, which is
what keeps names like ``execution`` and ``simulator`` from colliding with the
other examples in this repository. A package cannot be run as a script, so this
launcher exists to make one command work from a fresh checkout with nothing
installed:

    uv run python examples/research/systems_optimization/main.py

``examples`` and ``examples/research`` are namespace packages, so no
``__init__.py`` is needed above this directory for the import below to resolve.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from examples.research.systems_optimization.command import main  # noqa: E402

if __name__ == "__main__":
    # ``SystemExit`` rather than a bare call, so a failed replay cross-check is a
    # non-zero status and not only a ``False`` in the printed report. ``agent.py``
    # and ``verifier.py`` have always exited this way; this file did not.
    raise SystemExit(main())
