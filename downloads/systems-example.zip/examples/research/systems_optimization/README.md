<!--
Deliberately longer than the 300-line guideline in AGENTS.md, and not splittable
without making it worse. Most of it is the pinned command output, two diagrams,
and the reference tables, which have to be complete to be worth having. The prose
that remains is the part a reader cannot get anywhere else -- what the authority
boundary claims, and what it does not.
The deep version of each argument lives in the module docstring that owns it
(verifier.py, agent.py, reports.py, record.py, audit.py, policy.py), so this
file is a tour rather than a manual.
-->

# Systems optimization

One load-balancing scheduler, evolved against a simulator in a process of its
own.

The candidate is a `meta.SourceTree` holding a single file, `scheduler.py`. It is
executed -- as a real program, in its own workspace, in its own process -- against
a fixed simulator that counts two things: how evenly the work landed, and how much
the scheduler had to ask before it decided. Those two pull against each other, and
that tension is the whole search space.

| what | which |
|---|---|
| representation | `meta.SourceTree`, one declared file |
| execution | shipped `DirectoryWorkspaces` + `DevelopmentSubprocessSandbox` |
| authority boundary | a request/response process split: the measuring process never imports candidate code |
| measured | normalized load imbalance (down), scheduler probes per task (down) |
| declared objective | one `meta.Maximize("quality")` over an aggregate of those two |
| governed proposer | the committed deterministic fixture, decided in a kernel-confined process; no injection, model, network, or credential |
| method mapping | [ADRS](https://arxiv.org/abs/2512.14806) -- white-box optimization of a systems algorithm under a governed evaluator |

**This is a mechanism demonstration.** See [Non-claims](#non-claims) before
citing anything here. It is not a reproduction of ADRS.

## Run it

```bash
uv run python examples/research/systems_optimization/main.py
```

For the same fixture-only run as a progressive, executed walkthrough, open the
[systems optimization notebook](../../../docs/notebooks/systems_optimization/systems_optimization.ipynb).

No network, no credentials, no GPU, no optional provider package. It takes a
couple of seconds and always prints:

<!-- expected-output -->

```text
== declared surface ==
  candidate: scheduler.py only; everything else is evaluator-owned
  execution: the candidate runs in a process that holds no simulator

== development search: the only feedback the fixture uses ==
  round-robin (seed)         quality=0.7929 imbalance=0.2071 work=0.0
  most-loaded-of-two         quality=0.7731 imbalance=0.1869 work=2.0
  least-loaded-scan          quality=0.8219 imbalance=0.0381 work=7.0
  least-loaded-min-key       quality=0.8219 imbalance=0.0381 work=7.0
  power-of-two-choices       quality=0.9136 imbalance=0.0464 work=2.0
  places-off-the-cluster     unrankable  invalid_output/invalid-schedule
  refactor-into-a-helper     unrankable  policy_violation/off-surface
  scan-past-the-budget       unrankable  policy_violation/constraint-violated
  unparseable-rewrite        unrankable  invalid_output/malformed-source

== published selection: scored after the fixture search returned ==
  power-of-two-choices       quality=0.9014 work=2.0
  least-loaded-scan          quality=0.8275 work=6.7
  least-loaded-min-key       quality=0.8275 work=6.7
  round-robin (seed)         quality=0.7536 work=0.0
  most-loaded-of-two         quality=0.6070 work=2.0
  selected: power-of-two-choices
  tie-break: higher selection quality, then lower scheduling work, then earlier logical step

== published final comparison: baseline and selected only ==
  baseline: 0.7912
  selected: 0.8806
  verdict: improved
  promotion: external

== accounting ==
  evaluations: development 9/9, selection 5, final comparison 2
  scenario runs: 32 of at most 49
  processes per scenario run: 2
  wall clock recorded: True
  monetary cost: not measured here (issue #143 owns it)

== replay: the output directory alone, nothing rerun ==
  store holds the recorded run: True
  run declaration agrees: True
  every development attempt agrees: True
  search best agrees: True
  lineage agrees: True
  evidence agrees: True
  development accounting agrees: True
  every attempt has exactly one timing: True
  development timing agrees: True
  total timing agrees: True
  live decision matches: True
```

Read it top to bottom and the mechanism is all there: a baseline worth beating, a
regression kept rather than hidden, two different programs that measure
*identically*, four refusals that are not scores, an independent split that
agrees, one final comparison that happens last, and a record that reproduces
the whole decision without rerunning any of it.

## What the numbers mean

The scheduler is handed a `cluster` and one task at a time. It may call
`cluster.load(i)` -- a **probe**, and probes are counted -- and must name a
worker.

* **imbalance** = `(max load - mean load) / (total - mean)`. Zero is a perfect
  split, one is everything on a single worker. Normalizing against the *worst
  possible* split rather than against the mean is what makes scenarios with
  different worker counts comparable, so one aggregate covers a whole split
  without a scenario's size deciding how much it counts.
* **work** = probes per task. Zero means the scheduler never looked.
* **quality** = `max(0, 1 - imbalance - 0.02 * work)`. Stated as arithmetic, not
  as a black box: every number above is predictable from the two before it. The
  weight is small on purpose -- a scheduler should pay two probes for a large
  balance gain and refuse to pay a full cluster scan for a marginal one.

**Two measured components, one declared objective.** The task declares exactly
one, `meta.Maximize("quality")`, and that is what the search ranks and what
selection reads. `imbalance` and `work` are reported beside it -- per split and
per scenario -- because a reader needs to see which half a candidate bought its
score with. They are not separate objectives and the search does not weigh them
independently; `quality` already did that, once, visibly, above.

Every scenario repeats a pattern of small tasks with one large task at the end,
and its difficulty is that the pattern length shares a factor with the worker
count -- so round-robin sends *every* large task to the same handful of workers.
It fails by position, not by count, which fixes the baseline at good enough to be
a real bar and bad enough to beat. That is also why the winner is the one it is:
`least-loaded-scan` buys near-perfect balance for seven probes a task, more than
the imbalance it removed, and `power-of-two-choices` compares two workers for
two.

## Authority

The candidate may change the text of `scheduler.py`. That is the entire list.

| owned by the evaluator | why it cannot be a candidate's business |
|---|---|
| the simulator and its version | a candidate that could edit the measurement is not being measured |
| public development workloads | the feedback channel; changing it changes what "better" means |
| published post-search selection workloads | the fixture is scored after it has stopped proposing |
| published final-comparison suite | baseline and selected are scored only after selection |
| constraints, seeds, ordering, objectives, aggregation, tie-breaking | all of scoring |
| the report, and every invariant it is re-checked against | a candidate that can state its own result is not being evaluated |
| process timeouts, output limits, evaluation and trial budgets | what a run is allowed to cost |
| evaluator and proposer declarations | so two runs over moved goalposts are refused, not ranked |
| export and promotion | this script exports nothing and promotes nothing |

Four mechanisms keep a candidate there, and they do genuinely different jobs.
Being precise about which is which matters: it is easy to claim the strongest of
them while implementing the weakest.

**1. The artifact type, at rest.** `SourceTree` refuses absolute paths, `..`
segments, backslash separators, NUL bytes, and non-UTF-8 content -- so path escape
and binary candidates are not defended against, they cannot be constructed, and a
mapping of paths to text materializes no symlink. `surface.check_surface` adds
*scope*: no added file, deleted file, rename, empty module, or module past a
declared byte ceiling.

**2. The process split, at run time.** The one that matters, and the reason each
workspace holds five files instead of two:

```text
  sandbox boundary: cwd, environment, wall clock, output size
  ┌──────────────────────────────────────────────────────────────────────┐
  │  _verifier.py  ── owns simulator.Session: loads, probe counter,      │
  │                   task stream, scenario, and the report             │
  │        │                                                             │
  │        │  {"op": "task", "size": 5}      ──────────────►             │
  │        │  ◄──────────  {"op": "probe", "worker": 3}                   │
  │        │  {"op": "load", "value": 12}    ──────────────►             │
  │        │  ◄──────────  {"op": "place", "worker": 3}                   │
  │        ▼                                                             │
  │  _agent.py     ── imports scheduler.py. Holds no simulator state,    │
  │                   no loads, no task stream, no scenario name, and    │
  │                   no descriptor that reaches the sandbox's stdout.   │
  └──────────────────────────────────────────────────────────────────────┘
```

Everything the candidate can influence goes through that vocabulary, and there is
**no message in it that carries a measurement**. Three details make that hold:

* The scenario travels as a workspace file the verifier reads and unlinks *before*
  the process holding candidate code exists -- so the task stream is in no
  argument list, no environment variable, and nowhere in the workspace the
  candidate runs in. Through the protocol a scheduler sees one task size at a
  time -- and mechanism 3 is what stops it reading the file those streams are
  written in.
* `agent.py` duplicates the protocol channel onto private descriptors and points
  0, 1, and 2 at `/dev/null` before importing the candidate, so `print`,
  `sys.stdout`, and `os.write(1, ...)` all reach a black hole rather than the
  stream the evaluator parses.
* `reports.py` refuses a report that arrived beside a non-zero exit, and
  re-derives every invariant it can from the scenario alone -- identity, cluster
  shape, conservation of total work, task count, probe ceiling -- refusing rather
  than scoring when one does not hold.

The proxy is **not** sealed: Python has no private attributes, so
`cluster._channel` is reachable and no arrangement of `__slots__`, name mangling,
or closures changes that. It buys nothing -- the verifier meters every message, so
going through the channel pays what calling `load` pays, and reporting through it
gets `protocol-violated`. It bought exactly one thing while the agent still had
a message saying the *evaluator's* instruction was unusable -- `verifier-failed`,
the harness admitting fault -- which a candidate could write too, through the
channel or on the private descriptor at import time, before the handshake was
even answered. Three lines were enough to have their own failure recorded as the
harness's. That message is gone, and the two counts it protected are held to their rule by the
evaluator before it sends rather than reported back by the process that holds
candidate code. None of this is a deny-list: nothing scans candidate
source for `_loads`, `os._exit`, or `print`. `..._authority.py`, `..._channel.py`,
and `..._confinement.py` drive thirty-odd schedulers written to cheat and require
each to end as a typed unrankable failure or an honest measurement.

**3. Kernel confinement, over the filesystem.** `confinement.py` asks the
operating system to deny **file reads, directory enumeration, and writes beneath
this repository** from every process this example gives authority to -- a
`sandbox-exec` profile on macOS, `landlock.py` on Linux -- because `workloads.py`
holds the selection and final-comparison streams as committed literals. Without
it, a candidate that looked could recover the exact scenarios it was about to be
judged on and fit itself to them, open the same file for *writing* and change
them, or rewrite `verifier.py` and change the scorer. None of those is a hole
only in the prose: a scheduler that knows the stream can win without being
better.

One exemption, and it is checked rather than waved past: `sys.prefix` stays
readable, because CPython cannot start without its own standard library and this
project's environment lives at `.venv` inside the repository. `readable_paths`
**refuses outright** if that exemption would ever reach this example's own
directory, where every workload, scorer, and verifier lives -- and it compares
*canonical* paths, because the kernel follows symlinks and a lexical check does
not: a `sys.prefix` symlinked at this directory once passed one. Nothing under the
repository is writable, with no exemption at all.

Each mechanism also refuses a path it cannot express: a quote, a newline, or a
trailing backslash would each end an SBPL string early, and `os.pathsep` would
split `landlock.py`'s allow-list into entries that do not exist -- a rule silently
skipped is confinement silently not applied. The three characters are declared
once, in `confinement.UNSAFE_IN_A_PROFILE`: a guard that names two of the three
leaves `sandbox-exec` to answer the last by refusing the whole profile, which
fails closed on a parse error rather than on this example naming the path.

The two mechanisms are shaped differently on purpose. macOS's repository
`file-read-data` denial covers file contents and directory enumeration together;
Linux names `READ_FILE` and `READ_DIR` separately and grants both only on the
readable allow-list. macOS is a profile `confinement.py` writes, because it is a
handful of lines of SBPL. Linux is a module run as a script -- `python -I -B
landlock.py <readable> <writable>` in front of the real argv -- because it is sixty
lines of `ctypes`. As a `python -c` string it would be the one part of this
boundary no linter reads, `compileall` never parses, and no test on a macOS
machine can reach -- a blind spot wide enough to hide real defects.

`..._landlock.py` decides off Linux everything decidable off Linux: the rights
the reported ABI decides, the argument contract with the launcher from both
ends, an inert import, standard-library imports only, and the file starting when
run exactly as the launcher runs it. Whether the ruleset then holds needs a
kernel, and that is what CI is for.

Why the kernel and not Python: an in-process `sys.addaudithook` is reachable
through `gc.get_objects()`, so a candidate can replace the hook's `__code__` --
the same shape of hole as reading `Cluster._loads` directly. The boundary has to
sit below the thing it confines. The slice that introduces the filesystem
boundary drives twelve routes at the repository -- seven reads or observations through a direct path, `sys.prefix`, a
child, `ctypes`, directory listing, a workspace symlink, and Linux's
`/proc/self/root`; plus rewriting, creating, renaming, truncating, and
hard-linking. The platform-only `/proc` route and a cross-device hard-link route
skip explicitly. Every applicable route must return the errno *this* kernel denies
with -- `EPERM` on macOS, `EACCES` or `EXDEV` under Landlock, and never the
`ENOENT` a mistyped path would give, which is a way for all twelve to pass while
nothing is confined.

The five destructive routes act on a decoy file the fixture creates inside this
directory rather than on `workloads.py` itself, and the fixture then hashes every
file in this directory either side of the run and requires the two manifests to
match. `workloads.py` alone stood for that once, and it is the right file to name
first -- the routes aim at it -- but "the suite has not edited the repository it
is testing" is a claim about the directory, and one file is a spot check of it: a
boundary that failed on a route aimed at the decoy could have reached
`verifier.py` beside it with nothing to object. They are still real writes at
real paths inside the repository, so the boundary is tested exactly as before --
but a mechanism that is present and ineffective now costs a decoy instead of the
working tree, which is what it costs when one is simulated.

**A machine with no mechanism refuses to run** rather than scoring a candidate
it could not confine, and that refusal path is driven too.

**4. The sandbox, around all of it.** `DevelopmentSubprocessSandbox` bounds cwd,
environment, wall clock, and output size, and owns the process group both
processes live in.

**What none of the four defends against.** Not network, CPU, memory, or syscalls
generally -- the repository is what carries the questions, so the repository is
what mechanism 3 closes and nothing broader is claimed. Network is the one worth
naming twice: the questions are public literals, so a candidate that cannot read
them from disk could still fetch them over the wire. Not a candidate reading
the verifier's memory through the host. Not the injected simulator's source --
intended, since white-box optimization means seeing the system you are
optimizing. Not killing the verifier, which destroys the run and produces no
measurement.

So the governed claim is: **the protocol accepts no candidate-supplied
measurement, and confinement denies the candidate access to the repository file
holding the workloads.** The host-memory route described above is outside this
example's boundary.

The route is named on purpose. "Cannot read or write the workloads" would be
stronger than anything here makes good on: the
literals are public and egress is confined on neither platform, so a candidate
that opens a socket is outside all four mechanisms. **Unrestricted network access
is a scope limitation of #195**, not a gap in mechanism 3 -- the questions have to
be committed for the run to be reproducible from what is committed, and closing
the socket would be a different claim rather than a stricter one. The paragraph
above gets this right, and a summary of it that says "nothing in a run can reach
them" does not.

The proposer half is closed the same way, in two steps. First the seam went:
accepting any supplied proposer makes it ordinary Python in the process that
imported the later workloads, free to read them or score against them during its
own call. `search` and `run_example` now take the
committed fixture and nothing else. That closed the API and not the authority --
the fixture was still a callable in that same process, which is the same finding
wearing different clothes. So the fixture moved out too:
`handoff.py` serializes the development context into a file, runs `plan.py`
through `propose.py` under the same launcher the scenario runs use, and validates
one JSON line back. **The process that decides what to propose cannot open
`workloads.py`**, which is what #195's separation gate actually asks for, and
the crossing laws drive that boundary from inside the proposer rather than
asserting it from outside. The confinement policy is declared on the proposer's own
`ComponentRef`, so a run made without it cannot claim this one's identity.

Not claimed: that hostile code is safe to execute here, or that the later
questions are secret to anyone reading this repository from outside a run. They
are committed literals, on purpose, because an example whose workloads you cannot
read is an example you cannot check.

## The three splits

```text
                        ┌─ development (2 scenarios) ── public ──► the fixture reads this
                        │                                          and cites the record
  scheduler.py ─────────┤
  (one candidate)       ├─ selection (3 scenarios) ──── published, scored later
                        │
                        └─ final (2 scenarios) ───────── published, scored twice:
                                                        baseline and selected
```

The fixture's sequence is separated in **time** -- development search finishes,
selection runs, the final comparison runs last -- and the recorded run contains no
later-suite result because the command computes none until `meta.run` returns.
That sequencing is not the separation argument by itself, and reading it as one
is too weak: temporal order in trusted code is not authority.
What backs it now is authority, on both sides. Neither the candidate's process
nor the process that decides what to propose can open `workloads.py` at all
([Authority](#authority), mechanism 3) -- there is no supplied-proposer seam, and
the committed fixture does not run in the driver either. The questions stay
published, because an example whose workloads you cannot read is one you cannot
check.

**Selection direction and tie-breaking.** Both measured components are minimized
and `quality` aggregates them, so the selection split ranks on **higher quality**,
then **lower work**, then **the earlier logical step**. That rule is one declared,
versioned value in `policy.py`, consumed by both the ranking and the record, so a
reader of the file can reconstruct a tie *and* tell whether the rule has moved
since. The version is a fold of the four fields declared beside it, over the
canonical bytes the record is written in, so a reader can recompute it from the
file -- and `invariants.py` does, on every read. Folding a `repr` of Python
objects instead would be a shape no record stores, so the recomputation would be
impossible and the labels decoration: the policy name could be restated in a
written record with every check still passing. The last term
is the one worth stating: it prefers the candidate that arrived first rather than
whichever name sorts lower, and the run exercises it. `least-loaded-scan` and
`least-loaded-min-key` are different programs that probe the same workers in the
same order and score identically, so `scan` wins by having been proposed first.

**Selection may overrule development.** Here the two agree, which is what makes the
final comparison worth reporting. `test_systems_optimization_decision.py` runs
the same command against a uniform selection stream where blind round-robin
balances perfectly for free, so the development best loses -- and then requires
the record to reconstruct *that* winner.

## Budgets

| bound | value | derived from |
|---|---|---|
| outer evaluations | **9** | the seed plus one per plan entry |
| outer trials | **8** | one per plan entry |
| scenario runs | at most **49** | `ceiling_for()`: 9 candidates x 2 development + 9 x 3 selection + 2 x 2 final |
| processes per scenario run | **2** | one verifier, one agent holding the candidate |
| candidate wall clock per scenario | **6 s** | the inner clock; running out is a typed `timed-out` with a report |
| process wall clock per scenario | **10 s** | the outer backstop, for the verifier itself not coming back |
| stdout / stderr per scenario | **64 000 bytes** | each |

`bounds.py` derives every one of these from `len(PLAN)`, the split sizes, and each
other, so adding a scheduler moves the budget instead of exhausting it and the
outer clock cannot drift into the inner one. If the two clocks were equal, a
candidate that ran long would be reported as a typed timeout or as no report at
all depending on scheduling.

**49 is a ceiling and the run reports what it actually did** -- 32 above, because
four plan steps stop their split at the first refusal. The per-split counts are
taken from the evidence, so what the record says ran and what the sandbox was
asked to run cannot disagree.

Attempts, evaluations, and scenario runs are distinct counts. A refused proposal
is retained with its failure and usage but spends no evaluation. An off-surface
candidate reaches evaluation but starts no scenario. Replay checks development
evaluation counts against the kernel's recorded usage.

The ceiling is **derived from the splits a command was actually given**, not from
the committed ones. `run_example` takes the selection and final splits as
parameters, and a bound computed from the defaults and then retained beside a
larger run printed `scenario runs: 62 of at most 49` -- a declared bound the
count beside it exceeded, which is the one thing a bound must never be. It is
`bounds.ceiling_for(private, held_out)` now, and a test drives a bigger split
through it.

Wall clock is measured and rolled up, including the private and held-out work the
run itself cannot see. **Monetary cost is not measured**: nothing here is billed,
and inventing a number would be worse than the gap. Issue #143 owns spend.

## Failure taxonomy

Fourteen named outcomes, and exactly one is rankable. The distinction that
matters is between a scheduler that is *bad* and a scheduler that is *not
evidence*.

| outcome | typed as | what happened |
|---|---|---|
| `completed` | rankable metrics | it ran; the numbers are what they are |
| `off-surface` | `policy_violation` | added, removed, renamed, empty, or oversized |
| `malformed-source` | `invalid_output` | `scheduler.py` does not parse |
| `construction-failed` | `invalid_output` | it parses, then raises on import, or defines no callable `choose` |
| `execution-failed` | `invalid_output` | it imported, then raised mid-stream |
| `invalid-schedule` | `invalid_output` | it named something that is not a worker of this cluster |
| `protocol-violated` | `invalid_output` | it said something the placement vocabulary does not contain |
| `abandoned` | `invalid_output` | it stopped talking before the schedule finished -- `os._exit`, or a crash |
| `constraint-violated` | `policy_violation` | it probed past the scenario's declared budget |
| `timed-out` | `timeout` | one of the two wall clocks ran out |
| `resource-exhausted` | `resource_exhausted` | the machine ran out |
| `infrastructure-failed` | `infrastructure_failure` | the boundary could not run it at all |
| `report-rejected` | `evaluator_failure` | a report that failed the evaluator's own re-check of its invariants |
| `verifier-failed` | `evaluator_failure` | no usable report arrived; the harness is at fault, not the candidate |

None of the thirteen refusals receives a metric -- `EvaluationResult` refuses to
carry one beside a failure, and the decision record re-checks the same rule
because a verdict is computed from it. That is the load-bearing property: a
taxonomy whose entries quietly become low scores is worse than none, because a
broken scheduler scoring zero out-ranks a working one scoring 0.6 the moment the
zero is treated as a measurement.

`protocol-violated` and `abandoned` describe the *channel* rather than the
algorithm and exist only because of the process split. `report-rejected` and
`verifier-failed` are the evaluator admitting fault, because classifying a broken
measurement as the candidate's problem is how a bug turns into a finding. It runs
the other way too, and did: while the agent had a message for it, a candidate
could have its own failure recorded as `verifier-failed`, which is how a broken
scheduler turns into a false finding about the harness.

**A slow but valid schedule is not in that table.** `most-loaded-of-two` is one,
and its low score is correct. **Timeouts sit on the unrankable side** for the
opposite reason: a scheduler that ran out of wall clock has told us about the
machine, not the algorithm.

## Modules, split by what can be tested on its own

| the evaluator | owns |
|---|---|
| `simulator.py` | `Session`: the loads, the metered probe, the task stream, the trace |
| `protocol.py` | the message vocabulary the two processes share |
| `verifier.py` | the measuring process: drives the session, spawns the agent, classifies |
| `agent.py` | the only program that imports candidate code, in a process of its own |
| `reports.py` | reading one report, and refusing an inconsistent one |
| `workloads.py` | the three splits and their identities |
| `surface.py` | the declared surface, the baseline scheduler, the scope checks |
| `outcomes.py` | scoring, the report shapes, the outcome-to-typed-failure map |
| `bounds.py` | every declared budget, process limit, and ceiling, all derived; and a split with nothing in it refused by name |
| `confinement.py` | the kernel boundary: no process it launches can read or write this repository |
| `landlock.py` | the Linux mechanism, run as a script: restrict this process, then become the real command |
| `identity.py` | what the evaluator declares itself to be, and what moves it |
| `execution.py` | workspace injection and sandbox execution |
| `policy.py` | the selection rule: one ordering, one version, declared |

| the candidate side, the decision, the command | owns |
|---|---|
| `schedulers.py` | the eight scheduler rewrites, as source text |
| `plan.py` | the plan and the whole proposal decision, in stdlib-only Python |
| `propose.py` | the confined process's entry point: one context in, one proposal out |
| `handoff.py` | the proposer boundary: what crosses it, and what is checked on the way back |
| `proposals.py` | the kernel-facing half: `ProposerSpec`, the declaration, the citations |
| `decision.py` | what an attempt, a selection, and a comparison are |
| `invariants.py` | the rules between a record's sections, refused rather than reported |
| `development.py` | the one durable-trial projection shared by creation and replay |
| `observations.py` | completed clocks retained outside deterministic decision identity |
| `record_io.py` | canonical bytes, content identities, path resolution, and the typed reads every door goes through |
| `record.py` | the verified envelope one command leaves behind |
| `selection.py` | published post-search selection, final comparison, counts, and clocks |
| `audit.py` | reading the directory back: the store and the record, cross-checked |
| `reporting.py` | how a negative, a tie, four refusals, and no verdict are made legible -- and the exit code a disagreeing replay leaves behind |
| `declarations.py` | what the two components claim to be, and the manifests a replay verifies |
| `command.py` | search, select, compare once, record, replay |
| `main.py` | the entry point, and nothing else |

`verifier.py`, `agent.py`, `protocol.py`, and `simulator.py` are ordinary modules
that are *also* injected into each workspace under underscored names. Each falls
back from a relative import to a flat one, so the same file is importable and
unit-testable here and runnable there.

**It is a package, and that is a correctness property.** Example modules imported
by bare name share one `sys.modules` namespace with every other example in the
repository, so a second `evaluation.py` or `simulator.py` anywhere under
`examples/` silently wins or loses on import order -- this one collided with
`examples/research/harness_evolution`. A test asserts that importing
it claims no bare top-level name, and that it and a bare-named sibling survive
being imported in either order.

## The fixture proposer, and what is scripted about it

`propose_scheduler` is a plain function, and it decides nothing. It serializes
what the run's context policy pushed to it -- unfiltered -- into a workspace, runs
`plan.py` there in a confined process, and validates what comes back. `plan.py` is
where the reading happens: the most recent public development evaluation, cited in
`derived_from`, with the parent it edited named by content digest and the numbers
it read retained as `proposal-basis` evidence, and one scheduler written.

Both halves state what they did, and every statement is cross-checked. The
confined side reports which parent it edited, which observation it read, and the
three numbers it read off that observation; this side re-derives all five against
the payload it actually serialized, and a mismatch is a typed proposer failure
rather than a proposal recorded with evidence nobody can trust. The numbers are
checked because verifying only that the cited step exists lets all three be
replaced with `999.0` and still become durable `proposal-basis` evidence -- which is the causal evidence
[#195](https://github.com/sentient-xyz/meta-evolve/issues/195) asks for, fabricated.

Every field also has to arrive as the JSON type it claims: an integer that is not
a boolean for a step or a count, a finite number that is not a boolean for a
metric, text for text. **Nothing is coerced**, because coercion is not validation
and the coerced value is not what gets retained -- `int(0.9)` is `0`, `float("0.5")`
is `0.5`, and `Infinity` survives `json.loads`. All four get past a version
written with `int(...)` and `float(...)`, while the *original* value is what goes
into the evidence. Nor may the validator itself fail: integers are treated as
finite by construction rather than handed to `math.isfinite`, which raises
`OverflowError` on one too large for a float, and a validator that raises past its
caller is not a refusal.

The containers holding those fields are read by the same rule, which took a round
longer to get there. Every mapping and list a record retains -- the sections, a
split's attempts, the two mappings an attempt carries, its evidence, the retained
timings -- went through `dict()` or was iterated straight, and those are the same
coercion one level out: a section written as a number reached a constructor and
came back as `'int' object is not iterable`, naming a Python type instead of the
field. Twelve of them, one rule each for mappings and lists, and the law that
forbids coercions at doors knows the two container names it was missing. That
law reads source rather than resolving symbols, so what it enforces is one
shape -- a call written `coercer(...)` in a module that binds no name over a
coercer -- and it refuses to analyse a module that aliases or shadows one
rather than guessing. `..._reads.py` states the boundary and is tested against
both sides of it.

Anything else from that process is the same refusal: a crash, silence, noise, or
more than one line on stdout. Exactly one JSON object crosses, and reading only
the *last* line would let arbitrary output through in front of a valid payload.

The tree itself is asked of `SourceTree` rather than re-checked here, and asked
where a failure is still this module's to type: a payload naming an absolute or
unnormalized path passes every check above, because those paths are strings like
any other. The kernel would catch the resulting `ValueError` and record a proposer
failure regardless -- but a promise kept by somebody else is not a promise this
module gets to make.

**The order of the plan is a fixture decision, not a finding.** A live proposer
choosing from the same observations would pick its own edits and would not
helpfully produce one of each outcome class. The plan exists so a single command
exhibits every outcome this example claims to keep inspectable, instead of
describing them in prose and hoping.

What is *not* scripted is any number: every score above comes from running the
scheduler. Which plan entry is next comes from the serialized logical step, which
keeps the proposer a pure function of what it was handed -- what lets it be
registered as deterministic and replayed. Counting *ancestors* would not work: a
search that keeps its parent through a failed trial has no new ancestor to count.

## Replay, and what the record holds

The command writes one JSON file beside the durable store, **named by the digest
of its own contents** -- `decision-<digest>.json` -- and then reads it back with
nothing in hand but the directory. Between the store and that file, the whole
decision is reconstructable:

| reconstructed from | what |
|---|---|
| the durable store | the best artifact, the lineage, every trial's metrics and per-scenario evidence |
| the record | every later attempt, all evaluator identities, the executable selection policy, counts, timing observations, winner, and verdict |

Two properties make that worth something, and they are separate.

**Verified, not just written.** The deterministic decision has one digest; the
complete envelope, including real wall-clock observations, has another repeated
in the filename. `read` verifies both. Two fixed-seed processes therefore agree
on decision bytes and identity even when their clocks differ. `O_EXCL` alone is
not immutability: it stops one function from writing the same pathname twice, and
nothing stops a later ordinary write from replacing the file -- a rewritten
held-out quality loads cleanly.

**Independent, not a round trip.** `audit.replay` takes one argument, the output
directory. Taking the live `meta.Run` and the in-memory `Decision` as its
expected values would leave it unable to fail in any way a fresh reader would
notice -- a fresh reader has neither. It reads the two things the directory holds,
neither derived from the other: the store the kernel wrote *during* the run, and
the record this command wrote *after* it. Every check can come back false, and a
test drives each with a forged record -- candidate identity, outcome, failure
detail, usage, per-attempt work, timing, and the totals -- and another runs replay in a
separate interpreter handed nothing but the path. It runs no workspace, no
subprocess, no simulator, and not even this example's evaluator -- which is what
auditing a selection without re-paying for the machinery means.

**What the digest does not buy, at its real size.** A rewrite that edits the
decision, reseals both digests, *and* renames the file is self-consistent. The
development section survives it anyway, because the store was written
independently. For the sections written *after* the run the answer goes row by
row, and the honest table is longer than it first looks:

| forged in a later section | caught | by what |
|---|---|---|
| a **measurement** -- a private or held-out quality | no | nothing; the store never saw the later splits |
| a later **clock reading**, with the retained total moved to match it | no | nothing; the same reason |
| the **private or held-out evaluator identity** | no | the store never ran those evaluators; only their being three distinct declarations is checked |
| the retained **scenario ceiling** the reader is shown | no | it is a declared bound, not a measurement; it is derived from the splits the command ran, but nothing in the directory re-derives it |
| the retained **selection policy** restated as a whole, or under a version scheme this repository does not implement | no | nothing outside the record declares the rule that record was selected under |
| one **label** of that policy -- its name, its tie-break prose, its ranking, or its source digest -- restated on its own | yes | the version is a fold of exactly those four fields, so a restated label no longer folds to the version beside it |
| a **field nobody declared**, smuggled into the envelope, a section, an attempt, or the accounting | yes | both retained sections are rebuilt on read and compared against the file that produced them -- the one fault no type rule can see, since nothing declares the field |
| a **section, split, or mapping** written as something other than the container it is | yes | every door reads its containers through one rule, so the refusal names the field rather than being whatever touched the value first |
| a candidate **identity** the search never evaluated | yes | the private split has to be *exactly* the development candidates that ranked |
| a development refusal promoted to winner | yes | the same rule: source that would not parse is never privately scored |
| a baseline that is not the seed, or a comparison of a candidate that was not selected | yes | `Decision` refuses to exist |
| counts that are not the counts of the retained work | yes | re-derived from the attempts, per split *and* per attempt |
| the retained total wall clock, moved on its own | yes | the store recorded what the search cost |
| a clock reading dropped, duplicated, or relabelled | yes | one reading per attempt, matched both ways |
| an attempt filed under a split it does not claim | yes | the sections are named for the splits they hold |
| a scenario observation claiming a different split or outcome from its attempt | yes | every observation must match its split; scenarios preceding a failure must have completed |
| the **random seed**, the **proposer**, the **development evaluator**, or the **seed artifact** | yes | the run's own start declaration, kept by the store before a candidate was scored |

So the open gap is the five rows above: a later **number**, a later **clock
reading**, the two later **evaluator identities**, the one declared bound that is
retained rather than counted, and a selection policy restated *consistently* --
its labels are pinned to its version, but nothing outside the file declares
either. Everything below them in that table is
pinned to the development section -- `invariants.py` holds those rules and
refuses rather than reports -- and the development section is the half the store
witnesses attempt for attempt. Forging a later **candidate** identity therefore
means forging the search to match, which the provenance laws further up this stack do: the record
loads, and the store objects anyway. A later *evaluator* identity is not
anchored that way and is one of the five.

Checked by membership alone, a record can rename a losing candidate, drop one,
duplicate one, promote a scheduler that did not parse, compare against a baseline
of its choosing, restate its own counts, file a private attempt under the
held-out split, or rewrite the seed and the proposer it ran with -- and pass
every check a replay makes. Closing the five that
remain needs an anchor outside the output root -- a signature, or an append-only
log -- which this example does not have. Tamper-evident, then, and specific about
what it evidences; `record.py` argues it in full and a test pins each row above.

Post-search selection and the final comparison are outside the *run* on purpose.
Being outside the run is not licence to be outside the record, so
every attempt each split makes is retained there, including the ones that
produced no metric, with its typed failure, evidence, scenario count, and usage.
This also holds when every development attempt fails: the command writes the
decision and timing records, skips later measurements, and exits unsuccessfully.
Replay verifies the retained failures without requiring a best candidate or
executing the proposer or evaluator again.
Keeping three floats per selection candidate and dropping every selection
failure would let replay report that it had reconstructed "the decision" when it
had reconstructed the search.

**The three sections hold different candidate sets, and the record is read as a
whole.** Nine development attempts, five selection ones, two final. A candidate
whose *development* evaluation failed is never scored again: it produced no
evidence to select on, its typed refusal is already in the development section,
and source that will not parse will not parse on another split either. A test
asserts that as an exact equality rather than leaving it to the reader, because
"every attempt on every split" would read as though all nine were scored three
times.

**Clock readings are observations, not decision facts.** Per-scenario wall clock
is absent because identical evidence across processes is the claim and a clock
cannot satisfy it. Completed per-attempt and total timings live in the record's
`observations` section, outside `Decision` equality and digest. The complete
record may differ across machines; the decision payload, decision digest,
evidence, selection, and command output do not.

## No supplied proposer, and the fixture confined too

`search` and `run_example` take the committed fixture and nothing else. There is
no `ProposerSpec` parameter and no separate **Experimental/live-only** mode for
proposers that cannot promise reproducibility, and the reason is [#195](https://github.com/sentient-xyz/meta-evolve/issues/195)'s
separation gate: *held-out facts cannot reach proposal context.*

A supplied proposer would be ordinary Python **in this process** -- the one that
imported the later workloads. It could read them, or call their evaluator and
compute their answers during its own invocation, and no confinement applied to
the *candidate* reaches a proposer at all.

Removing the parameter closes the API and not the authority -- the same finding
in different clothes, because the committed fixture is still a callable in this
same process. So the second half was built:
the fixture's decision moved into a confined process that receives one serialized
development context and can neither read nor write this repository. `plan.py` is
the decision, `propose.py` is its entry point, `handoff.py` is the crossing, and
the crossing laws drive it from the inside. That is **filesystem** authority, not
sequencing in trusted code.

Filesystem confinement is not the whole gate, and the gate does not rest on it
alone. *Held-out facts cannot reach proposal context* is closed three times over by
the declaration and crossing laws, and not one of the three is a promise about what the fixture
chooses to look at. The splits are scored in exactly one order, checked by
recording it: every development score inside the search, every private score only
after `meta.run` has returned, held out last of all and only after selection --
so at the moment any proposal is made, no later result exists for one to reach.
No later suite fact appears anywhere in the recorded run. And every payload the
real search sent is inspected for later scenario names and for metrics outside
the development evaluator's set, the second being the one that catches a
widening, since a private score arrives as a number long before it arrives as a
name.

Confinement is what makes that hold against code rather than against review, on
the route this repository is the carrier for: reading the file. The socket route
stays open, and closing it would be a different claim rather than a stricter one.
There is no proposer to supply -- the parameter is gone, and `search` takes the
fixture and nothing else -- so egress would serve a proposer that does not exist
here; and the one this directory says is missing is a model on the far side of
the boundary, which needs egress in order to exist at all. What a socket could
still fetch is the later *questions*: `PRIVATE` and `HELD_OUT` are committed
literals because the run has to be reproducible from what is committed, so the
property that makes this example checkable is the same one that publishes them.
SBPL could deny the network where Landlock cannot below ABI 4 and governs only
TCP above it, which would be exactly the platform-dependent guarantee an earlier
round warned against declaring. So what stands against code that opens sockets is
that the fixture is committed, deterministic, and reviewable -- a weaker thing,
and named as one.

What it costs, said plainly: there is no live path here at all, so nothing in this
directory demonstrates a model proposing a scheduler. `examples/agents/` holds the
live-proposer patterns. What a future adapter needs in order to bring one here now
exists -- a confined proposer host -- but it takes plain data across that boundary,
so an adapter that wants a model on the far side has to put the client there too,
and declare it.

## Non-claims

Stated plainly, because the paper claims more than this example demonstrates:

- **Not a reproduction.** This does not reproduce ADRS's ten case studies, its
  framework, its models, its iteration counts, its load-balancing system, or any
  of its reported improvements. It is a small mechanism inspired by the paper.
- **Nothing upstream is vendored or claimed.** No ADRS fixture, workload, or
  algorithm is copied. If a future adapter wants them it must pin the upstream
  commit and honour its licence.
- **The simulator is not a cluster.** No network, queueing, contention, failures,
  heterogeneity, or clock. `power-of-two-choices` winning here is a statement about
  this simulator, not about production scheduling -- though the result it gestures
  at is a real and well-known one.
- **The boundary is about measurement, not safety.** The protocol carries no
  candidate-supplied score, and the candidate cannot open the repository file
  holding the workloads. Network, CPU, memory, and syscalls generally are *not*
  confined -- so the published literals stay fetchable over a socket, and this is
  not a claim that hostile code is safe to run here; see [Authority](#authority).
- **The workloads are published, not secret.** They are committed literals in
  `workloads.py`, readable by anyone with the repository -- which is deliberate,
  because an example whose workloads you cannot read is one you cannot check.
  What is enforced is narrower and is the thing that matters: during a run,
  neither the process holding candidate code nor the process deciding what to
  propose can open this file -- which is the file route and not every route,
  since egress is confined on neither platform. The interpreter installation
  inside this repository stays readable, and `readable_paths` refuses to run at
  all if that exemption would ever cover this example's own directory.
  Confinement is per-platform, and a machine offering neither mechanism refuses
  to run rather than scoring unconfined. The shared declaration covers only that
  repository boundary: macOS otherwise allows filesystem access by default,
  while Landlock denies handled reads outside its interpreter, system and
  workspace allow-lists. Writes agree: both deny everything but the workspace
  and `/dev/null`. Candidate code can observe the read difference, so the
  evaluator identity does not claim equivalent authority outside the repository.
- **Write isolation between workspaces, but not read isolation.** A writable
  system temporary directory -- "deliberately, because that is what scratch space
  is for" -- lets a candidate write a file while measured on development and read
  it back on private. Writes
  are an allow-list on both platforms now -- the process's own workspace and
  `/dev/null`, nothing else -- so that channel is closed. Reads are not symmetric
  and are not claimed to be: macOS allows reading anything outside this
  repository, and Landlock's readable list includes `/tmp`, so a candidate that
  knew another workspace's path could read it. It could not put anything there.
  Still not a sandbox for two hostile candidates side by side; it is a boundary
  between a candidate and the questions, plus enough to keep the splits apart.
- **The record is tamper-evident, not immutable.** Editing it is caught, and the
  development section is witnessed by a store written independently. Every later
  candidate *identity* and every count is pinned to that section, so forging one
  means forging the search too. What is not detectable from the output directory
  is a self-consistent rewrite of a selection or final *number*, of a later
  clock reading with the total moved to match, or of the two evaluator identities
  the store never witnessed -- all on a candidate that really ran.
- **No live measurement.** Every number above comes from the deterministic plan.
  The live-call ceiling says what a wrapper *would* cost, not what one did.
- **One split agreeing is not generalization.** The selection and final splits
  agree with the development ranking here, which is what makes the comparison
  worth reporting. It is not evidence that this mechanism transfers.
- **No promotion.** The command prints a verdict. Promotion is external, and
  nothing here exports an artifact.
- **Sequential only.** No parallel workers. Concurrency is M11's.

## Tests

Every test file here drives the example's own functions, and each has one
subject. The `_systems_optimization*` helpers sit beside them, holding the
fixtures more than one file needs -- a real run, the filesystem routes, and the
shared spellings.

The table below is **not an inventory**, and reading it as one is how it went
stale: it names the files whose subject is not obvious from the filename, and
what each of them pins. A file missing from it is not missing coverage --
`..._workspace.py` tests the workspace, and the row would say so. Each file's
own module docstring is the authority on what it grades; this is a reader's way
in, not a census.

**On file length.** `AGENTS.md` asks for a split by independently testable
responsibility, or a documented reason. Where there is a real seam it was taken:
`..._guards.py` is what the Linux mechanism refuses to do, apart from
`..._landlock.py`'s arithmetic and shape; `..._workspace.py` is the directory a
scenario borrows, apart from `..._execution_core.py`'s claims about what the
evaluator returns; `..._enforcement.py` is whether the kernel actually denies,
apart from every other confinement law, which is about what this example
decides.

Where there is no seam the file stays long and its own docstring says why --
every file of this example at or over the guideline carries that note, and says
what splitting it would separate. `..._crossing.py` and `..._decision.py` are
each one subject driven many ways, and the only split available would be "the
first half of the cases". `decision.py` is the largest module, and the one place
a split was considered and refused: the seam is available -- the value helpers
against the three dataclasses that retain them -- and taking it would put
`Attempt`'s rule about its own fields in a different file from `Attempt`, which
is the opposite of the reasoning that moved `MINIMUM_LANDLOCK_ABI` *into*
`landlock.py`.

This section does not carry a census of how many files there are, how many are
over the line, or which ones by name. It used to, along with a law that parsed
all of it out of this document. An accurate directory count is not evidence that
a design is small, it went stale on every split, and `wc -l` answers it for
anyone who wants the number.

**These rows are a way in, not a list of the test files.** They are the ones
whose subject is not obvious from the name; every other file says what it grades
in its own module docstring, which is the authority either way. Counting the
rows against the directory is the mistake this section must not invite.

| file | what it pins |
|---|---|
| `..._authority.py` | what the candidate cannot **hold or reach**: the loads array, a probe counter, a trace, a placement, and the injected simulator and protocol it can freely monkeypatch to no effect |
| `..._channel.py` | what it cannot **say**: forged reports on stdout and on descriptor one, `os._exit`, `atexit`, and talking past its own proxy -- which is charged, and cannot report; plus the two forgeries of an evaluator fault, through the proxy and on the private descriptor before the handshake is answered, and the silence a handshake the agent cannot act on ends in |
| `..._confinement.py` | what it cannot **see** through the protocol -- `sys.argv`, the scenario file, the environment, the task stream -- and what killing the verifier or refusing to answer gets it |
| `..._reports.py` | eleven ways a report can fail to describe what was asked for, plus a report beside a non-zero exit, each refused rather than scored; and the same argument on the way out, where both counts are held to one rule both processes share and a bad one never leaves this side |
| `..._example.py` | the run end to end, stable output, two processes sharing one decision identity despite different clocks, and the exit code the entry point hands the shell |
| `..._decision.py` | candidate sets, a selection refusal, one named refusal shared by both entry points rather than an `assert` in the exported one, selection overruling development, and a final split yielding no number |
| `..._surface.py` | both surface layers, a workspace holding only regular files, and that the off-surface candidate would have worked if inlined |
| `..._guards.py` | what that mechanism refuses to do at all, each guard the enforcer's half of a line the selector already held: a non-Linux platform, an ABI below the floor, a C library missing either symbol the boundary calls, and an argument shape the launcher checks and the entry point must not trust |
| `..._landlock.py` | the Linux mechanism, decided off Linux: rights that grow with the reported ABI and never shrink, the handled set bit by bit, the argument contract with the launcher asserted from both ends, an inert import, standard-library imports only, and the file starting as a loose script exactly as the launcher runs it |
| `..._profile.py` | the macOS mechanism, decided off macOS: every denial ahead of everything handed back, writing denied from the root down where reading cannot be -- deny-by-default reading does not survive interpreter startup -- the repository exempted for reads and never for writes, the workspace writable only because its own allow comes after that root denial, and each of the three characters that would end an SBPL string refused, against the one tuple that declares them |
| `..._measurements.py` | what may be a number in the record, one test per layer, each layer deeper than the last: the ranked fields required to be present, then to be finite -- with the ordering hazard planted past the constructor, to show that refusal is load-bearing -- then to be numbers at all rather than coerced from text or a boolean, then a record serialized as JSON a reader outside Python can parse; plus a number that passes retained as the type it arrived as, and all three ways of building an attempt required to give one answer |
| `..._filesystem.py` | twelve repository routes -- seven reads or observations plus five writes or links, including a child, `ctypes`, listing, symlink, truncate, hardlink, and Linux `/proc` alias -- each applicable route refused with the kernel's exact errno; plus the Landlock ABI floor below which there is no mechanism, four exemptions that may not reach the example, an inexpressible path, the no-mechanism refusal, and the meter surviving all of it |
| `..._record.py` | both content identities, rewrite refusal, summaries derived from attempts, and no field the reader does not read back -- smuggled at five levels, since a digest over stored bytes pins them against themselves |
| `..._reads.py` | every value the record retains read back at the type it was written or refused, the sections nobody reported held to the same rule, the declared types pinned against the payloads they check, and no door allowed to coerce again -- `dict` and `tuple` included, whose absence from that law is what lets the containers survive it -- a seed of `0.9` loaded as `0` and replayed as agreeing |
| `..._replay.py` | forged development metrics, a dropped attempt, timing, a fresh-interpreter replay, and the two later readings nothing witnesses |
| `..._invariants.py` | the four ways a selection section can stop covering the search, a promoted refusal, a chosen baseline, a decision that selected nothing, and counts that are not the counts |
| `..._provenance.py` | every durable attempt field against the store, a phantom written into the search itself, and one clock reading per attempt |
| `..._policy.py` | the executable retained ranking, its version folded from the rule beside it so a restated label is refused, the declared source list pinned by name, an empty declaration refused rather than given today's rule, and an older rule surviving a current-rule change anyway -- which is the bound on the fold |
| `..._declarations.py` | every module of this example required to be in a declaration or named as deliberately in none, every sibling a declared adapter imports required to be declared too, the count `identity.py` states for the modules in neither list, and no rule of this example carried by an `assert` that `python -O` would delete |
| `..._failures.py` | every unrankable outcome driven deliberately, the evaluator's own failure typed apart from abandonment, and the counterpart claim that a merely bad scheduler stays rankable |
| `..._accounting.py` | derived budgets, nested clocks, counts that match the work, and every retained clock held to the exact figures the proposal and scenario seams reported |
| `..._failure_retention.py` | all-failed development retained and replayed, proposal refusals excluded from evaluation counts, and contradictory scenario evidence rejected |
| `..._evaluator_version.py` | every applied process bound declared, and every evaluator-owned module moving the declared version when it is edited |
| `..._separation.py` | fixture ordering, no later fact in its recorded run, exact citations, and collision-free module names |
| `..._handoff.py` | the proposer boundary driven from inside it: reads and writes at `workloads.py` refused, only development facts crossing, the confined decision equal to the in-process one, the policy and every applied bound declared, five ways of not answering, and no proposal at all without a mechanism |
| `..._proposal.py` | what may become `proposal-basis` evidence: twenty payloads refused -- six that misstate what the proposer did, a parent never handed over and a record never given among them, three numbers quoted off no record, and eleven values of the wrong JSON type or beyond a float -- four trees this task cannot hold, and every required field required to have a declared type |
| `..._scratch.py` | where a confined process may write, driven rather than described: two workspaces sharing no writable directory, `$HOME` and both temporary trees refused, and the one black hole the agent blinds descriptors with -- granted as a file, because the directory holding it is a shared tmpfs; plus the arithmetic behind the same claim, a readable path granted no right to write and a readable file no right to be enumerated |
| `..._degenerate.py` | inputs and records that do not add up: an empty split, one scenario name meaning two measurements refused where repeating a scenario is not, a retained ceiling the counts beside it exceed, and every one of the fourteen containers a record holds refused by name in a resealed record rather than crashing whatever touched it first, including the two outermost -- the whole observations section and a file whose JSON root is not an object at all |

## Sources consulted

- <https://arxiv.org/abs/2512.14806> -- *Let the Barbarians In: How AI Can
  Accelerate Systems Performance Research*
- <https://github.com/UCB-ADRS/ADRS> -- the upstream repository, read for scope
  and boundaries only; nothing from it is vendored here

Related future work, none of it depended on or closed by this example:
[#118](https://github.com/sentient-xyz/meta-evolve/issues/118) (hardware
evidence), [#143](https://github.com/sentient-xyz/meta-evolve/issues/143)
(monetary cost),
[#163](https://github.com/sentient-xyz/meta-evolve/issues/163) (finite
trial-budget inheritance -- this example declares its budget outright instead),
and [M11](https://github.com/sentient-xyz/meta-evolve/issues/10) (trusted parallel
workers).
