"""The fixed load-balancing simulator, owned by the evaluator and never edited.

A scheduler's whole job here is to answer one question per task -- *which
worker?* -- and the only thing it may ask before answering is how loaded a
worker currently is. Each such question is a **probe**, and probes are counted,
because a scheduler that queries every worker on every task buys its balance
with work it has to do in the request path. That tension between balance and
scheduling cost is the reason this example has anything to search over.

Everything here is driven, never called back into. ``Session`` is a state
machine the *verifier* advances: it hands out one task at a time, answers
probes it has charged for, and accepts one placement. No candidate object,
callable, or module is ever passed to this module, which is what lets the
metering be an actual boundary rather than an honour system -- see
``verifier.py`` for the process split that carries candidate code.

The simulator is deliberately boring physics: no randomness that is not seeded
here, no clock, no I/O. Two runs of the same scenario against the same
scheduler produce byte-identical traces, which is what lets one command have a
stable output and lets a replay reconstruct a decision without rerunning
anything.

Scoring lives in ``outcomes.py``, not here. This module reports what happened;
the evaluator decides what it is worth.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines:
``Scenario``, ``Session`` and ``Trace`` are one physics -- the workload, the
state machine that runs it, and what the run observed -- and each is meaningless
without the other two. They are also materialized together into every candidate
workspace as one injected module, so splitting them would add a file to that map
for no reader's benefit. Most of what is here is the reasoning behind the
metering and the seeding, which is the part a reviewer needs.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256


SIMULATOR_VERSION = "probe-counted-session-v2"


class InvalidPlacement(Exception):
    """The scheduler named something that is not a worker of this cluster."""


class ProbeBudgetExceeded(Exception):
    """The scheduler asked for more worker loads than the scenario allows."""


class OutOfOrder(Exception):
    """The session was driven out of order.

    Always an evaluator bug. No candidate can reach this class, let alone drive
    a session, so a raise here means the verifier's own loop is wrong.
    """


@dataclass(frozen=True, slots=True, kw_only=True)
class Scenario:
    """One fixed workload: a cluster shape, a task stream, and a probe cap.

    ``probe_budget`` is a *per-task* cap and a declared constraint rather than a
    scoring term: exceeding it is a constraint violation with no rankable
    metric, while staying under it and being expensive is ordinary evidence
    that costs the candidate score.
    """

    name: str
    workers: int
    sizes: tuple[int, ...]
    probe_budget: int

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("scenario name must be non-empty")
        if isinstance(self.workers, bool) or not isinstance(self.workers, int) or self.workers < 2:
            raise ValueError("scenario must have at least two workers")
        if not isinstance(self.sizes, tuple) or not self.sizes:
            raise ValueError("scenario must have at least one task")
        if any(isinstance(size, bool) or not isinstance(size, int) or size <= 0 for size in self.sizes):
            raise ValueError("scenario task sizes must be positive")
        if isinstance(self.probe_budget, bool) or not isinstance(self.probe_budget, int) or self.probe_budget < 0:
            raise ValueError("scenario probe budget must not be negative")

    @property
    def digest(self) -> str:
        """A stable identity for this workload, used in evaluator declarations."""

        payload = f"{self.name}|{self.workers}|{self.probe_budget}|{self.sizes}"
        return sha256(payload.encode("utf-8")).hexdigest()[:16]

    def to_payload(self) -> dict[str, object]:
        """The exact JSON the verifier is handed. No candidate ever reads it."""

        return {
            "name": self.name,
            "workers": self.workers,
            "sizes": list(self.sizes),
            "probe_budget": self.probe_budget,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, object]) -> Scenario:
        if not isinstance(payload, dict):
            raise ValueError("scenario payload must be an object")
        name = payload.get("name")
        workers = payload.get("workers")
        sizes = payload.get("sizes")
        probe_budget = payload.get("probe_budget")
        if not isinstance(name, str):
            raise ValueError("scenario name must be a string")
        if isinstance(workers, bool) or not isinstance(workers, int):
            raise ValueError("scenario workers must be an integer")
        if not isinstance(sizes, list) or any(
            isinstance(size, bool) or not isinstance(size, int) for size in sizes
        ):
            raise ValueError("scenario sizes must be a list of integers")
        if isinstance(probe_budget, bool) or not isinstance(probe_budget, int):
            raise ValueError("scenario probe_budget must be an integer")
        return cls(
            name=name,
            workers=workers,
            sizes=tuple(sizes),
            probe_budget=probe_budget,
        )


class Session:
    """One scenario in progress, and the only thing that can measure anything.

    The verifier drives it: ``next_task`` to get a size, ``probe`` and ``pick``
    to answer questions on a candidate's behalf, ``place`` to apply the answer.
    Nothing on this class accepts a callable, so there is no arrangement of
    candidate code that can run inside the process that owns these counters.

    ``probe`` is the metered surface. ``pick`` is free because it is not a query
    about the cluster: it hands back a worker index from a fixed sequence, which
    is how a scheduler that wants two arbitrary workers to compare gets them
    without any entropy source and without being able to reseed anything.
    """

    __slots__ = (
        "_budget",
        "_index",
        "_loads",
        "_open",
        "_placements",
        "_probes",
        "_sizes",
        "_spent",
        "_state",
    )

    # A fixed 64-bit linear congruential generator, stated here rather than
    # imported, so that ``pick`` spreads well without reaching ``random``.
    _MULTIPLIER = 6364136223846793005
    _INCREMENT = 1442695040888963407
    _MODULUS = 1 << 64

    def __init__(self, scenario: Scenario) -> None:
        self._loads = [0] * scenario.workers
        self._sizes = scenario.sizes
        self._budget = scenario.probe_budget
        self._index = 0
        self._open = False
        self._placements: list[int] = []
        self._probes = 0
        self._spent = 0
        # Seeded from the cluster's shape and from nothing else, because the
        # shape is what the handshake already tells the candidate. This used to
        # be seeded from the number of tasks, which the handshake deliberately
        # does not: ``pick`` is free and uncapped, so a scheduler can pull an
        # unbounded stream from one open task, and ``_simulator.py`` is
        # materialized readable in the workspace, so the constants above are in
        # its hands. That made the sequence an oracle for the task count -- a
        # search over plausible counts rather than an inversion, since ``trace``
        # truncates, but a search for a number ``protocol.BEGIN`` promises is
        # withheld. Whatever seeds this has to be something already given away.
        self._state = len(self._loads) % self._MODULUS

    @property
    def workers(self) -> int:
        """How many workers exist. Told to the candidate once, in the handshake."""

        return len(self._loads)

    @property
    def probes(self) -> int:
        return self._probes

    @property
    def placed(self) -> int:
        return self._index

    @property
    def complete(self) -> bool:
        return self._index == len(self._sizes) and not self._open

    def next_task(self) -> int | None:
        """Open the next task and return its size, or ``None`` when done."""

        if self._open:
            raise OutOfOrder("a task is already open")
        if self._index >= len(self._sizes):
            return None
        self._open = True
        self._spent = 0
        return self._sizes[self._index]

    def probe(self, index: object) -> int:
        """Return one worker's accumulated load. Costs exactly one probe."""

        if not self._open:
            raise OutOfOrder("no task is open to probe for")
        if isinstance(index, bool) or not isinstance(index, int):
            raise InvalidPlacement(f"worker index must be an integer: {index!r}")
        if not 0 <= index < len(self._loads):
            raise InvalidPlacement(f"no such worker: {index!r}")
        self._spent += 1
        self._probes += 1
        if self._spent > self._budget:
            raise ProbeBudgetExceeded(
                f"probed {self._spent} workers for one task; "
                f"the budget is {self._budget}"
            )
        return self._loads[index]

    def pick(self) -> int:
        """Return the next index of a fixed, seeded sequence. Costs nothing."""

        if not self._open:
            raise OutOfOrder("no task is open to pick for")
        self._state = (
            self._state * self._MULTIPLIER + self._INCREMENT
        ) % self._MODULUS
        return (self._state >> 33) % len(self._loads)

    def place(self, index: object) -> None:
        """Apply one placement and close the task, or refuse the whole schedule."""

        if not self._open:
            raise OutOfOrder("no task is open to place")
        if isinstance(index, bool) or not isinstance(index, int):
            raise InvalidPlacement(f"placement must be an integer: {index!r}")
        if not 0 <= index < len(self._loads):
            raise InvalidPlacement(f"placement names no worker: {index!r}")
        self._loads[index] += self._sizes[self._index]
        self._placements.append(index)
        self._index += 1
        self._open = False

    def trace(self) -> Trace:
        """What the completed schedule observed. Refuses a partial schedule."""

        if not self.complete:
            raise OutOfOrder(
                f"placed {self._index} of {len(self._sizes)} tasks; "
                "a partial schedule has no trace"
            )
        return Trace(
            loads=tuple(self._loads),
            placements=tuple(self._placements),
            probes=self._probes,
            tasks=len(self._sizes),
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Trace:
    """What a completed simulation observed. Facts only; no score."""

    loads: tuple[int, ...]
    placements: tuple[int, ...]
    probes: int
    tasks: int

    def __post_init__(self) -> None:
        """Refuse a trace whose own derived numbers would divide by zero.

        Both properties below divide by something this class accepts, and the
        checks holding that off lived in two other modules -- a guarantee by
        accident rather than by right, for a class that is public and built
        directly by tests. So it defends its own arithmetic.
        """

        # Two, not one: ``imbalance`` normalizes against ``total - mean``, and
        # on a single worker the max *is* the mean, so refusing only the empty
        # trace still divides zero by zero. ``Scenario`` has required two
        # workers all along, so this states the same physics where the division
        # happens rather than adding a restriction -- one worker has no balance.
        if len(self.loads) < 2:
            raise ValueError(
                "a trace with fewer than two workers has no imbalance to report "
                f"-- balance is a relation between workers, and this one has "
                f"{len(self.loads)}"
            )
        if self.tasks <= 0:
            raise ValueError(
                f"a trace of {self.tasks} tasks has no scheduling work to report"
            )
        if self.probes < 0:
            raise ValueError(f"a trace cannot have spent {self.probes} probes")
        if sum(self.loads) <= 0:
            raise ValueError(
                "a trace whose workers carry no load at all measures nothing; "
                "every task in this simulator has a positive size"
            )

    @property
    def imbalance(self) -> float:
        """Normalized load imbalance, in ``[0, 1]``. Lower is better.

        ``(max - mean) / (total - mean)``. Zero is a perfectly even split; one
        is every task on a single worker. Normalizing against the *worst
        possible* split rather than against the mean is what makes scenarios
        with different worker counts and different total work directly
        comparable, which in turn is what lets one aggregate cover a whole
        split without a scenario's size deciding how much it counts.
        """

        total = sum(self.loads)
        mean = total / len(self.loads)
        return (max(self.loads) - mean) / (total - mean)

    @property
    def work(self) -> float:
        """Scheduler cost: probes per task. Lower is better."""

        return self.probes / self.tasks


__all__ = [
    "SIMULATOR_VERSION",
    "InvalidPlacement",
    "OutOfOrder",
    "ProbeBudgetExceeded",
    "Scenario",
    "Session",
    "Trace",
]
