"""What a decision must satisfy to be one decision rather than three sections.

``decision.py`` says what an attempt, a selection, and a comparison *are*.
``policy.py`` owns the ordering. ``record.py`` owns the envelope. This module owns
the rules *between* the sections, and it refuses at construction rather than
reporting on read: a decision whose private split scored a candidate the search
never made, whose baseline is not the seed, whose final comparison scored someone
other than the winner, or whose counts disagree with the attempts they are
counting, is not a decision anybody should be able to hold.

**Why the later splits are pinned to the development section.** The store the
kernel wrote holds the search and nothing after it, so no check anywhere can
witness a private or held-out *measurement*. What it does witness, attempt for
attempt and field for field, is the development section -- ``audit.replay`` does
exactly that. So tying the later sections to the development section is what
carries the store's authority into splits the store never saw. Selection scores
exactly the development candidates that ranked; the baseline is the seed the
search started from; the comparison scores the candidate selection chose. Forging
a later *candidate* identity now requires forging the development section to
match, and that is the half the store objects to. The evaluator identities the
later splits declare are not anchored this way -- nothing here ran those
evaluators -- and ``record.py`` lists that with the other gaps.

Applied as *membership* -- was this identity somewhere in the store at all --
one rule covers none of this. Membership allows a losing candidate to be
renamed, one to be dropped, one to be duplicated, and, worst, a candidate whose
source did not parse to be resurrected as the winner,
because a failed development trial is still an identity the store holds.
Membership is the wrong question; coverage is the right one.
**On the file's length**, since AGENTS.md asks for a reason above 300 lines: the
subject is the rules *between* a decision's sections, so every rule is a
statement about two of them at once. Grouping them by section would put each
rule in whichever file the reader happened to open first; grouping them by kind
would separate a rule from ``counted``, the one projection both the writer and
the reader go through. What is here is one pass over one decision, and the
paragraphs are the arguments for rules that cannot be derived from a section
alone.
"""

from __future__ import annotations


from collections import Counter
from collections.abc import Iterable

from .decision import Accounting, Attempt, Comparison, Selection, _measurements
from .policy import RANKED_FIELDS, check_declaration


def identity(attempt: Attempt) -> tuple[str, str, int]:
    """What names one candidate across splits: who it is, and what it was.

    Deliberately *without* the split. Matching a private attempt to the
    development attempt it must correspond to is the whole job, and a key that
    included the label could never match across two sections. Which section an
    attempt is actually in is a separate rule -- ``_sections_are_labelled`` --
    because it is a separate claim.
    """

    return (attempt.candidate, attempt.digest, attempt.logical_step)


def observed_runs(attempt: Attempt) -> int:
    """The scenario runs this attempt's own retained evidence accounts for."""

    return sum(
        1 for frame in attempt.evidence if frame.get("kind") == "scenario-observation"
    )


def counted(
    development: tuple[Attempt, ...],
    selection: Selection,
    comparison: Comparison | None,
    *,
    ceiling: int,
) -> Accounting:
    """The accounting these attempts imply, computed in exactly one place.

    ``selection.account`` calls this when a record is written and ``check`` calls
    it when one is read, so "the counts are what happened" is a single projection
    rather than two implementations that agree until they do not. The ceiling is a
    declared bound that no attempt can derive, so it travels in.
    """

    groups = {
        "development": development,
        "private": selection.attempts,
        "held_out": () if comparison is None else (comparison.baseline, comparison.selected),
    }
    return Accounting(
        evaluations={
            name: sum(item.evaluated for item in items) for name, items in groups.items()
        },
        scenario_runs={
            name: sum(item.scenario_runs for item in items)
            for name, items in groups.items()
        },
        scenario_ceiling=ceiling,
    )


def _ceiling_bounds_the_runs(accounting: Accounting) -> None:
    """The declared ceiling has to bound the counts retained beside it.

    Checked here and not folded into the comparison below, because the
    comparison cannot see it. ``check`` passes the stored ceiling into
    ``counted``, which copies it straight through, so that term of
    ``implied != decision.accounting`` agrees by construction whatever it says.
    A ceiling of 1 against 32 retained scenario runs, resealed into the record,
    leaves every replay check returning true -- while ``bounds.ceiling_for``
    documents the exact regression the bound exists to catch ("scenario runs: 62
    of at most 49").

    The ceiling is a *declared* bound, so nothing in the record derives it and
    this cannot verify the number is right. What it can say is that a bound the
    counts beside it exceed is not a bound at all.
    """

    if accounting.scenario_ceiling <= 0:
        raise ValueError(
            f"a scenario ceiling of {accounting.scenario_ceiling} bounds nothing"
        )
    if accounting.total_scenario_runs > accounting.scenario_ceiling:
        raise ValueError(
            f"{accounting.total_scenario_runs} scenario runs are retained beside "
            f"a declared ceiling of {accounting.scenario_ceiling}; a bound the "
            "count next to it exceeds is the one thing a declared bound may "
            "never be"
        )


def attempts_of(decision: object) -> tuple[Attempt, ...]:
    """Every attempt the decision holds, in section order. Used by the replay too."""

    held_out: tuple[Attempt, ...] = (
        ()
        if decision.comparison is None
        else (decision.comparison.baseline, decision.comparison.selected)
    )
    return (*decision.development, *decision.selection.attempts, *held_out)


def check(decision: object) -> None:
    """Every rule, in the order a reader would state them, raising on the first.

    Each one is a claim about this record's own sections, so testing them needs
    no store, no run, and no filesystem -- which is why they are refusals rather
    than entries in a replay report. ``audit.replay`` is for the claims that need
    something written independently to compare against.
    """

    # Reads like a cross-check and is not one: every caller here builds both from
    # one object. ``check_declaration`` is the rule that reads the record.
    if dict(decision.selection.policy_declaration) != dict(decision.selection_policy):
        raise ValueError("selection and decision must declare the same policy")
    check_declaration(decision.selection_policy)
    _sections_are_labelled(decision)
    _three_splits_are_three_measurements(decision)
    chosen = decision.selection.chosen
    # A run where nothing ranked on the private split is a terminal outcome with
    # a record of its own: every attempt, its typed failure and its clock, and
    # no held-out work. Raising an exception out of ``select`` instead throws
    # away exactly those attempts -- and they happen after ``meta.run``, so the
    # durable store never held them either. What has to stay
    # refused is a record that claims one without the other: a comparison with
    # no winner to have compared, or a winner with no comparison behind it.
    if chosen is None:
        if decision.comparison is not None:
            raise ValueError(
                "nothing ranked on the private split, so there is no winner -- "
                "and a held-out comparison of a candidate that was never "
                "selected is not evidence about this decision"
            )
        if any(attempt.rankable for attempt in decision.selection.attempts):
            raise ValueError(
                "a rankable private attempt exists, so a winner was available "
                "and this record declines to name one"
            )
    else:
        if decision.comparison is None:
            raise ValueError(
                f"selection chose {identity(chosen)} but this record carries no "
                "held-out comparison, so nothing was measured about the winner"
            )
        _baseline_is_the_seed(decision)
        if identity(decision.comparison.selected) != identity(chosen):
            raise ValueError(
                f"the held-out comparison scored {identity(decision.comparison.selected)} "
                f"but selection chose {identity(chosen)}; a final comparison of a "
                "candidate that was not selected is not evidence about this decision"
            )
    _selection_covers_the_search(decision)
    _work_matches_the_evidence(decision)
    _observations_match_the_attempt(decision)
    _metrics_match_the_observations(decision)
    _ceiling_bounds_the_runs(decision.accounting)
    implied = counted(
        decision.development,
        decision.selection,
        decision.comparison,
        ceiling=decision.accounting.scenario_ceiling,
    )
    if implied != decision.accounting:
        raise ValueError(
            f"the retained accounting is {decision.accounting.to_payload()}, but "
            f"the attempts in this record imply {implied.to_payload()}; counts "
            "that are not the counts of the work retained beside them are not "
            "accounting"
        )


def _sections_are_labelled(decision: object) -> None:
    """Each section holds attempts that say they are from that section's split.

    The record's three lists are *named* for the splits they hold, so an attempt
    inside one that claims another is not readable as either -- and it is how a
    private measurement gets presented as an independent held-out one, which is
    the single most load-bearing distinction in the whole example. Cheap, and
    easy to leave out -- without it, relabelling one private attempt and its
    clock reading passes every check.
    """

    sections = (
        ("development", decision.development),
        ("private", decision.selection.attempts),
        (
            "held_out",
            ()
            if decision.comparison is None
            else (decision.comparison.baseline, decision.comparison.selected),
        ),
    )
    for split, attempts in sections:
        wrong = sorted({item.split for item in attempts} - {split})
        if wrong:
            raise ValueError(
                f"the {split} section holds attempts labelled {wrong}; the "
                "record's sections are named for the splits they hold"
            )


def _three_splits_are_three_measurements(decision: object) -> None:
    """The three declared evaluator identities are three, not two wearing a hat.

    Each split declares a configuration that includes its own name and the
    digest of its own scenarios, so three honest splits always declare three
    different identities. A record reusing one across two is claiming an
    independent comparison it did not make.

    This is the *only* thing checkable about the later two identities from inside
    the directory: the store never ran those evaluators, so an arbitrary rewrite
    of one has no witness here. ``record.py`` lists that with the other gaps.
    """

    # Two splits when nothing ranked: no held-out evaluator was configured,
    # because no held-out measurement was made.
    declared = (decision.development_evaluator, decision.selection.evaluator)
    if decision.comparison is not None:
        declared = (*declared, decision.comparison.evaluator)
    if len(set(declared)) != len(declared):
        raise ValueError(
            f"two splits declare the same evaluator identity: {declared}; three "
            "splits that measured identically are one split reported three times"
        )


def _selection_covers_the_search(decision: object) -> None:
    """Exactly the development candidates that ranked -- no more, and no fewer.

    Not membership, and not a subset either way. A dropped candidate removes the
    bar the winner was measured against, a duplicated one double-counts it, and
    a renamed one launders it; all three leave every other check here true.
    """

    ranked = [identity(item) for item in decision.development if item.rankable]
    scored = [identity(item) for item in decision.selection.attempts]
    if sorted(scored) != sorted(ranked):
        raise ValueError(
            "the private split must score exactly the development candidates "
            f"that ranked; scored but never evaluated: {_extra(scored, ranked)}; "
            f"evaluated but not scored: {_extra(ranked, scored)}"
        )


def _baseline_is_the_seed(decision: object) -> None:
    """The comparison's baseline is the artifact the search started from.

    Otherwise the final verdict is a comparison against whichever candidate the
    record chose to call the baseline, which is a different claim wearing the
    same word. The seed is the development attempt at logical step zero, so this
    rule reaches the store through the section the store witnesses.
    """

    seed = [item for item in decision.development if item.logical_step == 0]
    if decision.comparison is None:
        return
    baseline = identity(decision.comparison.baseline)
    if len(seed) != 1 or identity(seed[0]) != baseline:
        raise ValueError(
            f"the held-out baseline is {baseline}, but this search started from "
            f"{[identity(item) for item in seed]}; a baseline that is not the "
            "seed is not the thing this decision claims to have improved on"
        )


def _work_matches_the_evidence(decision: object) -> None:
    """Each attempt's scenario count against its own retained observations.

    The per-attempt half of the accounting rule. Without it the counts could be
    made to add up by editing the attempts they are summed from, which is the
    same forgery one level down.
    """

    for attempt in attempts_of(decision):
        if attempt.scenario_runs != observed_runs(attempt):
            raise ValueError(
                f"{attempt.candidate} on {attempt.split} claims "
                f"{attempt.scenario_runs} scenario runs but retains "
                f"{observed_runs(attempt)} scenario observations"
            )


def _observations_match_the_attempt(decision: object) -> None:
    """Scenario evidence must describe this split and this attempt's outcome."""

    for attempt in attempts_of(decision):
        observations = [
            frame["data"]
            for frame in attempt.evidence
            if frame["kind"] == "scenario-observation"
        ]
        for index, data in enumerate(observations):
            if data.get("split") != attempt.split:
                raise ValueError(f"{attempt.candidate}: scenario observation split disagrees")
            # Scoring stops at the first failure; preceding scenarios completed.
            expected = attempt.outcome if index == len(observations) - 1 else "completed"
            if data.get("outcome") != expected:
                raise ValueError(f"{attempt.candidate}: scenario observation outcome disagrees")


def _metrics_match_the_observations(decision: object) -> None:
    """Each rankable attempt's aggregate against the scenarios beside it.

    ``_work_matches_the_evidence`` counts the observations; this one reads them.
    Counting alone left a file able to contradict itself: changing only the
    held-out selected ``quality`` -- to a value still in range, with the derived
    verdict and both digests resealed -- produced a record whose retained
    per-scenario qualities no longer aggregate to the number the verdict was
    computed from, and every replay check returned true. The evidence needed to
    notice was already in the file.

    The aggregation is the one ``outcomes.SplitReport.metrics`` performs: the
    mean over the split's scenarios, per ranked field. A rankable attempt that
    retains *no* scenario observation is refused rather than skipped: an honest
    ``SplitReport`` cannot be built over zero scenarios, so an attempt claiming
    an aggregate beside no evidence is claiming an average over nothing --
    deleting every frame and zeroing the count was a record that ranked a
    candidate on no measurement at all and passed every check. An attempt whose
    observations *drop* a field it claims is refused for the same reason, and
    skipping it there is how the whole rule becomes optional.

    Each reading is held to what a measurement may be before any of them are
    averaged; ``_observed`` says why, and shares that rule with
    ``decision._measurements``.

    The honest limitation that remains is the one no rule here can close: a
    *consistently* rewritten set of later measurements -- the aggregate and the
    observations moved together -- has no anchor outside the file.
    """

    for attempt in attempts_of(decision):
        if not attempt.rankable:
            continue
        observations = [
            frame["data"]
            for frame in attempt.evidence
            if frame.get("kind") == "scenario-observation"
        ]
        # A rankable attempt measured something, and an honest ``SplitReport``
        # cannot be built over zero scenarios -- ``outcomes.py`` refuses that
        # split by name. So "no observations" is not an attempt this rule has
        # nothing to say about; it is an attempt claiming an aggregate over
        # nothing, and deleting every frame while zeroing the count was a record
        # that scored a candidate on no evidence and passed every check.
        if not observations:
            raise ValueError(
                f"{attempt.candidate} on {attempt.split} is rankable and "
                f"retains {len(attempt.evidence)} evidence items, none of them a "
                "scenario observation; an aggregate over no measurement is not a "
                "measurement"
            )
        for field in sorted(RANKED_FIELDS):
            retained = [
                _observed(data[field], attempt, field)
                for data in observations
                if field in data
            ]
            # Every observation, or the rule does not run at all -- and a rule
            # that does not run is the bypass. Skipping the field when one frame
            # lacks it lets a forger delete ``quality`` from a single scenario
            # observation and then claim any aggregate at all: the mean is never
            # computed, and every replay check comes back true.
            #
            # This is not a schema check standing in for ``decision._frames``.
            # The attempt *claims* this field in its metrics; an observation
            # beside it that does not carry the field is incomplete evidence for
            # the claim being made, which is this rule's own subject.
            if len(retained) != len(observations):
                raise ValueError(
                    f"{attempt.candidate} on {attempt.split} claims {field} "
                    f"{attempt.metrics[field]!r} beside {len(observations)} "
                    f"scenario observations of which {len(retained)} carry that "
                    "field; an aggregate cannot be checked against evidence that "
                    "does not report what it aggregates"
                )
            mean = sum(retained) / len(retained)
            claimed = float(attempt.metrics[field])
            if abs(mean - claimed) > 1e-9:
                raise ValueError(
                    f"{attempt.candidate} on {attempt.split} reports {field} "
                    f"{claimed!r}, but the {len(retained)} scenario observations "
                    f"retained beside it average {mean!r}; a record may not "
                    "contradict its own evidence"
                )


def _observed(value: object, attempt: object, field: str) -> float:
    """One retained observation reading, held to what a measurement may be.

    ``decision._measurements`` *is* that rule -- what a number may be when this
    example retains one -- so this calls it rather than restating it. Two
    spellings of one rule drift, and this stack's own history is that the weaker
    one survives: the record path kept a bare ``float(value)`` for four rounds
    while the proposal path checked, and each round fixed the instance that had
    been reported.

    Calling it also matters for what the two are *for*. An aggregate is compared
    against these readings, and a comparison between values typed by different
    rules is a comparison between different things.

    ``float(data[field])`` alone was three defects at once. The string ``"nan"``
    became a ``NaN`` mean, and every comparison against a ``NaN`` is ``False``,
    so ``abs(mean - claimed) > 1e-9`` was ``False`` and the aggregate could be
    anything at all. A list, a ``None`` or an object raised ``TypeError`` out of
    a reader whose whole subject is that every refusal has a name. And ``"0.73"``
    or ``true`` were silently coerced into a number the file did not contain.
    """

    subject = (
        f"{attempt.candidate} on {attempt.split} retains a {field!r} observation "
        "that is not a measurement"
    )
    return float(_measurements({field: value}, subject)[field])


def _extra(left: Iterable[object], right: Iterable[object]) -> list[object]:
    """What ``left`` holds that ``right`` does not, counting duplicates."""

    return sorted((Counter(left) - Counter(right)).elements())


__all__ = [
    "attempts_of",
    "check",
    "counted",
    "identity",
    "observed_runs",
]
