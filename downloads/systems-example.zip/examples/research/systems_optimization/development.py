"""The deterministic projection shared by record creation and replay."""

from __future__ import annotations

import meta_evolve as meta

from .decision import Attempt, evidence_frame, outcome_of, usage_payload
from .observations import AttemptTiming
from .proposals import candidate_name, source_digest


def recorded_trials(result: meta.Run) -> tuple:
    """Every development trial that reached a terminal outcome.

    Deliberately *not* filtered on ``artifact``. A proposal that failed --
    refused, timed out, or returned a tree the task could not hold -- is a
    terminal trial with a typed failure and no successor, and dropping it here
    dropped it from the record, from the per-attempt timing, and from the report,
    while the kernel store went on holding it. ``audit.replay`` built its
    expected side from this same helper, so "every development attempt agrees"
    agreed about a set both sides had already lost the same row from.

    A trial with neither metrics nor a failure is still not an attempt: nothing
    terminal happened to it, so there is nothing to retain.
    """

    return tuple(
        trial
        for trial in result.trials()
        if trial.metrics or trial.failure is not None
    )


def attempt_from_trial(trial: object) -> Attempt:
    """Project every deterministic attempt field from one durable trial."""

    failure = trial.failure
    # A proposal that never produced a successor has no artifact to digest, and
    # inventing one -- or reusing the parent's -- would present the attempt as a
    # candidate that was created and then failed. The empty digest is the honest
    # statement that no artifact exists; ``candidate`` still names the plan step
    # that was attempted, which is what a reader needs to find it.
    artifact = trial.artifact
    return Attempt(
        candidate=candidate_name(trial),
        digest="" if artifact is None else source_digest(artifact.value),
        logical_step=trial.logical_step,
        split="development",
        outcome=outcome_of(failure),
        failure_kind="" if failure is None else failure.kind,
        detail="" if failure is None else failure.message,
        metrics=trial.metrics,
        evidence=tuple(evidence_frame(item) for item in trial.evidence),
        scenario_runs=sum(
            1 for item in trial.evidence if item.kind == "scenario-observation"
        ),
        usage=usage_payload(trial.usage),
    )


def development_attempts(result: meta.Run) -> tuple[Attempt, ...]:
    return tuple(attempt_from_trial(trial) for trial in recorded_trials(result))


def development_timings(result: meta.Run) -> tuple[AttemptTiming, ...]:
    """The clock half of the same trials, retained outside the decision."""

    return tuple(
        AttemptTiming.of(attempt_from_trial(trial), trial.usage.wall_seconds)
        for trial in recorded_trials(result)
    )


__all__ = [
    "attempt_from_trial",
    "development_attempts",
    "development_timings",
    "recorded_trials",
]
