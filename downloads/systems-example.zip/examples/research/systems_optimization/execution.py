"""The governed evaluator: it owns the workspace, the boundary, and the refusals.

Named ``execution`` rather than ``evaluation`` for a dull reason worth knowing:
two examples that both ship a bare ``evaluation.py`` collide in ``sys.modules``
the moment one test session touches both. This example is an importable package,
so nothing it defines can be reached by a bare top-level name and the collision
cannot recur whatever a sibling is called; the name stays because it is the more
accurate one.

Nothing a proposal can reach lives in this file. A candidate arrives, is checked
against the declared surface, is materialized into a private workspace beside
evaluator-owned copies of the verifier, the agent, the simulator, the protocol,
and one scenario, and is executed once per scenario through the shipped bounded
subprocess sandbox. What comes back is one JSON report; what goes out is either
rankable metrics or one typed, unrankable failure from ``outcomes.py``.

**The report is re-checked before it is believed.** The verifier builds it from
its own ``simulator.Session`` in a process that never imports candidate code, so
the numbers are the evaluator's own; ``read_report`` still re-derives every
invariant it can -- the identity of the scenario, the shape of the cluster,
conservation of total work, the task count, the probe cap -- and refuses rather
than scores when one does not hold. A measurement this example cannot re-derive
is not a measurement it will rank.

**What the boundary is, and what it is not.** Three layers, different jobs. The
shipped ``DevelopmentSubprocessSandbox`` bounds the verifier's cwd, environment,
wall clock, and output. Inside it, the *process split* between the verifier and
the agent confines the candidate's authority over *state*: it holds no simulator
and no channel that can carry a measurement. Around both, ``confinement.py``
asks the kernel to deny reads and writes beneath this repository, because the
workloads are committed literals in it -- a candidate that could read them could
fit itself to the questions, and one that could write them could change them.
``handoff.py`` launches the proposer through the same boundary.

What none of them does is isolate network, CPU, memory, or syscalls generally, or
stop a candidate hunting the verifier's memory through the host. Running
model-written schedulers here is still an opt-in, user-owned decision.

**On the file's length**, since AGENTS.md asks for a reason at 300 lines and the
guideline is *below* it: one candidate's journey from arriving to being scored,
which is four functions that only make sense in order -- the tree it runs in,
the process request that confines it, the one scenario run, and the split that
aggregates those. The paragraphs above are what makes them readable: three
layers of boundary with different jobs, and a list of what none of them does.
Splitting the run from the aggregate would separate the early stop from the
thing it is an early stop *of*.
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

import meta_evolve as meta
from meta_evolve.adapters import DirectoryWorkspaces
from meta_evolve.adapters.development_subprocess import DevelopmentSubprocessSandbox
from meta_evolve.domain import SourceTree, Usage
from meta_evolve.ports import EvaluationResult

from . import confinement
from .bounds import (
    CANDIDATE_DEADLINE_SECONDS,
    INTERPRETER_FLAGS,
    OUTPUT_LIMIT,
    PROCESS_TIMEOUT_SECONDS,
)
from .identity import configuration_version, evaluator_configuration, resolve_split
from .outcomes import ScenarioReport, SplitReport, failure_for
from .reports import read_report
from .simulator import Scenario
from .surface import SURFACE, check_surface
from .verifier import AGENT_FILE, SCENARIO_FILE


HERE = Path(__file__).parent
VERIFIER_FILE = "_verifier.py"

# workspace path -> the module on disk that is copied into it. None can collide
# with the surface: ``check_surface`` refuses any candidate path that is not
# ``scheduler.py``, and every name here begins with an underscore.
INJECTED = {
    VERIFIER_FILE: "verifier.py",
    AGENT_FILE: "agent.py",
    "_simulator.py": "simulator.py",
    "_protocol.py": "protocol.py",
}
HARNESS = SourceTree(
    {
        path: (HERE / name).read_text(encoding="utf-8")
        for path, name in INJECTED.items()
    }
)


def workspace_tree(candidate: SourceTree, scenario: Scenario) -> SourceTree:
    """The exact tree one scenario run is executed in.

    The scenario travels as a workspace file rather than an argument because
    ``verifier.py`` deletes it before the process holding candidate code exists.
    A command line would still be readable through the host after that point.
    """

    return SourceTree(
        {
            **candidate,
            **HARNESS,
            SCENARIO_FILE: json.dumps(scenario.to_payload(), sort_keys=True),
        }
    )


def scenario_spec(workspace: Path) -> meta.ProcessSpec:
    """The one process request this evaluator ever makes, bounds and all.

    ``workspace`` is a parameter because the confinement is: the launcher has to
    name the one directory this run may read. The prefix comes first and the
    interpreter follows it, so the declared spec and the applied spec stay the
    same object -- a boundary that only some code paths carried would be worth
    nothing.
    """

    return meta.ProcessSpec(
        argv=(
            *confinement.launcher(workspace),
            sys.executable,
            *INTERPRETER_FLAGS,
            VERIFIER_FILE,
            str(CANDIDATE_DEADLINE_SECONDS),
        ),
        environment={},
        timeout_seconds=PROCESS_TIMEOUT_SECONDS,
        stdout_limit=OUTPUT_LIMIT,
        stderr_limit=OUTPUT_LIMIT,
    )


def run_scenario(
    candidate: SourceTree,
    scenario: Scenario,
    *,
    workspaces: DirectoryWorkspaces | None = None,
    sandbox: DevelopmentSubprocessSandbox | None = None,
) -> ScenarioReport:
    """Execute one candidate against one scenario in a workspace of its own.

    The providers are arguments so a test can drive a timeout or a broken
    execution boundary without waiting ten seconds or breaking a machine.
    """

    reason = check_surface(candidate)
    if reason is not None:
        return ScenarioReport(scenario=scenario.name, outcome="off-surface", detail=reason)
    workspaces = workspaces or DirectoryWorkspaces()
    sandbox = sandbox or DevelopmentSubprocessSandbox()
    try:
        workspace = workspaces.materialize(workspace_tree(candidate, scenario))
    except (OSError, TypeError) as error:
        return ScenarioReport(
            scenario=scenario.name,
            outcome="infrastructure-failed",
            detail=f"could not materialize evaluator workspace: {error}",
        )
    # One lifetime owner from here down. Everything after a successful
    # materialization runs inside the ``try`` whose ``finally`` gives the
    # workspace back -- specification construction included. Sitting in a handler
    # that names only ``ConfinementUnavailable`` and ``OSError``, above the
    # ``finally``, lets a ``ProcessSpec`` validation error leave the directory on
    # disk with nothing left holding a reference to it.
    try:
        measured = _measured(sandbox, workspace, scenario)
    finally:
        undisposed = _dispose(workspaces, workspace)
    if undisposed is not None:
        return _cleanup_failure(scenario, measured, undisposed)
    return measured


def _measured(
    sandbox: DevelopmentSubprocessSandbox, workspace: object, scenario: Scenario
) -> ScenarioReport:
    """Build the specification, run it, and read the report it produced.

    Split out so the caller's ``finally`` is the only thing that gives a
    workspace back, on every path including the ones that raise.
    """

    try:
        spec = scenario_spec(workspace.root)
    # ``ValueError`` is a declared bound this evaluator cannot honour -- an
    # output ceiling or timeout the shipped ``ProcessSpec`` refuses. That is a
    # configuration fault of this example, so it takes the same typed outcome as
    # a machine with no boundary. Anything else propagates, and the caller's
    # ``finally`` still disposes.
    except (confinement.ConfinementUnavailable, OSError, ValueError) as unavailable:
        return ScenarioReport(
            scenario=scenario.name,
            outcome="infrastructure-failed",
            detail=str(unavailable),
        )
    try:
        completed = sandbox.run(spec, workspace)
    except OSError as error:
        return ScenarioReport(
            scenario=scenario.name,
            outcome="infrastructure-failed",
            detail=f"could not run evaluator process: {error}",
        )
    return read_report(completed, scenario)


def _cleanup_failure(
    scenario: Scenario, prior: ScenarioReport, error: OSError
) -> ScenarioReport:
    """A workspace that could not be given back makes the run unrankable.

    Disposal precedes commitment: the shipped M5 contract is that a cleanup
    failure overrides completion while the classification, the evidence and the
    charged usage are kept. The other way round -- logging the failure and
    returning rankable metrics anyway -- reads as a scheduler that was measured
    on a machine that then failed to clean up after it, and scores it.

    Keeping the measurement is not the same as ranking it. The numbers stay on
    the report, so the per-scenario evidence still says what was observed, and
    ``outcome`` says it cannot be ranked. The prior outcome travels in the
    detail, because "the disposal failed" alone loses whether there was a
    measurement underneath it at all.
    """

    underneath = prior.outcome if prior.detail == "" else f"{prior.outcome}: {prior.detail}"
    return ScenarioReport(
        scenario=scenario.name,
        outcome="infrastructure-failed",
        imbalance=prior.imbalance,
        work=prior.work,
        quality=prior.quality,
        loads=prior.loads,
        detail=(
            f"could not dispose of evaluator workspace: {error}; "
            f"the run itself reported {underneath}"
        ),
        usage=prior.usage,
    )


def _dispose(workspaces: DirectoryWorkspaces, workspace: object) -> OSError | None:
    """Give the workspace back; report the failure rather than deciding about it.

    Exactly once, from one ``finally``, whatever the run did. Logged as well as
    returned: the caller turns it into an outcome, and a leaked directory on a
    machine where every workspace lives under one temporary tree should also be
    findable by whoever notices the disk first.
    """

    try:
        workspaces.dispose(workspace)
    except OSError as error:
        logging.getLogger(__name__).warning(
            "could not dispose of evaluator workspace %s: %s", workspace.root, error
        )
        return error
    return None


def score_split(
    candidate: object,
    split_name: str,
    *,
    split: tuple[Scenario, ...] | None = None,
) -> SplitReport | ScenarioReport:
    """Score one whole split, or stop at the first refusal inside it.

    Returning a bare ``ScenarioReport`` for an off-surface candidate is the
    point: it never reached a scenario, so there is no split result to report.

    ``split`` is a parameter for the private and held-out stages, which are not
    registered components and are configured by whoever runs the command. The
    development evaluator the search registers takes the default, because a
    registered component has to be a plain function of one argument for its
    source digest to mean anything.
    """

    reason = check_surface(candidate)
    if reason is not None:
        return ScenarioReport(scenario=split_name, outcome="off-surface", detail=reason)
    reports: list[ScenarioReport] = []
    usage = Usage()
    # Through ``identity.resolve_split`` rather than resolving it here, so what
    # gets measured and what gets declared cannot be two different answers to the
    # same question, which running this expression separately in each would be.
    for scenario in resolve_split(split_name, split):
        report = run_scenario(candidate, scenario)
        reports.append(report)
        usage = usage + report.usage
        if not report.completed:
            # A split with one unrankable scenario has no aggregate. Stopping
            # also keeps a timeout from being paid once per remaining scenario.
            break
    return SplitReport(split=split_name, scenarios=tuple(reports), usage=usage)


def evaluate(
    candidate: object,
    split_name: str,
    *,
    split: tuple[Scenario, ...] | None = None,
) -> EvaluationResult:
    """The evaluator's whole contract: rankable metrics, or one typed failure."""

    scored = score_split(candidate, split_name, split=split)
    if isinstance(scored, ScenarioReport):
        return EvaluationResult(failure=failure_for(scored, split_name, SURFACE[0]))
    stopped = scored.failure
    if stopped is not None:
        return EvaluationResult(
            failure=failure_for(stopped, split_name, SURFACE[0]),
            evidence=scored.evidence,
            usage=scored.usage.resources,
        )
    return EvaluationResult(
        metrics=scored.metrics,
        evidence=scored.evidence,
        usage=scored.usage.resources,
    )


def evaluate_development(candidate: object) -> EvaluationResult:
    """The only evaluator the search ever calls. Its results are public."""

    return evaluate(candidate, "development")



__all__ = [
    "HARNESS",
    "INJECTED",
    "configuration_version",
    "evaluate",
    "evaluate_development",
    "evaluator_configuration",
    "run_scenario",
    "scenario_spec",
    "score_split",
    "workspace_tree",
]
