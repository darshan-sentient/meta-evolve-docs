"""Every declared bound this example runs under, in one place.

Budgets, process limits, and the worst-case work a command performs are all
evaluator-owned, and they are all *derived* here rather than restated: adding a
scheduler to the plan or a scenario to a split moves these numbers instead of
silently exhausting a budget or making a documented ceiling wrong.

A reader who wants to know what one command can possibly cost should be able to
read one short file, which is why this is not spread across the driver and the
evaluator.
"""

from __future__ import annotations

import meta_evolve as meta

from .plan import PLAN
from .simulator import Scenario
from .workloads import DEVELOPMENT, HELD_OUT, PRIVATE


def budget_for(max_trials: int) -> meta.Budget:
    """One evaluation per candidate -- the seed plus one per trial -- and one
    trial each. A function of the trial count rather than a constant, so that a
    proposer meaning to make five edits is budgeted for five: the fixture's own
    ``max_trials`` is the plan's length, and adding a plan step moves it."""

    return meta.Budget(evaluations=max_trials + 1, trials=max_trials)


SEARCH_BUDGET = budget_for(len(PLAN))

# Two nested wall clocks, and the nesting is the point. The inner one is the
# verifier's own: it is what a candidate that stops answering runs out of, and
# it produces a typed ``timed-out`` outcome with a report attached. The outer
# one is the sandbox's, and it is a backstop for the verifier itself failing to
# come back -- which yields no report at all. The allowance between them covers
# two interpreter starts and the report write, and exists so that the ordinary
# case is always diagnosed by the inner clock.
CANDIDATE_DEADLINE_SECONDS = 6.0
STARTUP_ALLOWANCE_SECONDS = 4.0
PROCESS_TIMEOUT_SECONDS = CANDIDATE_DEADLINE_SECONDS + STARTUP_ALLOWANCE_SECONDS

# The output one verifier may produce. It writes one JSON line; a candidate
# cannot reach this stream at all (see ``agent.py``), so exceeding this is the
# evaluator's own problem and is reported as an inconclusive outcome rather
# than as a badly performing scheduler.
OUTPUT_LIMIT = 64_000

# Interpreter flags for both evaluator-owned processes: no bytecode written
# into a workspace, and no ambient ``PYTHON*`` variable able to change how
# either behaves. Declared here because they are part of what was measured.
INTERPRETER_FLAGS = ("-B", "-E")

CANDIDATES = len(PLAN) + 1


def ceiling_for(
    private: tuple[Scenario, ...] = PRIVATE,
    held_out: tuple[Scenario, ...] = HELD_OUT,
    *,
    candidates: int = CANDIDATES,
) -> int:
    """The scenario runs a full command over *these* splits can perform.

    Every candidate over development, every candidate over private, and two
    candidates over held out. Development and private both stop at the first
    unrankable scenario in a split, so this is a ceiling and the real count is
    lower -- the run's own record carries the actual count, and
    ``tests/test_systems_optimization_accounting.py`` pins both.

    A function rather than only a constant, because ``run_example`` takes the
    later two splits as parameters. Computing this from the committed splits and
    then retaining it beside a run over larger ones printed ``scenario runs: 62
    of at most 49`` -- a bound that the count beside it exceeded, which is the
    one thing a declared bound must never be.
    """

    return (
        candidates * len(DEVELOPMENT) + candidates * len(private) + 2 * len(held_out)
    )


def require_splits(private: tuple[Scenario, ...], held_out: tuple[Scenario, ...]) -> None:
    """Refuse a split with nothing in it, by name, before anything is spent.

    ``outcomes.SplitReport`` refuses one too, and that is the load-bearing
    refusal -- it covers every path, and it is what turned an untyped
    ``ZeroDivisionError`` in ``metrics`` into something with a name. This one is
    only so ``run_example(root, private=())`` says which argument was wrong
    before it spends nine evaluations finding out.
    """

    for name, split in (("private", private), ("held_out", held_out)):
        if not split:
            raise ValueError(
                f"the {name} split is empty, so this command would select and "
                "compare against nothing; a split is the question being asked"
            )


# What the committed command costs, which is the number the README documents.
SCENARIO_CEILING = ceiling_for()

# Each scenario run is two processes: one verifier, and one agent holding the
# candidate. Stated because "how many processes does this command start" is a
# fair question to ask of an example that executes proposed code. One more per
# *proposal* sits outside this number, because a proposal is not a scenario run:
# ``handoff.py`` decides in a confined process of its own, one per plan step.
PROCESSES_PER_SCENARIO = 2


__all__ = [
    "CANDIDATES",
    "CANDIDATE_DEADLINE_SECONDS",
    "INTERPRETER_FLAGS",
    "OUTPUT_LIMIT",
    "PROCESSES_PER_SCENARIO",
    "PROCESS_TIMEOUT_SECONDS",
    "require_splits",
    "SCENARIO_CEILING",
    "SEARCH_BUDGET",
    "budget_for",
    "ceiling_for",
    "STARTUP_ALLOWANCE_SECONDS",
]
