"""The kernel-facing half of the proposer: what is declared, and what is recorded.

The decision is not here. It is in ``plan.py``, which runs through ``propose.py``
in a process ``confinement.py`` has kept away from this repository -- so it cannot
read ``workloads.py``, where the selection and final-comparison streams are
committed literals. ``handoff.py`` is the crossing. This module is what the kernel
sees: one declared ``ProposerSpec``, and one ``propose_scheduler`` that hands the
context across, validates what comes back, and either records a proposal or
returns one typed failure.

**Why this shape.** A proposer that is a callable in the process that imported
both later splits leaves #195's separation gate -- "held-out facts cannot reach
proposal context" -- resting on nothing but the committed fixture not looking.
Removing the supplied-proposer parameter removes the *API* for reaching later
facts, not the authority to. The gate is carried now by sequencing, by a payload closed to
development records, and by this one fixed proposer; confining the process is
what closes the file route on top of those, against code rather than against
review.

The candidate side stays deliberately dull: no model, no network, no credential.
What it also now has is no way to open the copy of the questions this repository
ships -- the file route, and not every route, since network retrieval is confined
on neither platform.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field

import meta_evolve as meta
from meta_evolve.domain import ProposerFailure, SourceTree

from . import confinement
from .bounds import INTERPRETER_FLAGS, OUTPUT_LIMIT, PROCESS_TIMEOUT_SECONDS
from .handoff import confined_proposal, context_payload, rejection
from .plan import PLAN, PLAN_BY_NAME, Edit, FIXTURE_DECLARATION, digest_of
from .surface import SURFACE


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposerSpec:
    """Everything the kernel needs declared about one proposer, in one value.

    ``command.py`` builds exactly one of these -- the committed fixture -- and
    registers it. It is a value rather than a bare callable because a registered
    component carries real obligations: a name, a version, whether it is
    deterministic and retry-safe, the modules its behaviour depends on, and the
    configuration it ran under. A run declaring none of them is a run nothing
    else can be compared against, which the kernel reports as a name-only
    component rather than silently allowing.

    There is no parameter anywhere that accepts somebody else's spec, and the
    absence is deliberate -- see ``command.build_registry``. The obligations are
    written out here anyway, because they are what a reader has to satisfy to
    build a governed proposer of their own on this kernel.

    Reported usage needs no field here. A proposer returns it on its own
    ``meta.ProposalResult``, and the kernel rolls it into the run's ``Usage``.

    ``deterministic`` and ``retry_safe`` are the two that bite. ``command.search``
    runs ``durable-local``, and the kernel refuses that mode for a component
    declaring either as false -- so a proposer that admits it cannot be re-driven
    to the same result could not be registered here at all. That is the honest
    price of a live seam and part of why this example ships a fixture: the
    alternative is a run recorded as resumable on something that cannot be.
    """

    name: str
    version: str
    propose: Callable[..., meta.ProposalResult]
    max_trials: int
    deterministic: bool = True
    retry_safe: bool = True
    dependencies: tuple[object, ...] = ()
    configuration: Mapping[str, object] = field(default_factory=dict)

    @property
    def label(self) -> str:
        """How the record names this proposer."""

        return f"{self.name}@{self.version}"


def proposer_configuration() -> dict[str, object]:
    """What the fixture proposer declares it ran under.

    The confinement policy is in here for the same reason it is in the
    evaluator's declaration: a proposal made in a process that could read the
    later workloads is not the same proposal as one made in a process that could
    not, and a ``ComponentRef`` that did not move between the two would let the
    record say something it cannot support.
    """

    return {
        "declaration": FIXTURE_DECLARATION,
        "plan": len(PLAN),
        "process_timeout_seconds": PROCESS_TIMEOUT_SECONDS,
        "process_stdout_limit": OUTPUT_LIMIT,
        "process_stderr_limit": OUTPUT_LIMIT,
        "interpreter_flags": list(INTERPRETER_FLAGS),
        **confinement.declaration(),
    }


def source_digest(candidate: SourceTree) -> str:
    """Name a candidate by its content, for evidence that reads on its own."""

    return digest_of(candidate[SURFACE[0]])


def candidate_for(name: str) -> SourceTree:
    """The tree one plan step writes, as a ``SourceTree``.

    ``plan.py`` hands back plain text because it has to import without
    ``meta_evolve``; this is where that text becomes an artifact.
    """

    return SourceTree(PLAN_BY_NAME[name].files(SURFACE[0]))


def candidate_name(trial: meta.TrialView | None) -> str:
    """Name a candidate by the plan step that wrote it, or as the seed.

    ``Run.trials()`` includes the bootstrap at logical step zero -- the seed is a
    scored candidate here, not a special case -- so everything that walks the
    trials has one place to ask what it is looking at. A proposal that wrote no
    ``plan_step`` metadata would be named by its step instead.
    """

    if trial is None or not trial.logical_step:
        return "round-robin (seed)"
    step = trial.metadata.get("plan_step")
    return str(step) if step else f"step-{trial.logical_step}"


EVIDENCE = (
    "plan_step",
    "parent_digest",
    "parent_bytes",
    "observed_step",
    "observed_sequence",
    "observed_quality",
    "observed_imbalance",
    "observed_work",
)


def propose_scheduler(
    parent: SourceTree, *, context: meta.ProposerContext
) -> meta.ProposalResult:
    """Write the plan's next scheduler, citing the observation that prompted it.

    The kernel calls this; a confined process decides it. Every failure path ends
    in one ``ProposerFailure``, which the kernel records as an unrankable trial
    that keeps its parent -- the boundary being unavailable is not a reason to
    propose without one.
    """

    records = {
        (record.logical_step, record.event_sequence): record
        for record in context.bundle.records
        if record.kind == "evaluation"
    }
    try:
        # The payload is kept, not rebuilt: ``rejection`` compares the far side's
        # statements against what actually crossed, so a serializer that sent
        # something other than what this function believes it sent is caught here
        # rather than being re-derived into agreement.
        crossing = context_payload(parent, context)
        proposed, usage, boundary_failure = confined_proposal(crossing)
    except confinement.ConfinementUnavailable as unavailable:
        return meta.ProposalResult(failure=ProposerFailure(message=str(unavailable)))
    # ``context_payload`` refuses a record labelled ``evaluation`` whose value is
    # not one, or whose metrics are unreadable, rather than probing the object and
    # serializing an empty mapping as though the record simply had none. It runs
    # on this side of the boundary, before any confined process exists, so its
    # refusal has to become this module's one typed failure here -- otherwise a
    # context the run's own policy assembled wrongly escapes as a bare exception
    # from a function whose whole contract is that it does not.
    except ValueError as unreadable:
        return meta.ProposalResult(
            failure=ProposerFailure(
                message=f"the proposal context cannot be serialized: {unreadable}"
            )
        )
    if boundary_failure is not None:
        return meta.ProposalResult(failure=boundary_failure, usage=usage.resources)
    refusal = rejection(proposed, parent, crossing)
    if refusal is not None:
        return meta.ProposalResult(failure=ProposerFailure(message=refusal), usage=usage.resources)
    # ``SourceTree`` is the authority on what a tree may be -- relative, normalized,
    # case-unique paths -- and asking it is how that authority stays in one place
    # rather than being restated here and drifting. It is asked *inside* the try
    # because the kernel catching a ``ValueError`` and rendering it is not the same
    # thing as this module keeping its own promise to return one typed failure.
    try:
        candidate = SourceTree(dict(proposed["files"]))
    except ValueError as invalid:
        # ``usage=usage.resources`` because the process already ran and already cost what
        # it cost. This return omitted it, so three otherwise valid replies --
        # an escaping ``../`` path, a NUL byte in the source, a case-colliding
        # ``SCHEDULER.py`` -- each reported the right typed failure and zero
        # wall seconds. Work that is refused is still work, and a wall-clock
        # budget that does not charge for it can be overrun by proposals that
        # never produce a candidate.
        return meta.ProposalResult(
            failure=ProposerFailure(
                message=f"the confined proposal wrote a tree this task cannot hold: {invalid}"
            ),
            usage=usage.resources,
        )
    # Nothing below coerces. ``rejection`` has refused any field that did not
    # arrive as the type it has to be, so what the record retains is exactly what
    # crossed -- a ``str()`` here would have let a mistyped value through as a
    # tidied one, which is the shape of the finding this replaced.
    observed = records[(proposed["observed_step"], proposed["observed_sequence"])]
    return meta.ProposalResult(
        candidate=candidate,
        hypothesis=proposed["hypothesis"],
        predicted_outcomes={"exhibits": proposed["exhibits"]},
        metadata={
            "plan_step": proposed["plan_step"],
            "declaration": FIXTURE_DECLARATION,
        },
        evidence=(
            meta.EvidenceDraft(
                kind="proposal-basis",
                data={key: proposed[key] for key in EVIDENCE},
            ),
        ),
        derived_from=(observed.ref,),
        usage=usage.resources,
    )


__all__ = [
    "Edit",
    "EVIDENCE",
    "FIXTURE_DECLARATION",
    "PLAN",
    "PLAN_BY_NAME",
    "ProposerSpec",
    "candidate_for",
    "candidate_name",
    "propose_scheduler",
    "proposer_configuration",
    "source_digest",
]
