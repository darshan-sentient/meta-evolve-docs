"""Canonical bytes, content identities, record-path resolution, and typed reads."""

from __future__ import annotations

import json
from collections.abc import Mapping
from hashlib import sha256
from pathlib import Path


RECORD_PREFIX = "decision-"
RECORD_SUFFIX = ".json"


def canonical(payload: Mapping[str, object]) -> str:
    """Stable JSON for hashing and writing, refusing non-finite numbers."""

    return json.dumps(retained_payload(payload), indent=2, sort_keys=True, allow_nan=False)


def retained_payload(value: object) -> object:
    """Project retained containers to dicts and lists without coercing leaves.

    Mapping keys must already be strings: coercion could merge distinct keys.
    Section readers validate leaf types; ``canonical`` validates JSON numbers.
    """

    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise ValueError("retained mapping keys must be strings")
        return {key: retained_payload(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [retained_payload(item) for item in value]
    return value


# What a retained scalar is allowed to be, in prose, for the refusal message.
# ``bool`` is in none of them and is refused before any of them: ``True`` is an
# ``int``, no field of this record is a flag, and a payload holding one there has
# gone wrong rather than told the truth cheaply.
KIND_NAMES = {(str,): "a string", (int,): "an integer", (int, float): "a number"}


def retained_scalars(
    payload: Mapping[str, object],
    fields: Mapping[str, tuple[type, ...]],
    subject: str,
) -> dict[str, object]:
    """Every scalar one section retains, at the type it was written, or a refusal.

    The read counterpart of ``canonical`` above, and the fourth boundary in this
    example where one rule had two spellings and the weaker one survived.
    ``protocol.as_count`` holds the two wire counts; ``decision._measurements``
    holds the two mappings an attempt carries; ``canonical`` refuses a number JSON
    cannot express on the way out. The way back *in* held nothing at all -- every
    field was read through ``int()``, ``float()`` or ``str()``, which are coercions
    and not checks.

    The seed is the clearest case. A record whose ``random_seed`` is ``0.9``
    loads as seed ``0``, and ``audit.replay`` then compares the store's declared
    ``0`` against that truncated value and reports agreement -- so the file stated something false about the run it came from and
    nothing refused it. What it does *not* do is get a different seed past the
    store, which is why this is a fidelity defect and not a separation one: the
    value that replays is the declared one either way. What it breaks is
    ``to_payload`` and ``from_payload`` being inverse, which is the property every
    digest in this module is an identity *of*.

    So each field's type is declared beside its name and checked, refusals are
    collected the way ``_measurements`` collects them so a record with two bad
    fields names both, and a value that passes is returned exactly as it arrived.
    A missing field is still a ``KeyError``: absent and wrong-typed are different
    faults and only the second one is this function's subject.

    The section itself goes through ``retained_mapping`` first, which is what
    covers every caller's payload in one place -- the evaluators block, the
    envelope, an attempt, the accounting -- rather than at each of the four
    ``from_payload`` methods separately.
    """

    payload = retained_mapping(payload, subject)
    read: dict[str, object] = {}
    refused: list[str] = []
    for name, kinds in fields.items():
        value = payload[name]
        if isinstance(value, bool) or not isinstance(value, kinds):
            wanted = KIND_NAMES.get(kinds) or " or ".join(k.__name__ for k in kinds)
            refused.append(f"{name} is {value!r}, not {wanted}")
            continue
        read[name] = value
    if refused:
        raise ValueError(f"{subject}: {'; '.join(sorted(refused))}")
    return read


def retained_mapping(value: object, subject: str) -> Mapping[str, object]:
    """The container one section retains, refused rather than crashed through.

    Typing the *contents* of the retained mappings left the things holding them
    read through ``dict()``, one level out, in four places. A section whose
    ``evaluations`` was a number announced itself as ``'int' object is not
    iterable``; a string got ``dictionary update sequence element #0 has length
    1``; ``null`` got ``'NoneType' object is not iterable``. Every one of those
    is a fault named by a constructor rather than by a reader -- which is the
    same complaint ``retained_counts`` was written to answer, so answering it
    only for the values would have left this rule the two spellings that this
    example has now spent six boundaries collapsing.

    What it does *not* buy is a forgery that was getting through.
    ``record._is_what_it_reconstructs`` rebuilds each section and re-hashes it, so
    a mapping written as a JSON array of pairs -- the shape ``dict()`` accepts --
    was already refused there; it is refused here instead, one step earlier and
    by name, which is the better of
    the two messages and is why the expectation for it moved rather than being
    dropped. Reconstruction still owns what no type rule can see: a *smuggled*
    field, which nothing declares and so nothing can find mistyped. It is also
    why a count widened to ``9.0`` got past it and needed ``retained_counts`` at
    all -- ``9.0`` reserializes to the same bytes, and a changed shape does not.
    """

    if not isinstance(value, Mapping):
        raise ValueError(f"{subject}: {value!r} is not a mapping")
    return value


def retained_counts(values: object, subject: str) -> dict[str, int]:
    """Every per-split count one section retains, at the type it was written.

    The mapping half of the rule above, and the fifth time this example has found
    one rule with two spellings. ``retained_scalars`` typed the scalars a section
    holds and stopped at its own edge, so ``Accounting`` had ``scenario_ceiling``
    checked while the two mappings beside it were read through a bare ``dict()``.

    Why the ceiling is the field that got typed is the half worth keeping.
    ``invariants.check`` recomputes the accounting from the attempts and compares,
    which pins every count's *value* -- ``9.5`` and ``'9'`` are both refused there
    -- and it cannot pin the ceiling at all, because ``counted`` copies the stored
    one straight through. So the ceiling visibly needed a check and the counts
    looked covered. They were not: a count equal to the true one at the wrong
    type compares equal to it. ``9.0`` for ``9`` loaded through a resealed record
    with every replay check returning true. ``True`` for ``1`` is that same
    equality, and is shown at construction rather than through a record, because
    no honest count in this example's run is ``1``: swapping one to ``true``
    moves its value too, and the recomputation then refuses it for the value
    instead of the type.

    That makes this a fidelity defect exactly like the seed and not a separation
    one -- no count can be misstated either way. What it breaks is ``to_payload``
    and ``from_payload`` being inverse, which is the property every digest in this
    module is an identity *of*. One shape was worse than merely surviving: a
    string reached ``total_evaluations`` and came back out of ``sum`` as a bare
    ``TypeError``, a fault announced by an arithmetic accident rather than by a
    reader that refuses.

    Checked where ``Accounting`` is built rather than where it is read, because it
    is built in two places -- back from a payload, and recomputed from the
    attempts -- and a rule that holds on one of those paths is this hole again.

    The thing holding the counts is ``retained_mapping``'s subject, not this
    one's. Keys are refused rather than coerced: ``str(key)`` was doing the
    coercing, and no record can reach it -- JSON object keys are strings -- but a
    reader that quietly renames what it cannot read is the defect this module
    keeps finding, and there is one rule for it now instead of two.
    """

    read: dict[str, int] = {}
    refused: list[str] = []
    for key, value in retained_mapping(values, subject).items():
        if not isinstance(key, str):
            refused.append(f"{key!r} is not a split name")
            continue
        if isinstance(value, bool) or not isinstance(value, int):
            refused.append(f"{key} is {value!r}, not {KIND_NAMES[(int,)]}")
            continue
        read[key] = value
    if refused:
        raise ValueError(f"{subject}: {'; '.join(sorted(refused))}")
    return read


def retained_sequence(value: object, subject: str) -> tuple[object, ...]:
    """The list one section retains, refused rather than iterated blindly.

    The other half of ``retained_mapping``, for the three places a record holds a
    list: a split's attempts, an attempt's evidence, and the retained timings.
    All three were iterated straight out of the payload, so a mistyped split
    answered with ``'int' object is not iterable`` from inside a generator.

    ``list`` and ``tuple`` by name, and nothing wider. A JSON array arrives as a
    ``list``, so that is the whole set a record can legitimately hold -- and
    naming it this narrowly is what makes a string refused *as a string* rather
    than iterated into one-character items and refused item by item, for a reason
    that would not be the fault. Testing ``isinstance(value, (str, bytes))``
    first reads as though the check below were a ``Sequence`` test that strings
    pass. It is not, so such a clause can never fire, and it is left out rather
    than kept looking load-bearing.
    """

    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{subject}: {value!r} is not a list")
    return tuple(value)


def digest_of(payload: Mapping[str, object]) -> str:
    """The content address of any canonical payload in this record."""

    return sha256(canonical(payload).encode("utf-8")).hexdigest()[:16]


def path_for(directory: Path, digest: str) -> Path:
    return directory / f"{RECORD_PREFIX}{digest}{RECORD_SUFFIX}"


def digest_in_name(path: Path) -> str:
    name = path.name
    if not name.startswith(RECORD_PREFIX) or not name.endswith(RECORD_SUFFIX):
        return ""
    return name[len(RECORD_PREFIX) : -len(RECORD_SUFFIX)]


def locate(directory: Path) -> Path:
    """Return the only record; a path-only replay cannot choose between two."""

    found = sorted(directory.glob(f"{RECORD_PREFIX}*{RECORD_SUFFIX}"))
    if len(found) != 1:
        raise ValueError(
            f"{directory} holds {len(found)} decision records, and a replay "
            "needs exactly one to be reading the decision that was made"
        )
    return found[0]


def reseal(envelope: Mapping[str, object]) -> dict[str, object]:
    """Recompute decision and complete-record identities after an edit."""

    body = {
        key: value
        for key, value in envelope.items()
        if key not in {"decision_digest", "record_digest"}
    }
    body["decision_digest"] = digest_of(body["decision"])
    return {**body, "record_digest": digest_of(body)}


__all__ = [
    "KIND_NAMES",
    "RECORD_PREFIX",
    "RECORD_SUFFIX",
    "canonical",
    "digest_in_name",
    "digest_of",
    "locate",
    "path_for",
    "reseal",
    "retained_counts",
    "retained_mapping",
    "retained_payload",
    "retained_scalars",
    "retained_sequence",
]
