"""Three published workload splits owned by the evaluator.

This first slice defines and validates the deterministic workloads. Its baseline
entry point measures only ``DEVELOPMENT``. Later stack slices add the confined
candidate process, proposal handoff, split sequencing, selection, and held-out
comparison; they own the corresponding authority claims.

The streams stay published, in an ordinary file, so a reader can inspect and
reproduce the evaluator's inputs. Here is what each split is intended for:

* ``DEVELOPMENT`` is **public**. Its per-scenario results are the only evaluator
  feedback the committed fixture uses, received through the declared context
  policy as ordinary evaluation records.
* ``PRIVATE`` selects. It is scored *after* the search has returned, by the run
  entry point the slice that adds selection owns -- nothing in this tree scores
  it yet. The questions remain published.
* ``HELD_OUT`` is the final comparison. It is scored exactly once, after
  selection, for the baseline and the selected candidate and nothing else.

Every scenario is one repeating pattern of small tasks with a large one at the
end, and the whole difficulty is that the pattern length shares a factor with
the worker count. A scheduler that rotates through workers without looking at
them therefore sends *every* large task to the same handful of workers -- the
classic way round-robin fails, which is by position rather than by count.

That also fixes how good the baseline is: good enough to be a real bar, bad
enough to be worth beating. The splits use different worker counts, different
pattern lengths, and different task sizes, so a candidate cannot win by
matching one stream's shape.
"""

from __future__ import annotations

from hashlib import sha256

from .simulator import Scenario


def _burst(workers: int, name: str, pattern: tuple[int, ...], tasks: int) -> Scenario:
    """One scenario from a repeating pattern, probed at most once per worker.

    The probe budget is the worker count: a full scan of the cluster is legal
    and expensive, and one probe past it is a declared-constraint violation.
    """

    if tasks % len(pattern):
        raise ValueError(f"{name}: task count must be a whole number of patterns")
    return Scenario(
        name=name,
        workers=workers,
        sizes=pattern * (tasks // len(pattern)),
        probe_budget=workers,
    )


DEVELOPMENT = (
    _burst(8, "dev-every-fourth-8", (1, 1, 1, 5), 40),
    _burst(6, "dev-every-third-6", (1, 1, 4), 36),
)

PRIVATE = (
    _burst(4, "private-every-other-4", (1, 4), 40),
    _burst(6, "private-every-third-6", (1, 1, 8), 30),
    _burst(10, "private-every-fifth-10", (1, 1, 1, 1, 8), 40),
)

HELD_OUT = (
    _burst(4, "held-out-every-sixth-4", (1, 1, 1, 1, 1, 8), 36),
    _burst(8, "held-out-every-fourth-8", (1, 1, 1, 6), 40),
)

SPLITS = {"development": DEVELOPMENT, "private": PRIVATE, "held_out": HELD_OUT}


def split_digest(split: tuple[Scenario, ...]) -> str:
    """One stable identity for a whole split, for evaluator declarations."""

    return sha256(
        "|".join(scenario.digest for scenario in split).encode("utf-8")
    ).hexdigest()[:16]


def scenario_names(split: tuple[Scenario, ...]) -> tuple[str, ...]:
    return tuple(scenario.name for scenario in split)


__all__ = [
    "DEVELOPMENT",
    "HELD_OUT",
    "PRIVATE",
    "SPLITS",
    "scenario_names",
    "split_digest",
]
