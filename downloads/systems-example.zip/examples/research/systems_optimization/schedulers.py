"""The eight scheduler rewrites the fixture proposer can write, as source text.

Only text lives here. What the plan does with it, and why each entry is in the
plan at all, is ``proposals.py``; keeping the two apart means a reader who wants
to know what a candidate *is* reads eight short modules of Python, and a reader
who wants to know how the search moves reads one file of orchestration.

Every one of these is written the way it would be written if the simulator were
in the same process, because from the candidate's side it may as well be: it is
handed something with ``size``, ``load(index)``, and ``pick()``, and it does not
and cannot know that all three are pipe round trips to a process it has no
handle on. See ``agent.py``.

The set is chosen so that one command exhibits every outcome class this example
claims to keep inspectable: an improvement, a tie, a negative, an invalid
schedule, an off-surface edit, a constraint violation, and source that will not
parse. That coverage is a fixture decision and not a finding.
"""

from __future__ import annotations


MOST_LOADED_OF_TWO = '''\
"""Compare two workers and take the *more* loaded one.

The comparison is the wrong way round. This is the single most ordinary bug a
scheduler rewrite can have, and it does not fail: it produces a perfectly
valid schedule that piles work onto whichever worker is already busiest.
"""


def choose(cluster, size):
    first = cluster.pick()
    second = cluster.pick()
    if second == first:
        second = (first + 1) % cluster.size
    return first if cluster.load(first) >= cluster.load(second) else second
'''

LEAST_LOADED_SCAN = '''\
"""Ask every worker, place on the least loaded. Best balance, highest cost."""


def choose(cluster, size):
    best = 0
    best_load = cluster.load(0)
    for index in range(1, cluster.size):
        load = cluster.load(index)
        if load < best_load:
            best, best_load = index, load
    return best
'''

LEAST_LOADED_MIN_KEY = '''\
"""The same algorithm, written as one expression.

``min`` evaluates the key left to right and keeps the first minimum, so this
probes the same workers in the same order and places on the same one. It is a
rewrite, not a change -- which is exactly why it is here.
"""


def choose(cluster, size):
    return min(range(cluster.size), key=cluster.load)
'''

POWER_OF_TWO = '''\
"""Compare two workers and take the less loaded one.

Two probes per task instead of one per worker. Most of the balance for a small
fraction of the scheduling cost -- the trade the search is looking for.
"""


def choose(cluster, size):
    first = cluster.pick()
    second = cluster.pick()
    if second == first:
        second = (first + 1) % cluster.size
    return first if cluster.load(first) <= cluster.load(second) else second
'''

OFF_THE_CLUSTER = '''\
"""Place past the last worker. An invalid schedule, not a slow one."""


def choose(cluster, size):
    return cluster.size
'''

WITH_HELPER = '''\
"""Least-loaded, refactored into a helper module that is not on the surface."""

from helpers import least_loaded


def choose(cluster, size):
    return least_loaded(cluster)
'''

HELPER = '''\
def least_loaded(cluster):
    return min(range(cluster.size), key=cluster.load)
'''

PAST_THE_BUDGET = '''\
"""Scan one worker more than the scenario's declared probe budget allows."""


def choose(cluster, size):
    loads = [cluster.load(index % cluster.size) for index in range(cluster.size + 1)]
    return loads.index(min(loads))
'''

MALFORMED = '''\
"""A rewrite that never parses."""


def choose(cluster, size
    return 0
'''


__all__ = [
    "HELPER",
    "LEAST_LOADED_MIN_KEY",
    "LEAST_LOADED_SCAN",
    "MALFORMED",
    "MOST_LOADED_OF_TWO",
    "OFF_THE_CLUSTER",
    "PAST_THE_BUDGET",
    "POWER_OF_TWO",
    "WITH_HELPER",
]
