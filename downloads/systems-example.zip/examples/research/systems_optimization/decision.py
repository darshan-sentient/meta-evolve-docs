"""Deterministic attempt, selection, comparison, and accounting values.

The search is a governed ``meta.run`` and its trials live in a durable store.
Published selection and final comparison happen after it and remain example-local.
Every attempt made becomes an ``Attempt``, including typed failures. ``record.py``
stores them; ``policy.py`` owns their executable retained ordering; wall-clock
observations live separately so they cannot move decision identity.

The one rule they all enforce is the kernel's: an attempt holds metrics or a
typed failure, never both and never neither. Checked in ``__post_init__`` rather
than trusted, because a failure that quietly carried zeros is exactly how a
stopped split becomes a regression.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: five
retained values -- an attempt, a selection, a comparison, an accounting, and the
timings' shape -- each of which is a dataclass, a ``to_payload``, a
``from_payload``, and the refusals that make the round trip mean something. They
are one vocabulary: every one of them is read back out of the same JSON object,
by the same reader, under the same rules about what a number and a container may
be, and the whole difficulty of this module is keeping those rules in one place
rather than two spellings. Splitting by value would give five files of forty
lines each and put the shared helpers -- ``_measurements`` and ``_frames`` --
somewhere none of them lives.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType

from meta_evolve.domain import Usage
from meta_evolve.ports import EvaluationResult

# Read through the module rather than a from-import, so the rule this ranking
# applies and the rule the record declares cannot become two bindings.
from . import policy
from .observations import AttemptTiming
from .record_io import (
    retained_counts,
    retained_mapping,
    retained_payload,
    retained_scalars,
    retained_sequence,
)


def usage_payload(usage: Usage) -> dict[str, float]:
    """Deterministic reported usage. Wall clock lives in ``Observations``."""

    return {
        "tokens": usage.tokens,
        "spend_micros": usage.spend_micros,
    }


def _measurements(values: object, subject: str) -> dict[str, float]:
    """Every number in one retained mapping, or a refusal naming what it held.

    One rule for the two mappings an ``Attempt`` carries, in one place, for
    ``protocol.as_count``'s reason: two spellings of one rule drift, and the
    weaker spelling is the one that survives. ``handoff._mistyped`` and
    ``handoff._measured`` are the spelling on the proposal side; this is the one
    on the record side; a bare ``float(value)`` here would be a coercion rather
    than a check.

    In one place literally, and it has to be: a builder coercing with
    ``float(value)`` before handing the mapping over turns an honest integer
    metric into a float on the recorded path while it stays an integer through
    the constructor and ``from_payload``. Two ``Attempt``s over the same numbers
    would then compare unequal, which is exactly the drift a rule in one place is
    supposed to make impossible. The builders pass the mapping through.

    ``bool`` before ``int``, because ``True`` is an ``int`` and a quality of
    ``True`` is not a quality. ``float`` is still called, on a value about to be
    discarded, because it is how an ``int`` too large to be one announces itself.
    A number that passes is kept exactly as it arrived, which is what makes
    ``Attempt``'s round trip the identity it claims: reading the record back gives
    an ``int`` for ``0`` and a ``float`` for ``0.5``. Refusals are collected, so a
    record with two bad fields names both.

    The container and the keys go through the same two rules ``retained_counts``
    uses, and for the reason this docstring already gives about its values: this
    function and that one are one rule with two callers, and the round that typed
    the counts fixed the mapping there and left ``dict(payload["metrics"])`` here.
    A metrics field that was a number reached ``set(self.metrics)`` below and
    answered with a ``TypeError``, which is the fourth untyped crash and the one
    this replaced.

    The history, and the three untyped crashes this replaced, are in
    ``test_systems_optimization_measurements.py``.
    """

    measured: dict[str, float] = {}
    refused: list[str] = []
    for key, value in retained_mapping(values, subject).items():
        if not isinstance(key, str):
            refused.append(f"{key!r} is not a measurement name")
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            refused.append(f"{key} is {value!r}, which is not a number")
            continue
        try:
            magnitude = float(value)
        except OverflowError:
            refused.append(f"{key} is an integer too large to be a measurement")
            continue
        if not math.isfinite(magnitude):
            refused.append(f"{key} is {value}, not a finite measurement")
            continue
        measured[key] = value
    if refused:
        raise ValueError(f"{subject}: {'; '.join(sorted(refused))}")
    return measured


def evidence_frame(item: object) -> dict[str, object]:
    """One evidence item as the record holds it: its kind beside its data.

    Retaining the data alone leaves nothing in the file saying what sort of thing
    each payload is, and leaves ``audit.retained_fingerprint`` blind to a
    relabelled observation.
    """

    if not isinstance(item.kind, str) or not isinstance(item.data, Mapping):
        raise ValueError("evidence must carry a string kind and mapping data")
    return {"kind": item.kind, "data": dict(item.data)}


def _frames(value: object, subject: str) -> tuple[Mapping[str, object], ...]:
    """Validate evidence frame shapes, then recursively freeze their contents."""

    frames = retained_sequence(value, f"{subject} evidence")
    refused = []
    for index, item in enumerate(frames):
        if not isinstance(item, Mapping):
            refused.append(f"evidence item {index} is {item!r}, not a frame")
        elif set(item) != {"kind", "data"}:
            refused.append(f"evidence item {index} must contain only kind and data")
        elif not isinstance(item["kind"], str) or not isinstance(item["data"], Mapping):
            refused.append(f"evidence item {index} has a mistyped kind or data")
    if refused:
        raise ValueError(f"{subject}: {'; '.join(refused)}")
    return tuple(freeze_retained(item) for item in frames)


def _freeze(value: object) -> object:
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    return value


def freeze_retained(value: object) -> object:
    """Recursively freeze one already-validated retained value."""

    return _freeze(retained_payload(value))


def outcome_of(failure: object) -> str:
    """The named outcome behind one typed failure, or ``completed`` for none.

    ``outcomes.failure_for`` put the name in the failure's own details: the
    kernel type says how unrankable this is, the name says which of the thirteen
    failures happened.
    """

    if failure is None:
        return "completed"
    details = getattr(failure, "details", {})
    outcome = details.get("outcome", failure.kind)
    if not isinstance(outcome, str) or not outcome:
        raise ValueError("failure outcome must be a non-empty string")
    return outcome


# The scalar half of each section's payload, declared once so the read path can
# check rather than coerce. ``test_systems_optimization_record.py`` pins each
# table against the payload its own class writes, so a field added to one and not
# the other fails there instead of being read at whatever type it arrives as.
_ATTEMPT_FIELDS: Mapping[str, tuple[type, ...]] = {
    "candidate": (str,),
    "digest": (str,),
    "logical_step": (int,),
    "split": (str,),
    "outcome": (str,),
    "failure_kind": (str,),
    "detail": (str,),
    "scenario_runs": (int,),
}

_ACCOUNTING_FIELDS: Mapping[str, tuple[type, ...]] = {"scenario_ceiling": (int,)}


@dataclass(frozen=True, slots=True, kw_only=True)
class Attempt:
    """One candidate's whole outcome on one split, retained either way.

    ``metrics`` is empty exactly when ``failure_kind`` is set: the kernel's
    ``EvaluationResult`` invariant, carried into the record.
    """

    candidate: str
    digest: str
    logical_step: int
    split: str
    outcome: str
    failure_kind: str = ""
    detail: str = ""
    metrics: Mapping[str, float] = field(default_factory=dict)
    evidence: tuple[Mapping[str, object], ...] = ()
    scenario_runs: int = 0
    usage: Mapping[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # The subject first, and the two containers with it. The checks below ask
        # ``bool()`` and ``set()`` of ``metrics``, and ``set()`` of a number is a
        # ``TypeError`` rather than a refusal -- so the container is established
        # before anything interrogates it, and its contents after.
        subject = f"{self.candidate} on {self.split}"
        object.__setattr__(self, "metrics", retained_mapping(self.metrics, subject))
        object.__setattr__(self, "usage", retained_mapping(self.usage, subject))
        if bool(self.failure_kind) == bool(self.metrics):
            raise ValueError(
                f"{self.candidate} on {self.split}: an attempt carries either "
                "metrics or a typed failure, never both and never neither"
            )
        # Presence was checked, content was not: ``metrics={"work": 1.0}`` was
        # rankable and raised a bare ``KeyError`` from ``.quality``, at a point
        # where something was already ranking it.
        if self.metrics and not policy.RANKED_FIELDS <= set(self.metrics):
            raise ValueError(
                f"{self.candidate} on {self.split}: metrics must carry "
                f"{sorted(policy.RANKED_FIELDS)}, which the selection ranks on"
            )
        # Checked and normalized in one pass, by the one rule both mappings
        # answer to. ``usage`` is held to it as well: nothing reads those numbers
        # arithmetically, so a string there is record fidelity rather than a
        # moved decision -- but it is the same field type in the same dataclass
        # read back off the same record, and fixing one of two spellings leaves
        # the other one open.
        object.__setattr__(self, "metrics", MappingProxyType(_measurements(self.metrics, subject)))
        object.__setattr__(self, "usage", MappingProxyType(_measurements(self.usage, subject)))
        object.__setattr__(self, "evidence", _frames(self.evidence, subject))
        if self.rankable != (self.outcome == "completed"):
            raise ValueError(f"{subject}: outcome and failure kind disagree")

    @property
    def rankable(self) -> bool:
        return not self.failure_kind

    @property
    def evaluated(self) -> bool:
        """Terminal attempts with an artifact reached evaluation, even if it failed.

        A refused proposal has no successor and retains an empty digest.
        Off-surface candidates do have a digest and consume an evaluation,
        although they start no scenario processes.
        """

        return bool(self.digest)

    @property
    def quality(self) -> float:
        return float(self.metrics["quality"])

    @property
    def work(self) -> float:
        return float(self.metrics["work"])

    def to_payload(self) -> dict[str, object]:
        return {
            "candidate": self.candidate,
            "digest": self.digest,
            "logical_step": self.logical_step,
            "split": self.split,
            "outcome": self.outcome,
            "failure_kind": self.failure_kind,
            "detail": self.detail,
            "metrics": dict(self.metrics),
            "evidence": [retained_payload(item) for item in self.evidence],
            "scenario_runs": self.scenario_runs,
            "usage": dict(self.usage),
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> Attempt:
        # Named the way ``_measurements`` names its subject, and read defensively
        # for it: a record holds dozens of attempts, so "an attempt is wrong" is
        # not something a reader can act on, and the two fields that identify one
        # may themselves be the fields at fault.
        payload = retained_mapping(payload, "retained attempt")
        subject = f"attempt {payload.get('candidate')!r} on {payload.get('split')!r}"
        # Handed over as they arrived, like ``Accounting``'s counts: the three
        # ``dict()`` calls here were the coercions that turned a mistyped
        # container into a constructor's ``TypeError`` before ``__post_init__``
        # could refuse it, and they ran on the payload path only -- so the rule
        # they were standing in for held on one of this class's two paths.
        return cls(
            **retained_scalars(payload, _ATTEMPT_FIELDS, subject),
            metrics=payload["metrics"],
            evidence=payload["evidence"],
            usage=payload["usage"],
        )

    @classmethod
    def of(
        cls,
        result: EvaluationResult,
        *,
        candidate: str,
        digest: str,
        logical_step: int,
        split: str,
    ) -> Attempt:
        """Retain one ``EvaluationResult`` without deciding anything about it.

        The scenario count is read off the evidence rather than passed in: one
        observation per scenario ran, so the count *is* the work done.
        """

        failure = result.failure
        return cls(
            candidate=candidate,
            digest=digest,
            logical_step=logical_step,
            split=split,
            outcome=outcome_of(failure),
            failure_kind="" if failure is None else failure.kind,
            detail="" if failure is None else failure.message,
            metrics=result.metrics,
            evidence=tuple(evidence_frame(item) for item in result.evidence),
            scenario_runs=sum(item.kind == "scenario-observation" for item in result.evidence),
            usage=usage_payload(result.usage),
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Selection:
    """What the private split chose, and everything it chose from."""

    evaluator: str
    attempts: tuple[Attempt, ...]
    policy_declaration: Mapping[str, object] = field(default_factory=policy.declaration)
    timings: tuple[AttemptTiming, ...] = field(default=(), compare=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "policy_declaration", freeze_retained(self.policy_declaration))

    @property
    def ranked(self) -> tuple[Attempt, ...]:
        rankable = (item for item in self.attempts if item.rankable)
        return tuple(
            sorted(
                rankable,
                key=lambda item: policy.ranking_key(
                    item, declaration=self.policy_declaration
                ),
            )
        )

    @property
    def refused(self) -> tuple[Attempt, ...]:
        return tuple(a for a in self.attempts if not a.rankable)

    @property
    def chosen(self) -> Attempt | None:
        ranked = self.ranked
        return ranked[0] if ranked else None

    @property
    def winner(self) -> str:
        chosen = self.chosen
        return "none" if chosen is None else chosen.candidate


@dataclass(frozen=True, slots=True, kw_only=True)
class Comparison:
    """The held-out comparison, which is allowed to have no number in it."""

    evaluator: str
    baseline: Attempt
    selected: Attempt
    timings: tuple[AttemptTiming, ...] = field(default=(), compare=False, repr=False)

    @property
    def rankable(self) -> bool:
        return self.baseline.rankable and self.selected.rankable

    @property
    def verdict(self) -> str:
        """One word, and ``unrankable`` is one of them.

        A held-out split that stopped at a refusal has no aggregate. Averaging
        its default zeros into a number and calling that a regression is the
        mistake this property exists to make impossible.
        """

        if not self.rankable:
            return "unrankable"
        if self.selected.quality > self.baseline.quality:
            return "improved"
        return "tied" if self.selected.quality == self.baseline.quality else "regressed"


@dataclass(frozen=True, slots=True, kw_only=True)
class Accounting:
    """What one command did, split by split, beside the bound it fits in.

    ``invariants.check`` is what makes that ceiling bound them.

    The counts are typed here rather than in ``from_payload``, because this class
    is built on two paths -- read back from a payload, and recomputed from the
    attempts by ``invariants.counted`` -- and both have to hold the same rule.
    ``retained_counts`` carries why the ceiling was typed first and these were
    not.
    """

    evaluations: Mapping[str, int]
    scenario_runs: Mapping[str, int]
    scenario_ceiling: int

    def __post_init__(self) -> None:
        for name in ("evaluations", "scenario_runs"):
            object.__setattr__(
                self,
                name,
                retained_counts(getattr(self, name), f"retained {name}"),
            )
            object.__setattr__(self, name, MappingProxyType(dict(getattr(self, name))))

    @property
    def total_evaluations(self) -> int:
        return sum(self.evaluations.values())

    @property
    def total_scenario_runs(self) -> int:
        return sum(self.scenario_runs.values())

    def to_payload(self) -> dict[str, object]:
        return {
            "evaluations": dict(self.evaluations),
            "scenario_runs": dict(self.scenario_runs),
            "scenario_ceiling": self.scenario_ceiling,
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> Accounting:
        payload = retained_mapping(payload, "retained accounting")
        # Handed over as they arrived. ``dict()`` here was the last coercion on
        # this path: it turned a section whose counts were not a mapping into a
        # constructor's ``TypeError`` before any reader could refuse it, and it
        # would have accepted an array of pairs as a mapping.
        return cls(
            evaluations=payload["evaluations"],
            scenario_runs=payload["scenario_runs"],
            **retained_scalars(payload, _ACCOUNTING_FIELDS, "retained accounting"),
        )


__all__ = [
    "Accounting",
    "Attempt",
    "Comparison",
    "Selection",
    "evidence_frame",
    "freeze_retained",
    "outcome_of",
    "usage_payload",
]
