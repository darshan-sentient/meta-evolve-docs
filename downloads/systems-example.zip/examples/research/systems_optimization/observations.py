"""Non-deterministic observations retained beside the deterministic decision.

Wall-clock readings describe completed work, but they are not facts about a
candidate and cannot be reproduced byte for byte. Keeping them in ``Decision``
made two fixed-seed commands produce different decision identities. This module
keeps the readings durable without letting a clock choose that identity.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass

from .record_io import retained_mapping, retained_scalars, retained_sequence


# Read at these types rather than coerced into them, for the reason
# ``record_io.retained_scalars`` gives. A clock reading is one of the four things
# nothing in this example anchors, so fidelity is all a reader gets here -- and a
# reading that arrives as a string is not a reading.
_TIMING_FIELDS: Mapping[str, tuple[type, ...]] = {
    "candidate": (str,),
    "digest": (str,),
    "logical_step": (int,),
    "split": (str,),
    "wall_seconds": (int, float),
}

_OBSERVATIONS_FIELDS: Mapping[str, tuple[type, ...]] = {
    "total_wall_seconds": (int, float)
}


@dataclass(frozen=True, slots=True, kw_only=True)
class AttemptTiming:
    """The completed wall clock for one identified attempt."""

    candidate: str
    digest: str
    logical_step: int
    split: str
    wall_seconds: float

    def __post_init__(self) -> None:
        _valid_elapsed(self.wall_seconds, "attempt wall_seconds")

    @classmethod
    def of(cls, attempt: object, wall_seconds: float) -> AttemptTiming:
        """Take the identity off an attempt already checked, and one reading.

        Nothing is coerced here, for the same reason ``Attempt.of`` does not: a
        builder that normalizes beside a read path that does not is how one rule
        becomes two, and the two then disagree about whether a
        whole-number reading is an ``int`` or a ``float`` over the same record.
        """

        return cls(
            candidate=attempt.candidate,
            digest=attempt.digest,
            logical_step=attempt.logical_step,
            split=attempt.split,
            wall_seconds=wall_seconds,
        )

    def to_payload(self) -> dict[str, object]:
        return {
            "candidate": self.candidate,
            "digest": self.digest,
            "logical_step": self.logical_step,
            "split": self.split,
            "wall_seconds": self.wall_seconds,
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> AttemptTiming:
        payload = retained_mapping(payload, "retained timing")
        subject = f"timing for {payload.get('candidate')!r}"
        return cls(**retained_scalars(payload, _TIMING_FIELDS, subject))


@dataclass(frozen=True, slots=True, kw_only=True)
class Observations:
    """All timing the command retained, outside decision identity."""

    attempts: tuple[AttemptTiming, ...]
    total_wall_seconds: float

    def __post_init__(self) -> None:
        if not isinstance(self.attempts, tuple) or not all(
            isinstance(item, AttemptTiming) for item in self.attempts
        ):
            raise ValueError("observations attempts must contain timings")
        _valid_elapsed(self.total_wall_seconds, "total_wall_seconds")

    def to_payload(self) -> dict[str, object]:
        return {
            "attempts": [item.to_payload() for item in self.attempts],
            "total_wall_seconds": self.total_wall_seconds,
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> Observations:
        # The section itself, before anything indexes into it. Every *inner*
        # container of this record went through ``retained_mapping`` and this one
        # did not, so a record whose whole ``observations`` was a number answered
        # with ``'int' object is not subscriptable`` out of ``payload["attempts"]``
        # -- the outer half of the fault the inner ones were fixed for. It was
        # invisible because ``retained_scalars`` does make this call, and it is
        # the second keyword argument: the indexing happens first.
        payload = retained_mapping(payload, "retained observations")
        return cls(
            attempts=tuple(
                AttemptTiming.from_payload(item)
                for item in retained_sequence(
                    payload["attempts"], "retained timing attempts"
                )
            ),
            **retained_scalars(payload, _OBSERVATIONS_FIELDS, "retained timing total"),
        )


__all__ = ["AttemptTiming", "Observations"]


def _valid_elapsed(value: object, subject: str) -> None:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        or value < 0
    ):
        raise ValueError(f"{subject} must be a finite non-negative number")
