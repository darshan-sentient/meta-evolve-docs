"""What an outcome *is*: the scoring, the reports, and the failure taxonomy.

``execution.py`` produces outcomes; this module defines them. The seam is
worth having because the interesting claim of this example is not how a
subprocess is spawned -- it is which outcomes are rankable and which are not,
and that claim is testable on its own here without a simulator anywhere near it.

**Fourteen named outcomes, and exactly one is rankable.** The distinction that
matters is between a scheduler that is *bad* and a scheduler that is *not
evidence*: a slow but valid schedule earns a low ``quality`` because that is a
real measurement of a real algorithm, while a scheduler that would not import,
placed a task on a worker that does not exist, or ran out of wall clock earns no
metric at all and so cannot out-rank anything.

Timeouts sit deliberately on the unrankable side. A scheduler that ran out of
wall clock has told us about the machine, not about the algorithm.
"""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import (
    EvaluatorFailure,
    Failure,
    InfrastructureFailure,
    InvalidOutput,
    PolicyViolation,
    ResourceExhausted,
    TimeoutFailure,
    Usage,
)
from meta_evolve.ports import EvidenceDraft


# Scoring is the evaluator's, and it is stated as arithmetic rather than as a
# black box so a reader can predict any number this example prints.
#
#   quality = max(0, 1 - imbalance - WORK_WEIGHT * work)
#
# ``imbalance`` is ``simulator.Trace.imbalance`` -- (max - mean) / (total - mean),
# so zero is a perfect split and one is everything on a single worker -- and
# ``work`` is probes per task. Both fall to zero at their ideal. The weight is
# small on purpose: a scheduler should be willing to pay a couple of probes for a
# large balance gain, and unwilling to pay a full scan of the cluster for a
# marginal one.
#
# The formula is named rather than restated here. Spelling it out beside this
# constant drifts from the simulator the moment the normalization changes, and
# silently retunes every score.
WORK_WEIGHT = 0.02
SCORING_VERSION = "mean-quality-imbalance-minus-weighted-work-v1"

# outcome name -> the typed kernel failure it is reported as. Six of them share
# ``InvalidOutput`` because they *are* the same kind of thing to the kernel -- a
# candidate that produced nothing usable -- and stay distinguishable through the
# ``outcome`` recorded in the failure's details.
#
# Two describe the *channel* rather than the algorithm, and exist because the
# candidate runs in a process of its own (see ``verifier.py``):
# ``protocol-violated`` said something the placement vocabulary does not
# contain, ``abandoned`` stopped talking before the schedule finished. Neither
# is a low score; both are the absence of evidence.
#
# The last two are the *evaluator* admitting fault -- a report that failed its
# own re-check, and the harness breaking before it measured anything -- so they
# are typed as ``EvaluatorFailure``. Classifying those as the candidate's
# problem is how a broken measurement turns into a finding.
FAILURE_TYPES: dict[str, type[Failure]] = {
    "off-surface": PolicyViolation,
    "malformed-source": InvalidOutput,
    "construction-failed": InvalidOutput,
    "execution-failed": InvalidOutput,
    "invalid-schedule": InvalidOutput,
    "protocol-violated": InvalidOutput,
    "abandoned": InvalidOutput,
    "constraint-violated": PolicyViolation,
    "timed-out": TimeoutFailure,
    "resource-exhausted": ResourceExhausted,
    "infrastructure-failed": InfrastructureFailure,
    "report-rejected": EvaluatorFailure,
    "verifier-failed": EvaluatorFailure,
}
UNRANKABLE_OUTCOMES = tuple(FAILURE_TYPES)


def quality(imbalance: float, work: float) -> float:
    """Aggregate one scenario's two objectives into one comparable number."""

    return max(0.0, 1.0 - imbalance - WORK_WEIGHT * work)


@dataclass(frozen=True, slots=True, kw_only=True)
class ScenarioReport:
    """One scenario's outcome: measurements, or a named unrankable outcome."""

    scenario: str
    outcome: str
    imbalance: float = 0.0
    work: float = 0.0
    quality: float = 0.0
    loads: tuple[int, ...] = ()
    detail: str = ""
    usage: Usage = Usage()

    @property
    def completed(self) -> bool:
        return self.outcome == "completed"


@dataclass(frozen=True, slots=True, kw_only=True)
class SplitReport:
    """A whole split's aggregate, or the first unrankable outcome in it."""

    split: str
    scenarios: tuple[ScenarioReport, ...]
    usage: Usage = Usage()

    def __post_init__(self) -> None:
        # A split with nothing in it is not a measurement that failed; it is a
        # question nobody asked. It has no ``failure`` either, so a caller takes
        # the rankable branch and ``metrics`` divides by zero -- an untyped
        # ``ZeroDivisionError`` out of a module whose whole subject is that
        # every way of not being rankable has a name. Reachable through the
        # public API as ``command.run_example(root, private=())``.
        if not self.scenarios:
            raise ValueError(
                f"the {self.split!r} split has no scenarios, so there is nothing "
                "to measure and no metric that would mean anything"
            )
        # ``metrics`` and ``evidence`` both key a scenario by its name, so a
        # name carrying two *different* readings keeps the later and drops the
        # earlier silently -- a plausible aggregate with nothing to see. On
        # development that map is the only evaluator feedback a proposer reads.
        #
        # Repeating a scenario *identically* stays legal: the simulator is
        # deterministic, so nothing is lost under one key, and ``run_example(
        # root, private=workloads.PRIVATE * 3)`` is how the accounting tests
        # move the declared ceiling. One name meaning two things is what cannot
        # be allowed.
        readings: dict[str, tuple[object, ...]] = {}
        for item in self.scenarios:
            reading = (
                item.outcome,
                item.imbalance,
                item.work,
                item.quality,
                item.loads,
            )
            if readings.setdefault(item.scenario, reading) != reading:
                raise ValueError(
                    f"the {self.split!r} split reports two different readings for "
                    f"{item.scenario!r}, so one would replace the other in this "
                    "split's per-scenario metrics and evidence; a scenario name "
                    "has to mean one measurement"
                )

    @property
    def failure(self) -> ScenarioReport | None:
        return next((item for item in self.scenarios if not item.completed), None)

    @property
    def metrics(self) -> dict[str, float]:
        """Aggregates first, then every scenario's own numbers beside them.

        Per-scenario keys are ordinary metrics rather than side-channel evidence
        because on the development split they *are* the public feedback: a
        proposer reading the run's context sees exactly this map and nothing
        else about how its parent did.

        **Only when the split is rankable.** A failed ``ScenarioReport`` carries
        the field defaults, so averaging over an unrankable split answered with
        ``quality=0.0, imbalance=0.0, work=0.0``: a measured, very bad scheduler
        rather than no measurement at all, which is the one distinction this
        module exists to make. That the shipped caller asks ``failure`` first is
        the caller being careful, not the report being honest -- and a report is
        a value anyone may hold. So the accessor refuses, and ``failure`` is how
        a caller asks which half it is in. ``evidence`` stays available either
        way: what a failed scenario did is a fact worth keeping, while an
        average over it is a claim that cannot be made.
        """

        unrankable = self.failure
        if unrankable is not None:
            raise ValueError(
                f"the {self.split!r} split is not rankable -- {unrankable.scenario!r} "
                f"reports {unrankable.outcome!r} -- so it has no metrics; a split "
                "that did not measure has no bad score, it has no score"
            )
        count = len(self.scenarios)
        values = {
            "quality": sum(item.quality for item in self.scenarios) / count,
            "imbalance": sum(item.imbalance for item in self.scenarios) / count,
            "work": sum(item.work for item in self.scenarios) / count,
        }
        for item in self.scenarios:
            values[f"{item.scenario}.imbalance"] = item.imbalance
            values[f"{item.scenario}.work"] = item.work
        return values

    @property
    def evidence(self) -> tuple[EvidenceDraft, ...]:
        """One durable observation per scenario: what ran, and what it measured.

        Deliberately *without* the per-scenario wall clock, even though
        ``ScenarioReport.usage`` carries it and any in-process caller can read
        it. A fixed seed and budget have to produce identical evidence across
        processes, and a clock reading is the one thing that cannot. Timing is
        real evidence, so it is not discarded -- it rolls up into the
        evaluation's ``Usage``, which is measurement rather than a reproducible
        fact about the candidate. What is lost is the per-scenario breakdown,
        and that is the price of the reproducibility claim.
        """

        return tuple(
            EvidenceDraft(
                kind="scenario-observation",
                data={
                    "split": self.split,
                    "scenario": item.scenario,
                    "outcome": item.outcome,
                    "loads": list(item.loads),
                    "imbalance": item.imbalance,
                    "work": item.work,
                    "quality": item.quality,
                },
            )
            for item in self.scenarios
        )


def sandbox_outcome(failure: Failure) -> str:
    """Name the outcome for a failure raised by the execution boundary itself.

    Everything that is not a clock or a resource ceiling is
    ``infrastructure-failed``, **including a ``PolicyViolation``**. The failures
    that reach here come from the sandbox adapter refusing the request *this
    evaluator* built -- an executable, cwd, argv or environment it will not run
    -- which is a configuration fault this example owns. Naming it
    ``constraint-violated`` would file an evaluator bug under the candidate's
    name and make a broken harness look like a finding.

    The rules a *candidate* can break never arrive through this function:
    ``off-surface`` comes from ``surface.check_surface`` before any process
    exists, and ``constraint-violated`` from the probe budget inside the
    verifier, which is measuring rather than launching. A candidate-controlled
    ``PolicyViolation`` reaching the boundary would need its own branch and its
    own name, not this one widened to cover both.
    """

    if isinstance(failure, TimeoutFailure):
        return "timed-out"
    if isinstance(failure, ResourceExhausted):
        return "resource-exhausted"
    return "infrastructure-failed"


def failure_for(report: ScenarioReport, split_name: str, surface: str) -> Failure:
    """Map one named outcome onto its typed, unrankable kernel failure.

    The lookup is guarded because the bare index answered an outcome this table
    does not hold with a ``KeyError`` naming only the missing string -- and the
    reachable one is ``completed``, i.e. a caller that skipped the rankable
    branch. A caller that has lost track of which half it is in should be told
    that, not handed a dictionary's complaint.
    """

    if report.outcome not in FAILURE_TYPES:
        raise ValueError(
            f"{report.outcome!r} is not an unrankable outcome, so it has no "
            f"typed failure; {sorted(FAILURE_TYPES)} are the named failures, "
            "and a completed report carries metrics rather than one of them"
        )
    return FAILURE_TYPES[report.outcome](
        message=f"{report.outcome} on {report.scenario}",
        details={
            "outcome": report.outcome,
            "split": split_name,
            "scenario": report.scenario,
            "surface": surface,
            "detail": report.detail,
        },
    )


__all__ = [
    "FAILURE_TYPES",
    "SCORING_VERSION",
    "UNRANKABLE_OUTCOMES",
    "WORK_WEIGHT",
    "ScenarioReport",
    "SplitReport",
    "failure_for",
    "quality",
    "sandbox_outcome",
]
