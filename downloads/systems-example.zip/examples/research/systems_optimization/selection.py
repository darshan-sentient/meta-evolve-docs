"""Everything that happens after ``meta.run`` returns, which is most of the point.

The search is governed by the kernel: its budget, its lineage, its typed
failures, and its evidence are all the coordinator's. What is *not* the
kernel's is the published selection and final comparison, because both must
happen after the committed fixture search has finished. Sequencing alone would be
a weak argument -- it is an observation about trusted code -- so it is not the one
this example rests on: the process that proposes cannot read the file these
splits live in. See ``handoff.py``.

Being outside the run is not a licence to be outside the record. Each function
here produces ``decision`` values: every attempt these functions make is
retained whether or not it produced a metric, each split's evaluator identity is
named, and the counts are counted rather than estimated. ``record.py`` writes
them once, and ``audit.replay`` reads them back with nothing else running.

What is *not* retained is an attempt nobody made. Only candidates the search
evaluated are scored later -- see ``select`` for why -- so the selection
section is smaller than the development one, and the record is read as a whole.
"""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve.domain import SourceTree

from .bounds import SCENARIO_CEILING
from .decision import Accounting, Attempt, Comparison, Selection
from .execution import evaluate
from .identity import configuration_version
from .invariants import counted
from .observations import AttemptTiming, Observations
from .policy import declaration
from .proposals import candidate_name, source_digest
from .simulator import Scenario
from .surface import BASELINE, check_surface
from .workloads import HELD_OUT, PRIVATE


def select(
    result: meta.Run,
    *,
    split: tuple[Scenario, ...] = PRIVATE,
    split_name: str = "private",
) -> tuple[Selection, SourceTree | None]:
    """Score every candidate the search evaluated on the private split.

    In ``run_example`` this runs after the fixed fixture's ``meta.run`` has
    returned. The workload is published; what keeps it out of both a proposal and
    a candidate is that the kernel will not let either process read the file it
    lives in -- see ``confinement.py``.

    **Exactly the candidates the search evaluated**, and every one of their
    outcomes is retained -- including a candidate that ranked on development and
    then refused here, which different worker counts and different streams make
    an ordinary result rather than an anomaly.

    A candidate whose *development* evaluation failed is deliberately never
    looked at. It produced no evidence to select on, its typed refusal is
    already in the record's development section, and scoring it again would buy
    nothing: source that will not parse will not parse on another split either.
    So the private section holds five attempts against development's nine, and
    the two together are the whole story rather than either one alone.
    """

    attempts: list[Attempt] = []
    timings: list[AttemptTiming] = []
    artifacts: dict[str, SourceTree] = {}
    for trial in result.trials():
        if trial.state != "evaluated" or trial.artifact is None:
            continue
        candidate = trial.artifact.value
        name = candidate_name(trial)
        artifacts[name] = candidate
        evaluated = evaluate(candidate, split_name, split=split)
        attempt = Attempt.of(
            evaluated,
            candidate=name,
            digest=source_digest(candidate),
            logical_step=trial.logical_step,
            split=split_name,
        )
        attempts.append(attempt)
        timings.append(AttemptTiming.of(attempt, evaluated.usage.wall_seconds))
    selection = Selection(
        evaluator=configuration_version(split_name, split=split),
        attempts=tuple(attempts),
        policy_declaration=declaration(),
        timings=tuple(timings),
    )
    # No winner is a terminal outcome, not an exception. Raising here threw away
    # every private attempt the loop above had just performed -- their typed
    # failures, their diagnostics and their wall clock -- and those evaluations
    # happen *after* ``meta.run``, so the kernel store never held them either.
    # The caller decides what to do with a selection that chose nothing; what it
    # may not do is discover that fact by catching an exception that carries
    # none of the work.
    chosen = selection.chosen
    winner = None if chosen is None else artifacts[chosen.candidate]
    return selection, winner


def _ranked(selection: Selection, split_name: str) -> Attempt:
    """The chosen attempt, or the one refusal this module has for its absence.

    Both public functions need it and each had its own answer. ``select`` raised
    this ``RuntimeError``; ``compare`` asserted, seven lines away -- a bare
    ``AssertionError`` with no message, out of the module whose whole subject is
    that every way of not being rankable has a name. And ``compare`` is exported
    and called directly, by this example's own suite among others, so it is a
    supported reading path: the same "the committed path is fine, the exported
    function is not" shape as a digest stamped off ``chosen``.

    Under ``python -O`` it was worse than unnamed. The assert vanished and the
    next line raised ``AttributeError: 'NoneType' object has no attribute
    'candidate'`` from inside the comparison.
    """

    chosen = selection.chosen
    if chosen is None:
        raise RuntimeError(
            f"no candidate was rankable on the {split_name} split, so there is "
            "nothing to select and no comparison worth making"
        )
    return chosen


def compare(
    selection: Selection,
    winner: SourceTree,
    *,
    split: tuple[Scenario, ...] = HELD_OUT,
    split_name: str = "held_out",
) -> Comparison:
    """Score the baseline and the winner once each, and nothing else, ever."""

    chosen = _ranked(selection, split_name)
    # The surface first, and the digest second. ``source_digest`` hashes
    # ``scheduler.py`` alone, so a tree carrying the chosen scheduler *plus* an
    # extra file has the chosen digest and passed this guard -- the baseline was
    # then measured, held-out budget was spent, and the comparison came back
    # naming the chosen candidate's identity for a tree that was never selected.
    # The evaluator does refuse the extra file, so no forged score is produced;
    # what was defeated is this function's own contract, which is that neither
    # evaluation happens unless the supplied artifact is the selected one.
    off_surface = check_surface(winner)
    if off_surface is not None:
        raise ValueError(
            f"compare was handed a tree that is not this task's artifact: "
            f"{off_surface}; no held-out budget was spent"
        )
    supplied_digest = source_digest(winner)
    if supplied_digest != chosen.digest:
        raise ValueError(
            f"selected winner digest is {chosen.digest}, but compare received "
            f"{supplied_digest}; no held-out budget was spent"
        )
    baseline_result = evaluate(BASELINE, split_name, split=split)
    selected_result = evaluate(winner, split_name, split=split)
    baseline = Attempt.of(
        baseline_result,
        candidate=candidate_name(None),
        digest=source_digest(BASELINE),
        logical_step=0,
        split=split_name,
    )
    # Derived from the tree this function just scored, exactly as the baseline
    # seven lines up derives its own -- not copied off ``chosen``. The two agree
    # for every caller that passes ``select``'s own winner, which is the whole
    # committed path, so this changes no number. It matters for the exported
    # ``compare``: stamping the selection's digest onto a different tree recorded
    # a measurement of one artifact under the identity of another, and no rule
    # downstream could see it, because both halves of the lie agreed.
    # ``invariants.check`` now refuses that record instead, since the identity it
    # compares against ``chosen`` carries the digest.
    selected = Attempt.of(
        selected_result,
        candidate=chosen.candidate,
        digest=supplied_digest,
        logical_step=chosen.logical_step,
        split=split_name,
    )
    return Comparison(
        evaluator=configuration_version(split_name, split=split),
        baseline=baseline,
        selected=selected,
        timings=(
            AttemptTiming.of(baseline, baseline_result.usage.wall_seconds),
            AttemptTiming.of(selected, selected_result.usage.wall_seconds),
        ),
    )


def account(
    development: tuple[Attempt, ...],
    selection: Selection,
    comparison: Comparison | None,
    *,
    ceiling: int = SCENARIO_CEILING,
) -> Accounting:
    """What actually happened, counted per split rather than estimated.

    Delegated to ``invariants.counted`` so that the counts a record is written
    with and the counts a record is checked against on read are one projection
    rather than two that agree until one of them is edited.

    ``ceiling`` is a parameter because the later splits are: a command run over a
    bigger private split has a bigger bound, and retaining the committed one
    beside it makes the record report a count larger than its own ceiling.
    """

    return counted(development, selection, comparison, ceiling=ceiling)


def observations(
    result: meta.Run,
    development_timings: tuple[AttemptTiming, ...],
    selection: Selection,
    comparison: Comparison | None,
) -> Observations:
    """Retain completed timing without making it part of decision identity."""

    later = (
        *selection.timings,
        *(() if comparison is None else comparison.timings),
    )
    return Observations(
        attempts=(*development_timings, *later),
        total_wall_seconds=(
            result.inspect().overview.task_usage.wall_seconds
            + sum(item.wall_seconds for item in later)
        ),
    )


__all__ = [
    "account",
    "compare",
    "observations",
    "select",
]
