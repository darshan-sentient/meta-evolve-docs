"""The only program that ever imports candidate code, in a process of its own.

``verifier.py`` spawns this module as a child process and speaks ``protocol``
to it over a pipe. This side imports ``scheduler.py`` -- the candidate -- and
hands it a proxy whose ``size``, ``load``, and ``pick`` are pipe round trips to
the verifier. The candidate's API is exactly what it would be in-process, so
the schedulers in ``schedulers.py`` are written the obvious way; what changed is
that the object they hold is a telephone, not the cluster.

**What this process does not have.** No simulator state, no loads array, no
task stream, no scenario name, no split name, no probe counter, and no way to
put anything on the sandbox's stdout. It learns the worker count from the
handshake and one task size at a time, and the only thing it can say is *which
worker*. There is no message in ``protocol`` through which it could report a
measurement, so a candidate cannot state its own score however it behaves.

**Why the first thing it does is close its own stdout.** The protocol channel
is this process's fd 0 and fd 1. Before any candidate code is imported, both
are duplicated to private descriptors and the standard ones are pointed at
``/dev/null``, so a candidate that calls ``print``, writes to ``sys.stdout``,
or calls ``os.write(1, ...)`` reaches a black hole rather than the channel the
verifier is parsing. That is a boundary rather than a deny-list: there is no
source text to pattern-match, and a candidate that finds the private
descriptor anyway gains only the ability to say something the verifier will
reject as a protocol violation.
"""

from __future__ import annotations

import os
import traceback

try:  # the example package: importable, reviewable, and unit-testable
    from . import protocol
except ImportError:  # a workspace copy: plain sibling modules, no package
    import _protocol as protocol  # type: ignore[no-redef]


class Halted(Exception):
    """The verifier stopped the schedule. It has already decided the outcome."""


class Channel:
    """The private duplicate of this process's pipe to the verifier."""

    __slots__ = ("_reader", "_writer")

    def __init__(self, reader: object, writer: object) -> None:
        self._reader = reader
        self._writer = writer

    @classmethod
    def take_over(cls) -> Channel:
        """Move the pipe to private descriptors and blind the standard ones.

        Called once, before candidate code exists in this process. Everything a
        candidate writes to its stdout or stderr from then on is discarded.
        """

        reader = os.fdopen(os.dup(0), "rb")
        writer = os.fdopen(os.dup(1), "wb")
        blackhole = os.open(os.devnull, os.O_RDWR)
        for standard in (0, 1, 2):
            os.dup2(blackhole, standard)
        os.close(blackhole)
        # ``sys.stdout`` and ``sys.stderr`` are not replaced, and do not need
        # to be: they still wrap descriptors 1 and 2, which now name
        # ``/dev/null``. Everything written through them, and everything
        # written to those numbers directly, goes to the same nowhere.
        return cls(reader, writer)

    def send(self, op: str, **fields: object) -> None:
        self._writer.write(protocol.encode(op, **fields))
        self._writer.flush()

    def receive(self) -> dict[str, object]:
        """Read one message, or raise ``Halted`` when the verifier is finished."""

        line = self._reader.readline()
        if not line:
            raise Halted("the verifier closed the channel")
        message = protocol.decode(line)
        if message["op"] == protocol.HALT:
            raise Halted(str(message.get("reason", "")))
        return message

    def ask(self, op: str, expected: str, **fields: object) -> int:
        """Send one question and read the one integer that answers it."""

        self.send(op, **fields)
        message = self.receive()
        if message["op"] != expected:
            raise protocol.ProtocolError(
                f"expected {expected} in answer to {op}, got {message['op']!r}"
            )
        value = message.get("value")
        if isinstance(value, bool) or not isinstance(value, int):
            raise protocol.ProtocolError(f"{expected} value must be an integer")
        return value


class Cluster:
    """What a candidate scheduler is handed: three questions, and a telephone.

    ``size``, ``load``, and ``pick`` are the intended surface. ``_channel`` is
    reachable as well, and saying otherwise would be false: Python has no
    private attributes, and neither ``__slots__``, nor name mangling, nor
    holding the channel in a closure changes that, because a closure is
    introspectable too.

    It is not a bypass, and the reason is the same one the whole boundary rests
    on. The channel carries protocol messages and the *verifier* meters every
    one of them, so a candidate that probes through ``_channel`` directly pays
    exactly the probes a candidate calling ``load`` pays. There is no message it
    can send that carries a measurement, and -- since the round that took away the
    one message which blamed the evaluator -- none that carries a verdict about
    whose fault a failure was either. The worst it buys is the ability to desync
    its own conversation, or to say something the vocabulary does not contain,
    and both cost it a schedule rather than earning it a score.
    ``test_systems_optimization_agent.py`` drives this module through real
    candidate code -- including a placement whose ``repr`` raises, which is the
    desync the paragraph above is about -- and the slice that adds the proposer
    boundary adds the channel-level cases beside it.
    """

    __slots__ = ("_channel", "_size")

    def __init__(self, channel: Channel, size: int) -> None:
        self._channel = channel
        self._size = size

    @property
    def size(self) -> int:
        """How many workers exist. Free: it is the cluster's shape, not its state."""

        return self._size

    def load(self, index: object) -> int:
        """Ask the verifier one worker's load. Costs one probe.

        One probe if the index names a worker. If it does not, the verifier
        refuses the placement instead of charging for it, which ends the whole
        schedule as ``invalid-schedule`` -- so there is nothing to charge to.
        """

        return self._channel.ask(
            protocol.PROBE, protocol.LOAD, worker=protocol.wire_worker(index)
        )

    def pick(self) -> int:
        """Ask for the next index of the verifier's fixed sequence. Costs nothing."""

        return self._channel.ask(protocol.PICK, protocol.INDEX)


def _import_scheduler(channel: Channel) -> object | None:
    """Import the candidate, or report why it is not usable and return ``None``.

    The diagnosis happens here because this is the only place with enough
    information to tell a module that will not parse from one that parses and
    then raises on import. The evaluator maps the reported name onto a typed
    failure; it does not re-diagnose.
    """

    try:
        import scheduler  # type: ignore[import-not-found]
    except SyntaxError as error:
        channel.send(
            protocol.UNUSABLE, reason="malformed-source", detail=_detail(error)
        )
        return None
    except BaseException as error:
        channel.send(
            protocol.UNUSABLE, reason="construction-failed", detail=_detail(error)
        )
        return None
    choose = getattr(scheduler, "choose", None)
    if not callable(choose):
        channel.send(
            protocol.UNUSABLE,
            reason="construction-failed",
            detail="scheduler.py defines no callable choose(cluster, size)",
        )
        return None
    return choose


def _detail(error: BaseException) -> str:
    try:
        rendered = str(error)
    except BaseException:
        rendered = "<exception text raised while rendering>"
    text = f"{type(error).__name__}: {rendered}"
    frames = traceback.extract_tb(error.__traceback__)
    if frames:
        last = frames[-1]
        text = f"{text} at {last.filename}:{last.lineno}"
    return text[: protocol.DETAIL_LIMIT]


def main() -> int:
    """Serve placement requests until the verifier halts. Always exits zero.

    A non-zero exit would be a claim about the candidate, and this process is not
    entitled to make claims -- about the candidate, and no more about the
    evaluator, because it holds candidate code and so anything it says about the
    other side is something a candidate can say. What it cannot act on it stops
    acting on. The verifier, which now holds every count it sends to the rule
    ``protocol.as_count`` states, owns what the outcome was.
    """

    channel = Channel.take_over()
    try:
        begin = channel.receive()
        if begin["op"] != protocol.BEGIN:
            return 0
        cluster = Cluster(channel, protocol.as_count(begin.get("workers"), "workers"))
        choose = _import_scheduler(channel)
        if choose is None:
            return 0
        channel.send(protocol.READY)
        while True:
            message = channel.receive()
            if message["op"] != protocol.TASK:
                return 0
            size = protocol.as_count(message.get("size"), "size")
            try:
                placement = choose(cluster, size)
            except Halted:
                return 0
            except BaseException as error:
                channel.send(protocol.RAISED, detail=_detail(error))
                return 0
            try:
                channel.send(protocol.PLACE, worker=protocol.wire_worker(placement))
            except BaseException as error:
                channel.send(protocol.RAISED, detail=_detail(error))
                return 0
    except (Halted, protocol.NotACount, protocol.ProtocolError, OSError):
        # Four ways to be unable to go on, and one thing to do about all of them.
        # The verifier halted, or it sent a count that is not one, or the channel
        # itself is broken -- and in none of those cases is there anywhere left to
        # say so, because the only channel out of this process is one candidate
        # code can write on. ``protocol.py`` carries the round that learned it.
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
