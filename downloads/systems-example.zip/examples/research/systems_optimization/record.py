"""The content-addressed file holding one decision and its observations.

``decision.py`` defines what an attempt, a selection, and a comparison *are*.
This module is the container: one JSON object holding every attempt each split
made, the evaluator identity each was scored under, the policy applied, the
counts, and the verdict. The three sections hold different numbers of attempts on
purpose -- ``selection.select`` says why -- so it is read as a whole.

The deterministic decision has its own digest. Completed wall-clock observations
sit beside it and the complete envelope has a second digest repeated in the
filename. Thus two fixed-seed processes agree on the decision identity while
each retains its real timing, and any ordinary edit moves the record identity.

What that buys, exactly. An edit to the decision is caught, because the
recomputed digest moves. An edit that also rewrites the envelope's digest is
caught, because the filename still holds the old one. An edit that adds a field
nothing here reads is caught too, and that one is newer than the rest: a digest
over the stored bytes pins them against themselves, so a resealed record could
carry a key in any section and the key rode along unread. Both sections are
reconstructed on read and compared against the file that produced them --
``_is_what_it_reconstructs`` -- because a record may not hold what its own reader
does not read back. An edit that rewrites all three digests *and* survives that
is self-consistent, and no scheme inside one file can catch it -- so
``audit.replay`` adds the checks that come from outside: the record names the
durable run it came from, and the store independently holds that run's
artifacts, metrics, lineage, evidence, clock, and the declaration it started
from -- the seed artifact, the random seed, the proposer, and the development
evaluator. Forging any of that does not move the store, and the replay reports
the disagreement.

**And the scope of that, said plainly.** The private and held-out splits are
scored after ``meta.run`` returns, so nothing in this directory ever witnessed
them. Five retained things therefore have no anchor here, and a rewrite of any
one of them that updates both digests and the filename stands:

* a later **measurement** -- a private or held-out quality;
* a later **clock reading**, moved together with the retained total;
* the private and held-out **evaluator identities**, which have nothing to be
  compared against and only have to be three distinct declarations;
* the declared **scenario ceiling**, which is a bound rather than a count;
* the retained **selection policy**, whose labels can each be restated one at a
  time. ``policy.check_declaration`` closes that much -- the version is a fold of
  the labels beside it, so restating one alone is refused -- but a declaration
  restated *consistently*, or restated under a
  version scheme this repository does not implement, has nothing here to
  disagree with. What the rule always does is make the claimed rule explicit.

Catching any of those needs an anchor this example does not have -- a signature,
or a log outside the output root.

What is not open to a forger is **who the candidates were**, in any section.
``invariants.py`` pins the later sections to the development one -- selection
scores exactly the development candidates that ranked, the baseline is the seed,
the comparison scores the winner, the sections are labelled, and the counts are
the counts of the retained work -- and this class refuses to exist when one does
not hold. Since the store witnesses that section attempt for attempt, forging a
later *candidate* identity means forging the search to match.

So: tamper-evident, and evident about *what*. What remains open is the five
above, and what closed the rest is that the later sections cannot describe a run
the store did not hold. Smaller than immutability, and true.

Reading it back runs nothing: no workspace, no subprocess, no simulator, and not
even this example's evaluator. That is the property anyone auditing an automated
search actually needs -- the ability to check a selection without trusting, or
re-paying for, the machinery that produced it.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: the
envelope and its two identities are one subject, and the paragraphs above are
most of the length -- what each digest catches, what it does not, and which gaps
are stated rather than closed. The serialization primitives already moved out to
``record_io.py`` once, which is the split there was to make; what is left is the
``Decision`` container, the write, and the read that reconstructs and re-hashes
both sections. Separating the write from the read that verifies it would put the
two halves of one guarantee in different files.
"""

from __future__ import annotations

import json
import os
import tempfile
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from . import invariants
from .decision import (
    Accounting,
    Attempt,
    Comparison,
    Selection,
    freeze_retained,
    retained_payload,
)
from .observations import Observations
from .record_io import (
    RECORD_PREFIX,
    RECORD_SUFFIX,
    canonical,
    digest_in_name,
    digest_of,
    locate,
    path_for,
    reseal,
    retained_mapping,
    retained_scalars,
    retained_sequence,
)


# Still v3 after the cross-section rules arrived, deliberately: the payload
# schema did not change and every rule holds on every honest v3 record, so files
# written before them still read. What would force v4 is a rule an honest older
# record could fail -- and a hand-written v3 that fails one now is refused
# without a version to explain why, which is the price of not bumping it.
RECORD_VERSION = "systems-optimization-decision-v3"

# What an envelope holds besides the two retained sections. Named so that
# ``_is_what_it_reconstructs`` can refuse a key nothing here reads rather than
# carry it: the two digests and the version are the whole of the rest.
_ENVELOPE_KEYS = frozenset({"record", "decision_digest", "record_digest"})

# This record's own scalars and the three evaluator names, at the types they were
# written. ``record_io.retained_scalars`` says why reading them is a check here
# rather than a coercion; ``random_seed`` is the field that shows the cost.
_DECISION_FIELDS: Mapping[str, tuple[type, ...]] = {
    "search_run": (str,),
    "random_seed": (int,),
    "proposer": (str,),
}

_EVALUATOR_FIELDS: Mapping[str, tuple[type, ...]] = {
    "development": (str,),
    "private": (str,),
    "held_out": (str,),
}


@dataclass(frozen=True, slots=True, kw_only=True)
class Decision:
    """Everything one command produced, in the order it produced it."""

    search_run: str
    random_seed: int
    proposer: str
    development_evaluator: str
    selection_policy: Mapping[str, object]
    development: tuple[Attempt, ...]
    selection: Selection
    # ``None`` when nothing ranked on the private split: there is no winner to
    # compare, and held-out budget is deliberately not spent inventing one.
    comparison: Comparison | None
    accounting: Accounting

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "selection_policy", freeze_retained(self.selection_policy)
        )
        # Every rule that holds the sections together, refused here rather than
        # reported on read. ``invariants.py`` says what they are and why they are
        # refusals: each is a claim about this record's own sections, so a reader
        # needs nothing else in hand to test one.
        invariants.check(self)

    def to_payload(self) -> dict[str, object]:
        return {
            "record": RECORD_VERSION,
            "search_run": self.search_run,
            "random_seed": self.random_seed,
            "proposer": self.proposer,
            # Retained rather than re-derived on read. A record written under an
            # older rule has to stay readable, because explaining a changed
            # winner is the entire reason the rule carries a version.
            "selection_policy": retained_payload(self.selection_policy),
            "evaluators": {
                "development": self.development_evaluator,
                "private": self.selection.evaluator,
                "held_out": "" if self.comparison is None else self.comparison.evaluator,
            },
            "development": [item.to_payload() for item in self.development],
            "private": [item.to_payload() for item in self.selection.attempts],
            "winner": self.selection.winner,
            "held_out": None if self.comparison is None else {
                "baseline": self.comparison.baseline.to_payload(),
                "selected": self.comparison.selected.to_payload(),
                "verdict": self.comparison.verdict,
            },
            "accounting": self.accounting.to_payload(),
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> Decision:
        payload = retained_mapping(payload, "retained decision")
        if payload.get("record") != RECORD_VERSION:
            raise ValueError(f"unknown decision record: {payload.get('record')!r}")
        named = retained_scalars(
            payload["evaluators"], _EVALUATOR_FIELDS, "decision record evaluators"
        )
        # ``None`` is the record of a run where nothing ranked: no winner, so no
        # comparison, and none invented on read either.
        raw_held_out = payload["held_out"]
        held_out = (
            None
            if raw_held_out is None
            else retained_mapping(raw_held_out, "retained held-out")
        )
        # Not ``dict()``. That accepts an array of pairs -- which
        # ``_is_what_it_reconstructs`` below catches a step later and without
        # naming the field -- and turns every other mistyped shape into a
        # constructor's ``TypeError`` instead of a refusal.
        policy = retained_mapping(payload["selection_policy"], "decision record")
        decision = cls(
            **retained_scalars(payload, _DECISION_FIELDS, "decision record"),
            development_evaluator=named["development"],
            selection_policy=policy,
            development=_attempts(payload["development"]),
            selection=Selection(
                evaluator=named["private"],
                attempts=_attempts(payload["private"]),
                policy_declaration=policy,
            ),
            comparison=None if held_out is None else Comparison(
                evaluator=named["held_out"],
                baseline=Attempt.from_payload(held_out["baseline"]),
                selected=Attempt.from_payload(held_out["selected"]),
            ),
            accounting=Accounting.from_payload(payload["accounting"]),
        )
        # The winner and the verdict are stored *and* re-derived, and a record
        # whose two disagree is refused rather than read. Without this the
        # summary fields would be decoration: a corrupted ``winner`` would load
        # cleanly, and a replay comparing reconstructed winners would compare
        # two copies of the same recomputation and agree with itself. The stored
        # policy is named in the refusal, because "these attempts no longer
        # derive this winner" is only actionable if a reader can see which rule
        # derived it in the first place.
        under = f"under selection policy {policy.get('version')!r}"
        _require(decision.selection.winner, payload["winner"], f"winner {under}")
        if decision.comparison is not None:
            _require(decision.comparison.verdict, held_out["verdict"], "held-out verdict")
        return decision


@dataclass(frozen=True, slots=True, kw_only=True)
class Outcome:
    """One command's whole result: the run, the record, and what replay saw.

    ``search`` stays a live ``meta.Run`` because the report reads its trials in
    visit order, which is the story the development section tells. Everything
    after the search is read out of ``decision``, so the printed later sections
    and the file on disk cannot disagree.
    """

    search: object
    decision: Decision
    observations: Observations
    record: Path
    decision_digest: str
    record_digest: str
    replayed: Mapping[str, bool]


@dataclass(frozen=True, slots=True, kw_only=True)
class RetainedRecord:
    """The two retained sections and both identities verified on read."""

    decision: Decision
    observations: Observations
    decision_digest: str
    record_digest: str


def _require(derived: object, stored: object, what: str) -> None:
    """Refuse a record whose stored summary does not match its own attempts."""

    if derived != stored:
        raise ValueError(
            f"decision record {what} is {stored!r}, but its attempts derive "
            f"{derived!r}; the record is not internally consistent"
        )


def _attempts(payload: object) -> tuple[Attempt, ...]:
    """One split's attempts, refusing a list that is not one.

    ``Attempt.from_payload`` refuses an item that is not a section;
    ``retained_sequence`` refuses the thing holding them, which was iterated
    straight and answered a mistyped split with ``'int' object is not iterable``.
    """

    return tuple(
        Attempt.from_payload(item)
        for item in retained_sequence(payload, "a retained split")
    )


def _is_what_it_reconstructs(
    envelope: Mapping[str, object], decision: Decision, observations: Observations
) -> None:
    """Refuse a record that holds anything the reader does not read back.

    Every digest here is an identity *of* ``to_payload`` and ``from_payload``
    being inverse, and asserting that in a docstring is not checking it. On their
    own the digests pin the bytes against themselves: a forger who reseals both
    and renames the file can add a field to any section, and the field rides
    along unread.

    Four levels of it, each confirmed against a written record: a key smuggled
    into the envelope, into the decision, into an attempt, or into the
    accounting. All four load, and all ten replay checks come back true, because
    a reader who takes the fields it knows and ignores
    the rest cannot notice the rest. The narrow case of the same shape is
    ``selection_policy`` written as a JSON list of pairs, which ``dict()``
    accepts and ``to_payload`` writes back as an object.

    So the rule is stated the only way that closes the class rather than the
    instances: what the reader rebuilds has to be what the file says, field for
    field. A field this code does not read is a field it cannot vouch for, and a
    record is not a place to put one.

    The refusal names the digests of both sides rather than diffing them,
    because these payloads are thousands of lines and the two identities are what
    a reader can act on -- the same handle ``read_retained`` gives above.
    """

    rebuilt = {
        "decision": decision.to_payload(),
        "observations": observations.to_payload(),
    }
    faults = [
        f"the retained {name} hashes to {digest_of(envelope[name])} but reads "
        f"back as {digest_of(payload)}"
        for name, payload in rebuilt.items()
        if payload != envelope[name]
    ]
    smuggled = sorted(set(envelope) - set(rebuilt) - _ENVELOPE_KEYS)
    if smuggled:
        faults.append(f"the envelope carries {smuggled}, which nothing here reads")
    if faults:
        raise ValueError(
            f"{'; '.join(faults)}; a record holding what its reader does not read "
            "back is not the decision it is a record of"
        )


def write(
    decision: Decision, observations: Observations, directory: Path
) -> tuple[Path, str, str]:
    """Write the complete record and return its two content identities.

    ``O_EXCL`` stays, but it is no longer the claim. The filename addresses the
    whole envelope, timing included, so two commands collide only when every
    retained byte matches -- and then the refusal is correct rather than
    inconvenient. Fixed-seed reproducibility is ``decision_digest``'s job.
    """

    # ``canonical`` runs inside ``reseal`` and refuses a non-finite number
    # anywhere in the envelope, which is the right refusal in the wrong words: it
    # says "Out of range float values are not JSON compliant" and names neither
    # the record being written nor the field holding the value, which leaves a
    # reader asking which of the several hundred numbers in a decision it meant.
    # Nothing here can find that field cheaply -- the envelope is nested and the
    # values arrive
    # from three sections -- so what is added is the context this function does
    # have: which directory the write was for, and what the two layers are.
    try:
        envelope = reseal({
            "record": RECORD_VERSION,
            "decision": decision.to_payload(),
            "observations": observations.to_payload(),
        })
    except ValueError as unwritable:
        raise ValueError(
            f"this decision cannot be written to {directory}: {unwritable}. "
            "Every number a record retains has to be finite, because NaN and "
            "Infinity are not JSON and readers disagree about them -- jq "
            "silently rewrites both to null while JSON.parse refuses the file. "
            "decision.Attempt refuses a non-finite ranked metric before this "
            "point, so a value reaching here is one of the numbers it does not "
            "cover: a usage figure, a timing, or a declared bound"
        ) from unwritable
    decision_digest = str(envelope["decision_digest"])
    record_digest = str(envelope["record_digest"])
    path = path_for(directory, record_digest)
    directory.mkdir(parents=True, exist_ok=True)
    serialized = (canonical(envelope) + "\n").encode("utf-8")
    temporary = ""
    try:
        with tempfile.NamedTemporaryFile(dir=directory, prefix=".decision-", delete=False) as handle:
            temporary = handle.name
            handle.write(serialized)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, path)
        directory_fd = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if temporary:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
    return path, decision_digest, record_digest



def _not_a_number(literal: str) -> float:
    """Refuse the three non-JSON constants ``json`` would otherwise accept."""

    raise ValueError(
        f"{literal} is not a number JSON can carry, and no measurement this "
        "example records is one"
    )


def read_retained(path: Path) -> RetainedRecord:
    """Verify both identities and reconstruct both retained sections.

    Both copies of the record digest are checked -- the one inside the envelope
    and the one in the filename. Each catches a different edit.

    Neither claimed digest is passed through ``str()`` any more. It read like
    defensive tidying and was the same coercion ``retained_scalars`` exists to
    refuse: a file whose ``record_digest`` is a number is a file that has been
    rewritten, and stringifying it first only meant the refusal blamed the digest
    rather than the type. A value that is not a digest cannot equal one, so the
    comparison refuses it either way -- and there is now a law that no door into
    this record coerces, which those two calls would have broken.

    Both sections are then reconstructed and compared against the file that
    produced them. ``_is_what_it_reconstructs`` says why a digest over the stored
    bytes was never that check.
    """

    try:
        with open(path, encoding="utf-8") as handle:
            # ``json`` accepts ``NaN``, ``Infinity`` and ``-Infinity`` by
            # default, which are not JSON and which this example's own writer
            # refuses to emit. Without this they were caught much later, by the
            # digest calculation, as "Out of range float values are not JSON
            # compliant: nan" -- a message naming neither the file it came from
            # nor the field that held it. Refused where the bytes are read, and
            # named there.
            envelope = json.load(handle, parse_constant=_not_a_number)
    except json.JSONDecodeError as error:
        raise ValueError(f"decision record {path.name} is not complete JSON") from error
    except ValueError as error:
        raise ValueError(f"decision record {path.name}: {error}") from error
    # The outermost container, and the one the container round missed: a file
    # whose JSON root is ``[]``, ``9`` or ``null`` parses fine and then answered
    # ``'list' object has no attribute 'get'`` from the version check below,
    # before any digest is computed and with nothing naming the file as the thing
    # that is wrong. Every section *inside* the envelope is refused by name; the
    # envelope must not be read on trust.
    envelope = retained_mapping(envelope, f"decision record {path.name}")
    if envelope.get("record") != RECORD_VERSION:
        raise ValueError(f"unknown decision record: {envelope.get('record')!r}")
    body = {key: value for key, value in envelope.items() if key != "record_digest"}
    record_digest = digest_of(body)
    for claimed, where in (
        (envelope.get("record_digest", ""), "the digest it carries"),
        (digest_in_name(path), "the digest in its name"),
    ):
        if claimed != record_digest:
            raise ValueError(
                f"decision record {path.name} hashes to {record_digest!r}, but "
                f"{where} is {claimed!r}; it has been rewritten since it was "
                "written and is not evidence of anything"
            )
    decision_digest = digest_of(envelope["decision"])
    if envelope.get("decision_digest", "") != decision_digest:
        raise ValueError(
            f"decision hashes to {decision_digest!r}, but its retained digest is "
            f"{envelope.get('decision_digest')!r}"
        )
    decision = Decision.from_payload(envelope["decision"])
    observations = Observations.from_payload(envelope["observations"])
    _is_what_it_reconstructs(envelope, decision, observations)
    return RetainedRecord(
        decision=decision,
        observations=observations,
        decision_digest=decision_digest,
        record_digest=record_digest,
    )


def read(path: Path) -> Decision:
    """Compatibility convenience for callers that need only deterministic facts."""

    return read_retained(path).decision


__all__ = [
    "RECORD_PREFIX",
    "RECORD_SUFFIX",
    "RECORD_VERSION",
    "Decision",
    "Outcome",
    "RetainedRecord",
    "canonical",
    "digest_in_name",
    "digest_of",
    "locate",
    "path_for",
    "read",
    "read_retained",
    "reseal",
    "write",
]
