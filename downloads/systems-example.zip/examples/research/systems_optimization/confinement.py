"""Kernel-enforced confinement for the processes that hold candidate authority.

The process split makes a candidate unable to *say* anything that carries a
measurement. It says nothing about the filesystem, and the splits are committed
literals in ``workloads.py`` -- so a candidate that went looking could read the
exact scenarios it was about to be scored on. This module closes that, for the
scenario run and for the proposal that precedes it.

**Why the kernel and not Python.** An in-process ``sys.addaudithook`` is an
ordinary Python function, reachable through ``gc.get_objects()`` and replaceable
through its ``__code__``. The operating system is asked instead: a candidate
cannot patch it, and it holds across ``exec`` into every child.

**What is claimed, exactly.** *A confined process can neither read nor write the
files of this repository, apart from the interpreter installation inside it.*
That exemption is checked rather than waved past: CPython cannot start without
its standard library and this project's environment lives at ``.venv`` inside
the repository, so ``sys.prefix`` stays readable -- and ``readable_paths``
refuses outright, on canonical paths, if an exemption would reach this example's
own directory. It is exempt from *reading* only, because a candidate that could
rewrite ``workloads.py`` or ``verifier.py`` would never need to read them.

**What is not claimed.** Network, CPU, memory, and syscalls generally. Nor every
filesystem operation: Landlock mediates the access rights it defines, and
metadata operations -- ``chmod`` and ``chown`` among them -- are outside them
(https://docs.kernel.org/userspace-api/landlock.html#filesystem-flags). macOS's
sandbox does refuse some of those, and a passing test there is evidence about
that mechanism rather than a cross-platform guarantee. The declared policy is
file read and write access to this repository; that, and only that, is what both
mechanisms enforce.

**Two mechanisms, one repository policy.** macOS's ``file-read-data`` denial
covers file contents and directory enumeration together; Landlock names
``READ_FILE`` and ``READ_DIR`` separately and grants both only on its allow-list.
``declaration()`` names the boundary they share and never the mechanism: two
machines enforcing one rule by different means must declare one evaluator, or a
fixed seed would stop producing one decision identity. Outside the repository
they differ, and candidate code can observe that: macOS allows by default, while
Landlock denies handled access outside its allow-list. They also refuse
differently -- macOS ``EPERM``, Landlock ``EACCES``, and ``EXDEV`` for a
cross-directory link or rename it will not allow -- which the tests know and the
policy does not. Each validates what it alone cannot express: a quote, backslash
or newline in an SBPL string here, ``os.pathsep`` in ``landlock.py``'s joined
argument there. Without either there is no degraded mode: the evaluator returns a
typed ``infrastructure-failed`` outcome and the proposer a typed failure, because
a run that dropped the boundary silently would declare the same identity as one
that held it.

**Why an argv prefix.** ``launcher`` returns the front of a command rather than
wrapping the run, so the shipped subprocess sandbox keeps the timeout, output
ceiling and resource bounds this example already declared. macOS is a profile
written here, because it is a handful of lines of SBPL; Linux is ``landlock.py``,
run as a script, because it is sixty lines of ``ctypes`` that deserve to be read
by a linter and a test.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: the
code is one decision -- *what may this process touch* -- answered once and
rendered into whichever of two mechanisms the host has. Splitting the policy from
its two renderings is how the two come to disagree.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from . import landlock
from .landlock import MINIMUM_LANDLOCK_ABI


HERE = Path(__file__).resolve().parent
# ``examples/research/systems_optimization`` -> the repository that holds it.
REPOSITORY = HERE.parents[2]

# The policy, not the mechanism. Retained in the evaluator declaration, so it
# has to mean the same thing on every platform that can enforce it.
CONFINEMENT_POLICY = "candidate-cannot-read-or-write-this-repository-v4"

SANDBOX_EXEC = Path("/usr/bin/sandbox-exec")
# The Linux mechanism, as a module this example runs as a script.
LANDLOCK_FILE = HERE / "landlock.py"

# Everything the confined interpreter legitimately reads. The repository is
# absent, which is the point; ``sys.prefix`` is present even inside it, because
# that is where the interpreter and its standard library are.
#
# ``/tmp`` and ``/var/tmp`` are readable here and deliberately absent from
# ``writable_paths``. The asymmetry is the load-bearing part: every workspace and
# the default durable store live under the system temporary directory, so a tree
# that is writable joins two splits that are supposed to be two. Readable does
# not, because nothing the candidate ran was allowed to write any of it -- and a
# confined interpreter needs these trees to read, since ``tempfile`` probes them
# at import and multiprocessing's primitives live there. The write allow-list is
# therefore the half that has to be exact.
_LINUX_READABLE = (
    "/usr", "/lib", "/lib64", "/bin", "/sbin",
    "/etc", "/dev", "/proc", "/tmp", "/var/tmp",
)

# The one path outside its own workspace a confined process writes: ``agent.py``
# opens it read-write to blind the candidate's standard descriptors, before any
# candidate code exists in that process.
#
# It is the *whole* list, and an allow-list rather than a set of denied trees:
# naming trees to deny requires knowing where workspaces are, which depends on
# ``$TMPDIR``, while an allow-list is right whatever the host puts them under.
BLACKHOLE = "/dev/null"

# What a path may not contain if it is going to be quoted into an SBPL string.
# All three end the string: a quote closes it, a newline ends the rule, and a
# trailing backslash escapes the closing quote so the rest of the profile is read
# as part of the path. Refused here rather than left to ``sandbox-exec``, which
# rejects the whole profile with ``unbound variable`` and names no path.
UNSAFE_IN_A_PROFILE = ('"', "\\", "\n")


class ConfinementUnavailable(RuntimeError):
    """Raised instead of running anything without a boundary."""


def _landlock_status() -> tuple[int, str | None]:
    """The kernel's Landlock ABI, and *why* it has none, computed together.

    Asked through ``landlock.abi`` rather than queried again here, so the number
    that decides whether this machine is supported and the number that decides
    which rights to handle come from one implementation.

    Three different things arrive as a negative version, and an operator fixes
    each of them somewhere else: a C library that cannot be asked at all, a
    syscall the kernel refused, and a kernel that genuinely reports an ABI below
    the floor. Only the third is "upgrade the kernel". So the cause travels
    beside the number instead of being flattened into it, and the errno the
    syscall returned is part of that cause -- ``(-1, ENOSYS)`` is a query that
    failed, not an old Landlock.

    The pair is returned rather than remembered: stashing the last cause in
    module state would answer a question about trust with hidden global state.
    """

    if sys.platform != "linux":
        return -1, None
    try:
        version, errno = landlock.abi(landlock.libc())
    # ``AttributeError`` is what a libc without ``syscall`` raises -- ``ctypes``
    # surfaces a missing symbol through ``__getattr__``, never as ``OSError``.
    except (AttributeError, OSError) as unusable:
        return -1, str(unusable)
    if version < 0:
        return version, f"landlock_create_ruleset reported errno {errno}"
    return int(version), None


def landlock_abi() -> int:
    """The kernel's Landlock ABI, or a negative number when it has none.

    The number alone, for the callers that only have to decide. ``int`` is the
    contract every one of them already reads, so the cause travels beside it
    through ``_landlock_status`` rather than widening this return type.
    """

    return _landlock_status()[0]


def mechanism() -> str:
    """Which kernel facility would confine a process here, or ``""``.

    An ABI below ``MINIMUM_LANDLOCK_ABI`` is *no* mechanism rather than a weaker
    one. That is the same fail-closed choice ``launcher`` makes for a platform
    with nothing at all: this example would rather refuse to run than declare a
    boundary the kernel underneath it cannot hold.
    """

    if sys.platform == "darwin" and SANDBOX_EXEC.is_file():
        return "sandbox-exec"
    return "landlock" if landlock_abi() >= MINIMUM_LANDLOCK_ABI else ""


def supported() -> bool:
    return bool(mechanism())


def declaration() -> dict[str, object]:
    """What the record says was enforced, after proving it is available."""

    if not supported():
        raise ConfinementUnavailable(_unsupported_detail())
    return {"candidate_confinement": CONFINEMENT_POLICY}


def readable_paths(workspace: Path) -> tuple[str, ...]:
    """The interpreter, its standard library, and the workspace it runs in.

    ``sys.prefix`` is exempt because CPython cannot start otherwise, and here it is
    inside the repository -- so an exemption reaching this directory would hand back
    every workload the boundary hides. A refusal, not a warning."""

    paths = [sys.prefix, sys.base_prefix, str(workspace)]
    if sys.platform == "linux":
        paths.extend(_LINUX_READABLE)
    ordered = _ordered(paths)
    resolved_workspace = Path(workspace).resolve()
    if resolved_workspace.is_relative_to(REPOSITORY):
        raise ConfinementUnavailable(
            f"workspace ({resolved_workspace}) is inside the repository "
            f"({REPOSITORY}); granting it would reopen repository access"
        )
    for path in ordered:
        # Two traps, both found in review. ``is_relative_to`` is true of a
        # directory against itself, and that case is the *worst* one rather than an
        # exception to skip -- an exemption naming this directory grants every
        # workload in it. And both sides have to be canonical: a ``sys.prefix``
        # symlinked *at* this directory passed a lexical check while Landlock would
        # have followed the link and granted what is behind it.
        if HERE.is_relative_to(Path(path)):
            raise ConfinementUnavailable(
                f"a readable exemption ({path}) covers this example's own "
                f"directory ({HERE}); the boundary would be vacuous, so this "
                "example refuses to run rather than pretending to confine"
            )
    return ordered


def writable_paths(workspace: Path) -> tuple[str, ...]:
    """Where a confined process may write: its own workspace, and one black hole.

    The same two on both platforms, because writes are allow-listed on both. No
    shared temporary directory appears here, which is the point: two splits that
    share a writable directory are not two splits.
    """

    return _ordered([str(workspace), BLACKHOLE])


def launcher(workspace: Path) -> tuple[str, ...]:
    """The argv prefix that confines one process, or a refusal. Prefixing rather
    than wrapping keeps the shipped sandbox adapter as it is: the bounds, timeout,
    and output ceilings stay the contract this example declared."""

    readable = readable_paths(workspace)
    writable = writable_paths(workspace)
    chosen = mechanism()
    if chosen == "sandbox-exec":
        return (str(SANDBOX_EXEC), "-p", _profile(readable, writable))
    if chosen == "landlock":
        # ``landlock.py`` receives these ``os.pathsep``-joined, so a path holding the
        # separator arrives as two that do not exist -- and a rule that is skipped
        # is confinement that is not applied. ``_profile`` has the macOS version of
        # this: each mechanism refuses what *it* cannot express.
        if any(os.pathsep in path for path in (*readable, *writable)):
            raise ConfinementUnavailable(
                f"a path to declare contains {os.pathsep!r}: {readable + writable}"
            )
        # ``-B`` is not decoration: without it the interpreter would write
        # ``__pycache__`` into this example's own directory, before applying the
        # restriction that would have stopped it.
        return (
            sys.executable,
            "-I",
            "-B",
            str(LANDLOCK_FILE),
            os.pathsep.join(readable),
            os.pathsep.join(writable),
        )
    raise ConfinementUnavailable(_unsupported_detail())


def _unsupported_detail() -> str:
    """Explain why this host cannot make the declared boundary true."""

    if sys.platform == "linux":
        version, cause = _landlock_status()
        # A kernel that answers "ABI 2" and a kernel that could not be asked at
        # all are the same ``-1`` to every caller that only has to decide, and
        # two different machines to whoever has to fix one. Only the first is
        # "upgrade the kernel"; the second is a libc that has no ``syscall`` or
        # a ``landlock_create_ruleset`` that returned an errno, and reporting
        # either as "below the required 3" sends the operator somewhere the
        # problem is not.
        if cause is not None:
            trouble = f"the Landlock ABI could not be queried: {cause}"
        else:
            trouble = (
                f"Landlock ABI {version} is below the required "
                f"{MINIMUM_LANDLOCK_ABI}"
            )
        return (
            f"no confinement on 'linux': {trouble}; this example refuses to "
            "score or propose in a process it cannot keep away from workload files"
        )
    return (
        f"no confinement on {sys.platform!r}: this example refuses to score or "
        "propose in a process it cannot keep away from workload files"
    )


def _ordered(paths: list[str]) -> tuple[str, ...]:
    """Canonical, de-duplicated, order preserved -- and canonical is load-bearing.

    The kernel acts on the real path: Landlock opens the rule's directory, and
    macOS matches a resolved ``subpath``. Resolving here is what keeps the guard
    above and the rule below from disagreeing about a symlinked exemption."""

    resolved = (str(Path(path).resolve()) for path in paths if path)
    return tuple(dict.fromkeys(resolved))


def _profile(readable: tuple[str, ...], writable: tuple[str, ...]) -> str:
    """A ``sandbox-exec`` profile: reads allowed but for this repository, writes
    allowed nowhere but the allow-list.

    Later rules win in SBPL, and the asymmetry is deliberate. *Reading* is
    allow-by-default minus this repository: deny-by-default reading does not
    survive interpreter startup, and neither does denying ``file-read*`` rather
    than ``file-read-data``, because CPython's path resolution needs metadata
    above its own executable. *Writing* is deny-by-default from ``/`` down, then
    handed back on the workspace and ``/dev/null`` alone -- which is exactly what
    Landlock does on the other platform, so the two mechanisms now agree about
    writes instead of only about this repository.

    Naming trees to deny was tried and was worse than useless: it denied
    ``/private/tmp`` on a machine whose workspaces live in ``/private/var/folders``,
    and left ``$HOME`` writable besides."""

    for path in (str(REPOSITORY), *readable, *writable):
        if any(character in path for character in UNSAFE_IN_A_PROFILE):
            raise ConfinementUnavailable(f"path is unsafe in a profile: {path!r}")
    return "\n".join(
        (
            "(version 1)",
            "(allow default)",
            f'(deny file-read-data (subpath "{REPOSITORY}"))',
            # From the root down, before anything is handed back. The repository
            # denial above is now redundant for writes and kept anyway: it is the
            # rule this example is *about*, and a reader should find it stated.
            '(deny file-write* (subpath "/"))',
            *(f'(allow file-read-data (subpath "{path}"))' for path in readable),
            *(f'(allow file-write* (subpath "{path}"))' for path in writable),
        )
    )


__all__ = [
    "BLACKHOLE",
    "CONFINEMENT_POLICY",
    "LANDLOCK_FILE",
    "MINIMUM_LANDLOCK_ABI",
    "UNSAFE_IN_A_PROFILE",
    "ConfinementUnavailable",
    "declaration",
    "landlock_abi",
    "launcher",
    "mechanism",
    "readable_paths",
    "supported",
    "writable_paths",
]
