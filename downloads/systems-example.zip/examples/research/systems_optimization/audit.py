"""Reading the retained state back, and asking whether it agrees with itself.

Two things survive one command: the durable store the kernel wrote during the
search, and the content-addressed record this example wrote after it. Neither is
derived from the other, and that is the whole basis of this module. The store
holds the search's artifacts, metrics, lineage, and evidence; the record holds
every private and held-out attempt, the identities each was scored under, and the
selection rule that was applied. A forged record does not move the store.

So a replay does not re-run anything and does not re-derive anything it could
instead cross-check. It reads both, and reports where they agree. Every check it
returns can come back false -- a check that cannot is decoration, and the report
prints these as claims about the directory rather than as reassurance. Exactly
one of them can no longer fail *on its own*, and it says so where it sits rather
than being left to look more independent than it is.

**Scope, because it is narrower than it sounds.** Private selection and the
held-out comparison happen after ``meta.run`` returns, so the store holds neither
their numbers nor the evaluator identities they were scored under, and no check
here can contradict a self-consistent rewrite of either. What keeps that from
being a hole in the whole record is that the later sections are not free:
``invariants.py`` requires them to score exactly the candidates the development
section holds, and this module compares that section against the store attempt
for attempt -- along with the declaration the run started from, which pins the
seed, the proposer, and the development evaluator. So the identities are anchored
and the later measurements are not, and both halves are said out loud here and in
``record.py`` rather than left to be assumed.

**On the file's length**, since AGENTS.md asks for a reason above 300 lines: this
is one function and the ten claims it returns, each of which needs its own
paragraph saying what it corroborates and -- for the two that corroborate less
than they look like they do -- what it does not. Splitting the checks from
``replay`` would separate each claim from the report it appears in, and the
report is what a reader of a directory actually holds. The length is the scope
statements, which is the part that stops this module overclaiming.
"""

from __future__ import annotations

import json
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import RunId

from . import record as record_module
from .development import attempt_from_trial, recorded_trials
from .invariants import attempts_of
from .observations import AttemptTiming
from .proposals import source_digest
from .record import Decision
from .record_io import retained_mapping, retained_sequence


def replay(root: Path) -> tuple[Decision, dict[str, bool]]:
    """Reconstruct the decision from retained state alone, and cross-check it.

    ``root`` is the only argument, and that is the point. Taking the live
    ``meta.Run`` and the in-memory ``Decision`` as expected values makes this a
    useful round trip and nothing more: it cannot fail in a way a fresh reader of
    the directory would notice, because a fresh reader has neither of those
    things.

    So this reads the two things a directory actually holds -- the durable store
    the search wrote, and the content-addressed record the command left beside
    it -- and asks whether they agree with each other. Neither is derived from
    the other: the store is the kernel's, written during the run; the record is
    this example's, written after it. A forged record does not move the store,
    and that is what makes the agreement worth checking.

    Nothing here runs the simulator, a subprocess, or this example's evaluator.
    A reader needs a filesystem and a JSON parser.
    """

    retained = record_module.read_retained(record_module.locate(root))
    decision = retained.decision
    recorded = {(item.logical_step, item.digest): item for item in decision.development}
    with meta.Storage.read_only(root / "search") as reopened:
        durable = meta.Run(RunId(decision.search_run), reopened)
        inspected = durable.inspect()
        trials = recorded_trials(durable)
        best_trial = inspected.overview.best_trial
        best = None if best_trial is None else best_trial.artifact
        lineage = () if best is None else durable.lineage()
        observations = sum(
            1
            for trial in trials
            for item in trial.evidence
            if item.kind == "scenario-observation"
        )
        timing = tuple(
            AttemptTiming.of(attempt_from_trial(trial), trial.usage.wall_seconds)
            for trial in trials
        )
        retained_timing = tuple(
            item for item in retained.observations.attempts if item.split == "development"
        )
        return decision, {
            "store holds the recorded run": bool(trials),
            "run declaration agrees": _declaration_agrees(
                inspected.declaration, decision
            ),
            "every development attempt agrees": _attempts_agree(
                trials, decision.development
            ),
            "search best agrees": bool(trials) and _best_agrees(best, best_trial, recorded),
            "lineage agrees": _lineage_agrees(lineage, recorded),
            "evidence agrees": (
                evidence_fingerprint(trials)
                == retained_fingerprint(decision.development)
            ),
            # Implied, now that ``invariants.py`` re-derives the counts from the
            # attempts and the attempts are compared above: this can no longer
            # come back false on its own. Kept because it is the conclusion a
            # reader of the report wants stated, and because it takes two
            # independent edits to break rather than one.
            "development accounting agrees": (
                decision.accounting.evaluations.get("development")
                == inspected.overview.task_usage.evaluations
                and decision.accounting.scenario_runs.get("development") == observations
            ),
            "every attempt has exactly one timing": _timings_pair_up(
                decision, retained.observations
            ),
            "development timing agrees": timing == retained_timing,
            "total timing agrees": _total_agrees(
                inspected.overview.task_usage.wall_seconds, retained.observations
            ),
        }


def _declaration_agrees(declared, decision) -> bool:
    """The record's retained run facts against the run's own start declaration.

    The seed, the proposer, and the development evaluator are all *declared to
    the kernel* before a single candidate is scored, and the store keeps that
    declaration. So a record that renames the proposer it used, moves the random
    seed a reader would need to reproduce it, or swaps the evaluator identity
    that decides whether ``Run.compare`` will rank this run against another has
    something outside itself to disagree with. Without this function it does
    not: each of those fields can be edited in turn with nothing objecting.

    The declared seed artifact comes in too, because it makes the baseline
    directly witnessed rather than witnessed through the development section.

    **The seed-artifact term is the only one a missing comparison removes.** A
    record whose search selected nothing has no baseline to compare the declared
    seed against -- but it still has a seed, a proposer, and a development
    evaluator, all declared to the kernel before anything ran. Returning ``True``
    for the whole function when ``comparison`` is ``None`` dropped those three as
    well, so exactly the records this example added last -- the terminal
    no-winner ones -- were the records whose declaration nothing checked.
    """

    agrees = (
        declared.random_seed == decision.random_seed
        and f"{declared.proposer.name}@{declared.proposer.version}" == decision.proposer
        and declared.evaluator.version == decision.development_evaluator
    )
    if decision.comparison is None:
        return agrees
    return agrees and source_digest(declared.seed.value) == decision.comparison.baseline.digest


def _timings_pair_up(decision, observations) -> bool:
    """One retained clock reading per attempt, and no reading without an attempt.

    Structural, not corroborated, and the only thing here that looks at the
    *shape* of the later timing rather than its sum. A later reading can be
    dropped, duplicated, or attached to a candidate no split scored while the
    total still adds up, and no other check would notice.
    """

    return sorted(_timing_key(item) for item in attempts_of(decision)) == sorted(
        _timing_key(item) for item in observations.attempts
    )


def _timing_key(item) -> tuple[str, str, int, str]:
    return (item.candidate, item.digest, item.logical_step, item.split)


def _total_agrees(search_wall: float, observations) -> bool:
    """The retained total against the store's own clock plus the later readings.

    Half of this comes from outside the record: the store recorded what the
    search cost, so a total inflated to make the run look expensive disagrees
    with it. The later half has no witness at all, and the check is deliberately
    stated as the sum rather than as a claim about any one later reading -- which
    means a later reading moved *together with* the total is not caught here and
    is not claimed to be. ``README.md`` states that gap in the table with the
    others rather than in a footnote.
    """

    later = tuple(item for item in observations.attempts if item.split != "development")
    return observations.total_wall_seconds == search_wall + sum(
        item.wall_seconds for item in later
    )


def _attempts_agree(trials, attempts) -> bool:
    """Every trial the store kept against the attempt the record kept for it.

    All of them, and the counts both ways. Checking only the winning trial's
    numbers lets a rewritten metric on any losing candidate -- the numbers a
    reader compares the winner *against* -- pass every check in this function.
    """

    expected = tuple(attempt_from_trial(trial) for trial in trials)
    recorded = {(item.logical_step, item.digest): item for item in attempts}
    return len(attempts) == len(recorded) == len(expected) and all(
        recorded.get((item.logical_step, item.digest)) == item for item in expected
    )


def _best_agrees(best, trial, recorded: dict) -> bool:
    """Whether the artifact the store calls best is one the record holds.

    Identity rather than re-derivation. Re-deriving "the best" from the record
    would mean reimplementing the kernel's objective and its tie handling here,
    and a check that disagrees with the kernel about a tie is a bug pretending
    to be a finding. Asking whether the store's own answer is in the record at
    the same step is both safe and the thing worth knowing.
    """

    if best is None:
        return trial is None and bool(recorded) and not any(
            item.rankable for item in recorded.values()
        )
    if trial is None or trial.artifact is None:
        return False
    return (trial.logical_step, source_digest(best.value)) in recorded


def _lineage_agrees(lineage, recorded: dict) -> bool:
    """Whether every step the store kept is a step the record also holds."""

    steps = [trial for trial in lineage if trial.artifact is not None]
    if not steps:
        return bool(recorded) and not any(item.rankable for item in recorded.values())
    return all(
        (trial.logical_step, source_digest(trial.artifact.value)) in recorded
        for trial in steps
    )


def evidence_fingerprint(trials) -> tuple[str, ...]:
    """Every evidence item's kind **and** its payload, in order, from the store.

    Comparing only the kinds makes "evidence reconstructed" a claim about the
    *shape* of the record. Two runs whose observations disagree about every load,
    imbalance, and probe count still match, so the check reports only that the
    store held the right number of the right sort of thing.

    Payloads are compared as sorted JSON because evidence data is nested and
    order-insensitive; ``default=str`` keeps a value the store round-tripped into
    something exotic from raising here, where the answer would just be "these
    two differ".
    """

    return tuple(
        _frame(item.kind, dict(item.data))
        for trial in trials
        for item in trial.evidence
    )


def retained_fingerprint(attempts) -> tuple[str, ...]:
    """The same fingerprint, computed from the record instead of the store.

    This is the half that makes the record's evidence carry its kind. Without it
    the two sides can only be compared on payloads, and "evidence agrees" is
    silent about a relabelled observation.

    Each frame is read through ``_retained_frame`` rather than subscripted, for
    the reason given there.
    """

    return tuple(
        _retained_frame(frame)
        for attempt in attempts
        # The list itself, before its items: iterating ``attempt.evidence``
        # straight out of an edited record answered ``'int' object is not
        # iterable`` from inside this generator, which is the same complaint one
        # container out from the one below.
        for frame in retained_sequence(attempt.evidence, "retained evidence")
    )


def _retained_frame(frame: object) -> str:
    """One evidence frame off the record, refused rather than crashed through.

    ``str(frame["kind"])`` and ``dict(frame["data"])`` was the reading, and this
    is a *read* path over a file nobody here wrote. ``{"kind": "x", "data": 5}``
    is the sharp case: ``dict(5)`` answers ``'int' object is not
    iterable`` from inside a generator expression, naming a Python type instead
    of the record field that is wrong -- and doing it from the one function whose
    job is to say whether a directory agrees with itself.

    ``decision._frames`` enforces this shape at construction, so a record built
    in this process cannot get here malformed. A record *read back* can:
    ``read_retained`` reconstructs from JSON somebody else may have edited,
    which is the whole reason a replay exists.
    """

    fields = retained_mapping(frame, "retained evidence frame")
    missing = sorted({"kind", "data"} - set(fields))
    if missing:
        raise ValueError(f"retained evidence frame is missing {missing}")
    return _frame(
        str(fields["kind"]),
        dict(retained_mapping(fields["data"], "retained evidence payload")),
    )


def _frame(kind: str, data: dict) -> str:
    return f"{kind}:{json.dumps(data, sort_keys=True, default=str)}"


__all__ = [
    "evidence_fingerprint",
    "recorded_trials",
    "replay",
    "retained_fingerprint",
]
