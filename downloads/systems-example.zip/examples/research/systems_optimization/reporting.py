"""Turning one command's outcome into the lines a reader actually sees.

Kept apart from ``command.py`` because the two answer different questions. The
command owns what runs, in what order, under which budget; this module owns how
a negative, a tie, four unrankable refusals, and a comparison with no number in
it are made legible side by side -- which is most of what this example is *for*,
and is worth being able to change without touching the mechanism.

Two rules keep the output honest. **Every number printed here comes from the
record**, apart from the development rows, which come from the run in the order
the search visited them; the printed decision and the file on disk cannot
disagree because they are the same values. And **no wall-clock reading is ever
printed**, only whether one was recorded, which is what lets one command have a
byte-identical output across machines while still accounting for its own time.
"""

from __future__ import annotations

import sys

import meta_evolve as meta

from .bounds import PROCESSES_PER_SCENARIO, SEARCH_BUDGET
from .decision import Attempt
from .development import recorded_trials
from .policy import TIE_BREAK
from .proposals import candidate_name
from .record import Outcome
from .surface import SURFACE


NAME_WIDTH = 26


def _refusal(name: str, kind: str, outcome: str) -> str:
    return f"  {name:<{NAME_WIDTH}} unrankable  {kind}/{outcome}"


def _development_row(trial: meta.TrialView) -> str:
    """One development trial: three numbers, or the refusal that replaced them."""

    name = candidate_name(trial)
    failure = trial.failure
    if failure is not None:
        return _refusal(
            name, failure.kind, str(failure.details.get("outcome", failure.kind))
        )
    metrics = trial.metrics
    if not metrics:
        return f"  {name:<{NAME_WIDTH}} unevaluated"
    return (
        f"  {name:<{NAME_WIDTH}} quality={float(metrics['quality']):.4f} "
        f"imbalance={float(metrics['imbalance']):.4f} "
        f"work={float(metrics['work']):.1f}"
    )


def _private_row(attempt: Attempt) -> str:
    if not attempt.rankable:
        return _refusal(attempt.candidate, attempt.failure_kind, attempt.outcome)
    return (
        f"  {attempt.candidate:<{NAME_WIDTH}} "
        f"quality={attempt.quality:.4f} work={attempt.work:.1f}"
    )


def _held_out_row(label: str, attempt: Attempt) -> str:
    if not attempt.rankable:
        return f"  {label}: unrankable  {attempt.failure_kind}/{attempt.outcome}"
    return f"  {label}: {attempt.quality:.4f}"


def report(outcome: Outcome) -> str:
    """One command's whole story, in the order it happened."""

    result = outcome.search
    decision = outcome.decision
    selection, comparison, counted = (
        decision.selection,
        decision.comparison,
        decision.accounting,
    )

    lines = [
        "== declared surface ==",
        f"  candidate: {SURFACE[0]} only; everything else is evaluator-owned",
        "  execution: the candidate runs in a process that holds no simulator",
        "",
        "== development search: the only feedback the fixture uses ==",
        # Show every terminal attempt, including refusals that never reached
        # evaluation. The accounting below counts evaluations separately.
        *(_development_row(trial) for trial in recorded_trials(result)),
        "",
        "== published selection: scored after the fixture search returned ==",
        *(_private_row(attempt) for attempt in selection.ranked),
        *(_private_row(attempt) for attempt in selection.refused),
        f"  selected: {selection.winner}",
        f"  tie-break: {', then '.join(TIE_BREAK)}",
        "",
        "== published final comparison: baseline and selected only ==",
        *(
            [
                "  no candidate ranked on the private split, so nothing was "
                "selected",
                "  verdict: no-selection",
                "  promotion: none",
            ]
            if comparison is None
            else [
                _held_out_row("baseline", comparison.baseline),
                _held_out_row("selected", comparison.selected),
                f"  verdict: {comparison.verdict}",
                "  promotion: external",
            ]
        ),
        "",
        "== accounting ==",
        (
            f"  evaluations: development "
            f"{counted.evaluations['development']}/{SEARCH_BUDGET.evaluations}, "
            f"selection {counted.evaluations['private']}, "
            f"final comparison {counted.evaluations['held_out']}"
        ),
        (
            f"  scenario runs: {counted.total_scenario_runs} "
            f"of at most {counted.scenario_ceiling}"
        ),
        f"  processes per scenario run: {PROCESSES_PER_SCENARIO}",
        f"  wall clock recorded: {outcome.observations.total_wall_seconds > 0.0}",
        "  monetary cost: not measured here (issue #143 owns it)",
        "",
        "== replay: the output directory alone, nothing rerun ==",
        *(f"  {name}: {agreed}" for name, agreed in outcome.replayed.items()),
    ]
    return "\n".join(lines)


def finish(outcome: Outcome) -> int:
    """Print the report, then say on the exit code whether replay agreed.

    An entry point that discards this returns zero on a failed cross-check, with
    ``False`` printed in the section above and an empty stderr -- reachable by
    driving it against a tampered store. ``README.md`` says editing the record is
    *caught*; this is what makes catching it something ``set -e``, a CI wrapper,
    or any other caller reading a status can act on. ``agent.py`` and
    ``verifier.py`` have always exited this way.
    """

    print(report(outcome))
    failed = sorted(name for name, agreed in outcome.replayed.items() if not agreed)
    if failed:
        disagreed = ", ".join(failed)
        print(f"replay disagreed with the retained record: {disagreed}", file=sys.stderr)
        return 1
    # A run whose final comparison produced no number is not a successful run.
    # ``verdict`` already said ``unrankable`` in the section above and the exit
    # code said zero, so a caller reading a status could not tell "the selected
    # candidate beat the baseline" from "there was nothing to compare" -- and the
    # second is the outcome this example most wants a reader to notice, since it
    # means the whole search ended without a rankable answer. Replay disagreement
    # stays *ahead* of it, because a record that does not agree with its own store
    # is the more serious of the two and should be the reason reported.
    # Nothing ranked at all: there is no comparison to be unrankable, and the
    # run ended without an answer. Reported as its own outcome rather than
    # folded into the one below, because "the selected candidate could not be
    # measured" and "nothing was ever selected" send a reader to different
    # places.
    if outcome.decision.comparison is None:
        print(
            "no candidate ranked on the private split, so nothing was selected "
            f"and no held-out comparison was made; "
            f"{len(outcome.decision.selection.attempts)} private attempts are "
            "retained in the record",
            file=sys.stderr,
        )
        return 1
    if not outcome.decision.comparison.rankable:
        print(
            "the final comparison produced no number: "
            f"baseline was {outcome.decision.comparison.baseline.outcome} and "
            f"selected was {outcome.decision.comparison.selected.outcome}",
            file=sys.stderr,
        )
        return 1
    return 0


__all__ = ["finish", "report"]
