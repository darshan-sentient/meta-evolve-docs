"""The message vocabulary spoken across the candidate/evaluator process split.

Two evaluator-owned programs share this file: ``verifier.py``, which owns the
simulator and decides what happened, and ``agent.py``, which runs in a separate
process and is the only thing that ever touches candidate code. They exchange
newline-delimited JSON objects, one per line, each with an ``op``.

The vocabulary lives here rather than being spelled out twice because the two
halves are in different processes and cannot be type-checked against each
other, and two spellings of one rule drift.

**Direction matters, and it is the whole safety argument.** The verifier asks
for a placement and answers questions it has charged for. The agent may only
ask questions and answer with a worker index. There is no message an agent can
send that carries a measurement, so no candidate can state its own result, and
none that carries a verdict, so no candidate can state whose fault a failure
was.
"""

from __future__ import annotations

import json


PROTOCOL_VERSION = "placement-request-response-v1"

# Verifier -> agent.
BEGIN = "begin"  # the handshake: how many workers exist, and nothing else
TASK = "task"  # place a task of this size
LOAD = "load"  # the answer to one charged probe
INDEX = "index"  # the answer to one free pick
HALT = "halt"  # stop; the verifier has already decided the outcome

# Agent -> verifier.
READY = "ready"  # the candidate module imported and defines choose
UNUSABLE = "unusable"  # it did not, and this is why
PROBE = "probe"  # what is this worker's load? (charged)
PICK = "pick"  # give me the next index of the fixed sequence (free)
PLACE = "place"  # my answer for the current task
RAISED = "raised"  # the candidate raised, and this is the traceback tail

# What ``UNUSABLE`` is allowed to claim. The agent names one of these next to
# the failure; the evaluator maps the name onto a typed failure and does not
# re-diagnose. Anything else is a protocol violation rather than a diagnosis.
UNUSABLE_REASONS = frozenset({"malformed-source", "construction-failed"})

# There is deliberately no message through which the agent blames the evaluator,
# and the reason is that the agent is the process holding candidate code.
# ``{"op": "refused"}`` would be bytes any scheduler can write -- through the
# channel its own proxy holds, or on the private descriptor at import time --
# so a three-line candidate could have its evaluation recorded as
# ``verifier-failed``, the evaluator admitting a fault that was not its own. A
# claim from a witness with a motive is not evidence. The evaluator holds itself
# to ``as_count`` before each message leaves instead, which is the same claim
# made where it can be believed.

DETAIL_LIMIT = 400


def encode(op: str, **fields: object) -> bytes:
    """One protocol message as the exact bytes that go on the wire."""

    return (json.dumps({"op": op, **fields}, sort_keys=True) + "\n").encode("utf-8")


def decode(line: bytes) -> dict[str, object]:
    """Parse one line, or raise ``ProtocolError`` naming what was wrong with it.

    Every rejection here is a refusal to guess. A message that is not an object
    with a string ``op`` is not a message this vocabulary contains, and the
    caller turns that into an unrankable outcome rather than a default.

    ``RecursionError`` is a parse error here. How deep ``json`` will descend is a
    property of the interpreter, not of this vocabulary, and a candidate chooses
    the nesting: whose fault a message is may not depend on
    ``sys.getrecursionlimit()``.
    """

    try:
        message = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, RecursionError) as error:
        raise ProtocolError(f"unparseable message: {error}") from error
    if not isinstance(message, dict):
        raise ProtocolError(f"message must be an object, not {type(message).__name__}")
    op = message.get("op")
    if not isinstance(op, str) or not op:
        raise ProtocolError("message has no string op")
    return message


def as_count(value: object, field: str) -> int:
    """One ``workers`` or ``size``, or a refusal naming what it actually held.

    The two counts in this vocabulary, held to one rule in one place. Both halves
    apply it -- the verifier to every count before it sends one, the agent to
    every count that arrives -- and it lives here for the reason the rest of the
    file does: two spellings of one rule drift, and the weaker spelling is the
    one that survives. ``size`` was the weaker one. It admitted zero, negatives
    and floats, so ``int()`` silently truncated ``2.7`` to a size the simulator
    does not charge, while ``nan`` and ``inf`` raised
    ``ValueError``/``OverflowError`` out of a handler that caught neither.

    ``bool`` is excluded before ``int`` because ``True`` is an ``int`` and a
    worker count of ``True`` is not a worker count.
    """

    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise NotACount(f"{field} is {value!r}, not a positive integer")
    return value


def wire_worker(value: object) -> object:
    """Put one candidate answer on the wire without deciding whether it is valid.

    A scheduler that returns a string, a float, or an object has answered the
    question badly, not broken the protocol, and the two get different outcomes.
    So anything JSON cannot carry becomes its ``repr`` and travels as text; the
    simulator is left as the one authority on what names a worker, and it will
    refuse this exactly as it refuses an index past the last worker.
    """

    if isinstance(value, bool) or not isinstance(value, int):
        try:
            return repr(value)[:DETAIL_LIMIT]
        except BaseException:
            return f"<{type(value).__name__} repr failed>"
    return value


def detail_of(message: dict[str, object]) -> str:
    """Read a free-text diagnosis, truncated. It is never rankable."""

    return str(message.get("detail", ""))[:DETAIL_LIMIT]


class NotACount(Exception):
    """A field this vocabulary requires a positive integer for held something else."""


class ProtocolError(Exception):
    """The other side of the pipe said something this vocabulary does not have."""


__all__ = [
    "BEGIN",
    "DETAIL_LIMIT",
    "HALT",
    "INDEX",
    "LOAD",
    "NotACount",
    "PICK",
    "PLACE",
    "PROBE",
    "PROTOCOL_VERSION",
    "ProtocolError",
    "RAISED",
    "READY",
    "TASK",
    "UNUSABLE",
    "UNUSABLE_REASONS",
    "as_count",
    "decode",
    "detail_of",
    "encode",
    "wire_worker",
]
