"""The one declared mutation surface, and the checks that keep a candidate on it.

The candidate is a ``meta.SourceTree`` holding exactly one file,
``scheduler.py``. Everything else in this example -- the simulator, the
workloads, the verifier, the agent that carries the candidate, the objectives,
the budgets -- is evaluator-owned.

Two layers do the refusing *here*, and it is worth knowing which is which. Both
are about what a candidate may **be**; what it may **do** once it is running is a
third mechanism entirely, and lives in ``verifier.py``.

* **The artifact type.** ``SourceTree`` already refuses absolute paths, ``..``
  segments, backslash separators, NUL bytes, non-UTF-8 content, and paths that
  collide case-insensitively. Path escape and binary content are therefore not
  things this example has to defend against; they cannot be constructed. There
  is no symlink to reject either -- a ``SourceTree`` is a mapping of paths to
  text, so a workspace materialized from one has no link in it.
* **This module.** What the type cannot know is *scope*: that this task's
  surface is one named file. ``check_surface`` refuses an added file, a deleted
  file, a rename, an empty module, and a module past the declared size ceiling.

Both layers are tested, because "the type already handles it" is exactly the
kind of claim that stops being true quietly.
"""

from __future__ import annotations

from meta_evolve.domain import SourceTree


SURFACE = ("scheduler.py",)
MAX_SOURCE_BYTES = 8_000

BASELINE_SOURCE = '''\
"""Round-robin: hand out workers in order and never ask how loaded they are.

Zero probes per task, which is the cheapest a scheduler can possibly be. It
pays for that with placement: the stream's large tasks arrive at fixed offsets,
so rotating blindly sends all of them to the same worker.
"""

_cursor = [0]


def choose(cluster, size):
    index = _cursor[0] % cluster.size
    _cursor[0] += 1
    return index
'''

BASELINE = SourceTree({"scheduler.py": BASELINE_SOURCE})


def check_surface(candidate: object) -> str | None:
    """Explain why ``candidate`` is off the declared surface, or return ``None``.

    The string is the reason recorded on the typed refusal, so it is written to
    be read by whoever has to work out what their proposer did wrong.
    """

    if not isinstance(candidate, SourceTree):
        return f"candidate must be a SourceTree, not {type(candidate).__name__}"
    present = tuple(candidate)
    expected = set(SURFACE)
    added = sorted(path for path in present if path not in expected)
    if added:
        return f"candidate added files outside the declared surface: {added}"
    missing = sorted(expected - set(present))
    if missing:
        return f"candidate removed files from the declared surface: {missing}"
    source = candidate[SURFACE[0]]
    if not source.strip():
        return f"candidate left {SURFACE[0]} empty"
    measured = len(source.encode("utf-8"))
    if measured > MAX_SOURCE_BYTES:
        return (
            f"candidate {SURFACE[0]} is {measured} bytes; "
            f"the declared ceiling is {MAX_SOURCE_BYTES}"
        )
    return None


def with_scheduler(source: str) -> SourceTree:
    """Build a candidate on the surface from one module's text."""

    return SourceTree({SURFACE[0]: source})


__all__ = [
    "BASELINE",
    "BASELINE_SOURCE",
    "MAX_SOURCE_BYTES",
    "SURFACE",
    "check_surface",
    "with_scheduler",
]
