"""The proposer's half of the boundary: it decides, and it can see nothing else.

``proposals.py`` materializes a workspace holding proposer-owned copies of this
module, ``plan.py``, and ``schedulers.py`` beside one ``_context.json``, then runs
``python _propose.py`` in it through the shipped bounded subprocess sandbox with
``confinement.py``'s launcher in front. That is the whole point of the file: this
process can neither read nor write this repository's own files, so the committed
copy of ``workloads.py`` -- which holds the selection and final-comparison
streams as literals -- cannot be opened by the code that chooses what to propose.

That is the physical half of #195's requirement that held-out facts cannot reach
proposal context, and it is the file route alone. What establishes the
requirement is sequencing, the closed payload described below, and there being
one fixed proposer; confinement is what makes the file half hold against code
rather than against review. Network retrieval is confined on neither platform
and the literals are public, so a socket is a route this boundary does not cover.

A proposer that is a callable in the process that imported both later splits
makes this procedural, and the only honest defence is that the committed fixture
does not look. That is a promise about a fixture, not a boundary.

What crosses in is one JSON file: the logical step, the declared surface file
name, the parent's source, the declared objectives, and the development
evaluations the run's context policy pushed to this proposal. What crosses out is
one JSON line on stdout: the plan step, the files it writes, and the observation
it proposed from. Neither direction carries a later fact, and ``proposals.py``
re-checks the payload before it becomes a ``ProposalResult`` -- a proposer that
misstates the parent it edited is refused rather than recorded.
"""

from __future__ import annotations

import json
import sys

try:  # the example package: importable, reviewable, and unit-testable
    from . import plan
except ImportError:  # a workspace copy: a plain sibling module, no package
    import _plan as plan  # type: ignore[no-redef]


CONTEXT_FILE = "_context.json"


def main(argv: list[str] | None = None) -> int:
    """Read the serialized context, write one proposal, and say nothing else.

    Failure is deliberately loud rather than swallowed: a traceback and a
    non-zero exit make ``proposals.py`` report a typed proposer failure, which
    the kernel records as an unrankable trial. A confined process that answered
    with a guess would be worse than one that did not answer.
    """

    del argv
    with open(CONTEXT_FILE, encoding="utf-8") as handle:
        context = json.load(handle)
    sys.stdout.write(json.dumps(plan.proposal(context), sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised as a subprocess
    raise SystemExit(main(sys.argv[1:]))


__all__ = ["CONTEXT_FILE", "main"]
