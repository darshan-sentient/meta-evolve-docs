"""What the evaluator declares itself to be, and what makes that declaration move.

``Run.compare`` refuses to rank two runs whose evaluator ``ComponentRef`` is not
identical, and a ``ComponentRef`` is a name and a version string. So the version
has to be a function of everything that decides what a number means -- otherwise
the refusal is a formality that a human has to remember to trigger.

Two kinds of thing go into it:

* **Configuration.** The simulator and protocol versions, the scoring, the
  split and its digest, the surface, and every process bound the ``ProcessSpec``
  is built with. Two runs under different output ceilings or a different
  candidate deadline are two different measurements.
* **Source.** A digest over every evaluator-owned module. This is the half that
  cannot be forgotten: editing the simulator's arithmetic, the verifier's
  classification, the protocol's vocabulary, the failure map, or a workload
  moves the version whether or not anybody thought to bump a string. A
  hand-written constant on its own lets most of the runtime change underneath
  the version in silence.

``EVALUATOR_SOURCES`` is read from disk rather than through ``inspect``, because
two of these modules -- ``verifier.py`` and ``agent.py`` -- also exist as
injected workspace copies, and the file on disk is the thing that gets injected.
"""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path

from . import outcomes as outcomes_module
from .confinement import declaration as confinement_declaration
from .bounds import (
    CANDIDATE_DEADLINE_SECONDS,
    INTERPRETER_FLAGS,
    OUTPUT_LIMIT,
    PROCESS_TIMEOUT_SECONDS,
)
from .protocol import PROTOCOL_VERSION
from .simulator import SIMULATOR_VERSION, Scenario
from .surface import MAX_SOURCE_BYTES, SURFACE
from .workloads import SPLITS, scenario_names, split_digest


HERE = Path(__file__).parent

# Every module whose text decides what a reported number means.
#
# Deliberately absent: ``main.py``, ``command.py``, ``declarations.py``,
# ``selection.py``, ``decision.py``, ``record.py``, ``record_io.py``,
# ``invariants.py``, ``audit.py``, ``development.py``, ``policy.py``,
# ``observations.py``, and ``reporting.py``. Those choose what runs, how a
# decision is shaped, what may refuse one, and how it prints -- none of them
# changes what a *measurement* is.
#
# Absent from *this* list is not undeclared. Every one of them that can move a
# winner or refuse a record is in ``policy.SELECTION_SOURCES``, which digests its
# own modules and is retained in the record; that comment says where the line
# falls and which five modules are in neither list -- a count a test pins against
# the set the tests hold, because this one said five and prose was the reason.
#
# Two declarations rather than one, on purpose: folding the selection modules
# in here would make ``Run.compare`` refuse two runs that measured identically
# and differed only in how a tie was broken, which is a comparison worth
# having. Saying in words that the tie-break is in the record, with no selection
# declaration behind it, leaves the implementation free to move underneath the
# sentence.
#
# ``schedulers.py`` is absent for a different reason, and it was here once by
# mistake. It holds candidate *text*, which is the proposer's business: two runs
# that proposed different schedulers under the same evaluator are exactly what
# ``Run.compare`` is for, and refusing them would be wrong. The same goes for the
# four modules that choose and carry that text -- ``plan.py``, ``propose.py``,
# ``handoff.py``, and ``proposals.py``. All five are declared where they belong,
# as dependencies of the registered *proposer*, whose own ``ComponentRef`` moves
# when they do, so a durable replay still verifies every one of them.
EVALUATOR_SOURCES = (
    "agent.py",
    "bounds.py",
    "confinement.py",
    "execution.py",
    "identity.py",
    "landlock.py",
    "outcomes.py",
    "protocol.py",
    "reports.py",
    "simulator.py",
    "surface.py",
    "verifier.py",
    "workloads.py",
)


def evaluator_digest(*, root: Path | None = None) -> str:
    """One digest over the source of every evaluator-owned module.

    ``root`` is a parameter so a test can point this at a copy of the example
    with one file altered and watch the declared identity move, which is the
    only way to show that the declaration is doing work.
    """

    directory = root or HERE
    payload = sha256()
    for name in EVALUATOR_SOURCES:
        payload.update(name.encode("utf-8"))
        payload.update(b"\0")
        payload.update((directory / name).read_bytes())
        payload.update(b"\0")
    return payload.hexdigest()[:16]


def resolve_split(
    split_name: str, split: tuple[Scenario, ...] | None
) -> tuple[Scenario, ...]:
    """The one place a split name and an explicit split become scenarios.

    Written once because it was written twice: ``execution.score_split`` ran
    ``SPLITS[split_name] if split is None else split`` to decide what to measure,
    and this module ran the identical expression to decide what to *declare*.
    Nothing joined them, so passing an explicit ``split`` to one and not the
    other produced a declaration naming a registered split beside numbers from
    scenarios that were not in it -- the exact confusion the evaluator version
    exists to make impossible, arrived at through the version itself. It is
    latent -- no caller does that today -- and pinned anyway.

    What this deliberately does *not* do is require the scenarios to match the
    registered split of the same name. That was the first attempt and it was
    wrong: the private and held-out stages are configured by whoever runs the
    command and pass their own scenarios under those same registered names --
    ``run_example(root, private=PRIVATE * 3)`` is how the accounting tests grow a
    split to move the declared ceiling. The declaration stays honest there
    because it carries ``split_digest`` of the scenarios actually used, so the
    name is a label and the digest is the identity.

    The pairing obligation that remains is the caller's: whatever ``split`` is
    measured has to be the ``split`` declared. ``selection.select`` and
    ``selection.compare`` each discharge it by passing the same value to
    ``evaluate`` and to ``configuration_version``, and there is a test that says
    so -- because this function can make the two resolutions one, and cannot make
    a caller ask both questions.
    """

    if split is None:
        try:
            return SPLITS[split_name]
        except KeyError:
            raise ValueError(
                f"{split_name!r} is not a registered split and no scenarios were "
                f"given; the registered splits are {sorted(SPLITS)}"
            ) from None
    scenarios = tuple(split)
    if not scenarios:
        raise ValueError(f"the split given for {split_name!r} holds no scenarios")
    return scenarios


def evaluator_configuration(
    split_name: str, *, split: tuple[Scenario, ...] | None = None
) -> dict[str, object]:
    """Exactly what this evaluator was configured with, for its declaration."""

    scenarios = resolve_split(split_name, split)
    return {
        "simulator": SIMULATOR_VERSION,
        "protocol": PROTOCOL_VERSION,
        # Read through the module rather than a from-import so that the scoring
        # a run declares and the scoring it applied cannot be two bindings.
        "scoring": outcomes_module.SCORING_VERSION,
        "work_weight": outcomes_module.WORK_WEIGHT,
        "outcomes": sorted(outcomes_module.FAILURE_TYPES),
        "split": split_name,
        "scenarios": list(scenario_names(scenarios)),
        "split_digest": split_digest(scenarios),
        "surface": list(SURFACE),
        "surface_max_bytes": MAX_SOURCE_BYTES,
        # Every bound the two processes are built with, not only the interesting
        # one. Two runs under different output ceilings are two different
        # measurements -- a candidate whose verifier is truncated is scored
        # differently -- so the ceiling belongs in the digest that decides
        # whether ``Run.compare`` will rank them.
        "process_timeout_seconds": PROCESS_TIMEOUT_SECONDS,
        "process_stdout_limit": OUTPUT_LIMIT,
        "process_stderr_limit": OUTPUT_LIMIT,
        "candidate_deadline_seconds": CANDIDATE_DEADLINE_SECONDS,
        "interpreter_flags": list(INTERPRETER_FLAGS),
        # The policy, never the mechanism: macOS and Linux enforce the same rule
        # by different kernel facilities, and two machines that confined a
        # candidate identically must declare one evaluator.
        **confinement_declaration(),
        "sources": evaluator_digest(),
    }


def configuration_version(
    split_name: str, *, split: tuple[Scenario, ...] | None = None
) -> str:
    """A version that moves whenever anything above it moves."""

    configuration = evaluator_configuration(split_name, split=split)
    payload = repr(sorted(configuration.items()))
    return "2+" + sha256(payload.encode("utf-8")).hexdigest()[:16]


__all__ = [
    "EVALUATOR_SOURCES",
    "configuration_version",
    "evaluator_configuration",
    "evaluator_digest",
    "resolve_split",
]
