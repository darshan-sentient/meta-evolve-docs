"""Claude transport, observable traces, and file-tool permissions for this example."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
import re
import time
from uuid import uuid4

from claude_agent_sdk import (
    AssistantMessage, HookMatcher, PermissionResultAllow, PermissionResultDeny,
    ResultMessage, SystemMessage, TextBlock,
    ToolResultBlock, ToolUseBlock, UserMessage, query,
)

import meta_evolve as meta
from meta_evolve.errors import ExecutionAccountingUnknown


# --8<-- [start:schema]
PROPOSAL_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["name", "description"],
    "properties": {
        "name": {"type": "string", "pattern": "^[a-z][a-z0-9-]{0,62}$"},
        "description": {"type": "string", "minLength": 20, "maxLength": 800},
    },
}
# --8<-- [end:schema]


def validate_proposal(value):
    if not isinstance(value, dict) or set(value) != {"name", "description"}:
        raise ValueError("Expected a structured name and description")
    name, description = value["name"], value["description"]
    if (not isinstance(name, str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,62}", name)
            or name == "skill-builder" or not isinstance(description, str)
            or not 20 <= len(description) <= 800 or len(description.strip()) < 20):
        raise ValueError("Invalid skill name or high-level description")
    return value


def file_permissions(cwd, read_roots, write_root=None):
    """Constrain the small file-tool surface, including pre-approved tools.

    These hooks are not an OS sandbox. Bash, network tools, subagents and MCP
    are absent from this example's tool declarations.
    """
    cwd = Path(cwd).resolve()
    roots = tuple(Path(root).resolve() for root in read_roots)
    writable = Path(write_root).resolve() if write_root is not None else None

    async def check(event, tool_use_id, context):
        name, args = event["tool_name"], event["tool_input"]
        if name == "Skill":
            return {}
        field = "file_path" if name in {"Read", "Write", "Edit"} else "path"
        path = (cwd / args.get(field, ".")).resolve()
        if name in {"Write", "Edit"}:
            allowed = writable is not None and path.is_relative_to(writable)
        elif name in {"Read", "Glob", "Grep"}:
            allowed = any(path.is_relative_to(root) for root in roots)
            pattern = args.get("pattern", "") if name == "Glob" else args.get("glob", "")
            if pattern:
                target = (path / pattern).resolve()
                allowed = allowed and any(target.is_relative_to(root) for root in roots)
        else:
            allowed = False
        if allowed:
            return {}
        return {"hookSpecificOutput": {
            "hookEventName": "PreToolUse", "permissionDecision": "deny",
            "permissionDecisionReason": "Outside this role's declared files/tools.",
        }}

    async def approve_write(name, args, context):
        # .claude is a protected path. Its mandatory prompt needs a callback in
        # default mode; dontAsk denies it even with bare Write/Edit allow rules.
        decision = await check({"tool_name": name, "tool_input": args}, None, {})
        if name in {"Write", "Edit"} and not decision:
            return PermissionResultAllow(updated_input=args)
        return PermissionResultDeny(message="Only candidate skill writes may be approved.")

    options = {
        "permission_mode": "dontAsk", "strict_mcp_config": True,
        "hooks": {"PreToolUse": [HookMatcher(hooks=[check])]},
    }
    if writable is not None:
        options.update(permission_mode="default", can_use_tool=approve_write)
    return options


@dataclass(frozen=True)
class AgentCall:
    record: dict
    usage: meta.Resources
    failure: str | None

    @property
    def answer(self):
        return self.record["result"].get("result") or ""

    @property
    def structured_output(self):
        return self.record["result"].get("structured_output")

    @property
    def invoked_skills(self):
        return [block["input"].get("skill") for item in self.record["trace"]
                for block in item.get("blocks", []) if block.get("name") == "Skill"]

    @property
    def loaded_skills(self):
        discovered = self.record.get("init", {}).get("skills", [])
        names = {item if isinstance(item, str) else item.get("name") for item in discovered}
        # Init also lists SDK-bundled skills, even when `skills` excludes them.
        return sorted(set(self.record["skills"]) & names)

    def evidence(self):
        return meta.EvidenceDraft(kind="evoskill.agent", data=self.record)


def token_count(result):
    """Use cumulative per-model counts; never double-count streamed messages."""
    model_usage = result.model_usage
    if model_usage:
        fields = ("inputTokens", "outputTokens", "cacheReadInputTokens",
                  "cacheCreationInputTokens")
        counts = [usage.get(key) for usage in model_usage.values() for key in fields]
    else:
        # A budget error can omit its final over-budget response from `usage`.
        if result.subtype == "error_max_budget_usd":
            raise ValueError("Budget error without cumulative model_usage")
        usage = result.usage or {}
        counts = [usage.get("input_tokens"), usage.get("output_tokens"),
                  usage.get("cache_read_input_tokens", 0),
                  usage.get("cache_creation_input_tokens", 0)]
    if any(type(value) is not int or value < 0 for value in counts):
        raise ValueError("Missing or invalid cumulative token counts")
    return sum(counts)


async def call_agent(role, prompt, options, records):
    """One fresh SDK session. Write a receipt even if accounting is unavailable."""
    records = Path(records)
    records.mkdir(parents=True, exist_ok=True)
    receipt = records / f"{role}-{uuid4().hex}.json"
    started, result, error = time.monotonic(), None, None
    record = {
        "role": role, "prompt": prompt, "model": options.model,
        "tools": options.tools, "skills": options.skills,
        "cwd": str(options.cwd), "add_dirs": [str(p) for p in options.add_dirs],
        "max_turns": options.max_turns, "max_budget_usd": options.max_budget_usd,
        "trace": [], "receipt": str(receipt),
    }
    try:
        async for message in query(prompt=prompt, options=options):
            if isinstance(message, SystemMessage) and message.subtype == "init":
                record["init"] = message.data
            elif isinstance(message, (AssistantMessage, UserMessage)):
                blocks = message.content if isinstance(message.content, list) else []
                visible = [asdict(block) for block in blocks
                           if isinstance(block, (TextBlock, ToolUseBlock, ToolResultBlock))]
                if isinstance(message.content, str):
                    visible = [{"text": message.content}]
                record["trace"].append({
                    "speaker": type(message).__name__, "blocks": visible,
                    "model": getattr(message, "model", None),
                })
            elif isinstance(message, ResultMessage):
                result = message
    except Exception as exception:
        # The SDK can yield an error ResultMessage and then raise. Keep both.
        error = f"{type(exception).__name__}: {exception}"
    finally:
        elapsed = time.monotonic() - started
        record.update(result=asdict(result) if result else None, error=error,
                      wall_seconds=elapsed)
        receipt.write_text(json.dumps(record, indent=2) + "\n")
    try:
        if result is None or result.subtype == "error_during_execution":
            raise ValueError("No trustworthy terminal accounting")
        tokens = token_count(result)
    except ValueError as exception:
        raise ExecutionAccountingUnknown(
            f"{role}: {exception}; stopped without retry. Receipt: {receipt}"
        ) from exception
    failure = error
    if result.is_error or result.subtype != "success":
        failure = f"{result.subtype}: {result.errors or result.result or error}"
    discovered = record.get("init", {}).get("skills", [])
    names = {item if isinstance(item, str) else item.get("name") for item in discovered}
    missing = set(options.skills or []) - names
    if missing:
        failure = f"SDK did not discover declared skills: {sorted(missing)}"
    return AgentCall(record, meta.Resources(
        tokens=tokens, spend_micros=None, wall_seconds=elapsed,
    ), failure)


def failure_feedback(evidence, limit=12000):
    """Only development failures cross into the proposer, never gold labels.

    Structured context records are not clipped by RecentAncestors.max_chars.
    Bound the actual forwarded JSON here and record when a trace was clipped.
    Full observable traces remain in the evaluator's evidence and receipts.
    """
    failures = []
    for case in evidence["cases"]:
        if case.get("score") == 0 or case.get("failure"):
            trace = json.dumps(case["trace"], default=dict)
            failures.append({
                "question": case["question"], "answer": case["answer"],
                "score": case.get("score"), "failure": case.get("failure"), "trace": trace[-limit:],
                "trace_truncated": len(trace) > limit,
            })
    return failures
