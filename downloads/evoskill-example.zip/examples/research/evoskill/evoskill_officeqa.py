"""Pinned public OfficeQA sample, external grading, and native skill folders."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
from urllib.request import urlopen

import meta_evolve as meta

HERE = Path(__file__).resolve().parent
DEVELOPMENT = ("UID0003", "UID0012", "UID0045")
HELD_OUT = ("UID0001", "UID0002", "UID0006")
SKILLS = ".claude/skills"


@dataclass(frozen=True)
class OfficeQA:
    root: Path
    corpus: Path
    builder: Path
    rows: dict
    score_answer: object
    identity: dict

    def cases(self, split):
        ids = {"development": DEVELOPMENT, "held_out": HELD_OUT}[split]
        return tuple(self.rows[uid] for uid in ids)


def verified_download(item, destination):
    destination = Path(destination)
    if destination.exists():
        content = destination.read_bytes()
    else:
        with urlopen(item["url"], timeout=60) as response:
            content = response.read()
    if (len(content) != item["bytes"] or
            hashlib.sha256(content).hexdigest() != item["sha256"]):
        raise ValueError(f"Checksum mismatch: {item['name']}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(content)
    return content


def prepare(root):
    """Download ~4.6 MB once; verify cached bytes on every subsequent setup."""
    root = Path(root).resolve()
    manifest = json.loads((HERE / "resources.json").read_text())
    corpus, private, builder = root / "corpus", root / "private", root / "builder"
    for item in manifest["files"]:
        directory = corpus if item["name"].endswith(".txt") else private
        verified_download(item, directory / item["name"])
    with (private / "officeqa_sample.csv").open(newline="") as stream:
        rows = {row["uid"]: row for row in csv.DictReader(stream)}
    if not set(DEVELOPMENT + HELD_OUT) <= rows.keys():
        raise ValueError("The pinned sample does not contain the declared split")
    namespace = {"__name__": "evoskill_reference_grader"}
    grader = private / "reward.py"
    exec(compile(grader.read_text(), str(grader), "exec"), namespace)
    target = builder / SKILLS / "skill-builder" / "SKILL.md"
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(HERE / "skill-builder" / "SKILL.md", target)
    source_hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in HERE.glob("*.py")}
    identity = {**manifest, "development": DEVELOPMENT, "held_out": HELD_OUT,
                "tolerance": 0.0, "source_sha256": source_hashes,
                "builder_sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
    return OfficeQA(root, corpus, builder, rows, namespace["score_answer"], identity)


def skill_names(tree):
    return sorted(Path(path).parent.name for path in tree if path.endswith("/SKILL.md"))


def validate_skills(tree):
    """A deliberately small native-skill format: name, description, Markdown body.

    Extra frontmatter (tool permissions, hooks, alternate models) is outside the
    candidate's authority. Plain UTF-8 references may accompany each SKILL.md.
    """
    if sum(len(text.encode()) for text in tree.values()) > 100_000:
        raise ValueError("Skill library exceeds 100 KB")
    names = skill_names(tree)
    for path, text in tree.items():
        parts = Path(path).parts
        if (len(parts) < 4 or parts[:2] != (".claude", "skills") or
                not re.fullmatch(r"[a-z][a-z0-9-]{0,62}", parts[2]) or
                parts[2] == "skill-builder" or parts[2] not in names):
            raise ValueError(f"Not a candidate skill resource: {path}")
        if parts[-1] == "SKILL.md":
            match = re.fullmatch(
                r"---\nname: ([a-z][a-z0-9-]{0,62})\n"
                r"description: ([^\n]+)\n---\n([\s\S]+)", text,
            )
            if not match or match[1] != parts[2] or len(parts) != 4:
                raise ValueError(f"Expected name/description frontmatter: {path}")
    return tree


def snapshot(repository):
    folder = Path(repository) / SKILLS
    folder.mkdir(parents=True, exist_ok=True)
    # Capture only skill content: never settings, transcripts, gold labels or logs.
    files = meta.load_source_tree(folder)
    return validate_skills(meta.SourceTree({f"{SKILLS}/{p}": text for p, text in files.items()}))


def materialize(tree, repository):
    repository = Path(repository)
    validate_skills(tree)
    if repository.exists() and any(repository.rglob("*")):
        raise ValueError("Materialize into a new, empty repository")
    (repository / SKILLS).mkdir(parents=True, exist_ok=True)
    for path, text in tree.items():
        target = repository / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)
    return repository


def workspace(root, tree):
    """A fresh repository per query; retained until the user removes the run folder."""
    directory = Path(root) / "workspaces"
    directory.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(dir=directory))
    repo = materialize(tree, work / "skill-repo")
    cwd = work / "agent"
    cwd.mkdir()
    (cwd / ".git").mkdir()  # Stop project-setting discovery at this empty workspace.
    return cwd, repo


def evaluation(cases, calls, score_answer, split):
    """Only a completed answer gets a score; an incomplete suite cannot rank."""
    from meta_evolve.domain import EvaluatorFailure, InvalidOutput

    usage, rows, failure = meta.Resources(), [], None
    for case, call in zip(cases, calls, strict=True):
        usage += call.usage
        row = {"uid": case["uid"], "question": case["question"],
               "answer": call.answer, "trace": call.record["trace"],
               "loaded_skills": call.loaded_skills,
               "invoked_skills": call.invoked_skills}
        if call.failure:
            failure = EvaluatorFailure(message=call.failure)
            row["failure"] = call.failure
        elif not call.answer.strip():
            failure = InvalidOutput(message="Executor returned an empty answer")
            row["failure"] = failure.message
        else:
            try:
                row["score"] = float(score_answer(case["answer"], call.answer, tolerance=0.0))
                if row["score"] not in (0.0, 1.0):
                    raise ValueError("OfficeQA must return a binary score")
            except Exception as error:
                failure = EvaluatorFailure(message=f"OfficeQA grader: {error}")
                row.pop("score", None)
                row["failure"] = failure.message
        rows.append(row)
    evidence = (meta.EvidenceDraft(kind=f"evoskill.{split}", data={"cases": rows}),
                *(call.evidence() for call in calls))
    if failure is not None:
        return meta.EvaluationResult(failure=failure, usage=usage, evidence=evidence)
    return meta.EvaluationResult(
        metrics={"solved": sum(row["score"] for row in rows) / len(rows)},
        usage=usage, evidence=evidence,
    )
