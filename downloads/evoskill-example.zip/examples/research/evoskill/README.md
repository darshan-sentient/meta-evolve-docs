# EvoSkill with Claude and OfficeQA

**Status: Experimental/live-only.** Haiku answers real OfficeQA questions.
Sonnet receives its failed traces and returns a structured skill proposal;
another Sonnet session invokes a fixed skill-builder to write native Claude
skill files. Meta-Evolve evaluates and selects folder snapshots.

The [standalone notebook](https://sentient-xyz.github.io/meta-evolve-docs/downloads/evoskill.ipynb)
embeds both helpers, the builder, resource manifest and a matching Meta-Evolve
source package (the public release lacks the feedback API used here). It needs no checkout
or companion file. The [walkthrough](https://sentient-xyz.github.io/meta-evolve-docs/build-patterns/evoskill/)
explains the roles and evaluation boundaries.

## Run

Use Python 3.12+ on macOS or Linux. From an installed Meta-Evolve checkout:

```bash
uv pip install -r examples/research/evoskill/requirements.txt
claude auth login
uv run --no-sync python examples/research/evoskill/main.py
```

Alternatively set `ANTHROPIC_API_KEY` in the process environment. Do not put
credentials in a notebook. The SDK includes its own Claude CLI; a separate
`claude` command is needed only if using that login command. API-key users do
not need the standalone CLI. Dependencies remain local to this example.

Use `--prepare-only` to download and verify data without calling Claude.
Use `--output /path/to/new-directory` to retain everything at a chosen location.
The default is a new temporary directory. The CLI retains durable search history
under `search/`, SDK receipts under `receipts/`, each candidate workspace, the
selected library, and the baseline/selected held-out results. The notebook keeps
its search history in memory and saves the same files and reports.

## Files and boundaries

- `main.py`: three SDK declarations, evaluation, proposal/generation and the
  two-revision experiment. The notebook displays this code directly.
- `evoskill_agents.py`: structured schema, observable traces, accounting and
  hooks limiting file tools to each role's permitted directories.
- `evoskill_officeqa.py`: checksum-verified downloads, split, scorer and native
  skill snapshots. No model grades another model.
- `skill-builder/SKILL.md`: this example's fixed builder, installed into the
  generator's separate `.claude/skills/` repository. It uses Write/Edit, without
  shell scripts. Only its generated skills reach the executor.
- `resources.json`: exact commits, URLs, sizes and SHA-256 hashes for all data
  and the official scorer. Cached downloads are verified again before use.

The empty seed is a directory. `SourceTree` snapshots its
`.claude/skills/<name>/SKILL.md` files and UTF-8 references. `SkillSet`'s flat
`skills/<name>.md` representation is unnecessary. Each executor starts fresh,
with native skill discovery through `add_dirs` and `setting_sources=["project"]`.
Loaded skills and observed invocations are recorded separately.

The executor has Read, Glob, Grep and Skill; the generator also has Write/Edit.
Neither has Bash, network tools, subagents or MCP. Path hooks protect gold
answers, grader, receipts and held-out inputs from file-tool access. This
constrained tool surface is not an OS sandbox for arbitrary agent code.

Three development questions (`UID0003`, `UID0012`, `UID0045`) guide search.
Three held-out questions (`UID0001`, `UID0002`, `UID0006`) compare baseline and
selected skills after selection. All nine documents are available to every
executor, without per-question filename hints. Tolerance is `0.0` in the official
OfficeQA scorer. Completed wrong answers score zero; SDK failures, malformed
proposals, missing skill invocation, and empty answers remain failures.

At most 19 SDK calls run: 9 development executions, 2 proposals, 2 generations,
and 6 held-out executions. SDK per-call estimate limits sum to $10.50 for that
maximum, can overshoot, and are not authoritative billed limits. Tokens and
elapsed work from every role count even after failure. Estimated USD is retained
separately; `spend_micros=None` records unknown bills. Missing terminal token
accounting aborts without retry and leaves a JSON receipt.

Live scores may improve, tie or regress. The seed may solve every question,
in which case no skill is generated. Do not infer broad benchmark performance
from this small demonstration. Provider behavior and model aliases may change.

## Sources and attribution

Data: the public ten-question sample and nine Treasury text files in
[EvoSkill](https://github.com/sentient-agi/EvoSkill/tree/36f6f04952293d7054145550c2b9f0b0411bff1c/examples/officeqa/data),
derived from [Databricks OfficeQA](https://github.com/databricks/officeqa).
OfficeQA data is attributed under CC-BY-SA-4.0. The Treasury bulletins originate
from the U.S. Treasury and FRASER. The full gated OfficeQA corpus is not needed.
The Apache-2.0 [reference scorer](https://github.com/databricks/officeqa/blob/7b9a3c154ef9fb40215bb67934afc43e6799de16/reward.py)
is downloaded unchanged and verified before loading. Setup does not download
unversioned remote Python.

The fixed builder here is example-owned, rather than EvoSkill's larger
skill-creator bundle. It is loaded and invoked through the SDK's native Skill
mechanism. The loop follows failure-driven proposal and generation from
[EvoSkill](https://arxiv.org/abs/2603.02766), using bounded Greedy instead of the
paper's validation Pareto selection. This is not a paper reproduction.

Maintainers regenerate the notebook with
`python docs/hooks/evoskill_notebook.py`. Offline tests substitute the SDK stream,
execute the notebook outside the checkout, and check grading, skill loading,
feedback isolation and failure accounting. They are not live performance evidence.
