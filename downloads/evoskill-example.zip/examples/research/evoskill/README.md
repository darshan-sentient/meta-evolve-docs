# EvoSkill with three callable Claude agents

**Experimental/live-only.** Haiku answers three OfficeQA questions. Sonnet proposes
one reusable skill from failed traces; another Sonnet agent invokes its fixed
`skill-builder` and writes the skill. Retry a missed question, then continue from
that folder with `Population(size=3, tournament_size=2, max_trials=2)`.

[Notebook](https://sentient-xyz.github.io/meta-evolve-docs/downloads/evoskill.ipynb)
· [Walkthrough](https://sentient-xyz.github.io/meta-evolve-docs/build-patterns/evoskill/)

The notebook has eight code cells: setup, agents, answers, proposal, generated
skill, retry, population, and held-out comparison. Read the answer tables,
structured output and rendered `SKILL.md` as you go; expand the observable
traces for details. Setup fetches two readable Python helpers and their resources
automatically, or imports them from a local checkout.

## Run

Use a Python 3.12+ kernel with pip on macOS or Linux. For the script, from an
installed Meta-Evolve checkout:

~~~bash
uv pip install -r examples/research/evoskill/requirements.txt
claude auth login
uv run --no-sync python examples/research/evoskill/main.py
~~~

Alternatively configure `ANTHROPIC_API_KEY` in the process environment.
The SDK includes a CLI for API-key use; login needs the standalone Claude CLI.
`--prepare-only` verifies downloads without model calls. `--output /path/to/new`
chooses a retained run folder; the default is a new temporary folder.

## Source layout

- `main.py`: two output schemas, three agents, direct calls, and population search.
  The notebook and walkthrough use these same source sections.
- `evoskill_agents.py`: `ClaudeAgentOptions`, the small callable over
  `ClaudeSDKClient`, structured outputs, observable messages and usage receipts.
  A worker thread lets the ordinary callable run inside Jupyter.
- `evoskill_officeqa.py`: pinned downloads, independent grading, skill-folder
  snapshots, validation and presentation.
- `resources.json`: immutable URLs and SHA-256 checksums for the public sample,
  nine Treasury texts and official scorer, about 4.6 MB total.
- `skill-builder/SKILL.md`: the generator's fixed native skill.

Candidates are path-to-text dictionaries validated through `SourceTree`.
Fresh SDK sessions discover `.claude/skills/` through `add_dirs` and project
settings. The builder lives in a separate repository. Gold labels remain in
Python; the agents can read the source documents but cannot access the grader.
File-tool permissions exclude shell and network tools; this is not an OS sandbox.

## Grading and evidence

Development uses `UID0003`, `UID0012` and `UID0045`; held-out questions are
`UID0001`, `UID0002` and `UID0006`. UID0003 explicitly names Table 2 of the
February 1954 Treasury Bulletin: Tables 2 and 3 print conflicting monthly values,
and the official answer matches Table 2. The original question and clarification
are retained. This is an adapted teaching sample, not an unchanged benchmark.

The executor returns a numeric `final_answer` in the requested units, separately
from its explanation. Python places only that value in the official scorer's
answer tags. Ground truth, tolerance `0.0`, and the scorer itself are unchanged.
Wrong completed answers score zero; failed calls and invalid outputs retain
their failures and usage. Unknown token accounting stops without automatic retry.

Run All makes at most 25 SDK calls: six walkthrough, thirteen population and six
held-out calls. Per-call estimate limits sum to $14 at that maximum and can
overshoot. A perfect score can stop the search early. If the empty folder already
solves every development question, the manual revision is skipped. The population
always grades its starting folder on the full development set.

The run folder contains skills, full observable SDK receipts, held-out results
and `report.json`. The report counts all stages; `run.usage()` covers population
search only. SDK dollar estimates are separate from unknown billed spend. Search
history is in memory. These six questions demonstrate the mechanism; outcomes
can improve, tie or regress and vary across model runs.

## Sources and maintenance

The sample comes from [EvoSkill](https://github.com/sentient-agi/EvoSkill/tree/36f6f04952293d7054145550c2b9f0b0411bff1c/examples/officeqa/data),
derived from [OfficeQA](https://github.com/databricks/officeqa) (CC-BY-SA-4.0).
The Apache-2.0 scorer is unchanged; the builder is example-owned.

Run `python docs/hooks/evoskill_notebook.py` after editing. Matching helpers are
published at a content-versioned URL. Saved live outputs are retained only when
the notebook's code fingerprint matches its capture; changing code clears them.
Offline fresh-kernel tests use SDK stream doubles. The docs build never makes
model calls.
