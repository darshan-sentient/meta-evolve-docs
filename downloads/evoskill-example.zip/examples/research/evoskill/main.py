"""Failure → structured proposal → native skill → fresh OfficeQA execution."""

# --8<-- [start:imports]
import asyncio
from dataclasses import asdict
import json
from pathlib import Path
import tempfile

from claude_agent_sdk import ClaudeAgentOptions

import meta_evolve as meta
from meta_evolve.domain import InvalidOutput, ProposerFailure

from evoskill_agents import (
    PROPOSAL_SCHEMA, call_agent, failure_feedback, file_permissions, validate_proposal,
)
from evoskill_officeqa import (
    SKILLS, evaluation, materialize, prepare, skill_names, snapshot, workspace,
)
# --8<-- [end:imports]


# --8<-- [start:executor-options]
def executor_options(cwd, skills_repo, corpus):
    return ClaudeAgentOptions(
        model="haiku", cwd=cwd,
        add_dirs=[skills_repo, corpus],  # skills_repo contains .claude/skills/.
        setting_sources=["project"], skills=skill_names(snapshot(skills_repo)),
        tools=["Read", "Glob", "Grep", "Skill"],
        allowed_tools=["Read", "Glob", "Grep"],
        max_turns=32, max_budget_usd=0.50,
        **file_permissions(cwd, [cwd, skills_repo, corpus]),
    )
# --8<-- [end:executor-options]


# --8<-- [start:proposer-options]
def proposer_options(cwd, skills_repo):
    return ClaudeAgentOptions(
        model="sonnet", cwd=cwd, add_dirs=[skills_repo],
        setting_sources=[], skills=[], tools=[],
        permission_mode="dontAsk", strict_mcp_config=True,
        max_turns=5, max_budget_usd=0.50,
        output_format={"type": "json_schema", "schema": PROPOSAL_SCHEMA},
    )
# --8<-- [end:proposer-options]


# --8<-- [start:generator-options]
def generator_options(cwd, skills_repo, builder_repo):
    return ClaudeAgentOptions(
        model="sonnet", cwd=cwd, add_dirs=[skills_repo, builder_repo],
        setting_sources=["project"], skills=["skill-builder"],
        tools=["Read", "Glob", "Grep", "Skill", "Write", "Edit"],
        max_turns=16, max_budget_usd=1.00,
        **file_permissions(cwd, [cwd, skills_repo, builder_repo], skills_repo / SKILLS),
    )
# --8<-- [end:generator-options]


# --8<-- [start:executor]
async def execute(tree, case, data):
    cwd, skills_repo = workspace(data.root, tree)
    activation = ("First invoke the current library with the Skill tool, one skill at a time: "
                  + ", ".join(skill_names(tree)) + ". ") if tree else ""
    prompt = activation + (
        f"Answer the question using the Treasury documents in {data.corpus}. "
        "Search across the corpus; verify the date, table headings and units. "
        "Invoke any relevant available skills using the Skill tool. "
        "Put reasoning outside the final tags. Finish with "
        "<FINAL_ANSWER>only the requested value and units</FINAL_ANSWER>; "
        "no explanation, citations or additional numbers inside those tags.\n\n"
        f"Question: {case['question']}"
    )
    return await call_agent("executor", prompt,
                            executor_options(cwd, skills_repo, data.corpus), data.root / "receipts")


async def evaluate(tree, data, split="development"):
    cases = data.cases(split)
    calls = [await execute(tree, case, data) for case in cases]
    return evaluation(cases, calls, data.score_answer, split)
# --8<-- [end:executor]


# --8<-- [start:generator]
async def generate(parent, proposal, data):
    cwd, skills_repo = workspace(data.root, parent)
    prompt = (
        "First invoke skill-builder using the Skill tool, then follow it. "
        f"Create or revise only {skills_repo / SKILLS / proposal['name']}. "
        "The executor has Read, Glob, Grep and Skill, with no shell. "
        f"The proposal is:\n{json.dumps(proposal)}"
    )
    call = await call_agent("generator", prompt,
                           generator_options(cwd, skills_repo, data.builder), data.root / "receipts")
    if call.failure:
        return call, None, call.failure
    if "skill-builder" not in call.invoked_skills:
        return call, None, "Generator did not invoke the initialized skill-builder"
    try:
        candidate = snapshot(skills_repo)
        changed = {p for p in set(parent) | set(candidate) if parent.get(p) != candidate.get(p)}
        prefix = f"{SKILLS}/{proposal['name']}/"
        if not changed or any(not path.startswith(prefix) for path in changed):
            raise ValueError("Generator must change only the proposed skill folder")
        if prefix + "SKILL.md" not in candidate:
            raise ValueError("Generator did not write the proposed SKILL.md")
    except (OSError, ValueError) as error:
        return call, None, str(error)
    return call, candidate, None
# --8<-- [end:generator]


# --8<-- [start:proposer]
async def revise(parent, feedback, data, derived_from=()):
    failures = failure_feedback(feedback)
    if not failures:
        return meta.ProposalResult(failure=ProposerFailure(message="No failed development answers"))
    cwd, skills_repo = workspace(data.root, parent)
    prompt = ("Propose one reusable skill from these failed executor traces. "
              "Return its name and high-level description using the output schema. "
              "A name already in the library means revise that skill. Teach a method; "
              "do not memorize benchmark questions, answers or filenames.\n" +
              json.dumps({"library": dict(parent), "failures": failures}))
    call = await call_agent("proposer", prompt, proposer_options(cwd, skills_repo), data.root / "receipts")
    if call.failure:
        return meta.ProposalResult(failure=ProposerFailure(message=call.failure),
                                   usage=call.usage, evidence=(call.evidence(),))
    try:
        proposal = validate_proposal(call.structured_output)
    except ValueError as error:
        return meta.ProposalResult(failure=InvalidOutput(message=str(error)),
                                   usage=call.usage, evidence=(call.evidence(),))
    generated, candidate, problem = await generate(parent, proposal, data)
    evidence = (call.evidence(), generated.evidence(), meta.EvidenceDraft(
        kind="evoskill.proposal", data={"proposal": proposal, "feedback": failures},
    ))
    result = {"usage": call.usage + generated.usage, "evidence": evidence, "derived_from": derived_from}
    if problem:
        failure = ProposerFailure if generated.failure else InvalidOutput
        return meta.ProposalResult(failure=failure(message=problem), **result)
    return meta.ProposalResult(candidate=candidate, hypothesis=proposal["description"], **result)
# --8<-- [end:proposer]


# --8<-- [start:experiment]
def experiment(data, seed):
    def propose(parent, *, context):
        feedback = context.evidence.latest("evoskill.development")
        if feedback is None:
            return meta.ProposalResult(failure=ProposerFailure(message="Missing development feedback"))
        return asyncio.run(revise(parent, feedback.data, data, (feedback.ref,)))

    def grade(tree):
        return asyncio.run(evaluate(tree, data))

    experiment = meta.Experiment(
        seed=seed, proposer=propose,
        task=meta.Task(
            artifact=meta.SourceTree, evaluator=grade,
            objectives=(meta.Maximize("solved", satisfy=1.0),),
            budget=meta.Budget(trials=2, evaluations=3),
            environment={"officeqa": data.identity, "sdk": "claude-agent-sdk==0.2.156",
                         "models": {"executor": "haiku", "proposer": "sonnet", "generator": "sonnet"}},
        ),
        search=meta.Greedy(max_trials=2),
        context=meta.RecentAncestors(max_records=24, max_chars=12000),
        random_seed=0,
    )
    return experiment
# --8<-- [end:experiment]


# --8<-- [start:inspection]
def show_trial(trial):
    print("step:", trial.logical_step, "state:", trial.state, "metrics:", dict(trial.metrics))
    if trial.failure:
        print("failure:", trial.failure.kind, trial.failure.message)
    for item in trial.evidence:
        if item.kind == "evoskill.proposal":
            print("proposal:", dict(item.data["proposal"]))
        if item.kind == "evoskill.development":
            for case in item.data["cases"]:
                print(case["uid"], "score:", case.get("score"),
                      "loaded:", case["loaded_skills"], "invoked:", case["invoked_skills"])
    if trial.artifact:
        print("skill files:", list(trial.artifact.value))
# --8<-- [end:inspection]


def save_report(run, baseline, selected, data):
    usage = run.usage().resources + baseline.usage + selected.usage
    observations = [item for trial in run.trials() for item in trial.evidence]
    observations += list(baseline.evidence) + list(selected.evidence)
    costs = [item.data["result"].get("total_cost_usd") for item in observations
             if item.kind == "evoskill.agent"]
    report = {
        "run_id": str(run.id), "controls": data.identity,
        "development": [{"step": trial.logical_step, "state": trial.state,
                         "metrics": dict(trial.metrics)} for trial in run.trials()],
        "held_out_baseline": dict(baseline.metrics), "held_out_selected": dict(selected.metrics),
        "held_out_failures": [asdict(result.failure) if result.failure else None
                              for result in (baseline, selected)],
        "resources": asdict(usage),
        "estimated_cost_usd": sum(costs) if costs and all(cost is not None for cost in costs) else None,
        "selected_digest": run.best().digest,
    }
    (data.root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    for label, result in (("baseline", baseline), ("selected", selected)):
        (data.root / f"held-out-{label}.json").write_text(
            json.dumps([dict(item.data) for item in result.evidence], default=dict, indent=2) + "\n")
    return report


def main():
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="New output folder; defaults to a temporary directory")
    parser.add_argument("--prepare-only", action="store_true", help="Verify data without calling Claude")
    args = parser.parse_args()
    root = args.output or Path(tempfile.mkdtemp(prefix="evoskill-"))
    if args.output:
        root.mkdir(parents=True, exist_ok=False)
    data = prepare(root)
    print("Run folder:", root)
    if args.prepare_only:
        print("Verified 10 questions, 9 Treasury documents, and the OfficeQA grader.")
        return
    seed = snapshot(root / "seed")
    with meta.Storage.durable(root / "search") as storage:
        run = meta.run(experiment(data, seed), storage=storage)
        for trial in run.trials():
            show_trial(trial)
        if run.summary().primary_score is None:
            print("No rankable candidate. Inspect retained failures; held-out checks skipped.")
            return
        winner = run.best().value
        materialize(winner, root / "selected")
        baseline = asyncio.run(evaluate(seed, data, "held_out"))
        selected = asyncio.run(evaluate(winner, data, "held_out"))
        print(json.dumps(save_report(run, baseline, selected, data), indent=2))


if __name__ == "__main__":
    main()
