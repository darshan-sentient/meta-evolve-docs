"""Teach a native Claude skill, inspect the retry, then continue with a population."""

# --8<-- [start:imports]
import json
from pathlib import Path
import tempfile

from pydantic import BaseModel, Field
import meta_evolve as meta

from evoskill_agents import ClaudeAgent, agent_options, failure_feedback, transcripts
from evoskill_officeqa import (
    answer_table, evaluation, generated_skills, population_table, prepare, restore,
    save_report, skill_markdown, skill_revision, snapshot,
)
# --8<-- [end:imports]


# --8<-- [start:schema]
class Answer(BaseModel):
    model_config = {"extra": "forbid"}
    final_answer: float = Field(description="One value in the question's requested units")
    explanation: str = Field(description="Brief explanation with the source table")


class SkillProposal(BaseModel):
    model_config = {"extra": "forbid", "str_strip_whitespace": True}
    name: str = Field(pattern=r"^[a-z][a-z0-9-]{0,62}$")
    description: str = Field(min_length=20, max_length=800)
# --8<-- [end:schema]


def lesson(root, manifest=None, builder_skill=None, display=None):
    from IPython.display import HTML, JSON, Markdown, display as notebook_display
    display = display or notebook_display

    # --8<-- [start:setup]
    data = prepare(root, manifest, builder_skill)
    skill_repo = data.root / "skill-repo"
    empty_skills = dict(snapshot(skill_repo))
    print("Run folder:", data.root)
    # --8<-- [end:setup]

    # --8<-- [start:agents]
    options = agent_options(data, executor_model="haiku", skill_model="sonnet")
    executor = ClaudeAgent(options["executor"], output_type=Answer, name="executor")
    proposer = ClaudeAgent(options["proposer"], output_type=SkillProposal, name="proposer")
    generator = ClaudeAgent(options["generator"], name="generator")
    # --8<-- [end:agents]

    # --8<-- [start:baseline]
    cases = data.cases("development")
    before = [executor(case["question"]).require() for case in cases]
    display(Markdown(answer_table(cases, before, data.score_answer)))
    display(HTML(transcripts(before)))
    feedback = evaluation(cases, before, data.score_answer, "development")
    if feedback.failure:
        raise RuntimeError(str(feedback.failure))
    failures = failure_feedback(feedback.evidence[0].data)
    # --8<-- [end:baseline]

    # --8<-- [start:propose]
    proposal = None
    if failures:
        proposal = proposer(json.dumps({"skills": empty_skills, "failures": failures})).require()
        display(JSON(proposal.output.model_dump()))
    else:
        print("All three answers passed; no failed trace needs a skill.")
    # --8<-- [end:propose]

    # --8<-- [start:generate]
    if proposal:
        generated = generator(proposal.output.model_dump_json()).require()
        seed = dict(generated_skills(empty_skills, proposal.output, generated, skill_repo))
        display(Markdown(skill_markdown(seed)))
        display(HTML(transcripts([generated])))
    else:
        seed = empty_skills
    # --8<-- [end:generate]

    # --8<-- [start:retry]
    if proposal:
        index = next(i for i, row in enumerate(feedback.evidence[0].data["cases"]) if row["score"] == 0)
        case = cases[index]
        retry = executor(case["question"]).require()
        display(Markdown(answer_table([case], [retry], data.score_answer, before=[before[index]])))
        display(JSON(retry.output.model_dump()), HTML(transcripts([retry])))
    # --8<-- [end:retry]

    # --8<-- [start:population]
    def evaluate(skills, split="development"):
        restore(skills, skill_repo)
        questions = data.cases(split)
        answers = [executor(case["question"]) for case in questions]
        display(Markdown(answer_table(questions, answers, data.score_answer)))
        return evaluation(questions, answers, data.score_answer, split)

    def revise(skills, *, context):
        observed = context.evidence.latest("evoskill.development")
        restore(skills, skill_repo)
        proposal = proposer(json.dumps({"skills": dict(skills), "failures": failure_feedback(observed.data)}))
        generated = generator(proposal.output.model_dump_json()) if not proposal.failure else None
        revision = skill_revision(skills, proposal, generated, skill_repo, (observed.ref,))
        print("Proposed:", proposal.output if not proposal.failure else proposal.failure)
        return revision

    experiment = meta.Experiment(
        task=meta.Task(evaluator=evaluate, objectives=(meta.Maximize("solved", satisfy=1.0),)),
        seed=seed, proposer=revise,
        search=meta.Population(size=3, tournament_size=2, max_trials=2),
        context=meta.RecentAncestors(max_records=24, max_chars=12000), random_seed=0,
    )
    run = meta.run(experiment)
    display(Markdown(population_table(run)))
    # --8<-- [end:population]

    # --8<-- [start:held-out]
    if run.summary().primary_score is not None:
        winner = dict(run.best().value)
        print("Empty folder — held out")
        baseline = evaluate(empty_skills, "held_out")
        print("Selected folder — held out")
        selected = baseline if winner == empty_skills else evaluate(winner, "held_out")
        restore(winner, skill_repo)
        report = save_report(run, data, baseline, selected)
        display(JSON({key: report[key] for key in (
            "held_out_baseline", "held_out_selected", "held_out_failures", "sdk_calls", "estimated_cost_usd",
        )}))
        print("Skills:", list(winner), "\nReport:", data.root / "report.json")
    # --8<-- [end:held-out]
    return run


def main():
    import argparse
    from IPython.display import HTML

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="A new run directory")
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    root = args.output or Path(tempfile.mkdtemp(prefix="evoskill-"))
    if args.output:
        root.mkdir(parents=True, exist_ok=False)
    if args.prepare_only:
        prepare(root)
        print("Verified OfficeQA data:", root)
        return
    lesson(root, display=lambda *items: [print(item.data) for item in items if not isinstance(item, HTML)])


if __name__ == "__main__":
    main()
