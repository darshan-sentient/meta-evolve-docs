"""Improve source against independent checks. Trusted development, POSIX only.

Run with --dry-run to inspect the seed without an SDK or credentials.
The three-file lesson is explained in docs/learn/llm-parser.md.
"""

import argparse
from dataclasses import asdict
from hashlib import sha256
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time

import meta_evolve as meta
from meta_evolve.errors import ExecutionAccountingUnknown
from meta_evolve.domain import (
    EvaluatorFailure, InfrastructureFailure, InvalidOutput,
    ResourceExhausted, TimeoutFailure,
)

from parser_cases import CONTRACT, DEVELOPMENT

# --8<-- [start:seed]
SEED = '''def parse_seconds(text):
    """Parse a whole number of seconds or minutes."""
    import re
    match = re.fullmatch(r"([0-9]+)(s|m)", text)
    if not match:
        raise ValueError("expected seconds or minutes")
    quantity, unit = match.groups()
    return int(quantity) * (60 if unit == "m" else 1)
'''
# --8<-- [end:seed]

CHILD_SECONDS = 3
OUTPUT_BYTES = 65_536
RUNNER = '''import json, resource, sys
resource.setrlimit(resource.RLIMIT_CPU, (2, 2))
resource.setrlimit(resource.RLIMIT_FSIZE, (65536, 65536))
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
scope = {}
exec(compile(open("candidate.py").read(), "candidate.py", "exec"), scope)
parse = scope.get("parse_seconds")
if not callable(parse):
    print(json.dumps({"invalid": "missing parse_seconds callable"}))
    sys.exit(0)
rows = []
for text in json.load(sys.stdin):
    try:
        value = parse(text)
        rows.append({"value": value} if type(value) is int else
                    {"error": "expected int, got " + type(value).__name__})
    except Exception as error:
        rows.append({"error": type(error).__name__})
print(json.dumps(rows))
'''


def evaluate(source, *, cases=DEVELOPMENT):
    """Run only candidate inputs in a bounded child; grade here in the parent."""
    if not cases:
        raise ValueError("evaluation requires at least one case")
    started = time.monotonic()
    evidence = ()
    failure = None
    try:
        if not isinstance(source, str) or len(source.encode()) > OUTPUT_BYTES:
            raise ValueError("source must be text of at most 65536 bytes")
        compile(source, "candidate.py", "exec")  # Validate syntax without executing it.
    except (SyntaxError, ValueError, TypeError, RecursionError) as error:
        return meta.EvaluationResult(failure=InvalidOutput(message=str(error)))
    try:
        with tempfile.TemporaryDirectory(prefix="duration-parser-") as directory:
            root = Path(directory)
            (root / "candidate.py").write_text(source)
            with (root / "input.json").open("w+") as inputs, \
                    (root / "output.json").open("w+b") as output:
                json.dump([text for text, _ in cases], inputs)
                inputs.seek(0)
                process = subprocess.Popen(
                    [sys.executable, "-I", "-c", RUNNER], cwd=root,
                    env={"PATH": os.defpath, "HOME": directory, "TMPDIR": directory},
                    stdin=inputs, stdout=output, stderr=output, start_new_session=True,
                )
                try:
                    process.wait(timeout=CHILD_SECONDS)
                except subprocess.TimeoutExpired:
                    failure = TimeoutFailure(message="candidate exceeded 3 seconds")
                finally:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait()
                output.seek(0)
                raw = output.read(OUTPUT_BYTES)
            evidence = (meta.EvidenceDraft(kind="parser-process", data={
                "returncode": process.returncode, "output": raw.decode(errors="replace"),
            }),)
            if failure is None:
                if len(raw) >= OUTPUT_BYTES or process.returncode == -signal.SIGXFSZ:
                    failure = ResourceExhausted(message="candidate output exceeded 65536 bytes")
                elif process.returncode in (-signal.SIGXCPU, -signal.SIGKILL):
                    failure = TimeoutFailure(message="candidate hit its CPU limit")
                elif process.returncode != 0:
                    failure = EvaluatorFailure(message="candidate failed before case results")
    except OSError as error:
        failure = InfrastructureFailure(message=f"cannot execute candidate: {error}")
    usage = meta.Resources(wall_seconds=time.monotonic() - started)
    if failure is not None:
        return meta.EvaluationResult(failure=failure, evidence=evidence, usage=usage)
    try:
        rows = json.loads(raw)
        if not isinstance(rows, list) or len(rows) != len(cases):
            raise ValueError("expected one result per case and a parse_seconds callable")
        for row in rows:
            if not isinstance(row, dict) or not (
                set(row) == {"value"} and type(row["value"]) is int
                or set(row) == {"error"} and isinstance(row["error"], str)
            ):
                raise ValueError("invalid case result")
    except (ValueError, UnicodeError) as error:
        return meta.EvaluationResult(
            failure=InvalidOutput(message=str(error)), evidence=evidence, usage=usage,
        )
# --8<-- [start:grade]
    checks = tuple(meta.EvidenceDraft(kind="duration-case", data={
        "input": text, "expected": expected, "actual": row,
        "passed": row == ({"error": "ValueError"} if expected is None else {"value": expected}),
    }) for (text, expected), row in zip(cases, rows))
    return meta.EvaluationResult(
        metrics={"score": sum(check.data["passed"] for check in checks) / len(checks)},
        evidence=checks, usage=usage,
    )
# --8<-- [end:grade]


# --8<-- [start:experiment]
def experiment(client, *, seed=SEED, trials=3):
    def propose(parent, *, context):
        # The newest case observations belong to the selected parent.
        observations = [record for record in context.bundle.records
                        if record.kind == "evidence" and record.value.kind == "duration-case"]
        latest = max((record.logical_step for record in observations), default=-1)
        feedback = [dict(record.value.data) for record in observations
                    if record.logical_step == latest]
        return client.generate(
            instructions=CONTRACT + "\nReturn only Python source, without Markdown fences.",
            # Evidence contains immutable mappings; JSON needs ordinary dicts.
            input=json.dumps({"source": parent, "development_checks": feedback}, default=dict),
        )

    return meta.Experiment(
        task=meta.Task(
            evaluator=evaluate, objectives=(meta.Maximize("score", satisfy=1.0),),
            environment={"model": client.configuration, "lesson": lesson_identity()},
        ),
        seed=seed, proposer=propose, search=meta.Greedy(max_trials=trials),
        context=meta.AncestorsOnly(max_records=200, max_chars=64_000),
    )
# --8<-- [end:experiment]


def lesson_identity():
    """Keep local histories distinct when implementation or grading changes."""
    root = Path(__file__).parent
    return {
        "sha256": sha256(b"".join((root / name).read_bytes() for name in
                                 ("parser.py", "parser_cases.py", "openai_client.py"))).hexdigest(),
        "python": sys.version, "child_seconds": CHILD_SECONDS, "output_bytes": OUTPUT_BYTES,
    }


def show(result):
    for index, attempt in enumerate(result.trials()):
        outcome = attempt.failure.kind if attempt.failure else (
            f"{attempt.metrics['score']:.0%}" if attempt.metrics else "incomplete"
        )
        print(f"{'Seed' if index == 0 else 'Revision ' + str(index)}: {outcome}")
        for name, value in attempt.metrics.items():
            if name != "score":
                print(f"  {name}: {value:.1%}")
    try:
        print("Best measured source:\n" + result.best().value)
    except meta.NoSuccessfulEvaluation:
        print("No successfully measured source.")
    print(f"Usage: {result.usage().trials} revisions, {result.usage().evaluations} evaluations")
    usage = result.usage()
    spend = "unknown" if usage.spend_micros is None else f"{usage.spend_micros} micro-USD"
    print(f"Tokens: {usage.tokens}; billed spend: {spend}")
    for item in result.inspect().evidence:
        if item.kind == "cost-report":
            print(f"Reported cost: USD {item.data['usd']} ({item.data['kind']}; {item.data['source']})")
        elif item.kind == "cost-reporting-failure":
            print(f"Cost report unavailable: {item.data['exception_type']}")


def run_lesson(client, directory, *, seed=SEED, trials=3, budget=None, declaration=None):
    """Save a parser experiment; a supplied declaration replaces seed/trials defaults."""
    configured = declaration if declaration is not None else experiment(client, seed=seed, trials=trials)
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=False)
    (root / "configuration.json").write_text(json.dumps({
        "model": client.configuration, "lesson": lesson_identity(),
        "trials": configured.search.configuration["max_trials"],
        "search": {"policy": asdict(configured.search.policy),
                   "configuration": dict(configured.search.configuration)},
        "context": None if configured.context is None else {
            "policy": asdict(configured.context.policy), **asdict(configured.context)},
        "objectives": [{"direction": type(item).__name__, **asdict(item)}
                       for item in configured.task.objectives],
        "task_budget": asdict(configured.task.budget) if configured.task.budget else None,
        "environment": dict(configured.task.environment), "random_seed": configured.random_seed,
        "budget": asdict(budget) if budget else None,
    }, indent=2, default=dict) + "\n")
    with meta.Storage.durable(root / "history") as storage:
        try:
            result = meta.run(configured, storage=storage, budget=budget)
        except ExecutionAccountingUnknown as error:
            (root / "accounting-unknown.json").write_text(json.dumps({
                "reason": str(error), "receipt": getattr(error, "receipt", None),
            }, indent=2) + "\n")
            raise
        finally:
            # Even an accounting escape leaves its committed prefix inspectable.
            if storage.runs():
                (root / "run-id.txt").write_text(storage.runs()[0].value + "\n")
        show(result)
        try:
            selected = result.best().value
        except meta.NoSuccessfulEvaluation:
            print("Separate final check: skipped; no successfully measured source.")
            return result.id
        (root / "selected.py").write_text(selected)
        from parser_cases import FINAL

        final = evaluate(selected, cases=FINAL)
        (root / "final.json").write_text(json.dumps({
            "metrics": dict(final.metrics),
            "failure": final.failure.kind if final.failure else None,
            "evidence": [dict(item.data) for item in final.evidence],
            "usage": asdict(final.usage),
        }, indent=2, default=dict) + "\n")
        print("Separate final check:", final.failure.kind if final.failure else
              f"{round(final.metrics['score'] * len(FINAL))}/{len(FINAL)}")
        return result.id


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    modes = cli.add_mutually_exclusive_group(required=True)
    modes.add_argument("--dry-run", action="store_true", help="grade only the seed; no SDK requests")
    modes.add_argument("--run", type=Path, metavar="DIRECTORY", help="save a new experiment")
    modes.add_argument("--inspect", type=Path, metavar="DIRECTORY", help="reopen without model calls")
    args = cli.parse_args()
    if args.dry_run:
        measured = evaluate(SEED)
        if measured.failure:
            cli.exit(1, f"{measured.failure.kind}: {measured.failure.message}\n")
        print("Dry run: no SDK requests; only the seed is evaluated.")
        print(f"Seed: {round(measured.metrics['score'] * len(DEVELOPMENT))}/{len(DEVELOPMENT)} development cases")
        for item in measured.evidence[:6]:
            row = item.data
            print(f"{row['input']!r}: {dict(row['actual'])}; expected {row['expected']}")
    elif args.inspect:
        from meta_evolve.domain import RunId

        with meta.Storage.read_only(args.inspect / "history") as storage:
            show(meta.Run(RunId((args.inspect / "run-id.txt").read_text().strip()), storage))
        final_path = args.inspect / "final.json"
        print("Separate final check:", final_path.read_text() if final_path.exists() else "not recorded")
    else:
        from openai_client import OpenAIClient

        try:
            with OpenAIClient.from_environment() as client:
                run_lesson(client, args.run)
        except meta.CapabilityError as error:
            cli.exit(2, f"{error}\n")


if __name__ == "__main__":
    main()
