"""Generate the two canonical notebook JSON files without executing them."""

from __future__ import annotations

import json
from pathlib import Path


HERE = Path(__file__).parent
QUESTIONS = (
    "Who holds the all-time record at the Grammys for the most wins in the album of the year category?",
    "What is the current age of the oldest person to sail solo across the Pacific Ocean?",
)


def markdown(source: str) -> dict[str, object]:
    return {"cell_type": "markdown", "metadata": {}, "source": source.splitlines(True)}


def code(source: str) -> dict[str, object]:
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source.splitlines(True),
    }


def setup_cell() -> str:
    return """from pathlib import Path
import os, sys

root = next(p for p in (Path.cwd(), *Path.cwd().parents) if (p / "pyproject.toml").exists())
lab = root / "examples/research/sealqa_labs"
if str(lab) not in sys.path:
    sys.path.insert(0, str(lab))

from sealqa_labs import UserSdkSessionRunner
from sealqa_labs.config import *

print({
    "wrapper": WRAPPER_DECLARATION, "sessions": TOTAL_SESSIONS,
    "inner_wall_seconds": INNER_BUDGET.wall_seconds,
    "opt_in": f"{LIVE_OPT_IN}=1",
})
"""


def declaration() -> str:
    return (
        "## Live declaration\n\nBring your own user-owned SDK wrapper and "
        "identify its behavior-affecting declaration. Set "
        "`META_EVOLVE_LIVE_SDK=1` only after authenticating it and reviewing "
        "its session, tool, permission, and spending limits. Every inner run "
        "declares `INNER_BUDGET.wall_seconds = 1860`; the wrapper must honor "
        "that bound or refuse preflight. These calls may incur cost."
    )


def run_cell(module: str) -> str:
    return f"""if os.getenv(LIVE_OPT_IN) != "1":
    raise RuntimeError(
        f"Live-only lab: set {{LIVE_OPT_IN}}=1 after authenticating your SDK."
    )

from sealqa_labs.{module} import execute

raise RuntimeError(
    "Define build_agent(request), then run(UserSdkSessionRunner(agent_factory=build_agent))."
)
print("sessions executed:", len(result.sessions))
print("usage:", result.usage)
"""


def inspect_cell() -> str:
    return """for session in result.sessions:
    print(session.label, "failure=" + (session.failure.kind if session.failure else "none"))
print("artifacts:", result.artifacts)
print("measurements:", result.measurements)
"""


def notebook(cells: list[dict[str, object]]) -> dict[str, object]:
    return {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            },
            "language_info": {"name": "python", "version": "3.12"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }


def feedback() -> list[dict[str, object]]:
    return [
        markdown(f"# Feedback Descent lab\n\n> **SealQA question:** {QUESTIONS[0]}\n"),
        markdown(
            "**Terminology.** A *candidate* is a `meta.Text` solver prompt. "
            "A pairwise evaluator chooses between two answers and emits textual feedback; "
            "an editor derives one successor prompt from that evidence. This is a small "
            "teaching implementation inspired by [Feedback Descent](https://openreview.net/forum?id=TIOFvhliLA), "
            "not a reproduction of its results or an official SealQA evaluation."
        ),
        markdown(
            "## What changes\n\nOnly the solver prompt changes. The frozen question and documents, "
            "hidden exact answer, declarations, and evaluator remain outside candidate authority. "
            "The path is two initial solves, one structured comparison, one feedback-derived edit, "
            "and one edited-prompt solve: **5 live sessions**."
        ),
        markdown(declaration()),
        code(setup_cell()),
        code(run_cell("feedback_descent")),
        markdown(
            "## Visible record\n\nThe next cell exposes prompt artifacts, the preferred candidate, textual "
            "feedback, edit lineage, typed failures, exact-answer measurements, and aggregate usage. "
            "Malformed comparison output, a missing edit, timeout, or provider failure has no metric."
        ),
        code(inspect_cell()),
        markdown(
            "## Live observation\n\nNo official provider capture is pending. A user may perform one "
            "authorized run with a declared wrapper. Any published capture must keep the single "
            "outcome—including a tie, regression, or typed failure—and sanitize credentials "
            "without rerunning for improvement."
        ),
        markdown(
            "## Audit and exercise\n\n- Did the editor see only the preferred prompt and textual feedback?\n"
            "- Did the evaluator-only answer enter any solver or editor request?\n"
            "- Is one edited evaluation enough to claim a robust improvement?\n\n"
            "**Change and predict:** remove the instruction to ignore distractors from candidate B. "
            "Predict the preference, feedback, and final exact score before rerunning."
        ),
    ]


def autodata() -> list[dict[str, object]]:
    return [
        markdown(f"# AutoData lab\n\n> **SealQA question:** {QUESTIONS[1]}\n"),
        markdown(
            "**Terminology.** The evolving `meta.Text` is a data-generation *recipe*. A "
            "`restricted_solver` sees only the generated question; an `informed_solver` sees the "
            "same question plus selected frozen evidence. The paper describes weak/strong models; "
            "this lab uses one model under different contexts. Inspired by [AutoData](https://facebookresearch.github.io/RAM/blogs/autodata/)."
        ),
        markdown(
            "## What changes\n\nOnly the recipe changes. Each recipe uses a generator and two solver "
            "sessions, followed by local schema, answerability, leakage, and normalized exact-answer "
            "checks. One rewrite separates the two evaluations: **3 + 1 + 3 = 7 sessions**. "
            "Same-model/different-context is a teaching simplification and a confounder."
        ),
        markdown(declaration()),
        code(setup_cell()),
        code(run_cell("autodata")),
        markdown(
            "## Visible record\n\nGenerated items, both solver answers, acceptance decisions, rejection "
            "reasons, recipe lineage, typed failures, and usage remain inspectable. A session failure "
            "is unrankable; it is never converted to a rejected example with score zero."
        ),
        code(inspect_cell()),
        markdown(
            "## Live observation\n\nNo official provider capture is pending. A user may perform one "
            "authorized run with a declared wrapper. Preserve rejection or a successor that is no "
            "better; do not rerun until a generated item happens to pass."
        ),
        markdown(
            "## Audit and exercise\n\n- Does the restricted solver workspace contain evidence?\n"
            "- Can the informed solver's context advantage be confused with model strength?\n"
            "- Does the generated reference answer leak verbatim into its question?\n\n"
            "**Change and predict:** require two evidence document IDs. Predict which deterministic "
            "check changes and whether acceptance becomes easier or harder."
        ),
    ]


def main() -> None:
    notebooks = {
        "01_feedback_descent.ipynb": feedback(),
        "02_autodata.ipynb": autodata(),
    }
    for name, cells in notebooks.items():
        (HERE / name).write_text(json.dumps(notebook(cells), indent=1) + "\n")


if __name__ == "__main__":
    main()
