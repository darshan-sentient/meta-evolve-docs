# SealQA fixture notice

This directory contains an eight-row teaching fixture derived from the
`longseal` configuration of [`vtllms/sealqa`](https://huggingface.co/datasets/vtllms/sealqa).
The questions, answers, row metadata, and document identifier lists are frozen
from revision `0b0787bc5c7c21bcc097a0ef8cd0660df06d6b3e`. That revision referred
to document IDs but did not yet contain `documents.jsonl`; the corresponding
document bodies come from the immediately following upload revision
`7c9c07126c7f85d68b755e9dc4d46c45644a7e11`.

SealQA is by Thinh Pham, Nguyen Nguyen, Pratibha Zunjare, Weiyuan Chen,
Yu-Min Tseng, and Tu Vu. The upstream dataset repository distributes its work
under the Apache License 2.0; a fixture-specific copy is included as `LICENSE`.
The rows were reduced to eight examples, assigned teaching roles, given stable
local document IDs, and serialized with per-row checksums.

This notice and the fixture-specific `LICENSE` apply only to the derived data
fixture. The Meta-Evolve repository is separately distributed under the
[Apache License 2.0](../../../../LICENSE).

These rows are an attributed teaching fixture, not a training corpus, an
official SealQA split, or a reproduction of published SealQA results.
