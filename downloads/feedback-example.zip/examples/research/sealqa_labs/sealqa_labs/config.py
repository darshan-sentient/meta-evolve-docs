"""Provider-neutral declarations for the live-only curriculum."""

from __future__ import annotations

import meta_evolve as meta


WRAPPER_DECLARATION = "user-supplied-sdk-wrapper"
LIVE_OPT_IN = "META_EVOLVE_LIVE_SDK"
WALL_SECONDS = 1860.0
INNER_BUDGET = meta.Budget(
    evaluations=2,
    trials=1,
    wall_seconds=WALL_SECONDS,
)

SESSION_COUNTS = {
    "feedback_descent": 5,
    "autodata": 7,
}
TOTAL_SESSIONS = sum(SESSION_COUNTS.values())


def session_identity_payload(*, purpose: str, schema: object) -> dict[str, object]:
    """All behavior-affecting session declarations used by local comparisons."""

    return {
        "wrapper": WRAPPER_DECLARATION,
        "purpose": purpose,
        "schema": schema,
        "budget": {
            "evaluations": INNER_BUDGET.evaluations,
            "trials": INNER_BUDGET.trials,
            "wall_seconds": INNER_BUDGET.wall_seconds,
        },
    }
