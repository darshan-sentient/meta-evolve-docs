"""Secret-safe identities for local teaching evaluators and comparisons."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping

from .config import session_identity_payload
from .models import EvaluatorCase


def configuration_digest(configuration: Mapping[str, object]) -> str:
    """Hash an explicit JSON-safe behavior declaration, never live provider state."""

    encoded = json.dumps(
        configuration,
        sort_keys=True,
        separators=(",", ":"),
        default=repr,
    ).encode()
    return hashlib.sha256(encoded).hexdigest()


def evaluator_identity(
    case: EvaluatorCase,
    *,
    purpose: str,
    schema: Mapping[str, object],
    extra: Mapping[str, object] | None = None,
) -> str:
    payload = session_identity_payload(purpose=purpose, schema=schema)
    payload.update(
        {
            "fixture_case_id": case.public.id,
            "fixture_row_checksum": case.checksum,
            "grader": "normalized-exact-v1",
            "extra": dict(extra or {}),
        }
    )
    return f"1+{configuration_digest(payload)}"
