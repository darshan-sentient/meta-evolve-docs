"""A seven-session AutoData teaching loop with deterministic acceptance checks."""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve.domain import InvalidOutput

from .fixture import evaluator_case, render_case
from .grading import exact_answer
from .identity import evaluator_identity
from .models import LabResult, Measurement, SessionRecord, SolverCase
from .session import SessionRequest, SessionRunner
from .structured import ANSWER_SCHEMA, validate_record


SESSION_COUNT = 7
SEED_RECIPE = meta.Text(
    "Generate one unambiguous fact-seeking question answerable from the evidence. "
    "Return its exact short answer and the document IDs used."
)
ITEM_SCHEMA = {
    "type": "object",
    "properties": {
        "question": {"type": "string", "minLength": 1},
        "reference_answer": {"type": "string", "minLength": 1},
        "evidence_doc_ids": {
            "type": "array",
            "items": {"type": "string", "minLength": 1},
        },
    },
    "required": ["question", "reference_answer", "evidence_doc_ids"],
    "additionalProperties": False,
}
RECIPE_SCHEMA = {
    "type": "object",
    "properties": {"recipe": {"type": "string", "minLength": 1}},
    "required": ["recipe"],
    "additionalProperties": False,
}


def execute(runner: SessionRunner) -> LabResult:
    case = evaluator_case("autodata_grounding")
    sessions: list[SessionRecord] = []
    evidence: dict[str, object] = {}
    first = _evaluate_recipe(runner, "autodata.seed", SEED_RECIPE, case.public)
    sessions.extend(first[0])
    evidence["seed"] = first[1]
    rewrite = validate_record(
        runner.run(
            SessionRequest(
                label="autodata.recipe_rewrite",
                instructions=(
                    "Rewrite recipe.md to address the acceptance report. Generalize; do "
                    "not copy the generated question or answer. Return the new recipe."
                ),
                schema=RECIPE_SCHEMA,
                workspace=meta.SourceTree(
                    {"recipe.md": str(SEED_RECIPE), "acceptance.txt": repr(first[1])}
                ),
            )
        ),
        RECIPE_SCHEMA,
    )
    sessions.append(rewrite)
    if rewrite.failure is not None:
        return LabResult(
            "autodata",
            tuple(sessions),
            {"seed_recipe": SEED_RECIPE, "evidence": evidence},
            {"successor": Measurement(failure=rewrite.failure)},
        )
    assert rewrite.value is not None
    successor = meta.Text(str(rewrite.value["recipe"]))
    second = _evaluate_recipe(runner, "autodata.successor", successor, case.public)
    sessions.extend(second[0])
    evidence["successor"] = second[1]
    return LabResult(
        "autodata",
        tuple(sessions),
        {
            "seed_recipe": SEED_RECIPE,
            "successor_recipe": successor,
            "evidence": evidence,
            "evaluator_identity": evaluator_identity(
                case,
                purpose="autodata.quality",
                schema=ITEM_SCHEMA,
                extra={"checks": "schema+answerability+leakage+exact-v1"},
            ),
        },
        {
            "seed": _acceptance_measurement(first[0], first[1]),
            "successor": _acceptance_measurement(second[0], second[1]),
        },
    )


def _evaluate_recipe(
    runner: SessionRunner, prefix: str, recipe: meta.Text, case: SolverCase
) -> tuple[tuple[SessionRecord, ...], dict[str, object]]:
    generated = validate_record(
        runner.run(
            SessionRequest(
                label=f"{prefix}.generator",
                instructions=f"{recipe}\nRead evidence.md and generate exactly one item.",
                schema=ITEM_SCHEMA,
                workspace=meta.SourceTree({"evidence.md": render_case(case)}),
            )
        ),
        ITEM_SCHEMA,
    )
    if generated.failure is not None:
        return (generated,), {"accepted": False, "reasons": [generated.failure.kind]}
    assert generated.value is not None
    question = str(generated.value["question"])
    reference = str(generated.value["reference_answer"])
    restricted = _solver(runner, f"{prefix}.restricted_solver", question, "")
    selected = set(generated.value["evidence_doc_ids"])
    documents = tuple(document for document in case.documents if document.id in selected)
    informed_case = SolverCase(case.id, question, documents, case.metadata)
    informed = _solver(
        runner,
        f"{prefix}.informed_solver",
        question,
        render_case(informed_case),
    )
    checks = quality_checks(generated.value, restricted, informed, set(d.id for d in case.documents))
    return (generated, restricted, informed), {
        "generated_item": dict(generated.value),
        "restricted_answer": restricted.value,
        "informed_answer": informed.value,
        **checks,
    }


def _solver(runner: SessionRunner, label: str, question: str, evidence: str):
    return validate_record(
        runner.run(
            SessionRequest(
                label=label,
                instructions="Answer the question exactly. Use evidence.md if it exists.",
                schema=ANSWER_SCHEMA,
                workspace=meta.SourceTree(
                    {"question.md": question, **({"evidence.md": evidence} if evidence else {})}
                ),
            )
        ),
        ANSWER_SCHEMA,
    )


def quality_checks(item, restricted, informed, available_ids: set[str]):
    reasons: list[str] = []
    reference = str(item["reference_answer"])
    if reference.casefold() in str(item["question"]).casefold():
        reasons.append("reference_answer_leaked_in_question")
    if not set(item["evidence_doc_ids"]) <= available_ids:
        reasons.append("unknown_evidence_document")
    if restricted.failure is not None or informed.failure is not None:
        reasons.append("solver_failure")
    else:
        assert restricted.value is not None and informed.value is not None
        if exact_answer(str(restricted.value["answer"]), reference):
            reasons.append("restricted_solver_already_knows_answer")
        if not exact_answer(str(informed.value["answer"]), reference):
            reasons.append("informed_solver_cannot_recover_answer")
    return {"accepted": not reasons, "reasons": reasons}


def _acceptance_measurement(records, evidence) -> Measurement:
    failure = next((record.failure for record in records if record.failure is not None), None)
    if failure is not None:
        return Measurement(failure=failure, evidence=evidence)
    return Measurement(metrics={"accepted": float(evidence["accepted"])}, evidence=evidence)
