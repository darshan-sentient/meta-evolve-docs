"""Evaluator-only exact-answer grading and failure conversion."""

from __future__ import annotations

import re
import unicodedata

from .models import Measurement, SessionRecord


def normalize_answer(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold().strip()
    return re.sub(r"\s+", " ", normalized)


def exact_answer(prediction: str, expected: str) -> bool:
    return normalize_answer(prediction) == normalize_answer(expected)


def grade_record(record: SessionRecord, expected: str) -> Measurement:
    """Grade without retaining the evaluator-only expected answer as evidence."""

    if record.failure is not None:
        return Measurement(failure=record.failure, evidence={"session": record.label})
    assert record.value is not None
    answer = str(record.value["answer"])
    return Measurement(
        metrics={"exact": float(exact_answer(answer, expected))},
        evidence={"session": record.label, "prediction": answer},
    )
