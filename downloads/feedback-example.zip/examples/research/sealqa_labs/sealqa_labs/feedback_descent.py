"""A five-session Feedback Descent teaching loop over one frozen case."""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve.domain import InvalidOutput, ProposerFailure

from .fixture import evaluator_case, render_case
from .grading import grade_record
from .identity import evaluator_identity
from .models import LabResult, Measurement, SessionRecord
from .session import SessionRequest, SessionRunner
from .structured import ANSWER_SCHEMA, validate_record


SESSION_COUNT = 5
PROMPTS = {
    "candidate_a": meta.Text(
        "Answer the question from the supplied documents. Return only the answer."
    ),
    "candidate_b": meta.Text(
        "Find the document that directly resolves the question, ignore conflicting "
        "distractors, and return only the answer."
    ),
}
COMPARISON_SCHEMA = {
    "type": "object",
    "properties": {
        "preferred_candidate": {
            "type": "string",
            "enum": ["candidate_a", "candidate_b"],
        },
        "textual_feedback": {"type": "string", "minLength": 1},
    },
    "required": ["preferred_candidate", "textual_feedback"],
    "additionalProperties": False,
}
EDIT_SCHEMA = {
    "type": "object",
    "properties": {"prompt": {"type": "string", "minLength": 1}},
    "required": ["prompt"],
    "additionalProperties": False,
}


def _solve(runner: SessionRunner, label: str, prompt: meta.Text, case_text: str):
    return validate_record(
        runner.run(
            SessionRequest(
                label=label,
                instructions=f"{prompt}\nRead case.md and answer it.",
                schema=ANSWER_SCHEMA,
                workspace=meta.SourceTree({"case.md": case_text}),
            )
        ),
        ANSWER_SCHEMA,
    )


def execute(runner: SessionRunner) -> LabResult:
    """Run once; failures are retained and never rerun until improvement appears."""

    case = evaluator_case("feedback_descent_development")
    rendered = render_case(case.public)
    sessions: list[SessionRecord] = []
    initial = {
        name: _solve(runner, f"feedback.{name}", prompt, rendered)
        for name, prompt in PROMPTS.items()
    }
    sessions.extend(initial.values())
    measurements = {
        name: grade_record(record, case.answer) for name, record in initial.items()
    }
    comparison = validate_record(
        runner.run(_comparison_request(case.answer, initial)), COMPARISON_SCHEMA
    )
    sessions.append(comparison)
    if comparison.failure is not None:
        measurements["comparison"] = Measurement(failure=comparison.failure)
        return LabResult("feedback_descent", tuple(sessions), dict(PROMPTS), measurements)
    assert comparison.value is not None
    preferred = str(comparison.value["preferred_candidate"])
    feedback = str(comparison.value["textual_feedback"])
    edit = validate_record(
        runner.run(
            SessionRequest(
                label="feedback.editor",
                instructions=(
                    "Rewrite prompt.md using every applicable point in feedback.md. "
                    "Do not answer the underlying question. Return the rewritten prompt."
                ),
                schema=EDIT_SCHEMA,
                workspace=meta.SourceTree(
                    {"prompt.md": str(PROMPTS[preferred]), "feedback.md": feedback}
                ),
            )
        ),
        EDIT_SCHEMA,
    )
    sessions.append(edit)
    if edit.failure is not None:
        measurements["edit"] = Measurement(failure=edit.failure)
        return LabResult("feedback_descent", tuple(sessions), dict(PROMPTS), measurements)
    assert edit.value is not None
    edited = meta.Text(str(edit.value["prompt"]))
    if not str(edited).strip() or edited == PROMPTS[preferred]:
        failure = ProposerFailure(message="the editor produced no prompt change")
        measurements["edit"] = Measurement(failure=failure)
        return LabResult("feedback_descent", tuple(sessions), dict(PROMPTS), measurements)
    final = _solve(runner, "feedback.edited_evaluation", edited, rendered)
    sessions.append(final)
    measurements["edited"] = grade_record(final, case.answer)
    artifacts = {
        **PROMPTS,
        "edited": edited,
        "preferred": preferred,
        "edit_derived_from": "feedback.comparison",
        "feedback": feedback,
        "evaluator_identity": evaluator_identity(
            case, purpose="feedback.answer", schema=ANSWER_SCHEMA
        ),
    }
    if artifacts["edit_derived_from"] != comparison.label:
        measurements["edited"] = Measurement(
            failure=InvalidOutput(message="edited prompt lacks feedback derivation")
        )
    return LabResult("feedback_descent", tuple(sessions), artifacts, measurements)


def _comparison_request(answer: str, initial: dict[str, SessionRecord]) -> SessionRequest:
    candidates = "\n".join(
        f"{name}: {record.value if record.value is not None else record.failure}"
        for name, record in initial.items()
    )
    return SessionRequest(
        label="feedback.comparison",
        instructions=(
            "Act only as the evaluator. Compare both candidate answers to the hidden "
            "reference in comparison.md. Prefer one and explain a general prompt fix."
        ),
        schema=COMPARISON_SCHEMA,
        workspace=meta.SourceTree(
            {"comparison.md": f"Reference answer: {answer}\n{candidates}\n"}
        ),
    )
