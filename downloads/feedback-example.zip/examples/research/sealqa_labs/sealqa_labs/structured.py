"""Tiny dependency-free validation for lab and injected-runner outputs."""

from __future__ import annotations

from collections.abc import Mapping

from meta_evolve.domain import InvalidOutput

from .models import SessionRecord


ANSWER_SCHEMA = {
    "type": "object",
    "properties": {"answer": {"type": "string", "minLength": 1}},
    "required": ["answer"],
    "additionalProperties": False,
}


def validate_record(record: SessionRecord, schema: Mapping[str, object]) -> SessionRecord:
    """Apply the same closed-world contract to live and injected outputs."""

    if record.failure is not None:
        return record
    assert record.value is not None
    error = schema_error(record.value, schema)
    if error is None:
        return record
    return SessionRecord(
        label=record.label,
        failure=InvalidOutput(
            message="session structured output failed independent validation",
            details={"validation": error},
        ),
        usage=record.usage,
        evidence=record.evidence,
        experience_usage=record.experience_usage,
    )


def schema_error(value: object, schema: Mapping[str, object], path: str = "$") -> str | None:
    expected = schema.get("type")
    if expected == "object":
        if not isinstance(value, Mapping):
            return f"{path} must be an object"
        properties = schema.get("properties", {})
        assert isinstance(properties, Mapping)
        required = schema.get("required", ())
        for name in required:
            if name not in value:
                return f"{path}.{name} is required"
        if schema.get("additionalProperties") is False:
            extra = set(value) - set(properties)
            if extra:
                return f"{path} has unexpected fields {sorted(extra)}"
        for name, child in properties.items():
            if name in value:
                assert isinstance(child, Mapping)
                error = schema_error(value[name], child, f"{path}.{name}")
                if error:
                    return error
        return None
    if expected == "array":
        if not isinstance(value, (list, tuple)):
            return f"{path} must be an array"
        item_schema = schema.get("items", {})
        assert isinstance(item_schema, Mapping)
        for index, item in enumerate(value):
            error = schema_error(item, item_schema, f"{path}[{index}]")
            if error:
                return error
        return None
    if expected == "string":
        if not isinstance(value, str):
            return f"{path} must be a string"
        if len(value) < int(schema.get("minLength", 0)):
            return f"{path} is too short"
    if expected == "integer" and (isinstance(value, bool) or not isinstance(value, int)):
        return f"{path} must be an integer"
    allowed = schema.get("enum")
    if allowed is not None and value not in allowed:
        return f"{path} must be one of {list(allowed)}"
    return None
