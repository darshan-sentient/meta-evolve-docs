"""Load the frozen fixture while enforcing its evaluator/candidate boundary."""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

from .models import EvaluatorCase, PublicDocument, SolverCase


DATA = Path(__file__).parents[1] / "data" / "longseal.jsonl"
SOURCE_REVISION = "0b0787bc5c7c21bcc097a0ef8cd0660df06d6b3e"
DOCUMENT_REVISION = "7c9c07126c7f85d68b755e9dc4d46c45644a7e11"

ROLES = (
    "feedback_descent_development",
    "autodata_grounding",
    "meta_harness_diagnostic",
    "meta_harness_validation",
    "evoskill_induction",
    "evoskill_induction",
    "evoskill_held_out",
    "evoskill_held_out",
)


@lru_cache(maxsize=1)
def evaluator_cases() -> tuple[EvaluatorCase, ...]:
    cases = tuple(_load_line(line) for line in DATA.read_text().splitlines())
    if tuple(case.role for case in cases) != ROLES:
        raise ValueError("SealQA fixture roles drifted")
    return cases


def _load_line(line: str) -> EvaluatorCase:
    raw = json.loads(line)
    if raw["source_revision"] != SOURCE_REVISION:
        raise ValueError("SealQA source revision drifted")
    if raw["document_revision"] != DOCUMENT_REVISION:
        raise ValueError("SealQA document revision drifted")
    documents = tuple(
        PublicDocument(
            id=item["id"],
            title=item["title"],
            date=item["date"],
            text=item["text"],
        )
        for item in raw["documents"]
    )
    public = SolverCase(
        id=raw["id"],
        question=raw["question"],
        documents=documents,
        metadata=raw["public_metadata"],
    )
    informed_documents = tuple(
        document
        for document, item in zip(documents, raw["documents"], strict=True)
        if item["is_gold"]
    )
    return EvaluatorCase(
        public=public,
        informed_documents=informed_documents,
        answer=raw["answer"],
        gold_urls=tuple(raw["gold_urls"]),
        role=raw["role"],
        checksum=raw["checksum"],
        source_revision=raw["source_revision"],
    )


def public_case(role: str, *, occurrence: int = 0) -> SolverCase:
    matches = tuple(case.public for case in evaluator_cases() if case.role == role)
    try:
        return matches[occurrence]
    except IndexError as error:
        raise KeyError(f"no SealQA fixture case for {role!r} occurrence {occurrence}") from error


def evaluator_case(role: str, *, occurrence: int = 0) -> EvaluatorCase:
    matches = tuple(case for case in evaluator_cases() if case.role == role)
    try:
        return matches[occurrence]
    except IndexError as error:
        raise KeyError(f"no SealQA evaluator case for {role!r}") from error


def render_case(case: SolverCase, *, include_documents: bool = True) -> str:
    lines = [f"Question: {case.question}"]
    if include_documents:
        for document in case.documents:
            lines.extend(
                (
                    "",
                    f"## {document.id}: {document.title}",
                    f"Date: {document.date or 'unknown'}",
                    document.text,
                )
            )
    return "\n".join(lines)
