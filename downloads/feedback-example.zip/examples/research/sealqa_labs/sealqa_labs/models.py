"""Immutable records shared by the two labs."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

import meta_evolve as meta
from meta_evolve.domain import Failure


@dataclass(frozen=True, slots=True)
class PublicDocument:
    """A candidate-visible document with source location deliberately removed."""

    id: str
    title: str
    date: str | None
    text: str


@dataclass(frozen=True, slots=True)
class SolverCase:
    """Exactly what a solver may observe."""

    id: str
    question: str
    documents: tuple[PublicDocument, ...]
    metadata: Mapping[str, object]


@dataclass(frozen=True, slots=True)
class EvaluatorCase:
    """The full row, retained only on evaluator-owned paths."""

    public: SolverCase
    informed_documents: tuple[PublicDocument, ...]
    answer: str
    gold_urls: tuple[str, ...]
    role: str
    checksum: str
    source_revision: str


@dataclass(frozen=True, slots=True, kw_only=True)
class SessionRecord:
    """One provider session; failed records never carry structured values."""

    label: str
    value: Mapping[str, object] | None = None
    failure: Failure | None = None
    usage: meta.Usage = meta.Usage()
    evidence: tuple[object, ...] = ()
    experience_usage: object | None = None

    def __post_init__(self) -> None:
        if (self.value is None) == (self.failure is None):
            raise ValueError("a session requires exactly one of value or failure")


@dataclass(frozen=True, slots=True, kw_only=True)
class Measurement:
    """Rankable metrics or a typed failure, never both."""

    metrics: Mapping[str, float] | None = None
    failure: Failure | None = None
    evidence: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if (self.metrics is None) == (self.failure is None):
            raise ValueError("a measurement requires metrics or a failure")


@dataclass(frozen=True, slots=True)
class LabResult:
    name: str
    sessions: tuple[SessionRecord, ...]
    artifacts: Mapping[str, object]
    measurements: Mapping[str, Measurement]

    @property
    def usage(self) -> meta.Usage:
        return sum((record.usage for record in self.sessions), start=meta.Usage())
