"""One live session expressed through a user-owned proposer wrapper."""

from __future__ import annotations

import os
import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from hashlib import sha256
from typing import Protocol

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, InfrastructureFailure
from meta_evolve.ports import EvaluationResult, EvidenceDraft, Proposer

from .config import (
    INNER_BUDGET,
    LIVE_OPT_IN,
    WRAPPER_DECLARATION,
    session_identity_payload,
)
from .models import SessionRecord
from .structured import validate_record


@dataclass(frozen=True, slots=True, kw_only=True)
class SessionRequest:
    label: str
    instructions: str
    schema: Mapping[str, object]
    workspace: meta.SourceTree = meta.SourceTree()
    seed_evidence: tuple[EvidenceDraft, ...] = ()
    experience: meta.PullAccess | None = None


class SessionRunner(Protocol):
    def run(self, request: SessionRequest) -> SessionRecord: ...


AgentFactory = Callable[[SessionRequest], Proposer]


class UserSdkSessionRunner:
    """Run an injected SDK wrapper only after explicit operator opt-in."""

    def __init__(
        self,
        *,
        agent_factory: AgentFactory,
        wrapper_declaration: str = WRAPPER_DECLARATION,
        require_opt_in: bool = True,
    ) -> None:
        if not callable(agent_factory):
            raise TypeError("agent_factory must be callable")
        if not wrapper_declaration.strip():
            raise ValueError("wrapper_declaration must be non-empty")
        self._agent_factory = agent_factory
        self._wrapper_declaration = wrapper_declaration
        self._require_opt_in = require_opt_in

    def run(self, request: SessionRequest) -> SessionRecord:
        if self._require_opt_in and os.getenv(LIVE_OPT_IN) != "1":
            return SessionRecord(
                label=request.label,
                failure=InfrastructureFailure(
                    message=f"set {LIVE_OPT_IN}=1 to permit this paid live session",
                    details={"wrapper": self._wrapper_declaration},
                ),
            )
        try:
            experiment = meta.Experiment(
                task=meta.Task(
                    evaluator=_session_evaluator(request),
                    artifact=meta.SourceTree,
                    objectives=(meta.Maximize("completed"),),
                    budget=INNER_BUDGET,
                ),
                seed=request.workspace,
                proposer=self._agent_factory(request),
                search=meta.Greedy(max_trials=1),
                experience=request.experience,
            )
            result = meta.run(experiment)
        except meta.CapabilityError as error:
            return SessionRecord(
                label=request.label,
                failure=InfrastructureFailure(
                    message="user SDK session failed preflight",
                    details={"exception_type": type(error).__name__, "reason": str(error)},
                ),
            )
        attempt = result.trials()[-1]
        if attempt.failure is not None:
            return SessionRecord(
                label=request.label,
                failure=attempt.failure,
                usage=attempt.usage,
                evidence=attempt.evidence,
                experience_usage=result.experience_usage(),
            )
        structured = next(
            (
                item.data["value"]
                for item in attempt.evidence
                if item.kind == "sdk.structured-output"
            ),
            None,
        )
        if not isinstance(structured, Mapping):
            return SessionRecord(
                label=request.label,
                failure=InfrastructureFailure(
                    message="successful SDK session retained no structured output"
                ),
                usage=attempt.usage,
                evidence=attempt.evidence,
                experience_usage=result.experience_usage(),
            )
        record = SessionRecord(
            label=request.label,
            value=dict(structured),
            usage=attempt.usage,
            evidence=attempt.evidence,
            experience_usage=result.experience_usage(),
        )
        return validate_record(record, request.schema)

def _session_evaluator(request: SessionRequest):
    def evaluate(_: meta.SourceTree) -> EvaluationResult:
        return EvaluationResult(
            metrics={"completed": 1.0},
            evidence=request.seed_evidence,
        )

    payload = session_identity_payload(purpose=request.label, schema=request.schema)
    payload["seed_evidence_kinds"] = tuple(item.kind for item in request.seed_evidence)
    payload["experience"] = None if request.experience is None else {
        "max_operations": request.experience.max_operations,
        "max_results": request.experience.max_results,
        "max_records": request.experience.max_records,
        "max_chars": request.experience.max_chars,
    }
    payload["instructions_sha256"] = sha256(request.instructions.encode()).hexdigest()
    payload["workspace_sha256"] = sha256(
        json.dumps(dict(request.workspace.to_payload()), sort_keys=True).encode()
    ).hexdigest()
    payload["seed_evidence_sha256"] = sha256(
        repr(request.seed_evidence).encode()
    ).hexdigest()
    version = sha256(
        json.dumps(payload, sort_keys=True, default=repr).encode()
    ).hexdigest()
    evaluate.component = ComponentRef.configured_local(
        "evaluator",
        evaluate,
        name="sealqa-labs:session-evaluator",
        version=f"1+{version}",
    )
    return evaluate
