"""Build the committed eight-row fixture from locally downloaded upstream files."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROW_REVISION = "0b0787bc5c7c21bcc097a0ef8cd0660df06d6b3e"
DOCUMENT_REVISION = "7c9c07126c7f85d68b755e9dc4d46c45644a7e11"
ROLES = (
    "feedback_descent_development",
    "autodata_grounding",
    "meta_harness_diagnostic",
    "meta_harness_validation",
    "evoskill_induction",
    "evoskill_induction",
    "evoskill_held_out",
    "evoskill_held_out",
)
PUBLIC_METADATA = (
    "freshness",
    "question_types",
    "effective_year",
    "search_results",
    "topic",
)


def digest(value: object) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def load_documents(path: Path, required: set[str]) -> dict[str, dict[str, object]]:
    found: dict[str, dict[str, object]] = {}
    with path.open() as source:
        for line in source:
            item = json.loads(line)
            if item["pid"] in required:
                found[item["pid"]] = item
    if found.keys() != required:
        raise ValueError(f"missing document ids: {sorted(required - found.keys())}")
    return found


def build(rows_path: Path, documents_path: Path) -> list[dict[str, object]]:
    lines = rows_path.read_text().splitlines()
    rows = [json.loads(line) for line in lines[: len(ROLES)]]
    required = {
        pid
        for row in rows
        for key in ("golds", "12_docs")
        for pid in row[key]
    }
    documents = load_documents(documents_path, required)
    return [build_row(index, row, documents) for index, row in enumerate(rows)]


def build_row(
    index: int, row: dict[str, object], documents: dict[str, dict[str, object]]
) -> dict[str, object]:
    golds = list(row["golds"])
    ordered = list(row["12_docs"])
    for offset, pid in enumerate(golds):
        if pid not in ordered:
            ordered.insert((index * 5 + 3 + offset) % (len(ordered) + 1), pid)
    public_documents = []
    for position, pid in enumerate(ordered, start=1):
        source = documents[pid]
        public_documents.append(
            {
                "id": f"doc-{position:02d}",
                "source_pid": pid,
                "source_url": source["url"],
                "title": source["title"],
                "date": source["date"],
                "text": source["text"],
                "is_gold": pid in golds,
            }
        )
    frozen = {
        "id": f"longseal-{index:03d}",
        "source_index": index,
        "source_revision": ROW_REVISION,
        "document_revision": DOCUMENT_REVISION,
        "question": row["question"],
        "answer": row["answer"],
        "gold_urls": row["urls"],
        "role": ROLES[index],
        "public_metadata": {name: row[name] for name in PUBLIC_METADATA},
        "source_document_ids": {
            name: row[name] for name in ("golds", "12_docs", "20_docs", "30_docs")
        },
        "documents": public_documents,
    }
    frozen["checksum"] = digest(frozen)
    return frozen


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("rows", type=Path)
    parser.add_argument("documents", type=Path)
    parser.add_argument("output", type=Path)
    arguments = parser.parse_args()
    rows = build(arguments.rows, arguments.documents)
    text = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    arguments.output.write_text(text)
    print(hashlib.sha256(text.encode()).hexdigest())


if __name__ == "__main__":
    main()
