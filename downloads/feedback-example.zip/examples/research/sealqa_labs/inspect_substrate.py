"""Inspect the deterministic SealQA lab boundary without calling a provider."""

from sealqa_labs import (
    INNER_BUDGET,
    MAX_TURNS,
    SESSION_COUNTS,
    TIMEOUT_SECONDS,
    TOTAL_SESSIONS,
    public_case,
)


case = public_case("feedback_descent_development")
print("sessions:", SESSION_COUNTS)
print("total sessions:", TOTAL_SESSIONS)
print(
    "inner bounds:",
    f"turns={MAX_TURNS}",
    f"timeout={TIMEOUT_SECONDS:g}",
    f"wall={INNER_BUDGET.wall_seconds:g}",
)
print("solver fields:", tuple(case.__dataclass_fields__))
print("hidden answer visible:", hasattr(case, "answer"))
