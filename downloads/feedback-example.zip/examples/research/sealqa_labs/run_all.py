"""Routing helpers for bring-your-own-wrapper live labs."""

from __future__ import annotations

import argparse

from sealqa_labs import SessionRunner
from sealqa_labs import autodata, feedback_descent
from sealqa_labs.config import SESSION_COUNTS


LABS = {
    "feedback_descent": feedback_descent.execute,
    "autodata": autodata.execute,
}


def run_selected(runner: SessionRunner, lab: str = "all") -> None:
    selected = LABS if lab == "all" else {lab: LABS[lab]}
    for name, execute in selected.items():
        result = execute(runner)
        print(f"{name}: {len(result.sessions)}/{SESSION_COUNTS[name]} sessions")
        print(f"  usage: {result.usage}")
        for label, measurement in result.measurements.items():
            outcome = measurement.metrics or {
                "failure": measurement.failure.kind if measurement.failure else "unknown"
            }
            print(f"  {label}: {outcome}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("lab", choices=("all", *LABS), default="all", nargs="?")
    parser.parse_args()
    raise SystemExit(
        "bring your own SDK wrapper: import run_selected and pass a SessionRunner"
    )


if __name__ == "__main__":
    main()
