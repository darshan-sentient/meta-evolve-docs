# Bring-your-own-wrapper SealQA research labs

**Status: Experimental/live-only.** Two teaching labs demonstrate mechanisms
inspired by Feedback Descent and AutoData. They are not paper reproductions or
official SealQA evaluations.

| Notebook | Artifact changed | Maximum sessions |
|---|---|---:|
| `01_feedback_descent.ipynb` | `meta.Text` prompt | 5 |
| `02_autodata.ipynb` | `meta.Text` generation recipe | 7 |
| **Complete curriculum** | | **12** |

Skill induction used to be a lab here. It now lives in
[`examples/research/context_evolution`](../context_evolution/) as a
deterministic example that needs no wrapper, no credentials, and no opt-in.

The repository supplies orchestration and a `SessionRunner` protocol, not an
SDK client. Implement `build_agent(request)` in your own opt-in driver and pass
it to `UserSdkSessionRunner`. The wrapper owns authentication, structured
decoding, tools, permissions, and its own provider limits. It must either honor
the declared inner wall budget or refuse before execution.

There is no official provider capture pending. You may perform one authorized
run with your own wrapper. Any published capture must identify the wrapper
declaration, be sanitized, and preserve ties, regressions, typed failures,
unused experience, and null results honestly. Do not rerun until an improvement
appears.

The notebooks are intentionally unexecuted and illustrative: no fabricated live output is included. CI drives the same orchestration with injected
deterministic runners.

`data/` contains the attributed fixture corpus described by its `NOTICE.md`,
`LICENSE`, and checksums. Evaluator-only answers and labels remain outside
solver views.
