"""Example-owned Responses integration with optional user-owned cost reporting."""

from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_CEILING, localcontext
from importlib.metadata import version
import os
import time
from typing import Callable, Literal

import meta_evolve as meta
from meta_evolve.domain import InvalidOutput
from meta_evolve.errors import ExecutionAccountingUnknown

DEFAULT_MODEL = "gpt-5.4-mini-2026-03-17"


# --8<-- [start:cost-report]
@dataclass(frozen=True)
class CostReport:
    usd: Decimal
    kind: Literal["estimated", "billed"]
    source: str

    def __post_init__(self):
        if not isinstance(self.usd, Decimal) or not self.usd.is_finite() or self.usd < 0:
            raise ValueError("usd must be a finite nonnegative Decimal")
        if self.kind not in ("estimated", "billed") or not isinstance(self.source, str) or not self.source.strip():
            raise ValueError("report an estimated or billed amount with its source")

    @property
    def micros(self):
        with localcontext() as context:
            context.prec = max(28, len(self.usd.as_tuple().digits) + 6)
            return int((self.usd * 1_000_000).to_integral_value(rounding=ROUND_CEILING))
# --8<-- [end:cost-report]


CostReporter = Callable[[object], CostReport | None]


def configuration():
    return {
        "model": os.environ.get("OPENAI_MODEL", DEFAULT_MODEL),
        "endpoint": "https://api.openai.com/v1", "api": "responses",
        "timeout_seconds": 120, "max_retries": 0,
        "max_output_tokens": 4096, "reasoning_effort": "none",
        "store": False, "wrapper_revision": "2", "cost_reporter_id": None,
    }


def decode_response(response, *, elapsed, cost_reporter: CostReporter | None = None):
    """Keep provider tokens, optional billed spend, and labeled cost evidence.

    Run the callback once, including for incomplete responses. A failed cost
    lookup leaves spend unknown and records its error without losing the model
    result. Missing token accounting still raises rather than fabricating zero.
    """
    evidence = []
    spend = None
    if cost_reporter is not None:
        try:
            report = cost_reporter(response)
            if report is not None:
                if not isinstance(report, CostReport):
                    raise TypeError("cost_reporter must return CostReport or None")
                evidence.append(meta.EvidenceDraft(kind="cost-report", data={
                    "usd": str(report.usd), "micros": report.micros,
                    "kind": report.kind, "source": report.source,
                }))
                if report.kind == "billed":
                    spend = report.micros
        except Exception as error:
            evidence.append(meta.EvidenceDraft(kind="cost-reporting-failure", data={
                "exception_type": type(error).__name__,
                "message": "Cost reporter failed; billed spend remains unknown.",
            }))
    usage = getattr(response, "usage", None)
    input_tokens = getattr(usage, "input_tokens", None)
    output_tokens = getattr(usage, "output_tokens", None)
    if any(type(value) is not int or value < 0 for value in (input_tokens, output_tokens)):
        error = ExecutionAccountingUnknown("Response lacks required token accounting.")
        error.receipt = {
            "response_id": getattr(response, "id", None),
            "input_tokens": input_tokens, "output_tokens": output_tokens,
            "charged_micros": spend, "wall_seconds": elapsed,
            "cost_evidence": [dict(item.data) for item in evidence],
        }
        raise error
    measured = meta.Usage(
        tokens=input_tokens + output_tokens, spend_micros=spend, wall_seconds=elapsed,
    )
    text = getattr(response, "output_text", None)
    evidence.append(meta.EvidenceDraft(kind="openai-response", data={
        "response_id": response.id, "model": response.model,
        "status": response.status, "output_text": text,
        "input_tokens": input_tokens, "output_tokens": output_tokens,
        "charged_micros": spend,
    }))
    if response.status != "completed" or not isinstance(text, str) or not text.strip():
        return meta.ProposalResult(
            failure=InvalidOutput(message="model returned empty or incomplete text"),
            usage=measured, evidence=tuple(evidence),
        )
    return meta.ProposalResult(candidate=text, usage=measured, evidence=tuple(evidence))


@dataclass
class OpenAIClient:
    """The lesson knows generate() and configuration; SDK types stay here."""

    sdk: object
    configuration: dict
    cost_reporter: CostReporter | None = None

    def __post_init__(self):
        reporter_id = self.configuration.get("cost_reporter_id")
        if self.cost_reporter is not None and (
            not callable(self.cost_reporter) or not isinstance(reporter_id, str) or not reporter_id.strip()
        ):
            raise ValueError("a callable cost reporter needs a recorded cost_reporter_id")

    @classmethod
    def from_environment(cls, *, cost_reporter=None, cost_reporter_id=None):
        if not os.environ.get("OPENAI_API_KEY", "").strip():
            raise meta.CapabilityError("Set OPENAI_API_KEY before requesting a live run.")
        if cost_reporter is not None and (
            not callable(cost_reporter) or not isinstance(cost_reporter_id, str) or not cost_reporter_id.strip()
        ):
            raise ValueError("supply a callable cost_reporter and its cost_reporter_id")
        try:
            from openai import OpenAI
        except ImportError as error:
            raise meta.CapabilityError("Install the SDK: python -m pip install openai") from error
        settings = configuration() | {
            "sdk_version": version("openai"), "cost_reporter_id": cost_reporter_id,
        }
        sdk = OpenAI(api_key=os.environ["OPENAI_API_KEY"], base_url=settings["endpoint"],
                     timeout=settings["timeout_seconds"], max_retries=settings["max_retries"])
        return cls(sdk, settings, cost_reporter)

    def generate(self, *, instructions, input):
        settings = self.configuration
        started = time.monotonic()
        try:
            response = self.sdk.with_options(
                timeout=settings["timeout_seconds"], max_retries=settings["max_retries"],
            ).responses.create(
                model=settings["model"], instructions=instructions, input=input,
                max_output_tokens=settings["max_output_tokens"],
                reasoning={"effort": settings["reasoning_effort"]}, store=settings["store"],
            )
        except ExecutionAccountingUnknown:
            raise
        except Exception as cause:
            raise ExecutionAccountingUnknown(
                "Request failed after dispatch; token accounting is unavailable."
            ) from cause
        try:
            result = decode_response(response, elapsed=0, cost_reporter=self.cost_reporter)
        except ExecutionAccountingUnknown as error:
            error.receipt["wall_seconds"] = time.monotonic() - started
            raise
        # Include a cost lookup's elapsed time in the component's usage too.
        return replace(result, usage=replace(result.usage, wall_seconds=time.monotonic() - started))

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.sdk.close()
