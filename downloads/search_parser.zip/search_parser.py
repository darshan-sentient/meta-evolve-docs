"""Compare parent selection with equal declared attempt limits. Makes model calls."""

import argparse
from dataclasses import replace
from pathlib import Path

import meta_evolve as meta
from openai_client import OpenAIClient
from parser import experiment, run_lesson


# --8<-- [start:declarations]
def declarations(client, attempts=3):
    base = experiment(client, trials=attempts)
    return (
        ("greedy", base),
        ("best-of-n", replace(base, search=meta.BestOfN(max_trials=attempts))),
    )
# --8<-- [end:declarations]


def compare(client, directory, attempts=3):
    for name, declaration in declarations(client, attempts):
        print("Search:", name)
        run_lesson(client, Path(directory) / name, declaration=declaration)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("directory", type=Path, help="new directory for both histories")
    args = cli.parse_args()
    with OpenAIClient.from_environment() as client:
        compare(client, args.directory)
