"""Hand-curated duration examples; None means the required ValueError."""

# --8<-- [start:contract]
CONTRACT = """Implement parse_seconds(text: str) -> int.
1. Accept only nonnegative ASCII integer quantities (0-9).
2. Units: s/sec/secs/second/seconds, m/min/mins/minute/minutes,
   h/hr/hrs/hour/hours; return the total in seconds.
3. Accept one or more quantity-unit pairs, case-insensitive, with optional
   whitespace before, between, or after tokens; repeated units add together.
4. Raise ValueError for everything else: empty input, decimals, signs,
   colon notation, unsupported units, missing quantities/units, or junk.
"""
# --8<-- [end:contract]

DEVELOPMENT = (
    ("1s", 1), ("2sec", 2), ("3secs", 3),
    ("4second", 4), ("5seconds", 5),
    ("1m", 60), ("2min", 120), ("3mins", 180),
    ("4minute", 240), ("5minutes", 300),
    ("1h", 3600), ("2hr", 7200), ("3hrs", 10800),
    ("4hour", 14400), ("5hours", 18000),
    ("1h30m", 5400), ("2 min 15 sec", 135),
    ("1h 2m 3s", 3723), ("1m2m", 180),
    (" 2 H ", 7200), ("3MiN", 180), ("\t4 seconds\n", 4),
    ("1 h\t5 M", 3900), ("01s", 1),
    ("0s", 0), ("0 minutes", 0), ("0h0m0s", 0),
    ("", None), ("   ", None), ("1.5h", None),
    ("-1m", None), ("+2s", None), ("1:30", None),
    ("2d", None), ("10", None), ("s", None),
    ("1ms", None), ("1h junk", None), ("1h,2m", None),
    ("1 2s", None),
)

# Only the parent driver imports these after search has selected a candidate.
FINAL = (
    ("7SECONDS", 7), ("12 MINUTES", 720), ("2 HOURS", 7200),
    ("2hrs3mins4secs", 7384), (" 0 HR 8 sec ", 8),
    ("3m 1h", 3780), ("2h1h", 10800), ("000m", 0),
    (".5s", None), ("1h -2m", None), ("1week", None),
    ("1m2", None),
)
