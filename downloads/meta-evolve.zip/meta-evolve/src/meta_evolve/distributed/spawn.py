"""`WorkerProcesses`: the children a dispatcher starts for its own run (D5).

Everything here happens BEFORE the epoch rolls over (PD2). Every child is
spawned and admitted inside `open()`, so a handshake that fails leaves a
genesis-only run that resumes with its epoch unchanged (T13) -- and a run that
reaches its rollover has the workers it asked for.

**Each child is its own session.** `start_new_session` keeps a terminal's
Ctrl-C, which goes to the foreground process group, from reaching them: one
interrupt would otherwise stop the dispatcher AND every child, and their
goodbyes would race the abort. It also makes `killpg` exact, since each child
is its own group leader.

**stdin is the death pipe.** The parent holds the write end for the child's
whole life, so a dispatcher that is SIGKILLed -- running no cleanup code at
all -- still closes it, and the child's watchdog kills its own group. That is
what makes "no child outlives its dispatcher" true of a kill, not only of an
orderly shutdown.

No respawn: replacing workers is administration, and it is M11.4's (#203).
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from meta_evolve.application.dispatch_admission import HostTerms, Joining
from meta_evolve.application.dispatcher import wall_clock
from meta_evolve.domain.workers import WorkerId
from meta_evolve.errors import CapabilityError
from meta_evolve.experiment_modules import refuse_main_hints

from .admission import HostAdmission, sealed_terms
from .frames import DEFAULT_MAX_FRAME_BYTES
from .handshake_envelope import HANDSHAKE_DEADLINE_SECONDS
from .keys import mint_key
from .listener import PendingHandshakes, bind_listener

#: How long a child may take to exit at each stage of cleanup.
GRACE_SECONDS = 2.0

#: The most a bootstrap line may be. It carries a key, an id, a module
#: reference and an address, and nothing that grows with the run.
BOOTSTRAP_LIMIT = 4096


class WorkerProcesses:
    """`Session.drive(execution=WorkerProcesses(count, module))`."""

    def __init__(
        self,
        count: int,
        module: str,
        *,
        max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
    ) -> None:
        if isinstance(count, bool) or not isinstance(count, int) or count < 1:
            raise ValueError("a distributed run needs at least one worker process")
        self._count = count
        self._module = str(module)
        self._max_frame_bytes = max_frame_bytes

    def open(self, terms: HostTerms) -> "SpawnedWorkers":
        """Spawn `count` children and admit them all, or clean up and refuse."""

        if not hasattr(os, "killpg"):
            raise CapabilityError(
                "worker processes need POSIX process groups, which this "
                "platform does not have"
            )
        # A child imports the module by reference, and no reference reaches
        # what a parent defined in its own `__main__`.
        refuse_main_hints(terms.manifests)
        module = self._module
        if module.endswith(".py"):
            module = str(Path(module).resolve())
        key = mint_key()
        listener = bind_listener(("127.0.0.1", 0))
        slots = tuple(
            WorkerId.for_slot(terms.run_id, slot).value for slot in range(self._count)
        )
        admission = HostAdmission(
            run_id=terms.run_id,
            started=terms.started,
            context=terms.context,
            manifests=terms.manifests,
            fingerprint=terms.fingerprint,
            key=key,
            heartbeat_seconds=terms.heartbeat_seconds,
            max_frame_bytes=self._max_frame_bytes,
            minted=slots,
        )
        sealed_terms(admission, host_nonce="0" * 8, worker_nonce="0" * 8)
        workers = SpawnedWorkers(listener, admission)
        try:
            host, port = listener.getsockname()
            for slot, worker_id in enumerate(slots):
                workers.spawn(
                    {
                        "key": key.hex(),
                        "worker_id": worker_id,
                        "module": module,
                        "address": f"{host}:{port}",
                        "parent_pid": os.getpid(),
                    },
                    slot=slot,
                )
            workers.admit_all(self._count)
        except BaseException:
            # Nothing this raise leaves behind is anyone else's to clean up:
            # the caller has no handle on these children yet.
            workers.finish(completed=False)
            raise
        return workers


class SpawnedWorkers:
    """The children of one run, as the dispatcher's `Workers`."""

    def __init__(self, listener, admission: HostAdmission) -> None:
        self._listener = listener
        self._admission = admission
        self._pending = PendingHandshakes(listener, admission)
        self._children: list[subprocess.Popen] = []
        self.endpoints: tuple = ()

    # -- starting ------------------------------------------------------------

    def spawn(self, bootstrap: dict, *, slot: int) -> None:
        line = json.dumps(bootstrap, separators=(",", ":")) + "\n"
        if len(line) > BOOTSTRAP_LIMIT:
            raise CapabilityError(
                f"a worker's bootstrap is {len(line)} bytes, over the "
                f"{BOOTSTRAP_LIMIT}-byte bound: name the experiment module by "
                "a shorter reference"
            )
        child = subprocess.Popen(
            [sys.executable, "-m", "meta_evolve.distributed.worker_process"],
            stdin=subprocess.PIPE,
            close_fds=True,
            start_new_session=True,
        )
        self._children.append(child)
        assert child.stdin is not None
        try:
            child.stdin.write(line.encode("utf-8"))
            child.stdin.flush()
        except OSError:
            raise CapabilityError(
                f"worker slot {slot} exited before it could be started"
            ) from None

    def admit_all(self, count: int) -> None:
        """Wait for every child's handshake, or refuse naming what happened."""

        deadline = time.monotonic() + HANDSHAKE_DEADLINE_SECONDS
        joined: list[Joining] = []
        while len(joined) < count:
            joined.extend(
                self._pending.joined(
                    wall_clock, max_frame_bytes=self._admission.max_frame_bytes
                )
            )
            if self._pending.refusals:
                raise CapabilityError(
                    "a worker process was refused at admission: "
                    f"{self._pending.refusals[0].reason}"
                )
            dead = [child for child in self._children if child.poll() is not None]
            if dead and len(joined) < count:
                raise CapabilityError(
                    f"a worker process exited before it was admitted (status "
                    f"{dead[0].returncode}); nothing has been claimed"
                )
            if time.monotonic() > deadline:
                raise CapabilityError(
                    f"only {len(joined)} of {count} worker processes were "
                    f"admitted within {HANDSHAKE_DEADLINE_SECONDS:.0f} seconds"
                )
            time.sleep(0.005)
        self.endpoints = tuple(item.endpoint for item in joined)
        # No respawn, so nothing else can arrive on this port.
        self._listener.close()

    # -- the dispatcher's view ----------------------------------------------

    def admit(self) -> tuple[Joining, ...]:
        return ()

    def may_admit(self) -> bool:
        """False: every child was admitted before the rollover, and a dead one
        is not replaced, so an empty endpoint set means the run is stuck."""

        return False

    def finish(self, *, completed: bool) -> None:
        """Farewell, grace, SIGTERM, then the death pipe and a group kill.

        The order matters at both ends. A `Goodbye` only when the run really
        finished (PD6). `SIGTERM` to the child's PID, not its group, so its
        own handler runs and a component's cleanup -- a sandbox killing the
        commands it started -- gets its chance. stdin closes LAST, because
        closing it trips the watchdog, which is a SIGKILL of the whole group
        and would pre-empt every gentler step above it.
        """

        failures: list[BaseException] = []
        for endpoint in self.endpoints:
            try:
                endpoint.farewell("the run finished") if completed else endpoint.close()
            except BaseException as error:  # noqa: BLE001 - reported below
                failures.append(error)
        self._pending.close()
        _close(self._listener, failures)
        self._wait(GRACE_SECONDS)
        for child in self._children:
            if child.poll() is None:
                _signal_process(child.pid, signal.SIGTERM, failures)
        self._wait(GRACE_SECONDS)
        for child in self._children:
            if child.stdin is not None:
                _close(child.stdin, failures)
            if child.poll() is None:
                # Its group, so a component's children go too; safe because a
                # pid that has not been reaped cannot be reused.
                _signal_group(child.pid, signal.SIGKILL, failures)
        for child in self._children:
            try:
                child.wait(timeout=GRACE_SECONDS)
            except BaseException as error:  # noqa: BLE001 - reported below
                failures.append(error)
        self._children.clear()
        self.endpoints = ()
        if failures:
            first = failures[0]
            for other in failures[1:]:
                first.add_note(f"cleaning up also failed: {other!r}")
            raise first

    def _wait(self, seconds: float) -> None:
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if all(child.poll() is not None for child in self._children):
                return
            time.sleep(0.01)


def _signal_process(pid: int, number: int, failures: list) -> None:
    """The child itself, so its own handler runs."""

    _delivered(lambda: os.kill(pid, number), failures)


def _signal_group(pid: int, number: int, failures: list) -> None:
    """The child's whole group, so what its component started goes too."""

    _delivered(lambda: os.killpg(pid, number), failures)


def _delivered(send, failures: list) -> None:
    try:
        send()
    except ProcessLookupError:
        pass  # it exited between the poll and the signal
    except OSError as error:
        failures.append(error)


def _close(closeable, failures: list) -> None:
    try:
        closeable.close()
    except BaseException as error:  # noqa: BLE001 - reported by the caller
        failures.append(error)


__all__ = ["GRACE_SECONDS", "SpawnedWorkers", "WorkerProcesses"]
