"""`WorkerHost`: the port an operator's workers connect to (D5).

The half of `Execution` that never spawns anything. An operator starts
`meta-evolve worker` wherever they have capacity, pointing it at this address
and this key file; the run itself neither knows nor cares how many there are.

**It stays open.** `may_admit()` is true while it listens, and that is what
tells a drive to WAIT when nothing is connected instead of refusing: a run
whose workers have not arrived yet is not a run that failed. A dispatcher
restart is the same picture from the other side -- the resumed host rebinds
its address while the old connections are still in TIME_WAIT, and the worker
holding an unacknowledged result reconnects and is answered `Duplicate` or
`Stale` (PD1, T7).

Multi-host use is documented and untested: the key authenticates a connection
and encrypts nothing, so a non-loopback address needs TLS this does not
provide.
"""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

from meta_evolve.application.dispatch_admission import HostTerms, Joining
from meta_evolve.application.dispatcher import wall_clock

from .admission import HostAdmission, sealed_terms
from .frames import DEFAULT_MAX_FRAME_BYTES
from .keys import key_file
from .listener import PendingHandshakes, bind_listener, parse_address
from .wire import WireEndpoint


class _LiveWorkers(Mapping):
    """Which worker ids have a connection that is still LIVE, and whose.

    Read by the handshake at every `Hello` (PD7), so it has to be a VIEW: an
    id whose connection the loop failed a moment ago is free again, and a
    snapshot taken at admission time would keep refusing its owner's restart.

    Live means heard from, not merely open. A worker that was killed outright
    leaves a socket the dispatcher has not yet judged silent, and refusing its
    replacement -- terminally, so it exits -- would mean an operator could not
    restart a worker until the loop noticed. The window is the loop's own
    silence threshold, so this agrees with what the loop is about to do.
    """

    def __init__(
        self,
        admitted: dict[str, tuple[WireEndpoint, str]],
        *,
        silence_seconds: int,
        clock,
    ) -> None:
        self._admitted = admitted
        self._silence = silence_seconds
        self._clock = clock

    def __getitem__(self, worker_id: str) -> str:
        endpoint, incarnation = self._admitted[worker_id]
        if not endpoint.alive(self._clock, self._silence):
            raise KeyError(worker_id)
        return incarnation

    def __iter__(self):
        return (
            worker_id
            for worker_id, (endpoint, _) in self._admitted.items()
            if endpoint.alive(self._clock, self._silence)
        )

    def __len__(self) -> int:
        return sum(1 for _ in iter(self))


class WorkerHost:
    """`Session.drive(execution=WorkerHost(address, key_file))`."""

    def __init__(
        self,
        address: str,
        key_file: str | Path,
        *,
        max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
        clock=wall_clock,
    ) -> None:
        self._address = parse_address(address)
        self._key_file = Path(key_file)
        self._max_frame_bytes = max_frame_bytes
        self._clock = clock

    def open(self, terms: HostTerms) -> "ListeningWorkers":
        """Bind, read or write the key, and check the run fits a frame.

        Admits nobody: an operator's workers arrive on their own schedule, and
        the rollover does not wait for them.
        """

        key = key_file(self._key_file)
        listener = bind_listener(self._address)
        admitted: dict[str, tuple[WireEndpoint, str]] = {}
        admission = HostAdmission(
            run_id=terms.run_id,
            started=terms.started,
            context=terms.context,
            manifests=terms.manifests,
            fingerprint=terms.fingerprint,
            key=key,
            heartbeat_seconds=terms.heartbeat_seconds,
            max_frame_bytes=self._max_frame_bytes,
            # Three heartbeat intervals, which is what the dispatch loop
            # itself waits before it judges a connection silent (D10 rule 2).
            live=_LiveWorkers(
                admitted,
                silence_seconds=3 * terms.heartbeat_seconds,
                clock=self._clock,
            ),
        )
        # Sized once, here, rather than one handshake at a time: a recorded
        # start too large for a frame would refuse every worker identically.
        sealed_terms(admission, host_nonce="0" * 8, worker_nonce="0" * 8)
        return ListeningWorkers(listener, admission, admitted, clock=self._clock)


class ListeningWorkers:
    """One open port, as the dispatcher's `Workers`."""

    endpoints: tuple = ()

    def __init__(
        self, listener, admission: HostAdmission, admitted: dict, *, clock=wall_clock
    ) -> None:
        self._clock = clock
        self._listener = listener
        self._admission = admission
        self._admitted = admitted
        self._pending = PendingHandshakes(listener, admission)
        self._open = True

    @property
    def address(self) -> tuple[str, int]:
        return self._listener.getsockname()

    def admit(self) -> tuple[Joining, ...]:
        if not self._open:
            return ()
        joined = self._pending.joined(
            self._clock, max_frame_bytes=self._admission.max_frame_bytes
        )
        for joining in joined:
            self._admitted[joining.endpoint.registrations[0].worker.value] = (
                joining.endpoint,
                joining.incarnation,
            )
        return joined

    def may_admit(self) -> bool:
        return self._open

    def finish(self, *, completed: bool) -> None:
        """Say goodbye if the run finished, then close the port.

        Only on a NORMAL end: an abort closes without a word, so an external
        worker reconnects and resends what it holds rather than exiting on a
        farewell the run did not mean (PD6).
        """

        self._open = False
        for endpoint, _incarnation in self._admitted.values():
            if completed:
                endpoint.farewell("the run finished")
            else:
                endpoint.close()
        self._pending.close()
        self._listener.close()


__all__ = ["ListeningWorkers", "WorkerHost"]
