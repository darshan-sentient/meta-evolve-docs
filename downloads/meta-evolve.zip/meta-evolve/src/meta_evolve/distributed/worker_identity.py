"""Who may connect under which worker id (design PD7, D3).

Three rules, in one place because they answer one question and each one is a
refusal an operator has to read:

- **the grammar**, so an id cannot smuggle anything into a message or a log;
- **the namespace**: a dispatcher mints `worker-` ids for the children it
  spawns, so an operator's worker may not name itself one, and a spawned-worker
  host admits only the ids it minted, each exactly once;
- **the incarnation**: a worker process draws one random value for its
  lifetime, so a reconnect of the SAME process (which supersedes its old
  connection) is told apart from a SECOND process using one id -- which is
  refused, because two live workers sharing an id would take the slot from
  each other forever, spending an attempt every time.
"""

from __future__ import annotations

from collections.abc import Mapping

from .handshake_envelope import RESERVED_PREFIX


def refuse_identity(hello: Mapping[str, object], admission) -> str | None:
    """The id rules, in one place (design PD7)."""

    worker_id = hello.get("worker_id")
    incarnation = hello.get("incarnation")
    if not isinstance(worker_id, str) or not _valid_id(worker_id):
        return "this worker's id is not 1-128 printable ASCII characters"
    if not isinstance(incarnation, str) or not incarnation:
        return "this worker declared no incarnation"
    reserved = next(
        (
            owner
            for claimed_id, owner in admission.reservations.values()
            if claimed_id == worker_id
        ),
        None,
    )
    minted = admission.minted
    if minted is None:
        if worker_id.startswith(RESERVED_PREFIX):
            return (
                f"{RESERVED_PREFIX!r} is reserved for the ids a dispatcher "
                "mints for the workers it spawns"
            )
    elif worker_id not in minted:
        return f"this host expects one of the worker ids it minted, not {worker_id!r}"
    elif worker_id in admission.admitted_ids or reserved is not None:
        return f"the worker id {worker_id!r} was already admitted"
    live = admission.live.get(worker_id)
    if (live is not None and live != incarnation) or (
        reserved is not None and reserved != incarnation
    ):
        return (
            f"the worker id {worker_id!r} is in use by another live process: "
            "two workers sharing one id would take the slot from each other"
        )
    return None


def _valid_id(value: str) -> bool:
    return 1 <= len(value) <= 128 and all(
        character.isascii() and (character.isalnum() or character in "._:-")
        for character in value
    )


__all__ = ["refuse_identity"]
