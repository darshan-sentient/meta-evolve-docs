"""What a host admits against, and the terms it seals for one connection.

The records, apart from the state machine that uses them (`handshake.py`), so
that the host, the spawner and their laws can name what is being admitted
without importing the exchange.

`sealed_terms` belongs here rather than beside the exchange for one reason:
its size check is a property of the RUN, not of a connection. A recorded start
too large for a frame would refuse every worker identically, so the host
learns it once -- before it spawns or listens -- instead of one handshake at a
time.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import RunId
from meta_evolve.domain.components import ComponentManifest
from meta_evolve.domain.context import ContextSpec
from meta_evolve.domain.events import RunStarted
from meta_evolve.domain.work import Lease
from meta_evolve.domain.workers import WorkerRegistration
from meta_evolve.errors import CapabilityError

from .frames import DEFAULT_MAX_FRAME_BYTES
from .handshake_codec import encode_body
from .handshake_envelope import seal


@dataclass(frozen=True, slots=True)
class HostAdmission:
    """What a host admits against: the run's record, and its id policy.

    `minted` is the ids a spawned-worker host handed out, each admissible
    exactly once; `None` means an operator's workers name themselves, and the
    reserved prefix is refused instead. `live` maps an id already connected to
    the incarnation that connected it, which is how a reconnect of the SAME
    process is told from a second process using one id (PD7). `reservations`
    holds final admissions by connection until the current listener poll hands
    them to the host; another handshake in that poll must see their ownership.
    """

    run_id: RunId
    started: RunStarted
    context: ContextSpec | None
    manifests: tuple[ComponentManifest, ...]
    fingerprint: str
    key: bytes
    heartbeat_seconds: int
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES
    minted: tuple[str, ...] | None = None
    live: Mapping[str, str] = field(default_factory=dict)
    admitted_ids: set[str] = field(default_factory=set)
    reservations: dict[object, tuple[str, str]] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Admitted:
    """One worker, admitted: what it may claim under, and what it still holds."""

    registration: WorkerRegistration
    incarnation: str
    held: tuple[Lease, ...]
    supersedes: bool


@dataclass(frozen=True, slots=True)
class Refused:
    """This connection is not admitted, and whether the reason was proved."""

    reason: str
    authenticated: bool


def sealed_terms(
    admission: HostAdmission, *, host_nonce: str, worker_nonce: str
) -> bytes:
    """The `Terms` frame body, refused here if no frame could carry it.

    Sealed once per connection but sized once per run: a `RunStarted` whose
    encoding exceeds the frame bound would refuse every worker identically, so
    the host learns it before it spawns or listens rather than one handshake
    at a time.
    """

    body = encode_body(
        {
            "host_nonce": host_nonce,
            "worker_nonce": worker_nonce,
            "run_id": admission.run_id.value,
            "started": admission.started,
            "context": admission.context,
            "heartbeat_seconds": admission.heartbeat_seconds,
            "max_frame_bytes": admission.max_frame_bytes,
        }
    )
    sealed = seal("terms", admission.key, body)
    if len(sealed) > admission.max_frame_bytes:
        raise CapabilityError(
            f"this run's recorded start seals to {len(sealed)} bytes, over the "
            f"{admission.max_frame_bytes}-byte frame bound: no worker could be "
            "told what to run. Raise the bound, or declare a smaller policy "
            "configuration"
        )
    return sealed


__all__ = ["Admitted", "HostAdmission", "Refused", "sealed_terms"]
