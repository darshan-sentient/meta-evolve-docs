"""The host's half of admission: proving the key, then proving the build.

D6's HMAC half and D11. The worker's half is `worker_admission.py`, the
envelope both share is `handshake_envelope.py`, and the id rules are
`worker_identity.py`.


Five messages over the same frames. Nothing that depends on the run, and no
lease secret, reaches a peer before that peer has proved it holds the key:

    host   -> Challenge    unauthenticated, one fresh nonce
    worker -> Hello        identity, incarnation, fingerprint
    host   -> Terms        the RECORDED start, and this connection's limits
    worker -> Manifests    what its registry builds, and any lease it holds
    host   -> Admitted | Refused

**Every authenticated frame is an opaque body plus a MAC over exactly the
bytes received.** The receiver decodes only the outer envelope -- three
string-valued keys, bounded by the frame -- recomputes the MAC over the body
TEXT and compares it with `compare_digest`, and hands that text to the decoder
only then. So a peer that cannot prove the key never reaches the tagged
decoder, and no re-canonicalisation is ever compared: what was signed is what
arrived, byte for byte.

**Labels carry the direction and the version.** A MAC covers
`meta-evolve/<kind>/v1\\0` and the body, so an `Admitted` cannot be replayed as
a `Terms`, and a peer speaking another version fails the MAC rather than being
parsed. **Both nonces ride in every authenticated body**, so no message can be
replayed onto another connection either.

**Bounds follow authentication.** Before a `Hello` is verified the host reads
under `HELLO_MAX_FRAME_BYTES`, which a `Hello` fits many times over, so an
unauthenticated peer cannot make it buffer a large frame. Afterwards both
sides use the connection's ordinary `max_frame_bytes`, which is what `Terms`
needs: it carries the recorded `RunStarted`.

The key authenticates a connection; it encrypts nothing. Multi-host use is
documented and untested: it needs TLS, which this package does not provide.
"""

from __future__ import annotations

import secrets
import time
from collections.abc import Callable

from meta_evolve.application.dispatch_messages import TransportFailure
from meta_evolve.domain.work import Lease
from meta_evolve.domain.workers import WorkerId, WorkerRegistration
from meta_evolve.errors import CapabilityError
from meta_evolve.manifests import verify_manifests

from .admission import Admitted, HostAdmission, Refused, sealed_terms
from .frames import FrameReader, frame
from .handshake_codec import HandshakeRefused, encode_body
from .handshake_envelope import (
    HANDSHAKE_DEADLINE_SECONDS,
    HELLO_MAX_FRAME_BYTES,
    NONCE_BYTES,
    seal,
    unseal,
)
from .worker_identity import refuse_identity


class HostHandshake:
    """One pending connection, advanced without ever blocking the loop."""

    def __init__(
        self,
        sock,
        *,
        admission: HostAdmission,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        sock.setblocking(False)
        self._sock = sock
        self._admission = admission
        self._monotonic = monotonic
        self._started_at = monotonic()
        self._reader = FrameReader(max_frame_bytes=HELLO_MAX_FRAME_BYTES)
        self._outgoing = bytearray()
        self._host_nonce = secrets.token_hex(NONCE_BYTES)
        self._hello: dict | None = None
        self._sent_challenge = False
        self._reservation = object()

    @property
    def socket(self):
        return self._sock

    def release_identity(self) -> None:
        """Release this connection's reservation, never another owner's."""

        self._admission.reservations.pop(self._reservation, None)

    def advance(self) -> Admitted | Refused | None:
        """One non-blocking step: `None` while the handshake is still in flight."""

        if self._monotonic() - self._started_at > HANDSHAKE_DEADLINE_SECONDS:
            return self._refuse(
                f"the handshake passed its {HANDSHAKE_DEADLINE_SECONDS:.0f}-second "
                "deadline",
                authenticated=False,
            )
        try:
            self._flush()
            if not self._sent_challenge:
                self._send(
                    seal(
                        "challenge",
                        None,
                        encode_body({"host_nonce": self._host_nonce}),
                    )
                )
                self._sent_challenge = True
                return None
            body = self._read()
            if body is None:
                return None
            if self._hello is None:
                return self._on_hello(body)
            return self._on_manifests(body)
        except HandshakeRefused as refusal:
            return self._refuse(refusal.reason, authenticated=refusal.authenticated)
        except TransportFailure as failure:
            return self._refuse(str(failure), authenticated=False)
        except OSError as error:
            self.release_identity()
            return Refused(f"the connection failed ({type(error).__name__})", False)

    # -- the two inbound messages -------------------------------------------

    def _on_hello(self, body: bytes) -> Admitted | Refused | None:
        hello = unseal("hello", self._admission.key, body)
        if hello.get("host_nonce") != self._host_nonce:
            raise HandshakeRefused(
                "the hello answered another connection's challenge", True
            )
        refusal = refuse_identity(hello, self._admission)
        if refusal is not None:
            raise HandshakeRefused(refusal, True)
        if hello.get("fingerprint") != self._admission.fingerprint:
            raise HandshakeRefused(
                "this worker runs a different build from the dispatcher: its "
                "environment fingerprint does not match",
                True,
            )
        self._hello = hello
        # Proven: from here the connection may carry the run's record and, in
        # the other direction, the lease secrets a held result was issued under.
        self._reader = FrameReader(max_frame_bytes=self._admission.max_frame_bytes)
        self._send(
            sealed_terms(
                self._admission,
                host_nonce=self._host_nonce,
                worker_nonce=hello["worker_nonce"],
            )
        )
        return None

    def _on_manifests(self, body: bytes) -> Admitted | Refused:
        assert self._hello is not None
        message = unseal("manifests", self._admission.key, body)
        if (
            message.get("host_nonce") != self._host_nonce
            or message.get("worker_nonce") != self._hello["worker_nonce"]
        ):
            raise HandshakeRefused("the manifests answered another connection", True)
        try:
            verify_manifests(self._admission.manifests, message["manifests"])
        except CapabilityError as mismatch:
            raise HandshakeRefused(str(mismatch), True) from None
        worker = WorkerId(self._hello["worker_id"])
        held = tuple(message.get("held") or ())
        for lease in held:
            if not isinstance(lease, Lease) or lease.worker_id != worker.value:
                raise HandshakeRefused(
                    "this worker listed a lease issued to another worker", True
                )
        # Several Hellos can precede any final admission. Recheck and reserve
        # in this same non-blocking step, before another handshake advances.
        refusal = refuse_identity(self._hello, self._admission)
        if refusal is not None:
            raise HandshakeRefused(refusal, True)
        self._admission.reservations[self._reservation] = (
            worker.value, self._hello["incarnation"]
        )
        self._send(
            seal(
                "admitted",
                self._admission.key,
                encode_body(
                    {
                        "host_nonce": self._host_nonce,
                        "worker_nonce": self._hello["worker_nonce"],
                        "worker_id": worker.value,
                    }
                ),
            )
        )
        self._flush()
        self._admission.admitted_ids.add(worker.value)
        return Admitted(
            registration=WorkerRegistration(
                worker=worker,
                generation=1,
                max_concurrent_leases=1,
                environment_fingerprint=self._admission.fingerprint,
            ),
            incarnation=self._hello["incarnation"],
            held=held,
            supersedes=self._hello["worker_id"] in self._admission.live,
        )

    # -- framing -------------------------------------------------------------

    def _read(self) -> bytes | None:
        try:
            chunk = self._sock.recv(65536)
        except (BlockingIOError, InterruptedError):
            return None
        if not chunk:
            raise TransportFailure("the peer closed the connection")
        bodies = self._reader.feed(chunk)
        return bodies[0] if bodies else None

    def _send(self, body: bytes) -> None:
        self._outgoing += frame(body, max_frame_bytes=self._admission.max_frame_bytes)
        self._flush()

    def _flush(self) -> None:
        while self._outgoing:
            try:
                sent = self._sock.send(self._outgoing)
            except (BlockingIOError, InterruptedError):
                return
            del self._outgoing[:sent]

    def _refuse(self, reason: str, *, authenticated: bool) -> Refused:
        """Answer the refusal, sealed only when the key was already proved."""

        self.release_identity()
        try:
            self._outgoing.clear()
            self._send(
                seal(
                    "refused",
                    self._admission.key if authenticated else None,
                    encode_body({"host_nonce": self._host_nonce, "reason": reason}),
                )
            )
            self._flush()
        except OSError:
            pass
        return Refused(reason, authenticated)


__all__ = ["HostHandshake"]
