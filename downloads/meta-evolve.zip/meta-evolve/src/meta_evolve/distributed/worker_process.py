"""One worker process: `python -m meta_evolve.distributed.worker_process`.

Both ways a worker starts end here. A child the dispatcher spawned reads its
bootstrap from stdin; an operator's `meta-evolve worker` passes the same
fields as arguments. What differs afterwards is only what an ending means: a
child exits when its parent is gone, and an operator's worker reconnects and
resends what it holds (PD8).

**The watchdog is what makes a dispatcher's death final for its children.** A
child's component runs on this thread, so a call that takes a minute would
otherwise keep running -- possibly spending money -- long after the run that
asked for it died. The parent holds this process's stdin, and a SIGKILLed
parent still closes it, so a thread blocked on that read is the one thing that
notices without the parent's cooperation. It answers by killing this process
GROUP, which is this process and whatever its component started in it.

**SIGTERM raises instead of killing**, so an orderly shutdown runs the
component's own cleanup (the development sandbox kills the command sessions it
started that way). A SIGKILL cannot, and does not: the record says so.

Exit codes: 0 finished or told to stop, 2 refused with proof, 130 interrupted.
"""

from __future__ import annotations

import json
import os
import signal
import socket
import sys
import threading
import time

from meta_evolve.application.dispatch_messages import TransportFailure
from meta_evolve.experiment_modules import experiment_declaration, worker_executors

from .frames import DEFAULT_MAX_FRAME_BYTES
from .listener import parse_address
from .worker import Finished, Lost, serve
from .worker_admission import WorkerRefused, worker_handshake

#: How long to wait before reconnecting, and the cap it doubles to.
FIRST_BACKOFF_SECONDS = 0.1
MAX_BACKOFF_SECONDS = 5.0


def main(argv: list[str] | None = None) -> int:
    """A spawned child. Its bootstrap arrives on stdin, and stdin is its life."""

    line = sys.stdin.buffer.readline()
    if not line:
        return 0  # the parent died before it said anything; nothing to run
    bootstrap = json.loads(line.decode("utf-8"))
    if os.getppid() != bootstrap["parent_pid"]:
        # Started after its parent died: the ppid it sees now is whatever
        # adopted it, so this process has no dispatcher to serve.
        return 0
    _watch_parent()
    return run_worker(
        address=bootstrap["address"],
        key=bytes.fromhex(bootstrap["key"]),
        module=bootstrap["module"],
        worker_id=bootstrap["worker_id"],
        reconnect=False,
    )


def run_worker(
    *,
    address: str,
    key: bytes,
    module: str,
    worker_id: str,
    reconnect: bool,
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
    sleep=time.sleep,
) -> int:
    """Connect, be admitted, and serve until this worker is done.

    `reconnect` is the whole difference between the two kinds of worker: a
    spawned child's dispatcher is gone for good when the connection ends,
    while an operator's worker outlives one dispatcher and reconnects to the
    next -- which is how an acknowledgment lost with a dispatcher is
    recovered (D13, T7).
    """

    signal.signal(signal.SIGTERM, _raise_system_exit)
    registry = experiment_declaration(module).registry
    incarnation = os.urandom(16).hex()
    held: tuple = ()
    pending = None
    pending_run: str | None = None
    backoff = FIRST_BACKOFF_SECONDS
    while True:
        try:
            sock = socket.create_connection(parse_address(address))
        except OSError as error:
            if not reconnect:
                print(f"meta-evolve worker: cannot connect ({error})", file=sys.stderr)
                return 1
            sleep(backoff)
            backoff = min(backoff * 2, MAX_BACKOFF_SECONDS)
            continue
        try:
            admitted = worker_handshake(
                sock,
                key=key,
                worker_id=worker_id,
                incarnation=incarnation,
                fingerprint=_fingerprint(),
                build=lambda started, context: worker_executors(
                    registry, started, context
                ),
                held=held,
                run_of=lambda _lease: pending_run,
                max_frame_bytes=max_frame_bytes,
            )
        except WorkerRefused as refusal:
            # Proved, so it is terminal: a build or an id a retry cannot fix.
            print(f"meta-evolve worker: refused ({refusal})", file=sys.stderr)
            sock.close()
            return 2
        except (TransportFailure, OSError) as failure:
            sock.close()
            if not reconnect:
                print(f"meta-evolve worker: {failure}", file=sys.stderr)
                return 1
            sleep(backoff)
            backoff = min(backoff * 2, MAX_BACKOFF_SECONDS)
            continue
        backoff = FIRST_BACKOFF_SECONDS
        try:
            if pending is not None and pending_run != admitted.run_id:
                print(
                    f"meta-evolve worker: refused: pending result belongs to run "
                    f"{pending_run!r}, but the host admitted run {admitted.run_id!r}",
                    file=sys.stderr,
                )
                return 2
            ending = serve(
                sock,
                evaluation=admitted.evaluation,
                proposal=admitted.proposal,
                heartbeat_seconds=admitted.heartbeat_seconds,
                max_frame_bytes=admitted.max_frame_bytes,
                resend=pending,
                run_id=admitted.run_id,
            )
        finally:
            sock.close()
        if isinstance(ending, Finished):
            return 0
        if not reconnect:
            return 0  # the dispatcher this child belongs to is gone
        pending = ending.pending if isinstance(ending, Lost) else None
        pending_run = None if pending is None else ending.run_id
        held = () if pending is None else (pending[0],)


def _watch_parent() -> None:
    """Kill this process group when the parent closes our stdin."""

    def watch() -> None:
        # The raw descriptor, not `sys.stdin.buffer`: a daemon thread holding
        # a buffered reader's lock makes the interpreter complain loudly at
        # shutdown, and this thread outlives every orderly exit by design.
        try:
            while os.read(0, 4096):
                pass
        except OSError:
            pass
        os.killpg(os.getpgrp(), signal.SIGKILL)

    threading.Thread(target=watch, name="meta-evolve-parent-watch", daemon=True).start()


def _raise_system_exit(_number, _frame):
    raise SystemExit(0)


def _fingerprint() -> str:
    from meta_evolve.environment import environment_fingerprint

    return environment_fingerprint()


if __name__ == "__main__":  # pragma: no cover - exercised by subprocess tests
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130) from None
