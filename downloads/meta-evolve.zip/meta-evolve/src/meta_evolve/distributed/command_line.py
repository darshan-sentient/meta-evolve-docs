"""The command line's worker flags, and the `worker` verb itself (D5).

Here rather than in `cli.py` for two reasons. `cli.py` is at its length
ceiling, and it owns one convention -- parse, make ONE public call, return a
report -- which the worker verb does not follow: it is long-running, like
`ui`, and it makes no run of its own.

What the flags mean:

- `--workers N` spawns N children for this run;
- `--listen ADDR --key-file PATH` opens a port for an operator's workers;
- `--lease-seconds S` is how long a lease lasts, at least 10.

The two backends are mutually exclusive, and either one needs
`--mode distributed`: a local or durable-local run has no work table for a
worker to claim from, so accepting the flag and ignoring it would be the
silent capability downgrade the record forbids.
"""

from __future__ import annotations

import argparse

from meta_evolve.experiment_modules import MODULE_HELP, refuse_main_hints

from .host import WorkerHost
from .keys import read_key_file
from .spawn import WorkerProcesses
from .worker_identity import refuse_identity
from .worker_process import run_worker

#: Matches the library floor, restated only as a parser message.
MIN_LEASE_SECONDS = 10


def add_worker_flags(parser: argparse.ArgumentParser) -> None:
    """The flags that choose a backend, on `run` or `resume`."""

    backend = parser.add_mutually_exclusive_group()
    backend.add_argument(
        "--workers",
        type=_count,
        metavar="N",
        help="spawn N worker processes for this run (distributed mode only)",
    )
    backend.add_argument(
        "--listen",
        metavar="ADDR",
        help=(
            "host:port to accept worker processes on, for workers started "
            "with `meta-evolve worker` (distributed mode only)"
        ),
    )
    parser.add_argument(
        "--key-file",
        metavar="PATH",
        help="shared key for --listen; created private if it does not exist",
    )
    parser.add_argument(
        "--lease-seconds",
        type=_lease,
        metavar="S",
        help=f"how long a work lease lasts, at least {MIN_LEASE_SECONDS}",
    )


def add_worker_verb(verbs, execute) -> argparse.ArgumentParser:
    """`meta-evolve worker`, which joins someone else's run."""

    parser = verbs.add_parser(
        "worker",
        help="run work for a dispatcher that is listening",
        description=(
            "Connect to a dispatcher's --listen address and run its work "
            "until the run finishes. Long-running, like `ui`."
        ),
    )
    parser.add_argument("--module", required=True, help=MODULE_HELP)
    parser.add_argument(
        "--connect", required=True, metavar="ADDR", help="the dispatcher's host:port"
    )
    parser.add_argument(
        "--key-file", required=True, metavar="PATH", help="the dispatcher's key file"
    )
    parser.add_argument(
        "--worker-id", required=True, metavar="ID", help="this worker's identity"
    )
    parser.set_defaults(execute=execute)
    return parser


def execution_for(arguments: argparse.Namespace, parser: argparse.ArgumentParser):
    """The backend these arguments name, or `None` for the inline path.

    Refusals are the parser's, so they exit 2 with usage, before a run is
    started or a store is touched.
    """

    workers = getattr(arguments, "workers", None)
    listen = getattr(arguments, "listen", None)
    key_file = getattr(arguments, "key_file", None)
    lease = getattr(arguments, "lease_seconds", None)
    mode = getattr(arguments, "mode", "distributed")
    if (workers or listen) and mode != "distributed":
        parser.error("--workers and --listen need --mode distributed")
    if key_file and not listen:
        parser.error("--key-file belongs with --listen")
    if listen and not key_file:
        parser.error("--listen needs --key-file")
    if lease is not None and not (workers or listen):
        parser.error("--lease-seconds needs --workers or --listen")
    if workers:
        return WorkerProcesses(workers, arguments.module)
    if listen:
        return WorkerHost(listen, key_file)
    return None


def drive_with(session, execution, arguments: argparse.Namespace) -> None:
    """Drive `session` through `execution`, with this run's lease duration."""

    lease = getattr(arguments, "lease_seconds", None)
    options = {} if lease is None else {"lease_seconds": lease}
    session.drive(execution=execution, **options)


def preflight(declaration) -> None:
    """Refuse a run whose components no child could import, writing nothing.

    The library refuses the same thing at `open()`, after genesis. Doing it
    here as well is what makes the common mistake -- components defined in the
    script being run -- cost nothing at all (T13).
    """

    from meta_evolve.registry import Registry

    registry = declaration.registry
    if isinstance(registry, Registry):
        refuse_main_hints(
            registry.manifests_for(
                proposer=declaration.proposer,
                evaluator=declaration.task.evaluator,
                search=_spec_of(declaration),
                context=None,
            )
        )


def run_worker_verb(arguments: argparse.Namespace) -> int:
    """`meta-evolve worker`: connect, serve, and reconnect until it is done."""

    refusal = refuse_identity(
        {"worker_id": arguments.worker_id, "incarnation": "command-line"},
        _NamesItself(),
    )
    if refusal is not None:
        raise SystemExit(f"meta-evolve worker: {refusal}")
    return run_worker(
        address=arguments.connect,
        key=read_key_file(arguments.key_file),
        module=arguments.module,
        worker_id=arguments.worker_id,
        reconnect=True,
    )


class _NamesItself:
    """The id policy for a worker an operator started: no minted ids, and
    nothing live to compare against -- the host checks that when it connects."""

    minted = None
    live: dict = {}
    admitted_ids: set = set()
    reservations: dict = {}


def _spec_of(declaration):
    from meta_evolve.application.search_preparation import prepare_search

    return prepare_search(
        declaration.search,
        proposer=declaration.proposer,
        budget=declaration.task.budget,
    ).spec


def _count(value: str) -> int:
    try:
        count = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("--workers must be an integer") from error
    if count < 1:
        raise argparse.ArgumentTypeError("--workers must be at least 1")
    return count


def _lease(value: str) -> int:
    try:
        seconds = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("--lease-seconds must be an integer") from error
    if seconds < MIN_LEASE_SECONDS:
        raise argparse.ArgumentTypeError(
            f"--lease-seconds must be at least {MIN_LEASE_SECONDS}"
        )
    return seconds


__all__ = [
    "MIN_LEASE_SECONDS",
    "add_worker_flags",
    "add_worker_verb",
    "drive_with",
    "execution_for",
    "preflight",
    "run_worker_verb",
]
