"""The handshake's own closed codec, sharing nothing with the dispatch one.

Two registries, deliberately disjoint by use: a dispatch frame decodes only
`MESSAGE_TYPES` (`messages.py`), and a handshake body decodes only what a
handshake carries. So a `Hello` after admission is that connection's transport
failure, and a `Pull` during the handshake is a refusal -- neither codec can
be made to accept the other's frames, which is what keeps admission from being
something a peer can talk its way past.

What a handshake body holds is the run's RECORDED start -- durable types, plus
the leases a reconnecting worker still holds. Those are values the durable
registry already names, so this binds `DURABLE_TYPES` plus the lease types and
nothing else: no `EncodedProposal`, no `EvaluationResult`, no exception.
"""

from __future__ import annotations

import json

from meta_evolve import domain
from meta_evolve.domain.work import Lease, LeaseToken, WorkAttemptId, WorkItemId
from meta_evolve.tagged_values import TaggedCodec

_TYPES = (*domain.DURABLE_TYPES, Lease, LeaseToken, WorkItemId, WorkAttemptId)

_CODEC = TaggedCodec({cls.__name__: cls for cls in _TYPES}, noun="handshake")


class HandshakeRefused(Exception):
    """This connection is not admitted, and whether the key was proved first.

    `authenticated` decides what the peer is told and what it does next: a
    proved refusal names its reason and is terminal, while an unproved one is
    advisory -- the host cannot prove anything to a peer that has not proved
    itself, and a worker that gets one retries rather than exiting.
    """

    def __init__(self, reason: str, authenticated: bool) -> None:
        super().__init__(reason)
        self.reason = reason
        self.authenticated = authenticated


def encode_body(body: dict) -> str:
    """One handshake body as canonical JSON text, which is what gets signed."""

    return json.dumps(
        {key: _CODEC.encode(value) for key, value in body.items()},
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
    )


def decode_body(text: str) -> dict:
    """The body a verified MAC vouched for, or a refusal naming its kind only.

    A refusal never quotes the text it choked on: a handshake body carries the
    lease secrets of a reconnecting worker.
    """

    try:
        decoded = json.loads(text, parse_constant=_refuse_constant)
    except (ValueError, RecursionError) as error:
        raise HandshakeRefused(
            f"an undecodable handshake body ({type(error).__name__})", True
        ) from None
    if not isinstance(decoded, dict):
        raise HandshakeRefused("a handshake body that is not an object", True)
    try:
        return {key: _CODEC.decode(value) for key, value in decoded.items()}
    except (ValueError, TypeError, KeyError, AttributeError) as error:
        raise HandshakeRefused(
            f"an undecodable handshake body ({type(error).__name__})", True
        ) from None


def _refuse_constant(name: str) -> object:
    raise ValueError("a non-finite number")


__all__ = ["HandshakeRefused", "decode_body", "encode_body"]
