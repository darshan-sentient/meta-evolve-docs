"""The wire codec: dispatch messages as JSON, and a closed map of exceptions.

The encoding is the durable one (`tagged_values.py`) bound to a wider registry:
`DURABLE_TYPES` plus the values only the wire carries -- leases with their
secret (D6), executor inputs and results, and the messages themselves. Nothing
here is added to `DURABLE_TYPES`; the durable format still refuses all of it.

Three things the durable format has no form for, each declared here only:

* `StaleReason` travels as `$enum`;
* an `Acknowledgment` travels as its payload and is rebuilt from it, so the
  replayed bytes are re-derived by the same canonical encoder, never sent;
* an exception travels as a `WireError` -- a name, a message and structured
  fields -- and is rebuilt ONLY from `_ERRORS`. A worker never pickles, and
  the host never resolves a class by name: an unmapped name is a protocol
  violation. The table is `ESCAPING_EXCEPTIONS`' members and their subclasses
  that a component can raise, plus `CandidateEncodingError`, the completion
  failure; a subclass travels as its nearest mapped base.

Every decoding refusal is a `TransportFailure` whose message names only what
kind of failure it was -- never the frame, which can carry a lease's secret.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from contextvars import ContextVar
from dataclasses import dataclass

from meta_evolve import domain
from meta_evolve.application.dispatch_messages import (
    MESSAGE_TYPES,
    Accepted,
    EvaluationCall,
    Message,
    ProposalCall,
    TransportFailure,
)
from meta_evolve.application.dispatch_outcomes import error_text
from meta_evolve.application.executors import (
    CandidateEncodingError,
    EncodedProposal,
    ProposalRequest,
)
from meta_evolve.domain.resources import Resources
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.domain.work import (
    Lease,
    LeaseToken,
    StaleReason,
    WorkAttemptId,
    WorkItemId,
)
from meta_evolve.errors import (
    CapabilityError,
    DispatcherSuperseded,
    DurableCorruption,
    DurableStoreError,
    ExecutionAccountingUnknown,
    ExperienceStoreUnavailable,
    SchemaVersionRejected,
)
from meta_evolve.ports.callables import EvaluationResult, EvidenceDraft
from meta_evolve.ports.event_store import EventStreamConflict
from meta_evolve.ports.work_store import Acknowledgment
from meta_evolve.ports.work_submission import Duplicate, Stale, StaleCompletion
from meta_evolve.tagged_values import Projection, TaggedCodec


@dataclass(frozen=True, slots=True, kw_only=True)
class WireError:
    """An exception as it crosses: its mapped name, message and fields.

    `origin_name` is the CONCRETE class the peer raised, which `name` may not
    be: a subclass crosses as its nearest mapped base, because the map is
    closed. It is a diagnostic only -- unverified text the peer supplied --
    and nothing ever resolves a class from it.
    """

    name: str
    message: str
    fields: tuple[tuple[str, object], ...] = ()
    origin_name: str = ""


def _message_only(cls: type[BaseException]):
    return (cls, lambda error: (), lambda message, fields: cls(message))


#: name -> (class, its structured fields, how to rebuild it). CLOSED.
_ERRORS: dict[str, tuple[type[BaseException], Callable, Callable]] = {
    "EventStreamConflict": (
        EventStreamConflict,
        lambda e: (("run_id", e.run_id), ("expected_version", e.expected_version),
                   ("actual_version", e.actual_version)),
        lambda message, f: EventStreamConflict(
            f["run_id"], f["expected_version"], f["actual_version"]
        ),
    ),
    "DispatcherSuperseded": (
        DispatcherSuperseded,
        lambda e: (("run_id", e.run_id), ("held", e.held), ("current", e.current)),
        lambda message, f: DispatcherSuperseded(
            f["run_id"], held=f["held"], current=f["current"]
        ),
    ),
    "StaleCompletion": (
        StaleCompletion,
        lambda e: (("item", e.item), ("reason", e.reason)),
        lambda message, f: StaleCompletion(f["item"], f["reason"]),
    ),
    **{
        cls.__name__: _message_only(cls)
        for cls in (
            DurableStoreError,
            DurableCorruption,
            SchemaVersionRejected,
            ExperienceStoreUnavailable,
            InvalidSearchHistory,
            ExecutionAccountingUnknown,
            CapabilityError,
            CandidateEncodingError,
        )
    },
}


#: How many UTF-8 BYTES of an exception's message cross by default; the rest
#: is marked as cut. A sender with a smaller frame bound passes its own
#: (`encode_message(..., text_limit=)`), so an escaping error can be made to
#: fit whatever frame the connection allows.
_MESSAGE_LIMIT = 16 * 1024

_text_limit: ContextVar[int] = ContextVar("wire_text_limit", default=_MESSAGE_LIMIT)


def bounded_text(text: str, limit: int) -> str:
    """`text` cut to at most `limit` UTF-8 bytes, marked when cut."""

    encoded = text.encode("utf-8")
    if len(encoded) <= limit:
        return text
    kept = encoded[: max(0, limit - 64)].decode("utf-8", errors="ignore")
    return kept + f" [... {len(encoded) - len(kept.encode())} bytes cut]"


def _bounded(text: str) -> str:
    return bounded_text(text, _text_limit.get())


def _to_wire_error(error: BaseException) -> WireError:
    for cls in type(error).__mro__:
        entry = _ERRORS.get(cls.__name__)
        if entry is not None and entry[0] is cls:
            return WireError(
                name=cls.__name__,
                message=_bounded(error_text(error)),
                fields=tuple(entry[1](error)),
                # Read from the CONCRETE class, before the mapping above
                # collapses it to its nearest mapped base.
                origin_name=type(error).__name__,
            )
    raise TypeError(
        f"{type(error).__name__} is not in the wire's exception map: only the "
        "escaping set and CandidateEncodingError cross"
    )


def _from_wire_error(record: WireError) -> BaseException:
    entry = _ERRORS.get(record.name)
    if entry is None:
        # The name is NOT quoted: it is text the peer chose, and a refusal
        # never carries frame content -- a lease secret could sit there.
        raise TransportFailure("a peer sent an exception outside the wire's map")
    error = entry[2](record.message, dict(record.fields))
    if record.origin_name and record.origin_name != record.name:
        # The class comes from the closed map above and nowhere else. This is
        # the peer's word for what it actually raised, carried so a cause pair
        # naming a subclass still round-trips -- and refused by
        # `CompletionFailed` when the two disagree.
        error.__wire_origin__ = record.origin_name  # type: ignore[attr-defined]
    return error


_WIRE_TYPES = (
    *domain.DURABLE_TYPES,
    Resources,
    EvaluationResult,
    EvidenceDraft,
    EncodedProposal,
    ProposalRequest,
    Lease,
    LeaseToken,
    WorkItemId,
    WorkAttemptId,
    Duplicate,
    Stale,
    Accepted,
    EvaluationCall,
    ProposalCall,
    WireError,
    *MESSAGE_TYPES,
)

_CODEC = TaggedCodec(
    {cls.__name__: cls for cls in _WIRE_TYPES},
    noun="wire",
    enums={"StaleReason": StaleReason},
    projections={
        "acknowledgment": Projection(
            Acknowledgment, lambda ack: ack.payload, Acknowledgment
        ),
        "error": Projection(BaseException, _to_wire_error, _from_wire_error),
    },
)


def encode_message(message: Message, *, text_limit: int = _MESSAGE_LIMIT) -> bytes:
    """One message as a frame body: canonical, finite, UTF-8 JSON.

    `text_limit` bounds, in bytes, the message of any exception the frame
    carries.
    """

    if not isinstance(message, MESSAGE_TYPES):
        raise TypeError(f"not a dispatch message: {type(message).__name__}")
    token = _text_limit.set(text_limit)
    try:
        encoded = _CODEC.encode(message)
    finally:
        _text_limit.reset(token)
    return json.dumps(
        encoded, ensure_ascii=False, allow_nan=False, separators=(",", ":")
    ).encode("utf-8")


def _refuse_constant(name: str) -> object:
    raise ValueError("a non-finite number")


def decode_message(body: bytes) -> Message:
    """A frame body back into its message, or a `TransportFailure`.

    Refusals carry the failure's KIND only and chain nothing: the text of a
    decode error can quote the value it choked on, and that value can be a
    lease secret.
    """

    try:
        value = _CODEC.decode(
            json.loads(body.decode("utf-8"), parse_constant=_refuse_constant)
        )
    except RecursionError:
        raise TransportFailure("a frame nested past the decoder's depth") from None
    except (ValueError, TypeError, KeyError, AttributeError) as error:
        raise TransportFailure(
            f"an undecodable frame ({type(error).__name__})"
        ) from None
    if not isinstance(value, MESSAGE_TYPES):
        raise TransportFailure("a frame that is not a dispatch message")
    return value


__all__ = ["WireError", "bounded_text", "decode_message", "encode_message"]
