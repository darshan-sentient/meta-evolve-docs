"""Typed failures raised by local run orchestration and queries."""


class RunError(RuntimeError):
    """Base class for application-level run failures."""


class BudgetUnavailable(RunError):
    """The requested action cannot fit within its effective budget."""


class InvalidDecision(RunError):
    """A search decision is stale, malformed, or exceeds its authority."""


class NoSuccessfulEvaluation(RunError):
    """A winner-dependent query has no successful measurement to rank.

    Use ``Run.trials()``, ``Run.inspect()``, or ``Run.usage()`` to diagnose and
    account for unsuccessful work. A missing measurement is never a zero score.
    """


class RunNotFound(RunError):
    """No durable run exists under the requested id (an empty event stream)."""


class RunsNotComparable(RunError):
    """Two runs disagree on a declaration their comparison is defined over.

    ``compare_runs`` ranks two runs only when they answer the same question:
    the same task, objective, budgets, initial artifact, and authorized
    components. ``declaration`` names the one that differed, so a caller can
    branch on it without parsing the message.
    """

    def __init__(self, declaration: str) -> None:
        super().__init__(f"runs declare different {declaration}s")
        self.declaration = declaration


class UnboundSearchProgram(RunError):
    """A public search preset was used without run-level binding."""


class CapabilityError(RunError):
    """A run's declared or requested execution profile is not honored.

    Raised for unverifiable component implementations (lambdas, closures,
    ``functools.partial``, decorated wrappers, or callables with no
    resolvable module source), unregistered ``(role, name, version)``
    lookups, and durable-local configuration that lacks a registry, durable
    storage, or a registered evaluator/proposer/policy. Also raised when
    storage is asked for an optional capability its components do not
    declare, such as enumerating runs through a non-``RunIndex`` event store.
    """


class DurableStoreError(RunError):
    """Base class for durable-format and durable-store failures."""


class SchemaVersionRejected(DurableStoreError):
    """A durable schema version is unknown, future, or unmigratable."""


class DurableCorruption(DurableStoreError):
    """Durable data is internally inconsistent or references missing content."""


class ExperienceStoreUnavailable(DurableStoreError):
    """A durable audit-event commit for an experience reader operation failed.

    Raised at the experience reader's audit-append boundary when the underlying
    store commit fails with a raw infrastructure fault (``OSError`` /
    ``sqlite3.Error``). It is INFRASTRUCTURE, not a logical proposer failure:
    it is the one typed signal a proposer-driven reader emits so the proposer
    adapter can let a genuine audit-store commit fault ESCAPE while a user
    proposer's own ``OSError`` still becomes a recoverable ``ProposerFailure``.
    """


class ExecutionAccountingUnknown(RunError):
    """Provider work may have started without exact required accounting.

    Part of the user-owned wrapper contract rather than an internal detail,
    imported as ``from meta_evolve.errors import ExecutionAccountingUnknown``.
    Raise when required nonnullable accounting, such as token usage after a
    dispatched request, cannot be recovered. Unknown billed spend alone can
    be retained as ``Usage(spend_micros=None)`` alongside a result or failure.
    An ordinary exception instead becomes a typed failure with default usage.

    It aborts a local structural run. It is not a durable failure outcome and
    makes no retry or resume claim.
    """


_EXPERIENCE_DENIED = "experience access denied"
_EXPERIENCE_EXHAUSTED = "experience budget exhausted"


class ExperienceAccessDenied(LookupError):
    """An opaque denial that discloses no protected content or topology."""

    def __init__(self) -> None:
        super().__init__(_EXPERIENCE_DENIED)


class ExperienceBudgetExhausted(RuntimeError):
    """A content-free signal that a grant's operation ceiling was exceeded."""

    def __init__(self) -> None:
        super().__init__(_EXPERIENCE_EXHAUSTED)


__all__ = [
    "BudgetUnavailable",
    "CapabilityError",
    "DurableCorruption",
    "DurableStoreError",
    "ExecutionAccountingUnknown",
    "ExperienceAccessDenied",
    "ExperienceBudgetExhausted",
    "ExperienceStoreUnavailable",
    "InvalidDecision",
    "NoSuccessfulEvaluation",
    "RunError",
    "RunNotFound",
    "RunsNotComparable",
    "SchemaVersionRejected",
    "UnboundSearchProgram",
]
