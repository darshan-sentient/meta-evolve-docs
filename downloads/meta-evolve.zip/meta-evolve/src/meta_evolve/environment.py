"""A versioned digest over the environment a run executed in.

`manifests.py` deferred this here by name, and this PR removed the sentence that
did the deferring, so it is paraphrased rather than quoted: that module verifies
a callable's *source* looks like the one a durable run recorded, and left
environment digests to the distributed milestone. This is that milestone, and
the two stay separate -- a source digest answers "is this the same code", this
answers "is this the same environment", and a worker can fail either
independently.

**It is a version-set fingerprint, not environment identity.** Name and version
pairs do not identify installed bytes, so two editable or locally patched
installs match, and the platform string omits OS release and libc ABI. It
reliably detects drift; it does not prove sameness. Content-hashed distributions
are the exit, and until then this is deliberately the weaker claim rather than a
stronger one nobody could keep.
"""

from __future__ import annotations

import platform
import sys
import sysconfig
from collections.abc import Iterable
from hashlib import sha256

from meta_evolve.domain.components import ENVIRONMENT_FINGERPRINT_VERSION
from meta_evolve.domain.values import canonical_payload_bytes



def _installed_distributions() -> tuple[tuple[str, str], ...]:
    """Every installed distribution as ``(lowercased name, version)``.

    Every one, and the plural is the point: this accumulates a LIST and sorts
    it, not a dict keyed by name. A dict silently collapses exactly the cases
    this fingerprint exists to notice -- one name installed at two versions, and
    every unreadable distribution mapping to the same empty-string key -- so an
    environment carrying three unreadable distributions fingerprinted
    identically to one carrying a single one, and a duplicate install
    fingerprinted as whichever entry `distributions()` happened to yield last.
    Nondeterministic, in a value whose whole job is to be stable.

    A distribution whose metadata carries no readable name is recorded under the
    empty string rather than dropped, and a missing version as ``"?"`` rather
    than ``""``: both are drift -- an environment that grew an unreadable
    distribution is not the environment that did not -- and silently skipping
    them makes the two fingerprint identically. ``""`` is reserved for a version
    that genuinely is empty.
    """

    from importlib.metadata import distributions

    seen: list[tuple[str, str]] = []
    for distribution in distributions():
        name = distribution.metadata["Name"] or ""
        version = distribution.version
        seen.append((name.lower(), "?" if version is None else version))
    return tuple(sorted(seen))


def _installed_source_digest() -> str:
    """A digest over the installed Meta-Evolve source, or a stated absence.

    An editable install records a `.pth` shim rather than the `.py` files, so
    there is nothing to digest and the absence is recorded as itself: `files()`
    returns entries with hashes, none of them a `.py`. A packaging backend that
    starts recording an `__editable___*.py` finder would silently begin
    digesting a path shim.

    The three absences are distinguished rather than folded into one literal.
    Not running from an installed distribution at all is a materially different
    environment from an editable install, and a fingerprint that cannot tell them
    apart is a fingerprint that reports no drift between them.

    A wheel install and an editable install differ, which is correct: they are
    different environments. Two editable installs match, which the module
    docstring already concedes.
    """

    from importlib.metadata import PackageNotFoundError, files

    try:
        recorded = files("meta-evolve")
    except PackageNotFoundError:
        return "source=not-an-installed-distribution"
    if not recorded:
        return "source=no-recorded-files"
    hashes = sorted(
        # `str(item)` is the recorded RELATIVE PATH; `item.name` is only its
        # final component. Keying on the basename made a module relocated
        # between subpackages with unchanged content fingerprint identically --
        # exactly the drift this exists to refuse -- and disagreed with the
        # filter one line below, which already uses the path.
        f"{item}:{item.hash.value}"
        for item in recorded
        if str(item).endswith(".py") and item.hash is not None
    )
    if not hashes:
        return "source=no-recorded-python-files"
    return sha256("|".join(hashes).encode("utf-8")).hexdigest()


def environment_fingerprint(
    *,
    implementation: str | None = None,
    version: str | None = None,
    platform_tag: str | None = None,
    distributions: Iterable[tuple[str, str]] | None = None,
    source: str | None = None,
) -> str:
    """The digest a run records and every worker declares.

    Every input is overridable so a caller can fingerprint an environment other
    than this process -- which is what lets a worker's declaration be compared
    against a run's recorded one without running inside it, and what lets the
    drift tests supply each input rather than mutating the interpreter.
    """

    payload = {
        "domain": ENVIRONMENT_FINGERPRINT_VERSION,
        "implementation": (
            sys.implementation.name if implementation is None else implementation
        ),
        "version": platform.python_version() if version is None else version,
        "platform": sysconfig.get_platform() if platform_tag is None else platform_tag,
        # Sorted, because two installs differing only in enumeration order are
        # the same environment and refusing a worker for that would be noise.
        "distributions": tuple(
            sorted(_installed_distributions() if distributions is None else distributions)
        ),
        "source": _installed_source_digest() if source is None else source,
    }
    digest = sha256(canonical_payload_bytes(payload)).hexdigest()
    return f"{ENVIRONMENT_FINGERPRINT_VERSION}:{digest}"


__all__ = ["ENVIRONMENT_FINGERPRINT_VERSION", "environment_fingerprint"]
