"""The in-memory broker's acceptance: its twin of the SQLite intent applier.

Acceptance is an `AcceptCompletion` intent applied inside the writing
transaction, never a broker call, and that stays true of every real run --
only the SQLite unit of work applies it. This ledger could therefore never
reach `COMPLETED`, so the accepted-row branches of the staleness rule and of
`submission_status` were proved against one adapter only, with no differential
oracle. `accept` is the same rule on the ledger, so the shared contract can
drive both brokers there (design SD10). It is not on the port.
"""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain import RunId
from meta_evolve.domain.work import Lease, WorkState
from meta_evolve.ports.work_store import Acknowledgment
from meta_evolve.ports.work_submission import DuplicateCompletion, StaleCompletion

from .work_ledger import _RunLedger, advance, classify_submission


def accept(
    ledger: _RunLedger,
    run_id: RunId,
    lease: Lease,
    *,
    now: int,
    acknowledgment: Acknowledgment,
) -> None:
    """`LEASED` -> `COMPLETED`, or the refusal `_accept_completion_in_txn` raises.

    Clamped and deliberately NOT swept, as the SQLite applier is: sweeping
    would release the very row being accepted, so a past-deadline lease is
    still `LEASED` here and is reported `EXPIRED` against its held deadline.
    """

    clock = advance(ledger, now)
    reason, state = classify_submission(ledger, run_id, lease, clock=clock)
    if reason is not None:
        raise StaleCompletion(lease.item, reason)
    if state is WorkState.COMPLETED:
        raise DuplicateCompletion(lease.item, ledger.accepted[lease.item][2])
    ledger.rows[lease.item] = replace(
        ledger.rows[lease.item], state=WorkState.COMPLETED
    )
    del ledger.leases[lease.item]
    ledger.accepted[lease.item] = (
        lease.attempt.ordinal,
        lease.token.digest,
        acknowledgment,
    )


__all__ = ["accept"]
