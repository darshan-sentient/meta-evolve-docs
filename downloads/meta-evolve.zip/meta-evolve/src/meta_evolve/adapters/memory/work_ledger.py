"""The in-memory work ledger: its rows, its clock, and its expiry rule.

Split from `work_broker.py`, which reached 335 lines. This module is the DATA
plus the one rule that changes it without anybody asking -- expiry -- and the
broker beside it is the operations a caller invokes. Keeping expiry here is what
lets it be stated once: every operation advances the clock and expires through
these two functions, so the half-open deadline has exactly one implementation.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace

from collections.abc import Iterable

from meta_evolve.domain import RunId
from meta_evolve.domain.work import (
    Lease,
    LeaseToken,
    WorkItemId,
    WorkRow,
    WorkState,
)
from meta_evolve.domain.work import require_broker_time, require_lease
from meta_evolve.ports.work_store import (
    InvalidWorkAppend,
    refuse_inadmissible_enqueue,
)

#: Re-exported from the domain, where the rule now lives. Kept as a name here
#: because this module's callers read it; what is gone is the second copy of
#: the fact.
TERMINAL = WorkState.terminal()


@dataclass(slots=True)
class _RunLedger:
    rows: dict[WorkItemId, WorkRow] = field(default_factory=dict)
    leases: dict[WorkItemId, Lease] = field(default_factory=dict)
    #: The attempt ordinal each recorded diagnosis came from.
    diagnosed: dict[WorkItemId, int] = field(default_factory=dict)
    #: The token digest each item's latest attempt was issued, kept after expiry.
    issued: dict[WorkItemId, str] = field(default_factory=dict)
    epoch: int = 1
    clock_floor: int = 0


def released(row: WorkRow) -> WorkRow:
    """What an unfinished lease leaves behind: READY, always.

    One statement, because expiry, rollover and `release` all make this
    transition and copies are how the two sides of one rule come to disagree --
    the argument this module exists to hold, and #217 is what it looks like
    when it is not held.

    No branch on exhaustion, which is D3's refinement of the record's original
    `expire at retry limit -> CANCELLED` edge. Retry exhaustion must append the
    terminal LOGICAL fact for its work kind, and none of these three callers is
    committing a batch, so none of them CAN carry one. A row terminated here
    would be terminal with nothing in the stream saying why and nothing that
    would ever revisit it; left READY it is unclaimable (the acquire guard) but
    still reclaimable, so a crash before the fact commits is recoverable. The
    dispatcher's reclaim step owns the edge that terminates it.
    """

    return replace(row, state=WorkState.READY)


def insert_absent(
    ledger: _RunLedger, run_id: RunId, rows: Iterable[WorkRow]
) -> None:
    """Insert rows that are absent, leaving any that already exist.

    Absent-only, exactly as the durable writer is: enqueue has no authority to
    change a committed row, and a retried commit of the same cohort must not
    fail on its own rows.

    ATOMIC across the batch. A cohort is enqueued as a generation, and a
    half-enqueued generation is the torn state the same-transaction rule exists
    to prevent. SQLite gets this from its transaction; here it has to be
    written, so every row is validated before any row is written. An earlier
    version mutated as it walked and left the valid prefix behind.

    Validated SEQUENTIALLY, though, against what the batch has already
    admitted. Evaluating every row against the PRE-BATCH ledger and then
    applying them made a batch that declares one item twice with different
    bounds succeed, with the second row silently overwriting the first --
    while SQLite, which inserts as it goes inside its transaction, refused the
    same batch. That is a divergence in the one rule this function was rewritten
    to make atomic, and it is the differential oracle that found it, not a law.
    """

    pending: dict[WorkItemId, WorkRow] = {}
    for row in rows:
        admitted = _admissible(ledger, run_id, row, pending)
        if admitted is not None:
            pending[admitted.item] = admitted
    ledger.rows.update(pending)


def _admissible(
    ledger: _RunLedger,
    run_id: RunId,
    row: WorkRow,
    pending: dict[WorkItemId, WorkRow],
) -> WorkRow | None:
    """The row to insert, or None when an identical one already exists.

    ``pending`` is what this batch has admitted so far, which a row must be
    checked against as well as the ledger: two rows for one item inside one
    batch are a conflicting declaration, not a resubmission.
    """

    refuse_inadmissible_enqueue(run_id, row)
    existing = ledger.rows.get(row.item) or pending.get(row.item)
    if existing is None:
        return row
    # Only the columns ENQUEUE AUTHORS. State and attempts belong to the broker,
    # so an item that has moved on is the same item further along.
    if (existing.trial_id, existing.kind, existing.max_attempts) != (
        row.trial_id,
        row.kind,
        row.max_attempts,
    ):
        raise InvalidWorkAppend(
            run_id,
            f"work row {row.item.value} already exists and differs; "
            "enqueue cannot change a committed row",
        )
    return None


def tick(ledger: _RunLedger, now: int) -> int:
    """Read the clock and settle expiry, which every operation does together.

    Paired on purpose: reading the clock without settling expiry would let an
    operation act on a lease the clock has already ended, and that pair is what
    the record means by a precondition read "inside the same transaction".
    """

    clock = advance(ledger, now)
    expire_in_place(ledger, clock)
    return clock


def release_all_leased(ledger: _RunLedger) -> None:
    """Return every leased row, whatever the clock says.

    Rollover's walk, kept beside expiry's because they differ only in what
    selects the rows -- a deadline there, an epoch change here -- and share the
    transition itself.
    """

    for key, _ in list(ledger.leases.items()):
        row = ledger.rows[key]
        if row.state is not WorkState.LEASED:
            continue
        del ledger.leases[key]
        ledger.issued.pop(key, None)
        ledger.rows[key] = released(row)


def advance(ledger: _RunLedger, now: int) -> int:
    """Read the clock once per operation, clamped non-decreasing.

    The clamp is why the broker owns an absolute wall-clock-derived timestamp
    rather than `time.monotonic()`: monotonic's origin is process-relative, so a
    restart rebases it and a persisted deadline becomes meaningless -- the exact
    failure this floor exists to prevent.
    """

    ledger.clock_floor = max(ledger.clock_floor, require_broker_time(now))
    return ledger.clock_floor


def expire_in_place(ledger: _RunLedger, clock: int) -> None:
    """Expiry follows from the clock, never from a caller asking for it.

    The deadline is half-open: a lease at exactly its deadline has expired, so a
    completion arriving then is already too late.

    Always to READY, even with no attempts left. This transition commits no
    batch, so it cannot carry the terminal logical fact the record requires of
    retry exhaustion -- "never a ledger-only edit" -- and terminating the row
    here would make it terminal with nothing in the stream saying why, and
    nothing that would ever revisit it. The acquire guard keeps an exhausted row
    unclaimable in the meantime, and the dispatcher's reclaim step ends it with
    `TerminateWork` alongside the fact, in one commit. A crash in between leaves
    a reclaimable row rather than a permanent silent hole.
    """

    for key, lease in list(ledger.leases.items()):
        row = ledger.rows[key]
        if row.state is not WorkState.LEASED or not lease.expired_at(clock):
            continue
        del ledger.leases[key]
        ledger.rows[key] = released(row)


def item_key(item: WorkItemId) -> str:
    return item.value



def authorised_to_diagnose(ledger: _RunLedger, lease: Lease) -> bool:
    """Whether this submission may write a diagnosis onto the row.

    The in-memory half of the rule `work_leases.authorised_to_diagnose_in_txn`
    states for SQLite; stated twice because one reads a dict and the other a
    SELECT, and compared by the shared contract law
    `check_a_forged_token_cannot_write_a_diagnosis` so the two cannot drift the
    way this module's own comments record them drifting before.

    Weaker than `_live_lease` deliberately -- the diagnosis describes the
    ATTEMPT and must survive the lease expiring -- but not absent, which is
    what guarded the write before: the row was found by item id alone, so any
    caller holding one could overwrite the reason a run records for its work
    dying.
    """

    require_lease(lease)
    recorded = ledger.rows.get(lease.item)
    if recorded is None or recorded.state in WorkState.terminal():
        return False
    # First writer wins per attempt, on every path.
    if ledger.diagnosed.get(lease.item, 0) >= lease.attempt.ordinal:
        return False
    held = ledger.leases.get(lease.item)
    if held is not None:
        return lease.matches_credential(held)
    # Expiry collected the lease. Only the latest attempt may still diagnose,
    # proving the token it was issued.
    digest = ledger.issued.get(lease.item)
    return (
        digest is not None
        and lease.attempt.ordinal == recorded.attempts
        and lease.token.presents(LeaseToken(digest))
    )


def record_diagnosis(
    ledger: _RunLedger, lease: Lease, cause: tuple[str, str]
) -> bool:
    """Write `cause` for `lease`'s attempt if the diagnosis rule allows it."""

    if not authorised_to_diagnose(ledger, lease):
        return False
    ledger.rows[lease.item] = replace(ledger.rows[lease.item], last_failure=cause)
    ledger.diagnosed[lease.item] = lease.attempt.ordinal
    return True


__all__ = [
    "TERMINAL",
    "_RunLedger",
    "advance",
    "authorised_to_diagnose",
    "expire_in_place",
    "release_all_leased",
    "tick",
    "insert_absent",
    "item_key",
    "record_diagnosis",
    "released",
]
