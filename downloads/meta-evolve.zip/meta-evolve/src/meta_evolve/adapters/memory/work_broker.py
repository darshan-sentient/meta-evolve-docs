"""The deterministic in-memory work broker.

The double the tests drive, and it obeys the same contract suite the SQLite one
does -- a double that did not would certify nothing about the real thing.

Deterministic means two things here, both from the record. The clock is
INJECTED: `now` is an argument on every operation, so a deadline is a value a
test sets rather than a race it hopes to win, and no adapter reads a clock
itself. And the clock is CLAMPED NON-DECREASING against a persisted floor, so a
backward step cannot un-expire a lease -- which is why the broker owns an
absolute wall-clock-derived timestamp rather than `time.monotonic()`, whose
origin is process-relative and meaningless across the restart the clamp exists
to survive.

Past the ~300-line guideline: this is one implementation of one port's eight
operations, and each needs the private `_ledger` and `_live_lease` helpers
beside it. The line that crossed the limit was the epoch fence -- one keyword
and one refusal on each of the five writes -- which is exactly the kind of rule
that has to stay visible in every operation it guards.
"""

from __future__ import annotations

from collections.abc import Iterable

import secrets
from dataclasses import replace

from meta_evolve.domain import RunId
from meta_evolve.domain.work import (
    DEFAULT_LEASE_SECONDS,
    FailureStage,
    Lease,
    LeaseToken,
    StaleReason,
    WorkAttemptId,
    WorkItemId,
    WorkRow,
    WorkState,
    require_lease,
    require_broker_time,
    require_lease_seconds,
    require_run_id,
)
from meta_evolve.domain.work_aborts import aborted
from meta_evolve.domain.workers import WorkerRegistration
from meta_evolve.ports.work_submission import ALREADY_ACCEPTED, AlreadyAccepted
from meta_evolve.ports.work_store import refuse_superseded
from meta_evolve.ports.work_submission import status_of

from .work_acceptance import accept
from .work_ledger import (
    _RunLedger,
    advance,
    classify_submission,
    record_diagnosis,
    insert_absent,
    item_key,
    release_all_leased,
    released,
    tick,
)

class InMemoryWorkBroker:
    """One ledger per run, held in memory for the life of the dispatcher."""

    def __init__(self, *, lease_seconds: int = DEFAULT_LEASE_SECONDS) -> None:
        self.lease_seconds = require_lease_seconds(lease_seconds)
        self._ledgers: dict[RunId, _RunLedger] = {}


    def shares_transaction_with(self, other) -> bool:
        """Only this broker: its ledgers live in no other object."""

        return other is self

    # -- reads ------------------------------------------------------------

    def rows(self, run_id: RunId) -> tuple[WorkRow, ...]:
        # Validated even though the lookup below tolerates anything hashable:
        # `.get` bypasses `_ledger`, which is where every other operation's
        # guard lives, so this one answered `()` for a non-`RunId` while its
        # siblings raised. Found by the shared type law, not by inspection --
        # the divergence is exactly the kind a suite driving valid values
        # cannot see.
        run_id = require_run_id(run_id)
        ledger = self._ledgers.get(run_id)
        if ledger is None:
            return ()
        return tuple(ledger.rows[key] for key in sorted(ledger.rows, key=item_key))

    def current_epoch(self, run_id: RunId) -> int:
        return self._ledger(run_id).epoch

    # -- writes -----------------------------------------------------------

    def enqueue(self, run_id: RunId, rows: Iterable[WorkRow]) -> None:
        insert_absent(self._ledger(run_id), run_id, rows)

    def acquire(
        self,
        run_id: RunId,
        worker: WorkerRegistration,
        *,
        now: int,
        item: WorkItemId | None = None,
        epoch: int | None = None,
    ) -> Lease | None:
        """Lease one ready row to ``worker``, or return None.

        None rather than an exception: "nothing to do right now" is an ordinary
        answer for a dispatcher polling a queue, and the record models refusals
        it wants noticed as terminal facts instead. ``item`` narrows the claim
        to one row, which is how a caller claims the row whose inputs it just
        resolved rather than whichever row a sweep has since made claimable.
        """

        if not isinstance(worker, WorkerRegistration):
            raise TypeError("acquire needs a WorkerRegistration")
        ledger = self._ledger(run_id)
        refuse_superseded(run_id, epoch, ledger.epoch)
        clock = tick(ledger, now)

        held = sum(
            1
            for item, lease in ledger.leases.items()
            if lease.worker_id == worker.worker.value
            and lease.generation == worker.generation
            and ledger.rows[item].state is WorkState.LEASED
        )
        if not worker.admits_one_more(currently_held=held):
            return None

        for key in sorted(ledger.rows, key=item_key):
            row = ledger.rows[key]
            if item is not None and row.item != item:
                continue
            if row.state is not WorkState.READY:
                continue
            if row.is_exhausted or aborted(row):  # D7: owed a fact, not an attempt
                continue
            attempt = WorkAttemptId(item=row.item, ordinal=row.attempts + 1)
            lease = Lease(
                item=row.item,
                attempt=attempt,
                worker_id=worker.worker.value,
                generation=worker.generation,
                deadline=clock + self.lease_seconds,
                epoch=ledger.epoch,
                token=LeaseToken.issue(secrets.token_hex(16)),
            )
            ledger.rows[key] = replace(
                row, state=WorkState.LEASED, attempts=row.attempts + 1
            )
            ledger.leases[key] = lease
            ledger.issued[key] = lease.token.digest
            return lease
        return None

    def renew(
        self, run_id: RunId, lease: Lease, *, now: int, epoch: int | None = None
    ) -> Lease | None:
        """Extend a live lease, keeping its credential.

        The dispatcher renews, not the worker: liveness in-process is
        `future.done()`, so the thing that knows a component is still running is
        the side holding the future. A new token would mean a worker in flight
        could no longer prove the lease it was issued.
        """

        answer = self.renew_or_stale(run_id, lease, now=now, epoch=epoch)
        return answer if isinstance(answer, Lease) else None

    def renew_or_stale(
        self, run_id: RunId, lease: Lease, *, now: int, epoch: int | None = None
    ) -> Lease | StaleReason | AlreadyAccepted:
        """Renew a live lease, or answer why not; see the SQLite adapter."""

        ledger = self._ledger(run_id)
        refuse_superseded(run_id, epoch, ledger.epoch)
        clock = tick(ledger, now)
        reason, state = classify_submission(ledger, run_id, lease, clock=clock)
        if reason is not None:
            return reason
        if state is not WorkState.LEASED:
            return ALREADY_ACCEPTED
        renewed = replace(lease, deadline=clock + self.lease_seconds)
        ledger.leases[lease.item] = renewed
        return renewed

    def submission_status(self, run_id: RunId, lease: Lease, *, now: int):
        """Classify without acting: no tick, no floor write, no fence."""

        ledger = self._ledger(run_id)
        clock = max(ledger.clock_floor, require_broker_time(now))
        reason, state = classify_submission(ledger, run_id, lease, clock=clock)
        return status_of(
            reason,
            state is WorkState.COMPLETED,
            lambda: ledger.accepted[lease.item][2],
        )

    def accept_completion(
        self, run_id: RunId, lease: Lease, *, now: int, acknowledgment
    ) -> None:
        """Test-facing twin of the SQLite acceptance intent (`work_acceptance`)."""

        accept(self._ledger(run_id), run_id, lease, now=now,
               acknowledgment=acknowledgment)

    def release(
        self,
        run_id: RunId,
        lease: Lease,
        *,
        now: int,
        failure: tuple[str, str] | None = None,
        epoch: int | None = None,
    ) -> bool:
        """Give a live lease back, spending its attempt. Fact-free.

        The dispatcher calls this when the attempt is dead but the WORK is not:
        an executor task raised, and the retry bound -- not this method -- gets
        to decide whether anything more is owed. Fenced exactly as `renew` is,
        because the same thing is at stake: a lease the caller no longer holds
        must not move the row.

        The transition goes through `released()`, the same statement expiry
        and rollover make -- so it inherits that statement's rule: READY,
        always, never terminal. A row out of attempts lands READY and
        unclaimable, and the terminal LOGICAL fact it owes is the reclaim
        step's to append, never this ledger edit, because the record is
        explicit that a ledger-only edit does not discharge it.
        """

        # BEFORE `lease.item` is touched. `require_lease` says the message
        # "travels with the check", and it did not travel here: this method
        # dereferenced the lease first, so a non-`Lease` raised `AttributeError`
        # while SQLite raised the typed `TypeError` its sibling promises. The
        # contract suite drives both with valid leases, so a guard present in
        # one and missing in the other is invisible to a differential oracle.
        lease = require_lease(lease)
        ledger = self._ledger(run_id)
        refuse_superseded(run_id, epoch, ledger.epoch)
        tick(ledger, now)
        if failure is not None:
            # BEFORE the liveness check, matching the SQLite adapter: the cause
            # describes the ATTEMPT, which happened, not the lease, which may
            # already have expired.
            record_diagnosis(ledger, lease, failure, FailureStage.ATTEMPT)
        if self._live_lease(ledger, lease) is None:
            return False
        released_row = released(ledger.rows[lease.item])
        ledger.rows[lease.item] = released_row
        del ledger.leases[lease.item]
        ledger.issued.pop(lease.item, None)
        return True

    def record_failure(
        self,
        run_id: RunId,
        lease: Lease,
        *,
        now: int,
        cause: tuple[str, str],
        epoch: int | None = None,
    ) -> bool:
        """Record a completion failure's cause under `release`'s diagnosis rule.

        The row keeps its state; see the SQLite adapter.
        """

        lease = require_lease(lease)
        ledger = self._ledger(run_id)
        refuse_superseded(run_id, epoch, ledger.epoch)
        tick(ledger, now)
        return record_diagnosis(ledger, lease, cause, FailureStage.COMPLETION)

    def cancel(
        self, run_id: RunId, item: WorkItemId, *, now: int, epoch: int | None = None
    ) -> None:
        """Terminate a ready or leased row on dispatcher authority.

        A terminal row is left alone rather than refused: cancelling something
        already finished is the dispatcher tidying up after a race it lost, and
        the record has terminal states absorb every lease operation.
        
        Half a transition, as expiry is: cancellation must "append the terminal
        logical fact for their work kind", and that append is the dispatcher's.
        See `work_ledger.expire_in_place` for the same note at the same seam.
        """

        ledger = self._ledger(run_id)
        refuse_superseded(run_id, epoch, ledger.epoch)
        advance(ledger, now)
        row = ledger.rows.get(item)
        if row is None or row.state in WorkState.terminal():
            return
        ledger.rows[item] = replace(row, state=WorkState.CANCELLED)
        ledger.leases.pop(item, None)

    def rollover(self, run_id: RunId) -> int:
        """Bump the epoch and make every prior-epoch lease claimable again.

        An explicit recovery step, not a side effect of restarting: every
        prior-epoch leased row goes back to READY, whether or not attempts
        remain, because `released()` may not terminate a row -- this commits no
        batch, so it cannot carry the terminal fact an exhausted row owes. One
        out of attempts is READY and unclaimable until the reclaim step ends it
        with that fact.

        Terminal rows are untouched, which is what makes the duplicate
        exemption above reachable after a restart.
        """

        ledger = self._ledger(run_id)
        ledger.epoch += 1
        release_all_leased(ledger)
        return ledger.epoch

    # -- internals --------------------------------------------------------

    def _live_lease(self, ledger: _RunLedger, lease: Lease) -> Lease | None:
        """The stored lease this submission is entitled to act on, or None.

        Every precondition the record names for a LIVE lease except the
        deadline: exact item, attempt, worker, token, the current epoch as the
        fence, and the worker's current generation.

        The deadline is deliberately NOT re-checked here. Both callers run
        `_expire_in_place` first, which is where the half-open rule lives, and
        an expired lease is gone from the table by the time this runs. Stating
        it twice made the second statement unreachable -- deleting it left every
        law passing -- and two copies of an expiry rule is how the two sides of
        one come to disagree.
        """

        require_lease(lease)
        held = ledger.leases.get(lease.item)
        if held is None:
            return None
        if ledger.rows[lease.item].state is not WorkState.LEASED:
            return None
        if lease.epoch != ledger.epoch:
            return None
        if lease.credential_mismatch(held) is not None:
            return None
        return held


    def _ledger(self, run_id: RunId) -> _RunLedger:
        if not isinstance(run_id, RunId):
            raise TypeError("run id must be a RunId")
        return self._ledgers.setdefault(run_id, _RunLedger())


__all__ = ["DEFAULT_LEASE_SECONDS", "InMemoryWorkBroker"]

