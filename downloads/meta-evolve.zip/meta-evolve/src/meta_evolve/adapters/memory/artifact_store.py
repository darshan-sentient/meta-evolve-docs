"""In-memory artifact storage."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

from meta_evolve.domain import Artifact, ArtifactId
from meta_evolve.ports.artifact_store import ArtifactConflict, ArtifactNotFound


class InMemoryArtifactStore:
    def __init__(self) -> None:
        self._artifacts: dict[ArtifactId, Artifact] = {}

    def put(self, artifact: Artifact) -> None:
        if not isinstance(artifact, Artifact):
            raise TypeError("artifact must be an Artifact")
        self._artifacts = self._validate(self._artifacts, (artifact,))

    def get(self, artifact_id: ArtifactId) -> Artifact:
        if not isinstance(artifact_id, ArtifactId):
            raise TypeError("artifact id must be an ArtifactId")
        try:
            return self._artifacts[artifact_id]
        except KeyError:
            raise ArtifactNotFound(artifact_id) from None

    def _snapshot(self) -> dict[ArtifactId, Artifact]:
        """Shallow copy of artifact state, for a copy-on-write unit of work.

        Internal contract with ``Storage``'s in-memory ``commit``; not part
        of the ``ArtifactStore`` port.
        """

        return dict(self._artifacts)

    def _validate(
        self,
        artifacts: Mapping[ArtifactId, Artifact],
        candidates: Iterable[Artifact],
    ) -> dict[ArtifactId, Artifact]:
        """Validate prospective puts against ``artifacts`` without mutating
        ``self``. Returns the resulting artifact table if applied; raises
        without any side effect otherwise (including on a within-batch
        conflict between two of ``candidates``).
        """

        updated = dict(artifacts)
        for artifact in candidates:
            if not isinstance(artifact, Artifact):
                raise TypeError("artifact must be an Artifact")
            current = updated.get(artifact.id)
            if current is None:
                updated[artifact.id] = artifact
            elif current != artifact:
                raise ArtifactConflict(artifact.id)
        return updated

    def _install(self, artifacts: dict[ArtifactId, Artifact]) -> None:
        """Swap in new artifact state. Internal to the atomic commit UoW."""
        self._artifacts = artifacts
