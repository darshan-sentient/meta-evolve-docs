"""Read-only artifact and payload-blob adapters for durable inspection."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from meta_evolve.domain import Artifact, ContentDigest
from meta_evolve.errors import CapabilityError, DurableStoreError

from .artifact_store import DurableArtifactStore
from .blob_store import FilesystemBlobStore


class ReadOnlyFilesystemBlobStore(FilesystemBlobStore):
    """Filesystem blob reads whose construction never creates directories."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)

    def put(self, digest: ContentDigest, payload_bytes: bytes) -> None:
        raise CapabilityError("read-only blob storage cannot put")

    def exists(self, digest: ContentDigest) -> bool:
        try:
            return super().exists(digest)
        except OSError as error:
            raise DurableStoreError(
                f"cannot access read-only payload blob {digest}: {error}"
            ) from error

    def get(self, digest: ContentDigest) -> bytes:
        try:
            return super().get(digest)
        except OSError as error:
            raise DurableStoreError(
                f"cannot read payload blob {digest} from read-only storage: {error}"
            ) from error


class ReadOnlyDurableArtifactStore(DurableArtifactStore):
    """Artifact reads with explicit refusal at both exposed write seams."""

    def __init__(self, connection: sqlite3.Connection, artifacts_root: Path) -> None:
        self._conn = connection
        self.blob_store = ReadOnlyFilesystemBlobStore(artifacts_root)

    def put(self, artifact: Artifact) -> None:
        raise CapabilityError("read-only artifact storage cannot put")


__all__ = ["ReadOnlyDurableArtifactStore", "ReadOnlyFilesystemBlobStore"]
