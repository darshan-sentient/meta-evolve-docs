"""Normalize patcher returns without confusing commands with candidates."""

from __future__ import annotations

from collections.abc import Mapping

from meta_evolve.domain.evaluation import Failure, InfrastructureFailure
from meta_evolve.domain.resources import Resources
from meta_evolve.domain.values import FrozenMap
from meta_evolve.ports.callables import ProposalResult
from meta_evolve.ports.patches import PatchResult, TextPatch

from .normalization import (
    _dropped_failure_details,
    _reported_usage,
    _role_failure,
)
from .proposers import _invalid_proposal


def proposal_failure(
    result: PatchResult,
    failure: Failure,
    *,
    derived_from: tuple = (),
) -> ProposalResult:
    return ProposalResult(
        failure=failure,
        hypothesis=result.hypothesis,
        predicted_outcomes=result.predicted_outcomes,
        metadata=result.metadata,
        evidence=result.evidence,
        usage=result.usage.resources,
        derived_from=derived_from,
    )


def infrastructure_result(
    error: Exception,
    *,
    reported_failure: str | None = None,
    prior_result: ProposalResult | None = None,
) -> ProposalResult:
    details: dict[str, object] = {"exception_type": type(error).__name__}
    if reported_failure is not None:
        details["reported_failure"] = reported_failure
    return ProposalResult(
        failure=InfrastructureFailure(
            message=str(error) or type(error).__name__, details=details
        ),
        hypothesis=prior_result.hypothesis if prior_result else None,
        predicted_outcomes=(
            prior_result.predicted_outcomes if prior_result else FrozenMap()
        ),
        metadata=prior_result.metadata if prior_result else FrozenMap(),
        evidence=prior_result.evidence if prior_result else (),
        usage=prior_result.usage if prior_result else Resources(),
    )


def normalize_patch_result(returned: object) -> PatchResult | ProposalResult:
    if isinstance(returned, TextPatch):
        return PatchResult(patch=returned)
    if isinstance(returned, Failure):
        if _role_failure(returned, "proposer") is None:
            return _invalid_proposal(
                "patch proposer returned an evaluator-specific failure",
                details=_dropped_failure_details(returned),
            )
        return PatchResult(failure=returned)
    if not isinstance(returned, PatchResult):
        return _invalid_proposal(
            "patch proposer returned invalid output",
            details={"output_type": type(returned).__name__},
        )
    if returned.failure is not None and (
        _role_failure(returned.failure, "proposer") is None
    ):
        return _invalid_proposal(
            "patch proposer returned an evaluator-specific failure",
            details=_dropped_failure_details(returned.failure),
            hypothesis=returned.hypothesis,
            predicted_outcomes=returned.predicted_outcomes,
            metadata=returned.metadata,
            evidence=returned.evidence,
            usage=returned.usage.resources,
        )
    usage, invalid_counts = _reported_usage(returned.usage)
    if invalid_counts:
        counts: Mapping[str, object] = {
            "evaluations": returned.usage.evaluations,
            "trials": returned.usage.trials,
        }
        return _invalid_proposal(
            "patch usage cannot report trials or evaluations",
            details=(
                counts
                if returned.failure is None
                else _dropped_failure_details(returned.failure, counts)
            ),
            hypothesis=returned.hypothesis,
            predicted_outcomes=returned.predicted_outcomes,
            metadata=returned.metadata,
            evidence=returned.evidence,
            usage=usage.resources,
        )
    if usage == returned.usage:
        return returned
    common = {
        "hypothesis": returned.hypothesis,
        "predicted_outcomes": returned.predicted_outcomes,
        "metadata": returned.metadata,
        "evidence": returned.evidence,
        "usage": usage,
        "derived_from": returned.derived_from,
    }
    if returned.failure is not None:
        return PatchResult(failure=returned.failure, **common)
    return PatchResult(patch=returned.patch, **common)


__all__ = ["infrastructure_result", "normalize_patch_result", "proposal_failure"]
