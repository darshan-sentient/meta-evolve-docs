"""Adapter from ordinary local callables to the decoded-value proposer port."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
import inspect
from typing import Literal

from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.evaluation import Failure, InvalidOutput, ProposerFailure
from meta_evolve.domain.experience_access import ExperienceSpec
from meta_evolve.domain.task import Budget, Objective, Usage
from meta_evolve.domain.values import FrozenMap
from meta_evolve.ports.callables import EvidenceDraft, ProposalResult
from meta_evolve.ports.proposers import ProposerContext
from meta_evolve.ports.runners import validate_run_hook

from .normalization import (
    ESCAPING_EXCEPTIONS,
    _dropped_failure_details,
    _local_component,
    _registered_component,
    _reported_usage,
    _role_failure,
)

# What must never be converted at the proposer boundary. DERIVED, not rebuilt:
# this is exactly `ESCAPING_EXCEPTIONS` -- the infrastructure set plus
# ``CapabilityError``, reserved abort control flow saying the whole run cannot
# proceed (see docs/programming-model.md). Re-deriving the union by hand gave
# it three independent spellings, and the predicate the scheduler asks
# (`escapes_normalization`) reads only one of them.
_PROPOSER_ESCAPE_EXCEPTIONS: tuple[type[BaseException], ...] = ESCAPING_EXCEPTIONS


_InvocationShape = Literal["parent", "parent-context"]


def _invocation_shape(
    fn: Callable[..., object], *, allow_uninspectable: bool
) -> _InvocationShape:
    """Choose one supported proposer spelling without executing user code."""

    try:
        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        if allow_uninspectable:
            return "parent-context"
        raise TypeError("registered proposer signature must be inspectable") from None

    marker = object()
    try:
        signature.bind(marker, marker)
    except TypeError:
        pass
    else:
        return "parent-context"
    try:
        signature.bind(marker)
    except TypeError:
        raise TypeError(
            "proposer must accept (parent, context) or (parent)"
        ) from None
    return "parent"


def _invalid_proposal(
    message: str,
    *,
    details: Mapping[str, object] | FrozenMap = FrozenMap(),
    hypothesis: str | None = None,
    predicted_outcomes: Mapping[str, object] | FrozenMap = FrozenMap(),
    metadata: Mapping[str, object] | FrozenMap = FrozenMap(),
    evidence: tuple[EvidenceDraft, ...] = (),
    usage: Usage = Usage(),
) -> ProposalResult:
    return ProposalResult(
        failure=InvalidOutput(message=message, details=details),
        hypothesis=hypothesis,
        predicted_outcomes=predicted_outcomes,
        metadata=metadata,
        evidence=evidence,
        usage=usage,
    )


@dataclass(frozen=True, slots=True, init=False)
class CallableProposer:
    component: ComponentRef
    _fn: Callable[..., object] = field(repr=False, compare=False)
    _invocation: _InvocationShape = field(repr=False, compare=False)
    _validator: Callable[..., object] | None = field(repr=False, compare=False)

    def __init__(self, proposer: ComponentRef | Callable[..., object]) -> None:
        component = _local_component(proposer, "proposer")
        retained = component.adapter
        assert retained is not None
        # ``ComponentRef`` guarantees a local proposer adapter is callable or
        # implements ``propose``, so one of these two always resolves.
        fn = retained if callable(retained) else getattr(retained, "propose")
        object.__setattr__(self, "component", component)
        object.__setattr__(self, "_fn", fn)
        object.__setattr__(
            self, "_invocation", _invocation_shape(fn, allow_uninspectable=True)
        )
        object.__setattr__(self, "_validator", validate_run_hook(retained))

    @classmethod
    def registered(
        cls, ref: ComponentRef, fn: Callable[..., object]
    ) -> "CallableProposer":
        """Bind ``fn`` (resolved from a ``Registry``) to a registered ref.

        ``fn`` is held only by this adapter instance -- ``ref`` (and the
        durable records built from it) never carries an adapter.
        """

        component = _registered_component(ref, fn, "proposer")
        instance = object.__new__(cls)
        object.__setattr__(instance, "component", component)
        object.__setattr__(instance, "_fn", fn)
        object.__setattr__(
            instance, "_invocation", _invocation_shape(fn, allow_uninspectable=False)
        )
        object.__setattr__(instance, "_validator", validate_run_hook(fn))
        return instance

    @classmethod
    def declared(
        cls, ref: ComponentRef, fn: Callable[..., object]
    ) -> "CallableProposer":
        """Bind a structural proposer's live methods to its local declaration.

        The optional ``validate_run`` hook is discovered from the retained
        object, so hook lookup has exactly one implementation.
        """

        if not isinstance(ref, ComponentRef) or ref.role != "proposer":
            raise TypeError(
                "declared proposer requires a proposer component reference"
            )
        if ref.origin != "local":
            raise ValueError(
                "declared proposer requires a local component reference"
            )
        if ref.adapter is None:
            raise ValueError(
                "declared proposer component reference has no retained adapter"
            )
        if not callable(fn):
            raise TypeError("declared proposer propose must be callable")
        instance = object.__new__(cls)
        object.__setattr__(instance, "component", ref)
        object.__setattr__(instance, "_fn", fn)
        object.__setattr__(
            instance, "_invocation", _invocation_shape(fn, allow_uninspectable=True)
        )
        object.__setattr__(instance, "_validator", validate_run_hook(ref.adapter))
        return instance

    def validate_run(
        self,
        *,
        artifact_kind: str,
        artifact_representation: str,
        objectives: tuple[Objective, ...],
        budget: Budget,
        experience: ExperienceSpec | None,
    ) -> None:
        if self._validator is not None:
            self._validator(
                artifact_kind=artifact_kind,
                artifact_representation=artifact_representation,
                objectives=objectives,
                budget=budget,
                experience=experience,
            )

    def propose(
        self, parent: object, context: ProposerContext
    ) -> ProposalResult:
        try:
            if self._invocation == "parent-context":
                returned = self._fn(parent, context)
            else:
                returned = self._fn(parent)
        except _PROPOSER_ESCAPE_EXCEPTIONS:
            # A proposer may drive the audited experience reader, whose audit
            # appends commit through ``commit_batch`` -> ``storage.commit``: an
            # infra fault raised there propagates (durable-local propagates
            # everything), leaving exactly the unresolved-attempt state the
            # reader roll-forward completes on resume. A native adapter escapes
            # the same way when provider work may have started but exact
            # accounting is unavailable -- recording a logical failure would
            # understate usage and imply a resumable local outcome. What does
            # NOT escape is a user proposer's OWN ``OSError`` (a proposer that
            # reads a file or the network): that is a genuine logical error, and
            # falls through to a recoverable ``ProposerFailure`` rather than
            # wedging the run. A ``CapabilityError`` escapes for the opposite
            # reason -- an ordinary proposer that drives a provider run one
            # level down meets the same refused preflight for every parent, so
            # retrying it against the rest of the budget could only fail again.
            raise
        except Exception as error:
            return ProposalResult(
                failure=ProposerFailure(
                    message=str(error) or type(error).__name__,
                    details={"exception_type": type(error).__name__},
                )
            )
        return self._normalize(returned)

    @staticmethod
    def _normalize(returned: object) -> ProposalResult:
        if isinstance(returned, Failure):
            if _role_failure(returned, "proposer") is None:
                return _invalid_proposal(
                    "proposer returned an evaluator-specific failure",
                    details=_dropped_failure_details(returned),
                )
            try:
                return ProposalResult(failure=returned)
            except (TypeError, ValueError) as error:
                return _invalid_proposal(
                    "proposer returned an unsupported failure",
                    details=_dropped_failure_details(
                        returned, {"error": str(error)}
                    ),
                )

        if isinstance(returned, ProposalResult):
            usage, invalid_counts = _reported_usage(returned.usage)
            if invalid_counts:
                counts: Mapping[str, object] = {
                    "evaluations": returned.usage.evaluations,
                    "trials": returned.usage.trials,
                }
                return _invalid_proposal(
                    "callable usage cannot report trials or evaluations",
                    details=(
                        counts
                        if returned.failure is None
                        else _dropped_failure_details(returned.failure, counts)
                    ),
                    hypothesis=returned.hypothesis,
                    predicted_outcomes=returned.predicted_outcomes,
                    metadata=returned.metadata,
                    evidence=returned.evidence,
                    usage=usage,
                )
            if returned.failure is not None:
                if _role_failure(returned.failure, "proposer") is None:
                    return _invalid_proposal(
                        "proposer returned an evaluator-specific failure",
                        details=_dropped_failure_details(returned.failure),
                        hypothesis=returned.hypothesis,
                        predicted_outcomes=returned.predicted_outcomes,
                        metadata=returned.metadata,
                        evidence=returned.evidence,
                        usage=usage,
                    )
                return ProposalResult(
                    failure=returned.failure,
                    hypothesis=returned.hypothesis,
                    predicted_outcomes=returned.predicted_outcomes,
                    metadata=returned.metadata,
                    evidence=returned.evidence,
                    usage=usage,
                    derived_from=returned.derived_from,
                )
            return ProposalResult(
                candidate=returned.candidate,
                hypothesis=returned.hypothesis,
                predicted_outcomes=returned.predicted_outcomes,
                metadata=returned.metadata,
                evidence=returned.evidence,
                usage=usage,
                derived_from=returned.derived_from,
            )

        # A candidate is carried through as the value the proposer returned.
        # Whether it can become a durable payload is the registered codec's
        # question, answered where the task's kind and representation are
        # known; an unencodable candidate becomes the same typed
        # ``InvalidOutput`` trial outcome there.
        return ProposalResult(candidate=returned)


__all__ = ["CallableProposer"]
