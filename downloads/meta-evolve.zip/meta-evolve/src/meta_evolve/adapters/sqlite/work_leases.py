"""The durable broker's clock, its expiry rule and its lease preconditions.

Split from `work_broker.py` for the same reason the in-memory broker has
`work_ledger.py` beside it: this module is the state and the one rule that
changes it without anybody asking -- expiry -- while the broker is the
operations a caller invokes. Keeping expiry here is what lets it be stated once
per adapter.

Every function assumes a transaction is already open. The record requires each
acquire, renew and complete precondition to be read "inside the same
transaction" as the write, so none of these opens one of its own.
"""

from __future__ import annotations


from meta_evolve.domain import RunId
from meta_evolve.errors import DurableCorruption
from meta_evolve.domain.work import (
    Lease,
    LeaseToken,
    StaleReason,
    WorkState,
    require_broker_time,
    require_lease,
)
from meta_evolve.domain.work_staleness import stale_reason_for
from meta_evolve.ports.work_store import InvalidWorkAppend, refuse_superseded

from .work_rows import lease_from

def epoch_in_txn(conn, run_id: RunId) -> tuple[int, int]:
    found = conn.execute(
        "SELECT epoch, observed_clock FROM work_epoch WHERE run_id=?",
        (run_id.value,),
    ).fetchone()
    return (1, 0) if found is None else (found[0], found[1])

def advance_in_txn(
    conn, run_id: RunId, now: int, *, held: int | None = None
) -> tuple[int, int]:
    """Read the clock once per transaction, clamped non-decreasing.

    And the epoch fence, BEFORE the clock floor is written: every broker write
    opens here, in its own transaction, so a caller holding a superseded epoch
    is refused before it has changed anything.

    Persisted rather than held in memory, which is the whole reason the
    broker owns an absolute wall-clock-derived timestamp: a restart reloads
    this floor, so a backward step cannot un-expire a lease across one.
    """

    now = require_broker_time(now)
    epoch, floor = epoch_in_txn(conn, run_id)
    refuse_superseded(run_id, held, epoch)
    clock = max(floor, now)
    conn.execute(
        "INSERT INTO work_epoch(run_id, epoch, observed_clock) VALUES(?,?,?)"
        " ON CONFLICT(run_id) DO UPDATE SET observed_clock=excluded.observed_clock",
        (run_id.value, epoch, clock),
    )
    return epoch, clock

def leases_in_txn(conn, run_id: RunId):
    return conn.execute(
        "SELECT item_id, lease_json FROM work_items"
        " WHERE run_id=? AND state=? AND lease_json IS NOT NULL",
        (run_id.value, WorkState.LEASED.value),
    ).fetchall()

# What an unfinished lease leaves behind, as one SQL fragment. Expiry,
# rollover and `release` all make this transition; copies of it are how the two
# sides of one rule come to disagree.
#
# READY unconditionally, with no exhaustion branch -- see `released()` in the
# in-memory ledger for the argument. Neither adapter may terminate a row from a
# transition that commits no batch and so cannot carry the terminal fact.
RELEASE_SQL = "UPDATE work_items SET state=?, lease_json=NULL"


def expire_in_txn(conn, run_id: RunId, clock: int) -> None:
    """Apply the half-open deadline to every live lease in this run.

    The rule itself is `Lease.expired_at` -- one statement, on the value it is
    about, asked by this sweep, by the in-memory one, and by the acceptance
    precondition. This module used to compare `clock < deadline` itself, which
    made it the second of what would have become three copies.

    Always to READY, never terminal: an exhausted row is left unclaimable for
    the dispatcher's reclaim step, which is the only place the terminal fact
    can ride a logical commit.
    """

    for item_id, stored_lease in leases_in_txn(conn, run_id):
        if not lease_from(item_id, stored_lease).expired_at(clock):
            continue
        conn.execute(
            RELEASE_SQL + " WHERE run_id=? AND item_id=?",
            (WorkState.READY.value, run_id.value, item_id),
        )

def live_lease_in_txn(
    conn, run_id: RunId, lease: Lease, epoch: int
) -> Lease | None:
    """Every precondition for a LIVE lease except the deadline.

    The deadline is not re-checked here for the same reason it is not in the
    in-memory broker: `_expire_in_txn` runs first and has already cleared an
    expired lease, and two copies of an expiry rule is how the two sides of
    one come to disagree.
    """

    require_lease(lease)
    if lease.epoch != epoch:
        return None
    found = conn.execute(
        "SELECT lease_json FROM work_items"
        " WHERE run_id=? AND item_id=? AND state=? AND lease_json IS NOT NULL",
        (run_id.value, lease.item.value, WorkState.LEASED.value),
    ).fetchone()
    if found is None:
        return None
    held = lease_from(lease.item.value, found[0])
    if lease.credential_mismatch(held) is not None:
        return None
    return held


def classify_submission_in_txn(
    conn, run_id: RunId, lease: Lease, *, epoch: int, clock: int
) -> tuple[StaleReason | None, WorkState, str | None]:
    """Read the row `lease` is presented at, and ask `stale_reason_for` about it.

    Answers the reason (or `None`), the row's state, and -- for a `COMPLETED`
    row -- its stored acknowledgment, so a caller can tell a live lease from a
    duplicate and replay the latter. Acceptance and `renew_or_stale` both
    classify through this, so the columns read, the damage refused and the
    fields handed to the rule are stated once.

    An item this run does not hold raises `InvalidWorkAppend`: a contract
    violation, not a stale submission. A row the record says cannot exist -- a
    `COMPLETED` row missing its acceptance, a `LEASED` row missing its lease, a
    malformed digest -- raises `DurableCorruption`.
    """

    require_lease(lease)
    item = lease.item.value
    found = conn.execute(
        "SELECT state, lease_json, attempts, last_lease_token_digest,"
        " accepted_attempt, accepted_token_digest, acknowledgment_json"
        " FROM work_items WHERE run_id=? AND item_id=?",
        (run_id.value, item),
    ).fetchone()
    if found is None:
        raise InvalidWorkAppend(
            run_id,
            f"work item {item} is not held by this run, so no lease was ever "
            "issued for it here",
        )
    raw_state, stored, attempts, issued, accepted_attempt, accepted_digest, ack = found
    try:
        state = WorkState(raw_state)
    except ValueError as error:
        raise DurableCorruption(
            f"work item {item} stores an unknown state {raw_state!r}"
        ) from error

    accepted_token = None
    if state is WorkState.COMPLETED:
        if None in (accepted_attempt, accepted_digest, ack):
            raise DurableCorruption(
                f"work item {item} is COMPLETED without its accepted attempt, "
                "token digest and acknowledgment"
            )
        if (
            not isinstance(accepted_attempt, int)
            or isinstance(accepted_attempt, bool)
            or accepted_attempt < 1
        ):
            raise DurableCorruption(
                f"work item {item} stores a malformed accepted attempt"
            )
        accepted_token = _stored_token(item, accepted_digest, "token digest")

    held = None
    if state is WorkState.LEASED:
        if stored is None:
            raise DurableCorruption(
                f"work item {item} is LEASED without the lease that justifies it"
            )
        held = lease_from(item, stored)

    reason = stale_reason_for(
        lease,
        state=state,
        held=held,
        attempts=attempts,
        verifier=None if issued is None else _stored_token(item, issued, "lease verifier"),
        accepted_attempt=accepted_attempt,
        accepted_token=accepted_token,
        current_epoch=epoch,
        clock=clock,
    )
    return reason, state, ack


def _stored_token(item: str, digest, what: str) -> LeaseToken:
    """A stored digest as the verifier it is, or `DurableCorruption` naming it."""

    try:
        return LeaseToken(digest)
    except (ValueError, TypeError) as error:
        raise DurableCorruption(
            f"work item {item} stores a malformed {what}"
        ) from error


__all__ = [
    "RELEASE_SQL",
    "advance_in_txn",
    "authorised_to_diagnose_in_txn",
    "classify_submission_in_txn",
    "epoch_in_txn",
    "expire_in_txn",
    "leases_in_txn",
    "live_lease_in_txn",
]


def authorised_to_diagnose_in_txn(conn, run_id: RunId, lease: Lease) -> bool:
    """Whether this submission may write a diagnosis onto the row.

    Weaker than `live_lease_in_txn` on purpose, and stronger than nothing --
    which is what guarded the write before. The diagnosis describes the
    ATTEMPT, so it must survive the lease expiring; but "before the liveness
    check" is not "without a credential", and the statement was predicated on
    `(run_id, item_id)` alone.

    First writer wins per attempt on every path. Then two cases, because the
    expiry sweep has already run by the time this is asked:

    * a lease is still HELD -- the presented one must match it, token and all;
    * none is held, because expiry collected it -- only the row's latest
      attempt may diagnose, and its token must prove against the digest that
      attempt was issued (`last_lease_token_digest`, kept through expiry). A
      row with no stored digest refuses.
    """

    require_lease(lease)
    found = conn.execute(
        "SELECT lease_json, attempts, state, last_failure_attempt,"
        " last_lease_token_digest FROM work_items"
        " WHERE run_id=? AND item_id=?",
        (run_id.value, lease.item.value),
    ).fetchone()
    if found is None:
        return False
    stored, attempts, state, diagnosed, issued = found
    # A terminal row already carries its terminal fact; nothing rewrites it.
    if state in {terminal.value for terminal in WorkState.terminal()}:
        return False
    # Both stored attempts are validated before either decides, so a damaged
    # count is reported whatever the diagnosis says.
    if not isinstance(attempts, int) or attempts < 0:
        raise DurableCorruption(
            f"work item {lease.item.value} stores a malformed attempt count"
        )
    if diagnosed is not None and not isinstance(diagnosed, int):
        raise DurableCorruption(
            f"work item {lease.item.value} stores a non-integer diagnosis attempt"
        )
    if diagnosed is not None and diagnosed >= lease.attempt.ordinal:
        return False
    if stored is not None:
        return lease.credential_mismatch(lease_from(lease.item.value, stored)) is None
    return lease.proves_latest_attempt(
        attempts, LeaseToken(issued) if isinstance(issued, str) else None
    )
