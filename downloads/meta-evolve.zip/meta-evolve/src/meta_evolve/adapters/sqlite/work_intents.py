"""Apply one work intent to the table, inside the caller's transaction.

Split from ``work_rows.py``, which now answers only "what does a row look like
in SQLite" -- encoding, decoding and the absent-only insert. This module answers
the other question: which transitions are legal, and what must be true for one
to happen. They divide cleanly because the preconditions here are about the
record's state machine, not about storage, and because the row vocabulary has
readers (``work_leases.py``) that have no business with intents at all.
"""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.domain.work import LeaseToken, WorkState
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.work_store import (
    AcceptCompletion,
    Acknowledgment,
    EnqueueWork,
    InvalidWorkAppend,
    TerminateWork,
)

from .work_leases import advance_in_txn
from .work_rows import _put_work_in_txn, lease_from

class DuplicateCompletion(Exception):
    """A completion that already landed, raised to short-circuit the commit.

    It exists because the duplicate must make the WHOLE commit a no-op, not
    merely decline to rewrite the row: a duplicate that returned normally would
    let its batch's events append a second time -- the same objection that
    defers the stale half to M11.3.

    Two claims this docstring used to make are now false and are corrected
    rather than left to rot. It said the exception is "never seen by a caller":
    nothing in `src` catches it, so it propagates out through `Storage.commit`
    to `commit_batch`'s caller, which is deliberate -- `unit_of_work.py` argues
    at length that swallowing it reported success while the rollback discarded
    everything else riding the batch. And it said `commit` "applies intents and
    then appends unconditionally"; the order is now the reverse, because the
    append carries the optimistic-concurrency check and a stale commit must
    hear `EventStreamConflict` rather than an intent refusal. The rollback is
    what makes this a no-op either way.
    """

    def __init__(self, item, acknowledgment: Acknowledgment | None = None) -> None:
        super().__init__(item.value)
        self.item = item
        # The stored bytes, replayed rather than recomputed. This is what makes
        # `acknowledgment_json` a column production code READS: it was written
        # once and read by nothing, while `Acknowledgment`'s docstring promised
        # it "replays to a duplicate submission".
        #
        self.acknowledgment = acknowledgment


def apply_intent_in_txn(conn, intent, *, run_id: RunId) -> None:
    """Apply one work intent, validating its preconditions in this transaction.

    The dispatch is a small closed set on purpose: a new intent is a new work
    transition, and the record's state machine has few. Each applier raises
    rather than returning a status, because a failed precondition must abort the
    whole commit -- the batch this intent rides with is not a valid stream
    without it.
    """

    if isinstance(intent, EnqueueWork):
        _put_work_in_txn(conn, intent.row, run_id=run_id)
        return
    if isinstance(intent, AcceptCompletion):
        _accept_completion_in_txn(conn, intent, run_id=run_id)
        return
    if isinstance(intent, TerminateWork):
        _terminate_work_in_txn(conn, intent, run_id=run_id)
        return
    raise TypeError(f"unknown work intent: {type(intent).__name__}")


def _accept_completion_in_txn(conn, intent, *, run_id: RunId) -> None:
    """`LEASED` -> `COMPLETED`, fenced on the lease that earned it.

    All four preconditions the record's state table states, checked here rather
    than in prose: exact worker, attempt, fence and token, and before the
    deadline. Three of them were missing while acceptance lived on an intent
    with nothing but the attempt and token to match against.

    Every check runs INSIDE the writing transaction, which is the whole reason
    acceptance moved off the broker: a precondition verified before the commit
    would be a TOCTOU on exactly the property the record wants fenced. The
    dispatcher's keepalive is a pre-flight that produces a good error message;
    this is the check that actually decides.
    """

    found = conn.execute(
        "SELECT state, lease_json, accepted_attempt, accepted_token_digest,"
        " acknowledgment_json FROM work_items WHERE run_id=? AND item_id=?",
        (run_id.value, intent.item.value),
    ).fetchone()
    if found is not None and found[0] == WorkState.COMPLETED.value:
        # The record's terminal duplicate exemption. A COMPLETED item is a
        # STORED FACT, not a live lease, so the lookup checks the accepted
        # attempt and its token and deliberately NOT epoch, generation or
        # deadline: a dispatcher that restarted between committing and
        # answering carries a bumped epoch, and answering it "stale" would lose
        # a completion that actually landed.
        #
        # Anything else reaching a terminal row is not a duplicate and still
        # refuses. The token is PROVED against the stored verifier, as on the
        # live path below: a digest read from the row carries no secret.
        if None in found[2:5]:
            raise DurableCorruption(
                f"work item {intent.item.value} is COMPLETED without its accepted "
                "attempt, token digest and acknowledgment"
            )
        if not isinstance(found[2], int) or isinstance(found[2], bool) or found[2] < 1:
            raise DurableCorruption(
                f"work item {intent.item.value} stores a malformed accepted attempt"
            )
        try:
            accepted = LeaseToken(found[3])
        except ValueError as error:
            raise DurableCorruption(
                f"work item {intent.item.value} stores a malformed token digest"
            ) from error
        if found[2] != intent.lease.attempt.ordinal or not (
            intent.lease.token.presents(accepted)
        ):
            raise InvalidWorkAppend(
                run_id,
                f"work item {intent.item.value} is already completed under a "
                "different attempt",
            )
        try:
            acknowledgment = Acknowledgment.from_content(found[4])
        except (ValueError, TypeError) as error:
            raise DurableCorruption(
                f"work item {intent.item.value} stores a malformed acknowledgment"
            ) from error
        raise DuplicateCompletion(intent.item, acknowledgment)
    if found is None or found[0] != WorkState.LEASED.value or found[1] is None:
        raise InvalidWorkAppend(
            run_id, f"work item {intent.item.value} holds no live lease"
        )
    held = lease_from(intent.item.value, found[1])
    # `matches_credential`, never a fourth copy of the comparison -- and this
    # path WAS that copy. It spelled the four-tuple out with `==`, and
    # `LeaseToken.secret` is `compare=False`, so a token rebuilt from the
    # stored digest compared EQUAL to the issued credential. That is the whole
    # authority boundary `presents()` exists to draw: storage holds a verifier,
    # not a credential, and anyone able to READ a work row could forge a
    # submission this branch accepted. Measured on the type: `rebuilt ==
    # issued` is True while `rebuilt.presents(issued)` is False.
    #
    # `matches_credential` proves the token instead of comparing it, and covers
    # the attempt, the worker and the generation in the same statement -- which
    # is why its own docstring says a copied rule is how two sides of one rule
    # come to disagree. This was that disagreement.
    if not intent.lease.matches_credential(held):
        raise InvalidWorkAppend(
            run_id,
            f"work item {intent.item.value} was completed by a superseded "
            "attempt, another worker, a stale generation, or without the "
            "lease credential",
        )
    if held.epoch != intent.lease.epoch:
        raise InvalidWorkAppend(
            run_id,
            f"work item {intent.item.value} was completed behind the fence: "
            f"epoch {intent.lease.epoch}, held {held.epoch}",
        )
    # Half-open, and the rule is `Lease.expired_at` rather than a fourth copy
    # of the comparison. The clock reading is CLAMPED to the broker's
    # non-decreasing floor first. Its siblings pair that with `expire_in_txn`;
    # acceptance deliberately does NOT, because expiry would release the very
    # row being accepted. Acceptance was the one operation that read a sample
    # without clamping it, so a `now` taken before a slow write could assert a
    # deadline that had already passed. `advance_in_txn` both clamps and
    # records, so a later reader sees the time this decision was made against.
    _epoch, clock = advance_in_txn(conn, run_id, intent.now)
    if held.expired_at(clock):
        raise InvalidWorkAppend(
            run_id,
            f"work item {intent.item.value} was completed at or after its "
            f"lease deadline ({clock} >= {held.deadline})",
        )
    conn.execute(
        "UPDATE work_items SET state=?, lease_json=NULL, accepted_attempt=?,"
        " accepted_token_digest=?, acknowledgment_json=?"
        " WHERE run_id=? AND item_id=?",
        (
            WorkState.COMPLETED.value,
            intent.lease.attempt.ordinal,
            intent.lease.token.digest,
            intent.acknowledgment.content,
            run_id.value,
            intent.item.value,
        ),
    )


def cancel_row_in_txn(conn, item, *, run_id: RunId) -> None:
    """`READY`/`LEASED` -> `CANCELLED`, beside its terminal logical fact.

    A terminal row is left alone rather than refused: cancelling something
    already finished is the dispatcher tidying up after a race it lost, and the
    record has terminal states absorb every lease operation.

    Takes the ITEM rather than an intent, so the broker's `cancel` and
    `TerminateWork` share one statement. They were the same UPDATE with the
    same guard written twice -- and the copy in the broker spelled the terminal
    pair through a local `_TERMINAL` while this one inlined the two states, so
    the two ways of saying it could drift apart without either moving.
    """

    conn.execute(
        "UPDATE work_items SET state=?, lease_json=NULL"
        " WHERE run_id=? AND item_id=? AND state NOT IN (?, ?)",
        (
            WorkState.CANCELLED.value,
            run_id.value,
            item.value,
            *[state.value for state in WorkState.terminal()],
        ),
    )


__all__ = ["DuplicateCompletion", "apply_intent_in_txn", "cancel_row_in_txn"]


def _terminate_work_in_txn(conn, intent, *, run_id: RunId) -> None:
    """`READY` + attempts exhausted -> `CANCELLED`, which is reclaim's row.

    Not `cancel_row_in_txn` alone. That statement is shared with
    `WorkBroker.cancel`, whose contract genuinely is "cancel whatever is
    there" -- an operator or the dispatcher asked, and the authority is the
    ask. Reclaim has no such authority: it is the step that gives an exhausted
    row its terminal fact, and the design table gives it the narrower
    transition. Sharing the statement silently dropped both preconditions, so
    an intent could terminate a freshly enqueued row with every attempt intact
    and discard work nothing had tried.

    Validated HERE, inside the writing transaction, because `TerminateWork`
    carries only the item and a reason -- there is nowhere else the state and
    the attempt count can be read without a TOCTOU on exactly the property the
    record wants serialized.
    """

    found = conn.execute(
        "SELECT state, attempts, max_attempts FROM work_items"
        " WHERE run_id=? AND item_id=?",
        (run_id.value, intent.item.value),
    ).fetchone()
    if found is None:
        raise InvalidWorkAppend(
            run_id, f"work row {intent.item.value} does not exist"
        )
    state, attempts, max_attempts = found
    if state != WorkState.READY.value:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} is {state}, and reclaim terminates "
            "only a READY row; a live lease is ended by expiry, not by an "
            "intent",
        )
    if attempts < max_attempts:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} has {max_attempts - attempts} of "
            f"{max_attempts} attempts left; reclaim terminates only an "
            "exhausted row",
        )
    cancel_row_in_txn(conn, intent.item, run_id=run_id)
