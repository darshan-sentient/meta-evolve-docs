"""Apply one work intent to the table, inside the caller's transaction.

Split from ``work_rows.py``, which now answers only "what does a row look like
in SQLite" -- encoding, decoding and the absent-only insert. This module answers
the other question: which transitions are legal, and what must be true for one
to happen. They divide cleanly because the preconditions here are about the
record's state machine, not about storage, and because the row vocabulary has
readers (``work_leases.py``) that have no business with intents at all.

The dispatch lives here; the appliers do not all have to. Acceptance stays,
because it is the one with a live lease and it is most of the file. The two
ENDINGS -- a row out of attempts, a row whose diagnosis says a re-run cannot
help -- are ``work_endings.py``, together, because they are one decision read
two ways and each must refuse what the other accepts.
"""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.domain.work import WorkState
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.work_store import (
    AbortWork,
    AcceptCompletion,
    Acknowledgment,
    EnqueueWork,
    RequireEpoch,
    TerminateWork,
    refuse_superseded,
)
from meta_evolve.ports.work_submission import DuplicateCompletion, StaleCompletion

from .work_endings import abort_work_in_txn, terminate_work_in_txn
from .work_leases import advance_in_txn, classify_submission_in_txn, epoch_in_txn
from .work_rows import _put_work_in_txn

def apply_intent_in_txn(conn, intent, *, run_id: RunId) -> None:
    """Apply one work intent, validating its preconditions in this transaction.

    The dispatch is a small closed set on purpose: a new intent is a new work
    transition, and the record's state machine has few. Each applier raises
    rather than returning a status, because a failed precondition must abort the
    whole commit -- the batch this intent rides with is not a valid stream
    without it.
    """

    if isinstance(intent, EnqueueWork):
        _put_work_in_txn(conn, intent.row, run_id=run_id)
        return
    if isinstance(intent, AcceptCompletion):
        _accept_completion_in_txn(conn, intent, run_id=run_id)
        return
    if isinstance(intent, TerminateWork):
        terminate_work_in_txn(conn, intent, run_id=run_id)
        return
    if isinstance(intent, AbortWork):
        abort_work_in_txn(conn, intent, run_id=run_id)
        return
    if isinstance(intent, RequireEpoch):
        # Against the epoch the store holds NOW, in this transaction -- never
        # against a lease's epoch, which says when the lease was issued, not
        # who is driving the run.
        current, _clock = epoch_in_txn(conn, run_id)
        refuse_superseded(run_id, intent.epoch, current)
        return
    raise TypeError(f"unknown work intent: {type(intent).__name__}")


def _accept_completion_in_txn(conn, intent, *, run_id: RunId) -> None:
    """`LEASED` -> `COMPLETED`, fenced on the lease that earned it.

    Every check runs INSIDE the writing transaction, which is the whole reason
    acceptance moved off the broker: a precondition verified before the commit
    would be a TOCTOU on exactly the property the record wants fenced. The
    dispatcher's keepalive is a pre-flight; this is the check that decides.

    Three answers besides acceptance, each unwinding the commit:

    * an item this run does not hold -- `InvalidWorkAppend`, a contract
      violation: no lease was ever issued for it here;
    * the accepted attempt presenting a token that proves the stored digest --
      `DuplicateCompletion`, replaying the stored acknowledgment. The record's
      terminal exemption, so epoch and generation are deliberately unchecked;
    * anything else -- `StaleCompletion`, naming the ONE reason
      `stale_reason_for` reports. That function holds the order the reasons are
      checked in; this applier only reads the row it needs.

    The clock is CLAMPED to the broker's floor before anything is compared, and
    deliberately not followed by an expiry sweep: sweeping would release the very
    row being accepted. So a past-deadline lease is still `LEASED` here, and is
    reported `EXPIRED` against its held deadline.
    """

    epoch, clock = advance_in_txn(conn, run_id, intent.now)
    reason, state, ack = classify_submission_in_txn(
        conn, run_id, intent.lease, epoch=epoch, clock=clock
    )
    if reason is not None:
        raise StaleCompletion(intent.item, reason)
    if state is WorkState.COMPLETED:
        try:
            acknowledgment = Acknowledgment.from_content(ack)
        except (ValueError, TypeError) as error:
            raise DurableCorruption(
                f"work item {intent.item.value} stores a malformed acknowledgment"
            ) from error
        raise DuplicateCompletion(intent.item, acknowledgment)
    conn.execute(
        "UPDATE work_items SET state=?, lease_json=NULL, accepted_attempt=?,"
        " accepted_token_digest=?, acknowledgment_json=?"
        " WHERE run_id=? AND item_id=?",
        (
            WorkState.COMPLETED.value,
            intent.lease.attempt.ordinal,
            intent.lease.token.digest,
            intent.acknowledgment.content,
            run_id.value,
            intent.item.value,
        ),
    )


__all__ = ["apply_intent_in_txn"]

