"""SQLite implementation of the EventStore port."""

from __future__ import annotations

import sqlite3
from collections.abc import Iterable
from hashlib import sha256

from meta_evolve import serialization
from meta_evolve.domain import EventEnvelope, RunId
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.event_store import EventStreamConflict, InvalidEventAppend

from .connection import transaction


class SqliteEventStore:
    """The ``EventStore`` port over one shared SQLite connection.

    ``append`` opens its own transaction via :func:`transaction`; its body
    is factored into :meth:`_append_in_txn`, a private no-transaction helper
    that assumes a transaction is already open. ``Storage.commit`` calls
    that same helper directly, inside its own single outer transaction that
    also writes artifact occurrence rows — the public ``append`` is never
    called by ``commit`` (no nested ``BEGIN``).
    """

    def __init__(self, connection: sqlite3.Connection) -> None:
        self._conn = connection

    def append(
        self,
        run_id: RunId,
        expected_version: int,
        events: Iterable[EventEnvelope],
    ) -> int:
        if not isinstance(run_id, RunId):
            raise TypeError("event stream run id must be a RunId")
        _require_position(expected_version, "expected version")
        pending = tuple(events)
        with transaction(self._conn):
            return self._append_in_txn(run_id, expected_version, pending)

    def _append_in_txn(
        self,
        run_id: RunId,
        expected_version: int,
        pending: tuple[EventEnvelope, ...],
    ) -> int:
        """Validate and insert ``pending`` for ``run_id``. Assumes a
        transaction is already open on ``self._conn`` (via :func:`transaction`
        in ``append``, or the caller's own outer transaction in
        ``Storage.commit``)."""

        actual = self._version_in_txn(run_id)
        if expected_version != actual:
            raise EventStreamConflict(run_id, expected_version, actual)
        if not pending:
            raise InvalidEventAppend(run_id, "append must contain at least one event")
        rows = []
        for offset, envelope in enumerate(pending, start=1):
            if not isinstance(envelope, EventEnvelope):
                raise InvalidEventAppend(run_id, "all appended items must be events")
            if envelope.run_id != run_id:
                raise InvalidEventAppend(
                    run_id, f"event at batch position {offset} belongs to another run"
                )
            required_sequence = expected_version + offset
            if envelope.sequence != required_sequence:
                raise InvalidEventAppend(
                    run_id,
                    f"event at batch position {offset} must have sequence "
                    f"{required_sequence}",
                )
            envelope_json = serialization.dumps(envelope)
            rows.append(
                (
                    run_id.value,
                    envelope.sequence,
                    envelope_json,
                    _event_digest(envelope_json),
                )
            )
        self._conn.executemany(
            "INSERT INTO events "
            "(run_id, sequence, envelope_json, content_digest) VALUES (?, ?, ?, ?)",
            rows,
        )
        return expected_version + len(pending)

    def read(self, run_id: RunId, after: int = 0) -> tuple[EventEnvelope, ...]:
        if not isinstance(run_id, RunId):
            raise TypeError("event stream run id must be a RunId")
        _require_position(after, "event read position")
        # A read-only transaction (BEGIN DEFERRED, no write lock) gives one
        # consistent snapshot across the query, so a concurrent commit can't
        # be observed half-applied.
        with transaction(self._conn, mode="DEFERRED"):
            rows = self._conn.execute(
                "SELECT sequence, envelope_json, content_digest "
                "FROM events WHERE run_id=? "
                "ORDER BY sequence",
                (run_id.value,),
            ).fetchall()
        # Full-stream integrity is O(stream length) on every read: it decodes
        # nothing extra, but does re-derive count/min/max over every row for
        # this run rather than caching a validated high-water mark. Cheap in
        # practice (an in-process SQLite scan), but not O(1).
        sequences = [sequence for sequence, _, _ in rows]
        _check_contiguous(
            run_id,
            len(sequences),
            min(sequences) if sequences else None,
            max(sequences) if sequences else None,
        )
        envelopes = []
        for sequence, envelope_json, content_digest in rows:
            if sequence <= after:
                continue
            if (
                not isinstance(content_digest, str)
                or content_digest != _event_digest(envelope_json)
            ):
                raise DurableCorruption(
                    f"event row ({run_id}, {sequence}) failed content digest check"
                )
            envelope = serialization.loads(envelope_json, EventEnvelope)
            if envelope.run_id != run_id or envelope.sequence != sequence:
                raise DurableCorruption(
                    f"event row ({run_id}, {sequence}) does not match its "
                    "decoded envelope's run_id/sequence"
                )
            envelopes.append(envelope)
        return tuple(envelopes)

    def runs(self) -> tuple[RunId, ...]:
        """The ``RunIndex`` capability: every run holding events, by id.

        Read-only and decode-free — it scans distinct keys off the
        ``(run_id, sequence)`` primary-key index and never touches
        ``envelope_json``, so listing a store costs nothing per event. The
        per-stream integrity checks of :meth:`read` are therefore *not*
        applied here; a listed id is a claim that rows exist, not that the
        stream is well-formed. ``ORDER BY run_id`` uses SQLite's default
        BINARY collation, which compares UTF-8 bytes; UTF-8 preserves code
        point order, so it agrees with the in-memory store's Python
        ``sorted`` for every id, not only ASCII ones.

        A stored id that is not a usable ``RunId`` can only come from a
        writer that bypassed this library, and is unreachable through
        :meth:`read` — no caller can construct the id to ask for it — so
        listing is where it first becomes visible. It surfaces as the same
        ``DurableCorruption`` every other durable read path raises.
        """

        with transaction(self._conn, mode="DEFERRED"):
            rows = self._conn.execute(
                "SELECT DISTINCT run_id FROM events ORDER BY run_id"
            ).fetchall()
        try:
            return tuple(RunId(run_id) for (run_id,) in rows)
        except ValueError as error:
            raise DurableCorruption(
                f"the events table holds an unusable run id: {error}"
            ) from error

    def run_version(self, run_id: RunId) -> int:
        """Return the committed high-water mark without validating the stream.

        Each call opens a new deferred transaction, so a long-lived read-only
        WAL connection observes commits made after earlier calls.
        """

        if not isinstance(run_id, RunId):
            raise TypeError("event stream run id must be a RunId")
        with transaction(self._conn, mode="DEFERRED"):
            row = self._conn.execute(
                "SELECT MAX(sequence) FROM events WHERE run_id=?",
                (run_id.value,),
            ).fetchone()
        maximum = row[0]
        if maximum is None:
            return 0
        if isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < 1:
            raise DurableCorruption(
                f"event stream {run_id} has an invalid sequence high-water mark: "
                f"{maximum!r}"
            )
        return maximum

    def _version_in_txn(self, run_id: RunId) -> int:
        # Aggregate over the (run_id, sequence) primary-key index: O(1) in
        # Python, so the append hot path does not re-materialize every row and
        # a run's incremental appends stay linear overall, not quadratic.
        count, minimum, maximum = self._conn.execute(
            "SELECT COUNT(*), MIN(sequence), MAX(sequence) FROM events WHERE run_id=?",
            (run_id.value,),
        ).fetchone()
        return _check_contiguous(run_id, count, minimum, maximum)


def _check_contiguous(
    run_id: RunId, count: int, minimum: int | None, maximum: int | None
) -> int:
    """Validate that a run's sequences start at 1 with no gaps.

    Takes precomputed ``count``/``minimum``/``maximum`` (MIN/MAX are ``None``
    for an empty stream). Returns the version (``0`` for an unseen stream). The
    events table has a ``CHECK(sequence >= 1)`` constraint, so with unique
    ``(run_id, sequence)`` keys, ``count == max`` alone already implies
    contiguity from 1 — but the minimum is checked explicitly too, as defense
    in depth against rows written by something that bypassed the constraint.
    """

    if count == 0:
        return 0
    if minimum != 1 or count != maximum:
        raise DurableCorruption(
            f"event stream {run_id} is not contiguous from 1: "
            f"count={count} min={minimum} max={maximum}"
        )
    assert maximum is not None  # count != 0 guarantees a MAX
    return maximum


def _require_position(value: int, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer")


def _event_digest(envelope_json: str) -> str:
    return sha256(envelope_json.encode("utf-8")).hexdigest()
