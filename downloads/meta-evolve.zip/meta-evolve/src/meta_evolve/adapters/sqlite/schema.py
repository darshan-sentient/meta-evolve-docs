"""The store's table shapes and its migration ladder.

This module says what the schema IS at every version -- the DDL, the column
shapes a read-only open validates against, and the rung that carries a store
from each version to the next. `connection.py` opens connections and decides
what to do with what it finds.

The two ladders in this repository are independent and must not be confused.
This one versions the STORE (`STORE_SCHEMA_VERSION`, the tables); the one in
`serialization.py` versions durable RECORDS. Work rows are not records in the
event stream, so they move this ladder and not that one.
"""

from __future__ import annotations

import sqlite3
from hashlib import sha256

from meta_evolve.errors import DurableCorruption

# Work and lease state lives in durable tables OUTSIDE the run event stream:
# renewals are clock-driven control-plane mutations, and putting them in the
# stream would make a policy's observed version depend on heartbeat frequency.
# They share this database so an event append and a work-row update are one
# transaction.
#
# Both tables are frozen here at the v3 shape they were introduced with, and
# `_migrate_v2_to_v3` builds them from exactly this DDL. A later version that
# changes either adds a rung that ALTERs it and gives `_TABLES` the new shape.
_WORK_ITEMS_V3 = (
    "CREATE TABLE IF NOT EXISTS work_items ("
    " run_id TEXT NOT NULL,"
    " item_id TEXT NOT NULL,"
    " trial_id TEXT NOT NULL,"
    " kind TEXT NOT NULL,"
    " state TEXT NOT NULL,"
    " attempts INTEGER NOT NULL DEFAULT 0,"
    " max_attempts INTEGER NOT NULL,"
    " lease_json TEXT,"
    " accepted_attempt INTEGER,"
    " accepted_token_digest TEXT,"
    " acknowledgment_json TEXT,"
    " PRIMARY KEY (run_id, item_id))"
)
# The dispatcher epoch and the broker's last observed timestamp, persisted so a
# restart cannot un-expire a lease. `NOT NULL` is spelled out because a TEXT
# PRIMARY KEY does not imply it in SQLite, and NULL keys do not collide: without
# it the table would accept unreachable NULL-run_id rows that
# `_has_recorded_rows` counts as content.
_WORK_EPOCH_V3 = (
    "CREATE TABLE IF NOT EXISTS work_epoch ("
    " run_id TEXT PRIMARY KEY NOT NULL,"
    " epoch INTEGER NOT NULL,"
    " observed_clock INTEGER NOT NULL)"
)

_SCHEMA_META = (
    "CREATE TABLE IF NOT EXISTS schema_meta ("
    " key TEXT PRIMARY KEY, value TEXT NOT NULL)"
)

# Frozen at v3 like the work tables: `_migrate_v2_to_v3` rebuilds from it.
_EVENTS_V3 = (
    "CREATE TABLE IF NOT EXISTS events ("
    " run_id TEXT NOT NULL,"
    " sequence INTEGER NOT NULL CHECK(sequence >= 1),"
    " envelope_json TEXT NOT NULL,"
    " content_digest TEXT NOT NULL,"
    " PRIMARY KEY (run_id, sequence))"
)

_TABLES = (
    _SCHEMA_META,
    _EVENTS_V3,
    "CREATE TABLE IF NOT EXISTS artifact_occurrences ("
    " artifact_id TEXT PRIMARY KEY,"
    " digest TEXT NOT NULL,"
    " kind TEXT NOT NULL,"
    " representation TEXT NOT NULL,"
    " parent_ids_json TEXT NOT NULL,"
    " provenance_json TEXT NOT NULL,"
    " schema_version INTEGER NOT NULL)",
    # The current `work_items`: v3's shape plus v4's two failure columns, which
    # carry why the LAST attempt failed to the terminal fact the reclaim step
    # writes -- in a later pass and possibly another process, so only the row
    # survives between them.
    "CREATE TABLE IF NOT EXISTS work_items ("
    " run_id TEXT NOT NULL,"
    " item_id TEXT NOT NULL,"
    " trial_id TEXT NOT NULL,"
    " kind TEXT NOT NULL,"
    " state TEXT NOT NULL,"
    " attempts INTEGER NOT NULL DEFAULT 0,"
    " max_attempts INTEGER NOT NULL,"
    " lease_json TEXT,"
    " accepted_attempt INTEGER,"
    " accepted_token_digest TEXT,"
    " acknowledgment_json TEXT,"
    " last_failure_type TEXT,"
    " last_failure_message TEXT,"
    " last_failure_attempt INTEGER,"
    " last_lease_token_digest TEXT,"
    " PRIMARY KEY (run_id, item_id))",
    _WORK_EPOCH_V3,
)


_CURRENT_COLUMNS = {
    "schema_meta": (
        ("key", "TEXT", 0, 1),
        ("value", "TEXT", 1, 0),
    ),
    "events": (
        ("run_id", "TEXT", 1, 1),
        ("sequence", "INTEGER", 1, 2),
        ("envelope_json", "TEXT", 1, 0),
        ("content_digest", "TEXT", 1, 0),
    ),
    "artifact_occurrences": (
        ("artifact_id", "TEXT", 0, 1),
        ("digest", "TEXT", 1, 0),
        ("kind", "TEXT", 1, 0),
        ("representation", "TEXT", 1, 0),
        ("parent_ids_json", "TEXT", 1, 0),
        ("provenance_json", "TEXT", 1, 0),
        ("schema_version", "INTEGER", 1, 0),
    ),
    "work_items": (
        ("run_id", "TEXT", 1, 1),
        ("item_id", "TEXT", 1, 2),
        ("trial_id", "TEXT", 1, 0),
        ("kind", "TEXT", 1, 0),
        ("state", "TEXT", 1, 0),
        ("attempts", "INTEGER", 1, 0),
        ("max_attempts", "INTEGER", 1, 0),
        ("lease_json", "TEXT", 0, 0),
        ("accepted_attempt", "INTEGER", 0, 0),
        ("accepted_token_digest", "TEXT", 0, 0),
        ("acknowledgment_json", "TEXT", 0, 0),
        ("last_failure_type", "TEXT", 0, 0),
        ("last_failure_message", "TEXT", 0, 0),
        ("last_failure_attempt", "INTEGER", 0, 0),
        ("last_lease_token_digest", "TEXT", 0, 0),
    ),
    "work_epoch": (
        # notnull=1 because the CREATE declares it, not because it is a primary
        # key: a TEXT PRIMARY KEY is not implicitly NOT NULL in SQLite, which is
        # why `artifact_occurrences.artifact_id` below still reads 0. It is
        # declared here for the reason the DDL states -- NULLs do not collide
        # under a primary key -- and this row is what would catch a store whose
        # `work_epoch` was created before that was spelled out.
        ("run_id", "TEXT", 1, 1),
        ("epoch", "INTEGER", 1, 0),
        ("observed_clock", "INTEGER", 1, 0),
    ),
}


# The events shape the v1 rung's `ADD COLUMN` leaves: the digest is nullable.
_EVENTS_V2_FROM_V1 = (
    ("run_id", "TEXT", 1, 1),
    ("sequence", "INTEGER", 1, 2),
    ("envelope_json", "TEXT", 1, 0),
    ("content_digest", "TEXT", 0, 0),
)


def _table_shape(
    conn: sqlite3.Connection, table: str
) -> tuple[tuple[str, str, int, int], ...]:
    return tuple(
        (name, column_type.upper(), not_null, primary_key)
        for _, name, column_type, not_null, _, primary_key in conn.execute(
            f"PRAGMA table_info({table})"
        ).fetchall()
    )


def _table_is_current(conn: sqlite3.Connection, table: str) -> bool:
    """Whether ``table`` has its current columns, and, for `events`, its CHECK.

    `PRAGMA table_info` reports columns only, so the sequence constraint is read
    from the stored DDL.
    """

    if _table_shape(conn, table) != _CURRENT_COLUMNS[table]:
        return False
    return table != "events" or _has_sequence_check(conn)


def _has_sequence_check(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='events'"
    ).fetchone()
    return row is not None and "check(sequence>=1)" in "".join(row[0].split()).lower()


def _migrate_v3_to_v4(conn: sqlite3.Connection) -> None:
    """Add the columns carrying why an attempt failed.

    A v3 store's `work_items` exists, and `CREATE TABLE IF NOT EXISTS` never
    alters it, so without this rung the columns would exist only in fresh
    stores. Nothing is backfilled: a migrated row has no recorded failure, and
    the reclaim step reads NULL as "no cause recorded".
    """

    conn.execute("ALTER TABLE work_items ADD COLUMN last_failure_type TEXT")
    conn.execute("ALTER TABLE work_items ADD COLUMN last_failure_message TEXT")
    conn.execute("ALTER TABLE work_items ADD COLUMN last_failure_attempt INTEGER")
    conn.execute("ALTER TABLE work_items ADD COLUMN last_lease_token_digest TEXT")


def _migrate_v2_to_v3(conn: sqlite3.Connection) -> None:
    """Add the work and epoch tables at their v3 shape; nothing is backfilled.

    Also rebuilds an `events` table whose `content_digest` is nullable, which
    is what the v1 rung's `ALTER TABLE ... ADD COLUMN` left behind in every
    store migrated from v1 -- the shape a read-only open refuses. Only that
    exact shape is rebuilt, and only with every digest present: the copy names
    four columns, so anything else would be dropped or fail mid-rung.
    """

    shape = _table_shape(conn, "events")
    if ("content_digest", "TEXT", 0, 0) in shape:
        if shape != _EVENTS_V2_FROM_V1 or not _has_sequence_check(conn):
            raise DurableCorruption(
                "durable store stamped version 2 has a malformed events table"
            )
        if conn.execute(
            "SELECT 1 FROM events WHERE content_digest IS NULL LIMIT 1"
        ).fetchone():
            raise DurableCorruption(
                "durable store stamped version 2 has an event with no content_digest"
            )
        conn.execute("ALTER TABLE events RENAME TO events_nullable_digest")
        conn.execute(_EVENTS_V3)
        conn.execute(
            "INSERT INTO events (run_id, sequence, envelope_json, content_digest)"
            " SELECT run_id, sequence, envelope_json, content_digest"
            " FROM events_nullable_digest"
        )
        conn.execute("DROP TABLE events_nullable_digest")
    conn.execute(_WORK_ITEMS_V3)
    conn.execute(_WORK_EPOCH_V3)


def _migrate_v1_to_v2(conn: sqlite3.Connection) -> None:
    """Add and backfill the digest authenticating each stored event body."""

    conn.execute("ALTER TABLE events ADD COLUMN content_digest TEXT")
    rows = conn.execute(
        "SELECT run_id, sequence, envelope_json FROM events"
    ).fetchall()
    conn.executemany(
        "UPDATE events SET content_digest=? WHERE run_id=? AND sequence=?",
        (
            (sha256(envelope_json.encode("utf-8")).hexdigest(), run_id, sequence)
            for run_id, sequence, envelope_json in rows
        ),
    )


__all__ = [
    "_CURRENT_COLUMNS",
    "_SCHEMA_META",
    "_TABLES",
    "_table_is_current",
    "_table_shape",
    "_migrate_v1_to_v2",
    "_migrate_v2_to_v3",
    "_migrate_v3_to_v4",
]
