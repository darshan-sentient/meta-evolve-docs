"""The durable work broker, over the tables PR-B1 landed.

Same operations and same contract suite as the in-memory broker, which is the
point: the in-memory one is the deterministic double every dispatcher test
drives, and a double that did not obey the same laws would certify nothing about
this.

What differs is only where the state lives. `work_items` holds THIRTEEN
columns: the nine `WorkRow` owns (its seven plain fields, plus the two that
carry `last_failure`) and the four this file is the first to write -- the lease,
the accepted attempt, its token digest and the acknowledgment. `work_epoch`
holds the dispatcher epoch and the broker's last observed clock, which is what
makes the clamp survive a restart rather than only a call.

Every operation is one `BEGIN IMMEDIATE` transaction, so the clock read, the
precondition checks and the write are one atomic step. That is the record's
requirement that every acquire, renew and complete precondition be read "inside
the same transaction", and it is why a distributed run needs durable storage.

Past the ~300-line guideline, for the same reason as its in-memory sibling: one
implementation of one port's eight operations, each its own transaction, and
the epoch fence -- `epoch=` on each of the five writes, refused inside
`advance_in_txn` -- is what crossed the limit.
"""

from __future__ import annotations

from collections.abc import Iterable

import secrets
from dataclasses import replace

from meta_evolve.domain import RunId
from meta_evolve.domain.work import (
    DEFAULT_LEASE_SECONDS,
    FailureStage,
    Lease,
    LeaseToken,
    StaleReason,
    WorkAttemptId,
    WorkItemId,
    WorkRow,
    WorkState,
    require_lease_seconds,
    require_run_id,
)
from meta_evolve.domain.work_aborts import aborted
from meta_evolve.domain.workers import WorkerRegistration
from meta_evolve.ports.work_submission import ALREADY_ACCEPTED, AlreadyAccepted

from .connection import transaction
from .work_endings import cancel_row_in_txn
from .work_leases import (
    RELEASE_SQL,
    advance_in_txn,
    authorised_to_diagnose_in_txn,
    classify_submission_in_txn,
    epoch_in_txn,
    expire_in_txn,
    leases_in_txn,
    live_lease_in_txn,
)
from .work_status import submission_status_in_txn
from .work_rows import (
    ROW_COLUMNS,
    _put_work_in_txn,
    lease_from,
    lease_json,
    row_from,
    stored_cause_type,
)

class SqliteWorkBroker:
    """One broker over one run database."""

    def __init__(
        self, connection, *, lease_seconds: int = DEFAULT_LEASE_SECONDS
    ) -> None:
        self._conn = connection
        self.lease_seconds = require_lease_seconds(lease_seconds)


    def shares_transaction_with(self, other) -> bool:
        """True for a broker over the same connection, and nothing else."""

        return isinstance(other, SqliteWorkBroker) and other._conn is self._conn

    # -- reads ------------------------------------------------------------

    def rows(self, run_id: RunId) -> tuple[WorkRow, ...]:
        run_id = require_run_id(run_id)
        cursor = self._conn.execute(
            f"SELECT {ROW_COLUMNS} FROM work_items WHERE run_id=? ORDER BY item_id",
            (run_id.value,),
        )
        return tuple(row_from(run_id, record) for record in cursor)

    def current_epoch(self, run_id: RunId) -> int:
        run_id = require_run_id(run_id)
        with transaction(self._conn):
            return epoch_in_txn(self._conn, run_id)[0]

    # -- writes -----------------------------------------------------------

    def enqueue(self, run_id: RunId, rows: Iterable[WorkRow]) -> None:
        run_id = require_run_id(run_id)
        with transaction(self._conn):
            for row in rows:
                _put_work_in_txn(self._conn, row, run_id=run_id)

    def acquire(
        self,
        run_id: RunId,
        worker: WorkerRegistration,
        *,
        now: int,
        item: WorkItemId | None = None,
        epoch: int | None = None,
    ) -> Lease | None:
        run_id = require_run_id(run_id)
        if not isinstance(worker, WorkerRegistration):
            raise TypeError("acquire needs a WorkerRegistration")
        with transaction(self._conn):
            current, clock = advance_in_txn(self._conn, run_id, now, held=epoch)
            expire_in_txn(self._conn, run_id, clock)

            held = 0
            for item_id, stored_lease in leases_in_txn(self._conn, run_id):
                lease = lease_from(item_id, stored_lease)
                if (
                    lease.worker_id == worker.worker.value
                    and lease.generation == worker.generation
                ):
                    held += 1
            if not worker.admits_one_more(currently_held=held):
                return None

            narrowed = "" if item is None else " AND item_id=?"
            # D7's filter at the claim, inside its transaction: a row whose
            # current attempt returned a verdict owes a terminal fact, and the
            # rule is asked of the decoded row rather than spelled in SQL.
            row = next(
                (
                    candidate
                    for candidate in (
                        row_from(run_id, record)
                        for record in self._conn.execute(
                            f"SELECT {ROW_COLUMNS} FROM work_items"
                            f" WHERE run_id=? AND state=? AND attempts < max_attempts{narrowed}"
                            " ORDER BY item_id",
                            (run_id.value, WorkState.READY.value)
                            + (() if item is None else (item.value,)),
                        ).fetchall()
                    )
                    if not aborted(candidate)
                ),
                None,
            )
            if row is None:
                return None

            lease = Lease(
                item=row.item,
                attempt=WorkAttemptId(item=row.item, ordinal=row.attempts + 1),
                worker_id=worker.worker.value,
                generation=worker.generation,
                epoch=current,
                deadline=clock + self.lease_seconds,
                token=LeaseToken.issue(secrets.token_hex(16)),
            )
            self._conn.execute(
                "UPDATE work_items SET state=?, attempts=?, lease_json=?,"
                " last_lease_token_digest=? WHERE run_id=? AND item_id=?",
                (
                    WorkState.LEASED.value,
                    row.attempts + 1,
                    lease_json(lease),
                    lease.token.digest,
                    run_id.value,
                    row.item.value,
                ),
            )
            return lease

    def renew(
        self, run_id: RunId, lease: Lease, *, now: int, epoch: int | None = None
    ) -> Lease | None:
        """`renew_or_stale`, with any answer but a renewed lease reported `None`.

        Delegating is what keeps renewal one statement: the keepalive asks
        `renew_or_stale` for the reason, every other caller asks this, and the
        two cannot come to disagree about whether a lease is live.
        """

        answer = self.renew_or_stale(run_id, lease, now=now, epoch=epoch)
        return answer if isinstance(answer, Lease) else None

    def renew_or_stale(
        self, run_id: RunId, lease: Lease, *, now: int, epoch: int | None = None
    ) -> Lease | StaleReason | AlreadyAccepted:
        """Renew a live lease, or answer the reason it is stale -- in ONE transaction.

        The reason is read in the transaction that refused renewal, so no write
        can land between the refusal and its reason. Expiry is swept first, as in
        every write; a lease that ran past its deadline is still named `EXPIRED`
        because the row keeps its verifier. `None` only for the accepted lease at
        a `COMPLETED` row, which is neither renewable nor stale.
        """

        run_id = require_run_id(run_id)
        with transaction(self._conn):
            current, clock = advance_in_txn(self._conn, run_id, now, held=epoch)
            expire_in_txn(self._conn, run_id, clock)
            reason, state, _ack = classify_submission_in_txn(
                self._conn, run_id, lease, epoch=current, clock=clock
            )
            if reason is not None:
                return reason
            if state is not WorkState.LEASED:
                return ALREADY_ACCEPTED
            # `replace`, as the in-memory broker does: six of the seven fields
            # were copied verbatim and only the deadline moved, so spelling
            # them out meant a new `Lease` field would be silently dropped here
            # while the other adapter carried it.
            renewed = replace(lease, deadline=clock + self.lease_seconds)
            self._conn.execute(
                "UPDATE work_items SET lease_json=? WHERE run_id=? AND item_id=?",
                (lease_json(renewed), run_id.value, lease.item.value),
            )
            return renewed

    def submission_status(self, run_id: RunId, lease: Lease, *, now: int):
        """Classify without acting; see `work_leases.submission_status_in_txn`."""

        run_id = require_run_id(run_id)
        with transaction(self._conn, mode="DEFERRED"):
            return submission_status_in_txn(self._conn, run_id, lease, now=now)

    def release(
        self,
        run_id: RunId,
        lease: Lease,
        *,
        now: int,
        failure: tuple[str, str] | None = None,
        epoch: int | None = None,
    ) -> bool:
        """Give a live lease back, spending its attempt. Fact-free.

        Third caller of `RELEASE_SQL`, alongside expiry and rollover, so the
        transition an unfinished lease leaves behind stays one statement -- and
        so this inherits its refinement: READY, never terminal, because no
        transition that commits no batch may end a work item. An exhausted row
        is left unclaimable for the reclaim step, which owns the terminal fact.
        """
        run_id = require_run_id(run_id)

        with transaction(self._conn):
            current, clock = advance_in_txn(self._conn, run_id, now, held=epoch)
            expire_in_txn(self._conn, run_id, clock)
            if failure is not None and authorised_to_diagnose_in_txn(
                self._conn, run_id, lease
            ):
                # BEFORE the liveness check, and deliberately. The cause
                # describes the ATTEMPT, which happened; the lease is only how
                # the attempt was authorised. A component that outlives its
                # deadline and then raises reaches exactly here with a lease
                # expiry has already collected, and writing the diagnosis after
                # the check dropped it in the one case the diagnosis exists for.
                # `_terminate` reads it back in a later call, and after a
                # restart in another process, so the row is the only channel.
                #
                # "Before the liveness check" is not "without a credential",
                # though, and the statement used to be predicated on
                # `(run_id, item_id)` alone: anyone holding an item id could
                # overwrite the reason a run records for its work dying.
                self._conn.execute(
                    "UPDATE work_items SET last_failure_type=?,"
                    " last_failure_message=?, last_failure_attempt=?"
                    " WHERE run_id=? AND item_id=?",
                    (
                        stored_cause_type(failure[0], FailureStage.ATTEMPT),
                        failure[1], lease.attempt.ordinal, run_id.value, lease.item.value,
                    ),
                )
            if live_lease_in_txn(self._conn, run_id, lease, current) is None:
                return False
            # Released, not expired: the holder gave the lease back, so its
            # token no longer authorises a later diagnosis.
            self._conn.execute(
                RELEASE_SQL + ", last_lease_token_digest=NULL"
                " WHERE run_id=? AND item_id=?",
                (WorkState.READY.value, run_id.value, lease.item.value),
            )
            return True

    def record_failure(
        self,
        run_id: RunId,
        lease: Lease,
        *,
        now: int,
        cause: tuple[str, str],
        epoch: int | None = None,
    ) -> bool:
        """Record a completion failure's cause under `release`'s diagnosis rule.

        The row keeps its state: a completion failure propagates rather than
        releasing, and this is how its cause still reaches the terminal fact.
        """
        run_id = require_run_id(run_id)

        with transaction(self._conn):
            _, clock = advance_in_txn(self._conn, run_id, now, held=epoch)
            expire_in_txn(self._conn, run_id, clock)
            if not authorised_to_diagnose_in_txn(self._conn, run_id, lease):
                return False
            self._conn.execute(
                "UPDATE work_items SET last_failure_type=?,"
                " last_failure_message=?, last_failure_attempt=?"
                " WHERE run_id=? AND item_id=?",
                (
                    stored_cause_type(cause[0], FailureStage.COMPLETION),
                    cause[1], lease.attempt.ordinal, run_id.value, lease.item.value,
                ),
            )
            return True

    def cancel(
        self, run_id: RunId, item: WorkItemId, *, now: int, epoch: int | None = None
    ) -> None:
        run_id = require_run_id(run_id)
        with transaction(self._conn):
            advance_in_txn(self._conn, run_id, now, held=epoch)
            # The same statement `TerminateWork` makes, called rather than
            # copied: this was the identical UPDATE with the identical guard
            # written in two modules.
            cancel_row_in_txn(self._conn, item, run_id=run_id)

    def rollover(self, run_id: RunId) -> int:
        """Bump the epoch and make every prior-epoch lease claimable again.

        Terminal rows are untouched -- which is what keeps the duplicate
        exemption above reachable after a restart -- and the retry bound chooses
        between the record's two outcomes rather than leaving them unselected.

        Half a transition: the record forbids a ledger-only edit for retry
        exhaustion, and the terminal logical fact is the dispatcher's to append
        alongside this row. Noted at each of the three sites that make one.
        """
        run_id = require_run_id(run_id)

        with transaction(self._conn):
            epoch, clock = epoch_in_txn(self._conn, run_id)
            epoch += 1
            self._conn.execute(
                "INSERT INTO work_epoch(run_id, epoch, observed_clock) VALUES(?,?,?)"
                " ON CONFLICT(run_id) DO UPDATE SET epoch=excluded.epoch",
                (run_id.value, epoch, clock),
            )
            self._conn.execute(
                RELEASE_SQL + ", last_lease_token_digest=NULL"
                " WHERE run_id=? AND state=?",
                (WorkState.READY.value, run_id.value, WorkState.LEASED.value),
            )
            return epoch

    # -- internals --------------------------------------------------------


__all__ = ["DEFAULT_LEASE_SECONDS", "SqliteWorkBroker"]
