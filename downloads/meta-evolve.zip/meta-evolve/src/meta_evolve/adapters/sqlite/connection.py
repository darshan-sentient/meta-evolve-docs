"""Open and version-check a Meta-Evolve SQLite store, and its shared
transaction-context helper.

The connection uses explicit transactions (``isolation_level=None``): every
write goes through :func:`transaction`, never a bare ``execute``. WAL journal
mode plus ``synchronous=FULL`` makes the fsync-before-return guarantee
honest; ``busy_timeout`` lets a second writer block for the lock rather than
immediately raising, so racing commits resolve as a real version conflict
instead of a flaky lock error.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path

from meta_evolve.durability import STORE_SCHEMA_VERSION, check_store_schema_version
from meta_evolve.errors import (
    DurableCorruption,
    DurableStoreError,
    SchemaVersionRejected,
)

_TABLES = (
    "CREATE TABLE IF NOT EXISTS schema_meta ("
    " key TEXT PRIMARY KEY, value TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS events ("
    " run_id TEXT NOT NULL,"
    " sequence INTEGER NOT NULL CHECK(sequence >= 1),"
    " envelope_json TEXT NOT NULL,"
    " content_digest TEXT NOT NULL,"
    " PRIMARY KEY (run_id, sequence))",
    "CREATE TABLE IF NOT EXISTS artifact_occurrences ("
    " artifact_id TEXT PRIMARY KEY,"
    " digest TEXT NOT NULL,"
    " kind TEXT NOT NULL,"
    " representation TEXT NOT NULL,"
    " parent_ids_json TEXT NOT NULL,"
    " provenance_json TEXT NOT NULL,"
    " schema_version INTEGER NOT NULL)",
)


@contextmanager
def transaction(conn: sqlite3.Connection, *, mode: str = "IMMEDIATE"):
    """Run the ``with`` body as one SQLite transaction on ``conn``.

    Rolls back on any exception, but only when a transaction is actually
    open — a failed ``BEGIN`` itself (e.g. lock contention before the
    transaction starts) is never rolled back, so its error surfaces
    unmasked instead of being replaced by a spurious "no transaction"
    failure. ``sqlite3.OperationalError`` (lock timeout, busy database) is
    wrapped as a typed ``DurableStoreError``; every other exception
    (``EventStreamConflict``, ``ArtifactConflict``, ``DurableCorruption``,
    serialization errors, ...) propagates unchanged after rollback.
    """

    try:
        conn.execute(f"BEGIN {mode}")
        yield conn
        # COMMIT is inside the protected region so a commit-time
        # OperationalError (e.g. SQLITE_BUSY under WAL contention) is rolled
        # back and wrapped like any other operational failure, leaving the
        # connection with no dangling transaction.
        conn.execute("COMMIT")
    except sqlite3.OperationalError as error:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise DurableStoreError(f"sqlite operational failure: {error}") from error
    except BaseException:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise


def open_store(path: Path) -> sqlite3.Connection:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, isolation_level=None)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    try:
        _ensure_schema(conn)
    except BaseException:
        conn.close()
        raise
    return conn


def open_read_only_store(path: Path) -> sqlite3.Connection:
    """Open and validate an existing store without changing it.

    This deliberately has no shared setup path with :func:`open_store`: it
    does not create a parent, select a journal mode, stamp a schema, execute
    DDL, or migrate. ``mode=ro`` removes filesystem write authority and
    SQLite's ``query_only`` pragma is a final database-level backstop.
    """

    path = Path(path)
    try:
        if not path.is_file():
            raise FileNotFoundError(f"durable database does not exist: {path}")
        uri = f"{path.resolve().as_uri()}?mode=ro"
        conn = sqlite3.connect(uri, uri=True, isolation_level=None)
    except (OSError, sqlite3.Error) as error:
        raise DurableStoreError(
            f"cannot open durable store database read-only at {path}: {error}"
        ) from error
    try:
        conn.execute("PRAGMA query_only=ON")
        _validate_read_only_schema(conn)
    except (SchemaVersionRejected, DurableCorruption):
        conn.close()
        raise
    except (OSError, sqlite3.Error) as error:
        conn.close()
        raise DurableStoreError(
            f"cannot access durable store database or WAL read-only at {path}: "
            f"{error}"
        ) from error
    except BaseException:
        conn.close()
        raise
    return conn


_CURRENT_COLUMNS = {
    "schema_meta": (
        ("key", "TEXT", 0, 1),
        ("value", "TEXT", 1, 0),
    ),
    "events": (
        ("run_id", "TEXT", 1, 1),
        ("sequence", "INTEGER", 1, 2),
        ("envelope_json", "TEXT", 1, 0),
        ("content_digest", "TEXT", 1, 0),
    ),
    "artifact_occurrences": (
        ("artifact_id", "TEXT", 0, 1),
        ("digest", "TEXT", 1, 0),
        ("kind", "TEXT", 1, 0),
        ("representation", "TEXT", 1, 0),
        ("parent_ids_json", "TEXT", 1, 0),
        ("provenance_json", "TEXT", 1, 0),
        ("schema_version", "INTEGER", 1, 0),
    ),
}


def _validate_read_only_schema(conn: sqlite3.Connection) -> None:
    """Validate the current durable schema without repairing any part of it."""

    check = conn.execute("PRAGMA quick_check").fetchall()
    if check != [("ok",)]:
        detail = "; ".join(str(row[0]) for row in check)
        raise DurableCorruption(f"durable SQLite database failed quick_check: {detail}")

    tables = {
        name
        for (name,) in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    if "schema_meta" not in tables:
        raise SchemaVersionRejected(
            "durable store is unstamped; reopen it once through writable "
            "Storage.durable(...) before using Storage.read_only(...)"
        )

    schema_columns = _table_shape(conn, "schema_meta")
    if schema_columns != _CURRENT_COLUMNS["schema_meta"]:
        raise DurableCorruption(
            "current durable schema has a malformed schema_meta table"
        )
    row = conn.execute(
        "SELECT value FROM schema_meta WHERE key='store_schema_version'"
    ).fetchone()
    if row is None:
        raise SchemaVersionRejected(
            "durable store is unstamped; reopen it once through writable "
            "Storage.durable(...) before using Storage.read_only(...)"
        )
    try:
        version = int(row[0])
    except (TypeError, ValueError) as error:
        raise SchemaVersionRejected(
            f"invalid store schema version {row[0]!r}; reopen with a compatible "
            "writable Storage.durable(...)"
        ) from error
    if str(version) != row[0] or version < 1:
        raise SchemaVersionRejected(
            f"invalid store schema version {row[0]!r}; reopen with a compatible "
            "writable Storage.durable(...)"
        )
    if version < STORE_SCHEMA_VERSION:
        raise SchemaVersionRejected(
            f"older store schema version {version} requires migration; reopen it "
            "once through writable Storage.durable(...)"
        )
    if version > STORE_SCHEMA_VERSION:
        raise SchemaVersionRejected(
            f"future store schema version {version} > {STORE_SCHEMA_VERSION}; "
            "open it with a compatible Meta-Evolve build"
        )

    for table, expected in _CURRENT_COLUMNS.items():
        if table not in tables or _table_shape(conn, table) != expected:
            raise DurableCorruption(
                f"current durable schema has a malformed {table} table"
            )


def _table_shape(
    conn: sqlite3.Connection, table: str
) -> tuple[tuple[str, str, int, int], ...]:
    return tuple(
        (name, column_type.upper(), not_null, primary_key)
        for _, name, column_type, not_null, _, primary_key in conn.execute(
            f"PRAGMA table_info({table})"
        ).fetchall()
    )


def _ensure_schema(conn: sqlite3.Connection) -> None:
    with transaction(conn):
        for statement in _TABLES:
            conn.execute(statement)
        found = _read_version(conn)
        populated = _has_events_or_occurrences(conn)
        check_store_schema_version(found, populated=populated)
        if found is None:
            conn.execute(
                "INSERT INTO schema_meta(key, value) VALUES('store_schema_version', ?)",
                (str(STORE_SCHEMA_VERSION),),
            )
        else:
            version = found
            while version < STORE_SCHEMA_VERSION:
                if version == 1:
                    _migrate_v1_to_v2(conn)
                else:  # pragma: no cover - guarded whenever a version is added
                    raise RuntimeError(f"missing store migration from version {version}")
                version += 1
            if found != STORE_SCHEMA_VERSION:
                conn.execute(
                    "UPDATE schema_meta SET value=? WHERE key='store_schema_version'",
                    (str(STORE_SCHEMA_VERSION),),
                )


def _migrate_v1_to_v2(conn: sqlite3.Connection) -> None:
    """Add and backfill the digest authenticating each stored event body."""

    conn.execute("ALTER TABLE events ADD COLUMN content_digest TEXT")
    rows = conn.execute(
        "SELECT run_id, sequence, envelope_json FROM events"
    ).fetchall()
    conn.executemany(
        "UPDATE events SET content_digest=? WHERE run_id=? AND sequence=?",
        (
            (sha256(envelope_json.encode("utf-8")).hexdigest(), run_id, sequence)
            for run_id, sequence, envelope_json in rows
        ),
    )


def _read_version(conn: sqlite3.Connection) -> int | None:
    row = conn.execute(
        "SELECT value FROM schema_meta WHERE key='store_schema_version'"
    ).fetchone()
    return int(row[0]) if row is not None else None


def _has_events_or_occurrences(conn: sqlite3.Connection) -> bool:
    for table in ("events", "artifact_occurrences"):
        if conn.execute(f"SELECT 1 FROM {table} LIMIT 1").fetchone() is not None:
            return True
    return False
