"""Write one work row inside a transaction someone else opened.

The sibling of ``occurrences.py``: a private no-transaction helper, so
``DurableUnitOfWork.commit`` can put work rows and events in the SAME
transaction rather than opening a nested one. That single transaction is the
whole reason a distributed run requires durable storage.

The sibling's *shape* matters as much as its placement. ``work_items`` declares
THIRTEEN columns and ``WorkRow``'s writer binds seven; the six it omits -- the
lease, the accepted attempt, its token digest, the acknowledgment and the two
failure columns -- are precisely the state the record says a restart must
retain. So this cannot be an upsert of the columns it knows: enqueue is an
absent-only transition, and an overwrite naming seven of thirteen would clear
the other six. ``_put_occurrence_in_txn``
already settled the same question the same way -- read back, no-op on an
identical resubmission, refuse a conflicting one -- and this follows it rather
than inventing a second answer.

Row vocabulary only. Which transitions are legal, and what must hold for one to
happen, is ``work_intents.py``.
"""

from __future__ import annotations

import sqlite3

import json

from meta_evolve.domain import RunId, TrialId
from meta_evolve.errors import DurableCorruption
from meta_evolve.domain.work import (
    Lease,
    LeaseToken,
    WorkAttemptId,
    WorkItemId,
    WorkKind,
    WorkRow,
    WorkState,
)
from meta_evolve.ports.work_store import (
    InvalidWorkAppend,
    refuse_inadmissible_enqueue,
)

# The columns `WorkRow` owns, in the order the table declares them. The row's
# identity is `(run_id, item_id)`; the re-enqueue comparison below is over
# `_AUTHORED_COLUMNS`, which is three of the remaining five and not all of them:
# the columns a submitter authors, and the only ones an idempotent re-enqueue
# compares. See the design record's Vocabulary.
_AUTHORED_COLUMNS = ("trial_id", "kind", "max_attempts")

_WORK_COLUMNS = (
    "run_id",
    "item_id",
    "trial_id",
    "kind",
    "state",
    "attempts",
    "max_attempts",
)


def _encode_work_row(row: WorkRow) -> tuple[str, str, str, str, str, int, int]:
    """Encode ``row`` as the seven columns an ENQUEUE authors, in declared
    order. `last_failure`'s two columns are written by `release`, not here.

    Private, and named so: its only caller is `_put_work_in_txn` below, and
    an exported name on an adapter-internal encoder invites a second caller
    to bind these columns without the enqueue rules that guard them.
    """

    return (
        row.run_id.value,
        row.item.value,
        row.trial_id.value,
        row.kind.value,
        row.state.value,
        row.attempts,
        row.max_attempts,
    )


def _put_work_in_txn(
    conn: sqlite3.Connection, row: WorkRow, *, run_id: RunId
) -> None:
    """Insert one work row, never overwriting an existing one.

    Idempotent for an identical resubmission, so a retried commit of the same
    cohort is safe; ``InvalidWorkAppend`` if ``(run_id, item_id)`` already holds
    a row that differs, because enqueue has no authority to change one. Assumes
    a transaction is already open.

    ``run_id`` is the run whose events authorise this transaction, and it is a
    separate argument from ``row.run_id`` on purpose: the two must agree, and
    checking that here puts the refusal on the only path that writes, the way
    ``_append_in_txn`` checks the same property for an event envelope.
    """

    refuse_inadmissible_enqueue(run_id, row)
    values = _encode_work_row(row)
    # Compare only the columns ENQUEUE AUTHORS -- the trial, the kind and the
    # retry bound. `state` and `attempts` belong to the broker, so a repeat
    # submission of an item that has since been leased is the same item further
    # along, not a conflicting claim; comparing them made a retried commit of a
    # partly-progressed cohort fail, which is the opposite of what an idempotent
    # enqueue is for. The in-memory broker always compared this set; this is
    # where the two disagreed.
    existing = conn.execute(
        f"SELECT {', '.join(_AUTHORED_COLUMNS)} FROM work_items"
        " WHERE run_id=? AND item_id=?",
        (row.run_id.value, row.item.value),
    ).fetchone()
    if existing is not None:
        authored = tuple(
            values[_WORK_COLUMNS.index(name)] for name in _AUTHORED_COLUMNS
        )
        if tuple(existing) != authored:
            raise InvalidWorkAppend(
                run_id,
                f"work row {row.item.value} already exists and differs; "
                f"enqueue cannot change a committed row",
            )
        return
    conn.execute(
        "INSERT INTO work_items("
        " run_id, item_id, trial_id, kind, state, attempts, max_attempts)"
        " VALUES(?,?,?,?,?,?,?)",
        values,
    )


ROW_COLUMNS = (
    "item_id, trial_id, kind, state, attempts, max_attempts,"
    " last_failure_type, last_failure_message,"
    " lease_json IS NOT NULL, accepted_attempt IS NOT NULL,"
    " accepted_token_digest IS NOT NULL, acknowledgment_json IS NOT NULL"
)


def row_from(run_id: RunId, record) -> WorkRow:
    (
        item_id,
        trial_id,
        kind,
        state,
        attempts,
        max_attempts,
        failure_type,
        failure_message,
        has_lease,
        *acceptance,
    ) = record
    # The broker's columns must back the state the row claims. The writers set
    # them together, so a mismatch is a partial or foreign write.
    if state == WorkState.LEASED.value and not has_lease:
        raise DurableCorruption(
            f"work item {item_id} is LEASED with no lease recorded"
        )
    if state == WorkState.COMPLETED.value and not all(acceptance):
        raise DurableCorruption(
            f"work item {item_id} is COMPLETED without its accepted attempt, "
            "token digest and acknowledgment"
        )
    return WorkRow(
        run_id=run_id,
        item=WorkItemId(item_id),
        trial_id=TrialId(trial_id),
        kind=WorkKind(kind),
        state=WorkState(state),
        attempts=attempts,
        max_attempts=max_attempts,
        # Both columns or neither: a half-written diagnosis would be worse
        # than none, and NULL means "no cause recorded" -- the state a v3
        # migration and a clean success share.
        last_failure=(
            (failure_type, failure_message)
            if failure_type is not None
            else None
        ),
    )


def lease_json(lease: Lease) -> str:
    return json.dumps(
        {
            "ordinal": lease.attempt.ordinal,
            "worker_id": lease.worker_id,
            "generation": lease.generation,
            "epoch": lease.epoch,
            "deadline": lease.deadline,
            "token": lease.token.digest,
        },
        sort_keys=True,
    )


def lease_from(item_id: str, lease_json: str) -> Lease:
    """Decode one stored lease, or raise `DurableCorruption`.

    `lease_json` is durable bytes a foreign writer or a torn write can reach,
    and this is the boundary that meets them: the decode used to be a bare
    `json.loads` followed by unchecked indexing, so truncated or malformed
    lease data surfaced `JSONDecodeError`, `KeyError`, `TypeError` or a raw
    value-constructor `ValueError`. Those come out of the expiry sweep, which
    every `Dispatcher.drive()` runs before anything else, carrying no run or
    item context at all -- and past the typed boundary the rest of the durable
    layer maintains (`event_store.py`, `connection.py`, `blob_store.py`).
    """

    item = WorkItemId(item_id)
    try:
        stored = json.loads(lease_json)
        if not isinstance(stored, dict):
            raise TypeError(f"lease is {type(stored).__name__}, not an object")
        return Lease(
            item=item,
            attempt=WorkAttemptId(item=item, ordinal=stored["ordinal"]),
            worker_id=stored["worker_id"],
            generation=stored["generation"],
            epoch=stored["epoch"],
            deadline=stored["deadline"],
            token=LeaseToken(stored["token"]),
        )
    except DurableCorruption:
        raise
    except Exception as error:
        raise DurableCorruption(
            f"stored lease for work item {item_id} is unreadable: {error}"
        ) from error


__all__ = [
    "ROW_COLUMNS",
    "_encode_work_row",
    "_put_work_in_txn",
    "lease_from",
    "lease_json",
    "row_from",
]
