"""Runner adapters over decoded values and full artifact occurrences."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.application.codecs import CodecIndex
from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.experience_access import ExperienceSpec
from meta_evolve.domain.task import Budget, Objective
from meta_evolve.domain.trial import Artifact
from meta_evolve.ports.callables import ProposalResult
from meta_evolve.ports.proposers import ProposerContext

from .proposers import CallableProposer


@dataclass(frozen=True, slots=True)
class DecodedValueProposerRunner:
    """Preserve the original callable contract behind the runner seam."""

    proposer: CallableProposer
    component: ComponentRef
    codecs: CodecIndex

    def validate_run(
        self,
        *,
        artifact_kind: str,
        artifact_representation: str,
        objectives: tuple[Objective, ...],
        budget: Budget,
        experience: ExperienceSpec | None,
    ) -> None:
        self.proposer.validate_run(
            artifact_kind=artifact_kind,
            artifact_representation=artifact_representation,
            objectives=objectives,
            budget=budget,
            experience=experience,
        )

    def execute(
        self,
        parents: tuple[Artifact, ...],
        context: ProposerContext,
    ) -> ProposalResult:
        values = tuple(self.codecs.decode(parent) for parent in parents)
        parent = values[0] if len(values) == 1 else values
        return self.proposer.propose(parent, context)


__all__ = ["DecodedValueProposerRunner"]
