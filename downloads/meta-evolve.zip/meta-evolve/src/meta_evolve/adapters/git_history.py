"""Authorized, bounded, read-only Git history adapter."""

from __future__ import annotations

import shutil
import subprocess
import os
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path

from meta_evolve.application.source_history import prepare_source_history
from meta_evolve.domain import Artifact, ComponentRef, SourceHistoryBounds, SourceTree
from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.errors import CapabilityError
from meta_evolve.ports.workspaces import Workspace

from .git_projection import (
    GitHistoryMount,
    dispose_git_history,
    project_git_history,
)


GIT_HISTORY_ADAPTER_VERSION = "git-history-view/v1"


@dataclass(frozen=True, slots=True, kw_only=True)
class GitHistoryView:
    max_ancestors: int
    max_archive_members: int
    max_chars: int

    def __post_init__(self) -> None:
        SourceHistoryBounds(
            max_ancestors=self.max_ancestors,
            max_archive_members=self.max_archive_members,
            max_chars=self.max_chars,
        )

    @property
    def bounds(self) -> SourceHistoryBounds:
        return SourceHistoryBounds(
            max_ancestors=self.max_ancestors,
            max_archive_members=self.max_archive_members,
            max_chars=self.max_chars,
        )

    def validate(self) -> Path:
        if os.name != "posix":
            raise CapabilityError("GitHistoryView requires a POSIX workspace session")
        executable = shutil.which("git")
        if executable is None:
            raise CapabilityError("GitHistoryView requires Git")
        git = Path(executable).resolve()
        try:
            completed = subprocess.run(
                (str(git), "--version"),
                env={"PATH": str(git.parent), "LANG": "C", "LC_ALL": "C"},
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
        except OSError as error:
            raise CapabilityError("GitHistoryView requires executable Git") from error
        if completed.returncode != 0:
            raise CapabilityError("GitHistoryView requires executable Git")
        return git

    def component(self, propose, base: ComponentRef) -> ComponentRef:
        digest = sha256(
            canonical_payload_bytes(
                {
                    "adapter_version": GIT_HISTORY_ADAPTER_VERSION,
                    "callback": base.name,
                    "max_ancestors": self.max_ancestors,
                    "max_archive_members": self.max_archive_members,
                    "max_chars": self.max_chars,
                }
            )
        ).hexdigest()
        return ComponentRef.configured_local(
            "proposer",
            propose,
            name=base.name,
            version=f"{GIT_HISTORY_ADAPTER_VERSION}+{digest}",
        )

    def mount(
        self,
        *,
        parent: Artifact,
        tree: SourceTree,
        workspace: Workspace,
        reader,
    ) -> GitHistoryMount:
        prepared = prepare_source_history(parent, tree, reader, self.bounds)
        return project_git_history(
            workspace,
            prepared,
            git=self.validate(),
        )

    @staticmethod
    def dispose(mount: GitHistoryMount) -> None:
        dispose_git_history(mount)


__all__ = ["GIT_HISTORY_ADAPTER_VERSION", "GitHistoryView"]
