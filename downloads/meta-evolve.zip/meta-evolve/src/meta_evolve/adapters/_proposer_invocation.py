"""Select and invoke proposer arguments without probing user callback bodies.

This module is an automatic source dependency of registered proposers: changing
argument delivery must invalidate resume even when callback source is unchanged.
"""

from collections.abc import Callable
import inspect
from typing import Literal


Invocation = Literal["parent", "keyword-context", "positional-context"]


def bind_callback(fn: Callable[..., object]) -> Invocation:
    """Plain callbacks opt into context only by its keyword-only name."""
    try:
        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        raise TypeError(
            "proposer callback signature must be inspectable; use an inspectable "
            "wrapper or a structural object with propose(parent, context)"
        ) from None

    positional = [
        parameter for parameter in signature.parameters.values()
        if parameter.kind in (parameter.POSITIONAL_ONLY, parameter.POSITIONAL_OR_KEYWORD)
    ]
    if any(parameter.name == "context" for parameter in positional[1:]):
        raise TypeError(
            "proposer callback context must be keyword-only: "
            "use def propose(parent, *, context) instead of positional context"
        )
    context = signature.parameters.get("context")
    inject = context is not None and context.kind == context.KEYWORD_ONLY
    marker = object()
    try:
        signature.bind(marker, **({"context": marker} if inject else {}))
    except TypeError as error:
        raise TypeError(
            "proposer callback must accept (parent) or (parent, *, context); "
            f"bind other required arguments in a wrapper or partial: {error}"
        ) from None
    return "keyword-context" if inject else "parent"


def bind_structural(fn: Callable[..., object]) -> Invocation:
    """Preserve the explicit structural port and its parent-only convenience."""
    try:
        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        return "positional-context"
    marker = object()
    try:
        signature.bind(marker, marker)
    except TypeError:
        pass
    else:
        return "positional-context"
    try:
        signature.bind(marker)
    except TypeError:
        raise TypeError("structural proposer must accept (parent, context) or (parent)") from None
    return "parent"


def invoke(fn: Callable[..., object], shape: Invocation, parent: object, context: object) -> object:
    """Use the selected shape once; normalization and escaping remain adapter-owned."""
    if shape == "keyword-context":
        return fn(parent, context=context)
    if shape == "positional-context":
        return fn(parent, context)
    return fn(parent)
