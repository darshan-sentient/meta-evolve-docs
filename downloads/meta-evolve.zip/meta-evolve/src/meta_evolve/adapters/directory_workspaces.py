"""Private directory-copy workspaces for UTF-8 source trees."""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from meta_evolve.domain.source_tree import SourceTree, load_source_tree
from meta_evolve.ports.workspaces import Workspace


class DirectoryWorkspaces:
    """Materialize each source tree into a newly owned temporary directory."""

    def __init__(self, root: str | Path | None = None) -> None:
        self._base = Path(root).resolve() if root is not None else None
        if self._base is not None:
            self._base.mkdir(parents=True, exist_ok=True)
        self._issued: set[Path] = set()

    def materialize(self, artifact: object) -> Workspace:
        if not isinstance(artifact, SourceTree):
            raise TypeError("DirectoryWorkspaces requires a SourceTree")
        root = Path(
            tempfile.mkdtemp(prefix="meta-evolve-", dir=self._base)
        ).resolve()
        try:
            for relative, content in artifact.items():
                target = root.joinpath(*relative.split("/"))
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content.encode("utf-8"))
        except Exception:
            shutil.rmtree(root, ignore_errors=True)
            raise
        self._issued.add(root)
        return Workspace(root=root)

    def capture(self, workspace: Workspace) -> SourceTree:
        root = self._owned_root(workspace)
        if not root.is_dir():
            raise ValueError("workspace is unavailable")
        return load_source_tree(root)

    def dispose(self, workspace: Workspace) -> None:
        if not isinstance(workspace, Workspace):
            raise TypeError("workspace must be a Workspace")
        root = workspace.root
        if root not in self._issued:
            return
        if root.exists():
            shutil.rmtree(root)
        self._issued.remove(root)

    def _owned_root(self, workspace: Workspace) -> Path:
        if not isinstance(workspace, Workspace):
            raise TypeError("workspace must be a Workspace")
        if workspace.root not in self._issued:
            raise ValueError("workspace was not created by this provider")
        return workspace.root


__all__ = ["DirectoryWorkspaces"]
