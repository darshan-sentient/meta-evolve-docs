"""Workspace-backed exact-file patch proposer."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace

from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.evaluation import (
    Failure,
    InfrastructureFailure,
    InvalidOutput,
    PolicyViolation,
    ProposerFailure,
    ResourceExhausted,
)
from meta_evolve.domain.experience_access import ExperienceSpec
from meta_evolve.domain.source_tree import SourceTree, normalize_source_path
from meta_evolve.domain.task import Budget, Objective
from meta_evolve.domain.trial import Artifact
from meta_evolve.errors import ExperienceAccessDenied, ExperienceBudgetExhausted
from meta_evolve.application.source_history import SourceHistoryUnavailable
from meta_evolve.ports.callables import ProposalResult
from meta_evolve.ports.patches import TextPatch
from meta_evolve.ports.proposers import ProposerContext
from meta_evolve.ports.workspaces import Workspace, WorkspaceProvider

from .directory_workspaces import DirectoryWorkspaces
from .git_history import GitHistoryView
from .patch_normalization import (
    infrastructure_result,
    normalize_patch_result,
    proposal_failure,
)
from .proposers import _PROPOSER_ESCAPE_EXCEPTIONS, _invalid_proposal


class PatchProposer:
    """Apply an exact-file patch through a private workspace.

    The callable receives the parent tree and proposer context, returning a
    TextPatch, PatchResult, or typed failure. Expected text must match before
    capture creates an immutable successor. Optional ``history`` supplies a
    bounded read-only Git presentation of authorized prior source.
    """

    def __init__(
        self,
        propose: Callable[[SourceTree, object], object],
        *,
        workspaces: WorkspaceProvider | None = None,
        history: GitHistoryView | None = None,
    ) -> None:
        if not callable(propose):
            raise TypeError("patch proposer must be callable")
        if history is not None and not isinstance(history, GitHistoryView):
            raise TypeError("history must be a GitHistoryView or None")
        base_component = ComponentRef.local_proposer(propose)
        self._propose = propose
        self._workspaces = workspaces or DirectoryWorkspaces()
        self.history = history
        if history is None:
            self.component = base_component
        else:
            self.component = history.component(propose, base_component)

    def validate_run(
        self,
        *,
        artifact_kind: str,
        artifact_representation: str,
        objectives: tuple[Objective, ...],
        budget: Budget,
        experience: ExperienceSpec | None,
    ) -> None:
        if artifact_kind != SourceTree.KIND or (
            artifact_representation != SourceTree.REPRESENTATION
        ):
            raise ValueError("PatchProposer requires Task(artifact=SourceTree)")
        if self.history is not None:
            if experience is None:
                raise ValueError("GitHistoryView requires declared pull experience")
            self.history.validate()

    def execute(
        self,
        parents: tuple[Artifact, ...],
        context: ProposerContext,
    ) -> ProposalResult:
        if len(parents) != 1:
            return _invalid_proposal(
                "patch proposer requires exactly one parent artifact"
            )
        try:
            tree = SourceTree.from_payload(parents[0].payload)
        except (TypeError, ValueError) as error:
            return _invalid_proposal(
                "patch proposer received invalid source-tree content",
                details={"error": str(error)},
            )
        try:
            workspace = self._workspaces.materialize(tree)
        except Exception as error:
            return infrastructure_result(error)

        escaped: BaseException | None = None
        try:
            result = self._run_in_workspace(parents[0], tree, workspace, context)
        except _PROPOSER_ESCAPE_EXCEPTIONS as error:
            escaped = error
            result = None
        try:
            self._workspaces.dispose(workspace)
        except Exception as error:
            # Durable-integrity exceptions must keep propagating; a failed
            # dispose cannot downgrade them into a committed trial failure.
            if escaped is not None:
                raise escaped from error
            prior = result.failure.kind if result is not None and result.failure else None
            return infrastructure_result(
                error,
                reported_failure=prior,
                prior_result=result,
            )
        if escaped is not None:
            raise escaped
        assert result is not None
        return result

    def _run_in_workspace(
        self,
        parent: Artifact,
        tree: SourceTree,
        workspace: Workspace,
        context: ProposerContext,
    ) -> ProposalResult:
        mount = None
        callback_context = context
        if self.history is not None:
            if context.experience is None:
                return ProposalResult(
                    failure=PolicyViolation(
                        message="source history requires declared pull experience"
                    )
                )
            try:
                mount = self.history.mount(
                    parent=parent,
                    tree=tree,
                    workspace=workspace,
                    reader=context.experience,
                )
                callback_context = replace(context, workspace=mount.session)
            except ExperienceAccessDenied:
                return ProposalResult(
                    failure=PolicyViolation(
                        message="source history access was not authorized"
                    )
                )
            except ExperienceBudgetExhausted:
                return ProposalResult(
                    failure=ResourceExhausted(
                        message="source history exhausted its experience grant"
                    )
                )
            except SourceHistoryUnavailable as error:
                return ProposalResult(failure=PolicyViolation(message=str(error)))
            except _PROPOSER_ESCAPE_EXCEPTIONS:
                raise
            except Exception as error:
                return infrastructure_result(error)

        escaped: BaseException | None = None
        try:
            returned = self._propose(tree, callback_context)
        except _PROPOSER_ESCAPE_EXCEPTIONS as error:
            escaped = error
            returned = None
        except Exception as error:
            returned = ProposalResult(
                failure=ProposerFailure(
                    message=str(error) or type(error).__name__,
                    details={"exception_type": type(error).__name__},
                )
            )
        if mount is not None:
            try:
                self.history.dispose(mount)
            except Exception as error:
                if escaped is not None:
                    raise escaped from error
                return infrastructure_result(error)
        if escaped is not None:
            raise escaped
        assert returned is not None
        if self.history is not None:
            try:
                unchanged = self._workspaces.capture(workspace)
            except (TypeError, ValueError):
                return ProposalResult(
                    failure=PolicyViolation(
                        message="history callback mutated the source workspace"
                    )
                )
            except Exception as error:
                return infrastructure_result(error)
            if not isinstance(unchanged, SourceTree):
                return infrastructure_result(
                    TypeError("workspace provider captured an unsupported artifact")
                )
            if unchanged != tree:
                return ProposalResult(
                    failure=PolicyViolation(
                        message="history callback mutated the source workspace"
                    )
                )
        if isinstance(returned, ProposalResult):
            return returned
        patch_result = normalize_patch_result(returned)
        if isinstance(patch_result, ProposalResult):
            return patch_result
        if patch_result.failure is not None:
            return proposal_failure(
                patch_result,
                patch_result.failure,
                derived_from=patch_result.derived_from,
            )
        assert isinstance(patch_result.patch, TextPatch)
        failure = self._apply(workspace, patch_result.patch)
        if failure is not None:
            return proposal_failure(patch_result, failure)
        try:
            captured = self._workspaces.capture(workspace)
        except Exception as error:
            return proposal_failure(
                patch_result,
                InfrastructureFailure(
                    message=str(error) or type(error).__name__,
                    details={"exception_type": type(error).__name__},
                ),
            )
        if not isinstance(captured, SourceTree):
            return proposal_failure(
                patch_result,
                InfrastructureFailure(
                    message="workspace provider captured an unsupported artifact",
                    details={"captured_type": type(captured).__name__},
                ),
            )
        return ProposalResult(
            candidate=captured,
            hypothesis=patch_result.hypothesis,
            predicted_outcomes=patch_result.predicted_outcomes,
            metadata=patch_result.metadata,
            evidence=patch_result.evidence,
            usage=patch_result.usage.resources,
            derived_from=patch_result.derived_from,
        )

    @staticmethod
    def _apply(workspace: Workspace, patch: TextPatch) -> Failure | None:
        try:
            relative = normalize_source_path(patch.path)
        except (TypeError, ValueError):
            return PolicyViolation(message="patch path is outside source authority")
        target = workspace.root
        if target.is_symlink():
            return PolicyViolation(message="patch path is outside source authority")
        for part in relative.split("/"):
            target = target / part
            if target.is_symlink():
                return PolicyViolation(
                    message="patch path is outside source authority"
                )
        if not target.is_file():
            return InvalidOutput(
                message="patch does not match parent content",
                details={"path": relative},
            )
        try:
            current = target.read_bytes().decode("utf-8")
        except Exception as error:
            return InfrastructureFailure(
                message=str(error) or type(error).__name__,
                details={"exception_type": type(error).__name__},
            )
        if current != patch.expected:
            return InvalidOutput(
                message="patch does not match parent content",
                details={"path": relative},
            )
        try:
            target.write_bytes(patch.replacement.encode("utf-8"))
        except Exception as error:
            return InfrastructureFailure(
                message=str(error) or type(error).__name__,
                details={"exception_type": type(error).__name__},
            )
        return None

__all__ = ["PatchProposer"]
