"""Published executable laws for deterministic search programs.

Every law runs through the ordinary public path — ``meta.run`` plus replay —
because a program's real contract is that the run it drove can be
reconstructed from its events by someone who never saw the program object.

*On length.* This module exceeds the repository's usual 300-line guideline
and is kept whole deliberately: it is one published class whose entire
interface is the fixtures and hooks its laws call, and the available split —
fixtures in one module, laws in another — would put a subclass author's
overrides in a different file from the laws that consume them.
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

import meta_evolve as meta
from meta_evolve import domain, serialization
from meta_evolve.application import replay_run_projection, replay_search_state
from meta_evolve.application.search_preparation import prepare_search


def _required() -> str:
    return (
        "SearchProgramTests needs exactly one of the 'search' or "
        "'search_factory' fixtures: override one in your subclass to point "
        "the suite at your search preset."
    )


def _propose(parent, _context):
    return parent + 1


def _evaluate(candidate):
    return candidate


class SearchProgramTests:
    """Determinism, replay, authority, budget, and durable-decision laws.

    Subclass it, name the subclass ``Test...``, and override one fixture::

        class TestMyProgram(SearchProgramTests):
            @pytest.fixture
            def search(self):
                return MyProgram(max_trials=1)

    A program built around the proposer — anything holding a
    ``ComponentRef.local_proposer`` — cannot be constructed before the run
    exists. Override ``search_factory`` instead and leave ``search`` alone::

        class TestProposerBoundProgram(SearchProgramTests):
            @pytest.fixture
            def search_factory(self):
                return MyProgram          # called as MyProgram(proposer)

    Exactly one of the two is required. Widen ``budget`` past the one-trial
    default so the laws traverse a multi-decision history.

    **What these laws do not cover.** Whether decisions realize the policy
    your program's name promises — a "best of N" that expands an arbitrary
    candidate is lawful here and wrong everywhere else. Selection, eviction,
    and stopping *semantics* are behaviors; test them as such, the way the
    shipped programs do in their own behavior tests.
    """

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture
    def search(self) -> domain.SearchProgram | None:
        """The program under test, when it can be built without a proposer."""

        return None

    @pytest.fixture
    def search_factory(self) -> Callable[..., domain.SearchProgram] | None:
        """``callable(proposer) -> SearchProgram``, for proposer-bound programs."""

        return None

    @pytest.fixture
    def seed(self) -> object:
        return 0

    @pytest.fixture
    def budget(self) -> meta.Budget:
        """The run budget. Widen it for a program that needs more trials."""

        return meta.Budget(evaluations=2, trials=1)

    def program(
        self,
        search: domain.SearchProgram | None,
        search_factory: Callable[..., domain.SearchProgram] | None,
    ) -> domain.SearchProgram:
        """One program, from whichever fixture the subclass supplied.

        Only ``search_factory`` yields a genuinely new one. A program handed
        over as an instance is reused for both determinism passes, so
        per-instance state would go unseen — which is why the determinism law
        says so rather than implying otherwise.
        """

        if (search is None) == (search_factory is None):
            raise NotImplementedError(_required())
        return search if search_factory is None else search_factory(_propose)

    # --- running the search -------------------------------------------------

    def execute(self, search, search_factory, seed, budget, program=None):
        """One complete run, with its storage and the program that drove it."""

        if program is None:
            program = self.program(search, search_factory)
        storage = meta.Storage.in_memory()
        run = meta.run(
            task=meta.Task(evaluator=_evaluate, budget=budget),
            seed=seed,
            proposer=_propose,
            search=program,
            storage=storage,
            random_seed=13,
        )
        return run, storage, program

    def prepared(self, search, search_factory, start):
        return prepare_search(
            self.program(search, search_factory),
            proposer=start.search.proposer,
            budget=start.run_budget,
        )

    # --- the laws ----------------------------------------------------------

    def test_two_runs_of_the_same_program_are_identical(
        self, search, search_factory, seed, budget
    ) -> None:
        """Same program, same seed, same events — down to the run identity.

        A shared ``search`` instance is what exposes state accumulating
        *across* runs; a ``search_factory`` resets that state per run, so
        this law misses it there — the replay law below is what catches
        within-run statefulness in both configurations. Events are compared
        as canonical serialized bytes (exact-type), so a lying subclass of a
        durable record fails to serialize rather than slipping through.
        """

        first, first_storage, _ = self.execute(search, search_factory, seed, budget)
        second, second_storage, _ = self.execute(search, search_factory, seed, budget)
        first_events = first_storage.events.read(first.id)
        second_events = second_storage.events.read(second.id)

        assert first.id == second.id, "a program must not vary the run identity"
        assert serialization.dumps(first_events) == serialization.dumps(
            second_events
        ), (
            "two runs of the same program recorded different events; the usual "
            "cause is randomness not taken from state.randomness"
        )
        assert first.lineage() == second.lineage(), (
            "two runs of the same program produced different lineages"
        )
        assert replay_run_projection(first.id, first_events) == replay_run_projection(
            second.id, second_events
        ), "two runs of the same program replayed to different projections"

    def test_every_decision_is_attributed_and_explained(
        self, search, search_factory, seed, budget
    ) -> None:
        """Policy identity is stable, and every decision carries it.

        ``policy`` is optional — ``SearchProgram`` is ``next()``-only and the
        kernel synthesizes a local identity when none is declared. A declared
        identity must hold still: resume rebuilds by it. The check runs
        against the instance ``execute()`` drove, so drift accumulated while
        running is visible in both configurations.
        """

        program = self.program(search, search_factory)
        declared_before = getattr(program, "policy", None)
        run, storage, _ = self.execute(
            search, search_factory, seed, budget, program=program
        )
        projection = replay_run_projection(run.id, storage.events.read(run.id))
        start = projection.start
        assert start is not None

        declared = getattr(program, "policy", None)
        assert (declared is None) == (declared_before is None), (
            "the policy declaration appeared or vanished across the run; an "
            "identity a program only sometimes declares cannot be rebuilt on "
            "resume"
        )
        if declared is not None:
            assert type(declared) is domain.PolicyRef, (
                f"program.policy is {type(declared).__name__}; a declared "
                "policy identity must be exactly a PolicyRef"
            )
            assert declared_before == declared, (
                "program.policy before the run differs from after it; a "
                "policy identity must be stable — resume rebuilds by it"
            )
            second_read = getattr(program, "policy", None)
            assert second_read == declared, (
                "reading program.policy twice gave two different references; "
                "a policy identity must be stable — resume rebuilds by it"
            )
            assert declared == start.search.policy, (
                "the program's declared policy is not the one the run "
                "recorded at start"
            )
        else:
            assert start.search.policy.origin == "local", (
                "a program with no declared policy gets a synthesized local "
                "identity; the run recorded something else"
            )

        # Kernel regression guard, not a program property: the coordinator
        # stamps host.search.policy onto every decision and commits the
        # explanation alongside it, so a program cannot violate these two —
        # they pin the kernel invariant.
        assert all(
            item.policy == start.search.policy for item in projection.decisions
        ), "a decision was recorded under a policy other than the run's"
        assert len(projection.explanations) == len(projection.decisions), (
            "every decision must carry an explanation, so a reader can see why "
            "it was made without rerunning the program"
        )

    def test_each_decision_is_reproducible_from_the_state_that_preceded_it(
        self, search, search_factory, seed, budget
    ) -> None:
        """The core replay law: ``next`` is a pure function of prior state."""

        run, storage, program = self.execute(search, search_factory, seed, budget)
        events = storage.events.read(run.id)
        projection = replay_run_projection(run.id, events)
        start = projection.start
        assert start is not None
        # A ``Stop`` is a decision, so counting decisions is not enough: a
        # program that stops immediately would satisfy every law here while
        # proposing nothing, leaving the trial-shaped laws iterating over an
        # empty list. Widen ``budget`` if yours needs room to propose.
        assert any(
            isinstance(item.decision, domain.TrialSpec) for item in projection.decisions
        ), (
            "the program proposed no trial, so the suite checked nothing but a "
            "stop; give it a budget it can search within"
        )

        prepared = self.prepared(search, search_factory, start)
        for recorded in projection.decisions:
            historical = replay_search_state(run.id, events[: recorded.observed_version])
            assert prepared.program.next(historical) == prepared.program.next(
                historical
            ), (
                "next() gave two answers to the same state; a program may not "
                "carry decision state of its own — everything it needs is in "
                "the state it is handed"
            )
            assert prepared.program.next(historical) == recorded.decision, (
                "replaying the state that preceded a recorded decision did not "
                "reproduce that decision, so the run cannot be reconstructed"
            )

    def test_recorded_randomness_is_the_randomness_that_was_used(
        self, search, search_factory, seed, budget, monkeypatch
    ) -> None:
        """Both directions: recorded seeds derive, and used streams are recorded.

        The second half is a *tripwire*, not a proof: ``next()`` calls routed
        through ``DecisionRandomness.seed`` must stay within the streams the
        same decision declared. Accesses are keyed by the randomness object's
        ``decision_id``, so a stream drawn during one decision cannot be
        laundered by declaring it on a later one. A saved method alias or
        direct derivation from the root seed bypasses the tripwire —
        structural limits of in-process observation. Subset, not equality:
        declaring a stream a path never draws from is a shipped contract.
        """

        accessed_by_decision: dict[object, set[str]] = {}
        access_sequence: list[object] = []
        original_seed = domain.DecisionRandomness.seed

        def recording_seed(randomness, name):
            accessed_by_decision.setdefault(randomness.decision_id, set()).add(name)
            access_sequence.append(randomness.decision_id)
            return original_seed(randomness, name)

        # Patched BEFORE the run, so the tripwire watches the instance that
        # actually executed — a factory whose first product draws a hidden
        # stream while later products do not cannot slip a fresh replay
        # subject past it.
        monkeypatch.setattr(domain.DecisionRandomness, "seed", recording_seed)
        run, storage, program = self.execute(search, search_factory, seed, budget)
        live = {key: set(names) for key, names in accessed_by_decision.items()}
        live_sequence = list(access_sequence)
        events = storage.events.read(run.id)
        projection = replay_run_projection(run.id, events)
        start = projection.start
        assert start is not None

        recorded_ids: set[object] = set()
        order: dict[object, int] = {}
        for recorded in projection.decisions:
            historical = replay_search_state(run.id, events[: recorded.observed_version])
            decision_id = historical.randomness.decision_id
            recorded_ids.add(decision_id)
            order[decision_id] = len(order)
            for name, value in recorded.random_seeds.items():
                assert original_seed(historical.randomness, name) == value, (
                    f"the recorded {name!r} seed is not the one replay derives; "
                    "a decision's randomness must be reconstructible"
                )
            undeclared = live.get(decision_id, set()) - set(recorded.random_seeds)
            assert not undeclared, (
                f"a decision drew from streams it never declared: "
                f"{sorted(undeclared)}. A stream is recorded with the decision "
                "that used it — declaring it on a later decision leaves this "
                "decision's audit trail understating what it depended on."
            )
        stray = set(live) - recorded_ids
        assert not stray, (
            "the run drew randomness under decision ids no recorded decision "
            "owns; every draw belongs to the decision being made"
        )
        # Decision ids are derivable ahead of time, so a program could draw
        # under decision N+1's id while making decision N and declare the
        # stream there. Order is the tell: a legitimate run's draws arrive in
        # decision order, and a future-id draw lands out of order.
        positions = [
            order[decision_id]
            for decision_id in live_sequence
            if decision_id in order
        ]
        assert positions == sorted(positions), (
            "a draw under a later decision's id happened while an earlier "
            "decision was still being made; deriving a future decision's "
            "randomness launders a stream past per-decision attribution"
        )

        # And per decision, against a freshly prepared replay of next():
        # the tripwire again, on the replay subject.
        prepared = self.prepared(search, search_factory, start)
        for recorded in projection.decisions:
            historical = replay_search_state(run.id, events[: recorded.observed_version])
            accessed_by_decision.clear()
            prepared.program.next(historical)
            drawn: set[str] = set()
            for names in accessed_by_decision.values():
                drawn |= names
            undeclared = drawn - set(recorded.random_seeds)
            assert not undeclared, (
                f"next() drew from streams the decision never declared: "
                f"{sorted(undeclared)}"
            )

    def test_trial_decisions_use_recorded_authority_and_remaining_budget(
        self, search, search_factory, seed, budget
    ) -> None:
        """A program may not invent parents, a proposer, a budget, or a seed."""

        run, storage, program = self.execute(search, search_factory, seed, budget)
        events = storage.events.read(run.id)
        projection = replay_run_projection(run.id, events)
        start = projection.start
        assert start is not None
        for recorded in projection.decisions:
            if not isinstance(recorded.decision, domain.TrialSpec):
                continue
            historical = replay_search_state(run.id, events[: recorded.observed_version])
            trial = recorded.decision
            assert set(trial.parent_ids) <= set(historical.artifact_ids), (
                "a trial parent must already exist in the search state"
            )
            assert trial.proposer == start.search.proposer
            assert trial.budget.narrow(historical.remaining_budget) == trial.budget, (
                "a trial budget must already fit the remaining run budget"
            )
            assert recorded.random_seeds["trial"] == trial.random_seed

    def test_the_search_stops_and_the_stop_is_stable(
        self, search, search_factory, seed, budget
    ) -> None:
        run, storage, program = self.execute(search, search_factory, seed, budget)
        projection = replay_run_projection(run.id, storage.events.read(run.id))
        start = projection.start
        assert start is not None
        state = projection.search_state
        assert state.stop is not None, "a conforming search terminates"
        assert self.prepared(search, search_factory, start).program.next(state) == (
            state.stop
        ), "replaying the final state did not reproduce the recorded stop"

    def test_the_run_survives_a_serialization_round_trip(
        self, search, search_factory, seed, budget
    ) -> None:
        run, storage, program = self.execute(search, search_factory, seed, budget)
        events = storage.events.read(run.id)
        restored = serialization.loads(serialization.dumps(events), tuple)
        assert isinstance(restored, tuple), "serialized events did not load as a tuple"
        assert replay_run_projection(run.id, restored) == replay_run_projection(
            run.id, events
        ), (
            "the run did not survive a serialization round trip; a decision "
            "recorded something that cannot be stored and read back"
        )


__all__ = ["SearchProgramTests"]
