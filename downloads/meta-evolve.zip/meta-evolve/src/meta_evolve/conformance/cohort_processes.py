"""The cohort oracle again, with the components in real worker processes.

`cohort_dispatch` drives a generation through a dispatcher whose components
run here -- inline, or on a `serve` thread over a socketpair. This drives the
SAME generation through worker processes, and the barrier the two produce
must agree: the next cohort, what was recorded, the ranking and the winner.

Why a second builder rather than a third backend. `cohort_dispatch` builds its
coordinator by hand, with synthetic manifests and per-call Python callables --
neither of which a child process can match or reach. A run whose work leaves
this process has to be started the way a user starts one: a module a worker
can import, a registry that resolves the components, and the manifests the
handshake checks. So the run here comes from `Session.start`, and the workers
are admitted before the rollover, exactly as `Session.drive` does it.

What is NOT compared across the two is anything that depends on where a run
was started from: a module-built run records its own manifests and identity.
The barrier is what both answer, and the barrier is what the policy sees.
"""

from __future__ import annotations

from collections.abc import Sequence

import meta_evolve as meta
from meta_evolve.application.dispatch_admission import HostTerms
from meta_evolve.application.dispatcher import Dispatcher
from meta_evolve.application.search_preparation import prepare_search
from meta_evolve.environment import environment_fingerprint
from meta_evolve.experiment_modules import experiment_declaration

from .cohort_dispatch import barrier_through

#: What these runs lease for. The floor, so a law never waits longer than it
#: has to for a worker that is genuinely gone.
LEASE_SECONDS = 10


def barrier_view_from_module(
    module: str,
    order: Sequence[tuple[int, str]],
    *,
    storage: meta.Storage,
    workers: int,
    execution=None,
):
    """The barrier a run of `module` reaches, with `workers` worker processes.

    `execution` replaces the backend, for a law that wants the same run driven
    somewhere else -- inline, to compare against.
    """

    declaration = experiment_declaration(module)
    session = meta.Session.start(declaration, storage=storage, mode="distributed")
    coordinator = session._coordinator
    prepared = prepare_search(
        declaration.search,
        proposer=declaration.proposer,
        budget=coordinator.task.budget,
    )
    broker = coordinator.work_broker(lease_seconds=LEASE_SECONDS)
    if execution is None:
        from meta_evolve.distributed import WorkerProcesses

        execution = WorkerProcesses(workers, module)
    # Admitted BEFORE the rollover, which is the order `Session.drive` keeps
    # and the reason a failed handshake costs a run nothing (PD2). Here it is
    # only faithfulness: these runs are fresh, so no law of this module can
    # tell the two orders apart. What the order BUYS is pinned where it acts,
    # on `drive_distributed`, by the refused-worker law in
    # `tests/test_worker_processes.py`.
    admitted = execution.open(_terms(coordinator))
    coordinator.fence.install(broker.rollover(coordinator.run_id))

    def dispatcher_for(claim_order):
        dispatcher = Dispatcher(
            coordinator,
            broker,
            claim_order=claim_order,
            endpoints=admitted.endpoints or None,
            admission=admitted,
        )

        def closing() -> None:
            admitted.finish(completed=True)
            dispatcher.close()

        return dispatcher, closing

    return barrier_through(coordinator, prepared, order, dispatcher_for=dispatcher_for)


def _terms(coordinator) -> HostTerms:
    return HostTerms(
        run_id=coordinator.run_id,
        started=coordinator.projection.start,
        context=None,
        manifests=coordinator.capabilities.component_manifests,
        fingerprint=environment_fingerprint(),
        heartbeat_seconds=max(1, LEASE_SECONDS // 4),
    )


__all__ = ["LEASE_SECONDS", "barrier_view_from_module"]
