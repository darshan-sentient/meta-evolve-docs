"""Executable evaluator checks published as a subclassable suite.

An evaluator is an ordinary callable, so the interesting laws are not about its
signature — they are about *authority and independence*. It scores a candidate;
it does not get to turn a broken candidate into a cheap low score, it does not
get to remember the candidates before it, and it does not get to edit what it
was handed. Each is checked through ``meta.run``, so an evaluator passes on
behavior the search can actually see.

The last of those is not redundant, though it looks it. With the built-in
codecs an evaluator receives a frozen value decoded from the stored payload and
*cannot* reach the caller's object — but a codec is user-supplied, and one that
hands back the instance it encoded gives the evaluator the real thing to edit.
:class:`~meta_evolve.conformance.codecs.ArtifactCodecTests` checks that codec
end through ``mutable_values``; this suite checks the evaluator end.

Every check scores a seed with no trials, the smallest run that reaches an
evaluator exactly once.

*On length.* This module exceeds the repository's usual 300-line guideline
and is kept whole deliberately: it is one published class whose entire
interface is the fixtures and hooks its laws call, and the available split
would put a subclass author's overrides in a different file from the laws
that consume them.
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

import meta_evolve as meta
from meta_evolve.application.results import TrialView
from meta_evolve.domain import EvaluatorFailure, InvalidOutput, Objective


def _required(name: str) -> str:
    return (
        f"EvaluatorTests needs a {name!r} fixture: override it in your "
        "subclass to point the suite at your evaluator."
    )


def _keep(parent, *, context):
    return parent


class EvaluatorTests:
    """What every evaluator owes the search that ranks by its scores.

    Subclass it, name the subclass ``Test...``, and override four things::

        class TestRecipeScore(EvaluatorTests):
            def make_evaluator(self):
                # A NEW object per call: a fresh instance, or a fresh
                # lambda wrapper for a plain function.
                return lambda recipe: score_recipe(recipe)

            @pytest.fixture
            def candidates(self):
                return (Recipe(("preheat",)), Recipe(()))

            @pytest.fixture
            def objectives(self):
                return (meta.Maximize("score"),)

            @pytest.fixture
            def scored_candidates(self):
                # The semantic oracle; () claims scores are unpredictable.
                return ((Recipe(("preheat",)), {"score": 1.0}),)

    ``candidates`` are values your evaluator accepts, in the task's artifact
    type; give it at least two so the ordering law has something to compare.
    ``rejected_candidates`` defaults to empty, unlike the codec suite's
    ``rejected_values``: an evaluator whose whole artifact type is scorable has
    nothing to refuse, and that is a legitimate evaluator. A custom artifact
    domain needs two more overrides: ``artifact_type`` (the type your task
    declares — it must carry string ``KIND`` and ``REPRESENTATION``
    attributes, per the artifact-domain tutorial) and ``registry`` (a
    ``Registry`` with your codec registered).
    """

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture
    def candidates(self) -> tuple[object, ...]:
        """Representative values the evaluator scores, including edge cases."""

        raise NotImplementedError(_required("candidates"))

    @pytest.fixture
    def objectives(self) -> tuple[Objective, ...]:
        """The objectives a task using this evaluator declares."""

        raise NotImplementedError(_required("objectives"))

    @pytest.fixture
    def rejected_candidates(self) -> tuple[object, ...]:
        """Values the evaluator cannot score, if there are any."""

        return ()

    @pytest.fixture
    def scored_candidates(self) -> tuple[tuple[object, dict], ...]:
        """``(candidate, expected metrics)`` pairs — the semantic oracle.

        Every other law holds for an evaluator that scores every candidate
        ``0.0``; only stated expectations catch it. No default, like the
        codec suite's ``rejected_values``: ``()`` is a positive claim that
        your scores are not predictable (a judge model, a wall-clock
        benchmark), and it skips the law visibly rather than passing it.
        """

        raise NotImplementedError(_required("scored_candidates"))

    @pytest.fixture
    def artifact_type(self) -> type | None:
        """The task's artifact type, or ``None`` for the built-in default."""

        return None

    @pytest.fixture
    def registry(self) -> meta.Registry | None:
        """A ``Registry``, required whenever ``artifact_type`` is custom."""

        return None

    # --- running one evaluation --------------------------------------------

    def evaluate(
        self,
        evaluator: Callable[..., object],
        objectives: tuple[Objective, ...],
        candidate: object,
        artifact_type: type | None,
        registry: meta.Registry | None,
    ) -> TrialView:
        """Score one candidate through the kernel and return its trial.

        Not ``Run.best_trial``: that raises when nothing scored successfully,
        and a refused candidate is an outcome to inspect, not an error.
        """

        task = meta.Task(
            evaluator=evaluator,
            objectives=objectives,
            budget=meta.Budget(evaluations=1, trials=0),
            **({} if artifact_type is None else {"artifact": artifact_type}),
        )
        run = meta.run(
            task=task,
            seed=candidate,
            proposer=_keep,
            search=meta.Greedy(max_trials=0),
            **({} if registry is None else {"registry": registry}),
        )
        trials = run.trials()
        assert len(trials) == 1, "a seed-only run evaluates exactly once"
        return trials[0]

    def make_evaluator(self) -> Callable[..., object]:
        """Build a brand-new evaluator. Required — there is no default.

        Every law builds its subject here; the ordering law builds two, one
        per pass, and refuses the same object twice. Return a **new** object
        each call — a fresh instance for a class, a fresh ``lambda`` wrapper
        for a plain function::

            def make_evaluator(self):
                return lambda candidate: score_recipe(candidate)

        There is no way to tell from outside whether an evaluator carries
        state (an object can hold a cache, a closure a cell, a function a
        module global), so the suite asks for a builder rather than guessing.
        The distinct-object check below is a configuration sanity check, not
        proof of fresh state: two distinct objects sharing hidden state remain
        invisible in-process.
        """

        raise NotImplementedError(
            "EvaluatorTests needs a 'make_evaluator' method: override it to "
            "build a new evaluator per call. Statelessness cannot be detected "
            "from outside, so the suite asks rather than assumes."
        )

    def outcome(self, trial: TrialView) -> object:
        """The projection of a trial that a repeated call must reproduce.

        A deliberate subset, not the whole trial. Metrics alone would let an
        evaluator hide a call counter in its uncertainty or evidence and still
        look stable, so those are in; reported ``tokens`` and ``spend_micros``
        are in for the same reason — identical work must report identical
        charged spend; a live wrapper whose pricing genuinely varies is a
        non-deterministic component, not a stable one. Only
        ``usage.wall_seconds`` is out, because it differs between two identical
        calls by nature.

        Overriding this is a trusted-author act: every field you remove is one
        the stability laws stop checking, so narrow it only for a field you
        have confirmed varies legitimately.

        An author narrowing this for a metered wrapper is not guessing: two
        identical calls to one pay-per-call provider billed 14 then 1 micro-USD
        while their token counts moved 96 → 11, measured live on 2026-08-16 —
        one provider on one day, so treat it as an existence proof rather than a
        rate. Both fields drifted, and they drifted *together*, so dropping
        ``spend_micros`` alone is rarely the right narrowing: a wrapper unstable
        in charge was also unstable in tokens, and keeping ``tokens`` would only
        move the failure.
        """

        return (
            dict(trial.metrics),
            dict(trial.uncertainty),
            tuple((item.kind, dict(item.data), item.uri) for item in trial.evidence),
            trial.usage.tokens,
            trial.usage.spend_micros,
            type(trial.failure).__name__ if trial.failure is not None else None,
        )

    # --- the laws ----------------------------------------------------------

    def test_every_declared_objective_gets_a_metric(
        self, candidates, objectives, artifact_type, registry
    ) -> None:
        """A task's objectives are the evaluator's obligation.

        The kernel already refuses an evaluation missing an objective metric
        (``CallableEvaluator._require_objectives`` converts it to a typed
        ``InvalidOutput``), so the refusal surfaces here as a failed trial
        whose message names the missing objectives.
        """

        assert candidates, "the suite proves nothing against an empty 'candidates'"
        evaluator = self.make_evaluator()
        for candidate in candidates:
            trial = self.evaluate(
                evaluator, objectives, candidate, artifact_type, registry
            )
            assert trial.failure is None, (
                f"scoring {candidate!r} was refused by the kernel: "
                f"{trial.failure}"
            )

    def test_repeated_scoring_is_stable_within_one_process(
        self, candidates, objectives, artifact_type, registry
    ) -> None:
        """Ranking is meaningless if one candidate scores two ways."""

        evaluator = self.make_evaluator()
        for candidate in candidates:
            first = self.outcome(
                self.evaluate(evaluator, objectives, candidate, artifact_type, registry)
            )
            second = self.outcome(
                self.evaluate(evaluator, objectives, candidate, artifact_type, registry)
            )
            assert first == second, f"scoring is not stable for {candidate!r}"

    def test_a_score_does_not_depend_on_what_was_scored_before(
        self, candidates, objectives, artifact_type, registry
    ) -> None:
        """No hidden state across candidates — a counter, a cache, a running total.

        The stability law above re-scores one candidate and misses all of
        them, since a per-call counter answers the same question the same way
        twice. Scoring the list forwards then backwards is what exposes order
        dependence.

        The reverse pass uses a *new* evaluator from ``make_evaluator``. Two
        passes through one instance would let a cache the forward pass filled
        answer the reverse pass, hiding the contamination this law seeks.
        """

        assert len(candidates) >= 2, (
            "'candidates' needs at least two values: with one, the ordering "
            "law has nothing to reorder and would pass without checking"
        )
        forward = self.make_evaluator()
        reverse = self.make_evaluator()
        assert reverse is not forward, (
            "make_evaluator() returned the same object twice. The reverse "
            "pass needs its own evaluator — return a new instance, or a "
            "fresh lambda wrapper for a plain function. (A configuration "
            "sanity check: distinct objects sharing hidden state remain "
            "invisible.)"
        )
        forwards = {
            index: self.outcome(
                self.evaluate(forward, objectives, candidate, artifact_type, registry)
            )
            for index, candidate in enumerate(candidates)
        }
        backwards = {
            index: self.outcome(
                self.evaluate(reverse, objectives, candidate, artifact_type, registry)
            )
            for index, candidate in reversed(list(enumerate(candidates)))
        }
        assert forwards == backwards, "scoring depends on the order candidates arrive"

    def test_scoring_does_not_edit_the_candidate(
        self, candidates, objectives, artifact_type, registry
    ) -> None:
        """Evaluator independence, concretely: scoring is not an edit.

        An evaluator that edits in place rewrites an artifact nobody proposed,
        and every later comparison in the run is against that.

        Observed through the kernel's content digest rather than a copy of the
        candidate. A copy is the artifact type's own code — a ``__deepcopy__``
        or ``__reduce__`` that returns ``self`` would leave the law comparing
        an object with itself — whereas the digest is derived from the encoded
        payload and nothing the candidate does can forge it.

        Its scope is exactly that: what the codec encodes. An edit the codec
        does not encode cannot reach the artifact either, so it is outside
        what this law is about.
        """

        evaluator = self.make_evaluator()
        for candidate in candidates:
            first = self.evaluate(
                evaluator, objectives, candidate, artifact_type, registry
            )
            second = self.evaluate(
                evaluator, objectives, candidate, artifact_type, registry
            )
            assert second.artifact.digest == first.artifact.digest, (
                f"scoring changed {candidate!r}: encoding it after one "
                "evaluation gives a different artifact than before. An "
                "evaluator ranks a candidate, it does not edit one. (The "
                "other suspect is a stateful codec whose encode drifts "
                "between calls — the codec suite's stability law tells the "
                "two apart.)"
            )

    def test_declared_expectations_hold_exactly(
        self, scored_candidates, objectives, artifact_type, registry
    ) -> None:
        """The semantic law: a stated expectation is a contract, not a hint.

        Stability, ordering, and independence all pass for a constant-zero
        evaluator; this is the only law that can tell it from a working one,
        and it reaches exactly as far as the expectations the author states.
        """

        if not scored_candidates:
            pytest.skip(
                "no 'scored_candidates': semantic scoring was not exercised. "
                "Declare (candidate, expected metrics) pairs wherever your "
                "scores are predictable."
            )
        evaluator = self.make_evaluator()
        for candidate, expected in scored_candidates:
            trial = self.evaluate(
                evaluator, objectives, candidate, artifact_type, registry
            )
            assert trial.failure is None, (
                f"scoring {candidate!r} failed: {trial.failure}"
            )
            assert dict(trial.metrics) == dict(expected), (
                f"scoring {candidate!r} produced {dict(trial.metrics)}, but "
                f"the subclass declared {dict(expected)}"
            )

    def test_rejected_candidates_become_typed_failures_not_low_scores(
        self, rejected_candidates, objectives, artifact_type, registry
    ) -> None:
        """The anti-pattern this rules out: ``except Exception: return 0.0``.

        A candidate the evaluator cannot score must arrive as a typed failure,
        so search can tell "this was broken" from "this was bad". Raising is
        the ordinary way to say so — the kernel converts the exception into an
        ``EvaluatorFailure``, and a returned score is believed.

        Empty ``rejected_candidates`` skips visibly rather than fails: some
        evaluators refuse nothing, and a skip cannot be mistaken for a pass.
        """

        if not rejected_candidates:
            pytest.skip(
                "no 'rejected_candidates': this law was not exercised. Override "
                "the fixture if your evaluator refuses anything."
            )
        evaluator = self.make_evaluator()
        for candidate in rejected_candidates:
            trial = self.evaluate(
                evaluator, objectives, candidate, artifact_type, registry
            )
            assert isinstance(trial.failure, (EvaluatorFailure, InvalidOutput)), (
                f"{candidate!r} was scored instead of refused; a candidate the "
                "evaluator cannot handle is a typed failure, never a low score"
            )


__all__ = ["EvaluatorTests"]
