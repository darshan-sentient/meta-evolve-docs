"""A cohort generation driven through the production writer and builders.

`barrier_view(program, width, order)` commits one generation with
`commit_cohort`, completes its members in the given ORDER through the same
builders a dispatcher uses -- `build_proposal_completion` and `build_evaluation`
over the projection at that point -- and returns what the policy sees at the
barrier. Nothing here writes an event by hand: dispositions and reservations are
computed inside the builders, and that computation is what could depend on the
order results arrive in.

The reference for streams that real worker processes produce out of order.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass
from itertools import permutations

import meta_evolve as meta
from meta_evolve import domain
from meta_evolve.adapters import (
    CallableEvaluator,
    CallableProposer,
    DecodedValueProposerRunner,
)
from meta_evolve.application.codecs import CodecIndex
from meta_evolve.application.coordinator import SequentialCoordinator
from meta_evolve.application.decisions import commit_cohort
from meta_evolve.application.evaluation_execution import build_evaluation
from meta_evolve.application.executors import (
    LocalEvaluationExecutor,
    LocalProposalExecutor,
    ProposalRequest,
)
from meta_evolve.application.identities import completion_key_for, correlation_for_trial
from meta_evolve.application.proposal_building import build_proposal_completion
from meta_evolve.application.search_preparation import prepare_search
from meta_evolve.application.work import ProposalWork
from meta_evolve.domain.search import rank_evaluations

PROPOSAL = "proposal"
EVALUATION = "evaluation"

#: One completion event: which member, and which of its two work kinds.
Completion = tuple[int, str]


def _propose(parent, *, context):
    return parent + 1


def _evaluate(candidate):
    return candidate


@dataclass(frozen=True)
class BarrierView:
    """What the policy sees once a generation has completed, and what it did next."""

    state: domain.SearchState
    next_cohort: tuple[domain.SearchDecision, ...]
    recorded: tuple[domain.SearchDecision, ...]
    ranking: tuple[domain.ArtifactId, ...]
    winner: domain.ArtifactId | None
    run_id: domain.RunId
    events: tuple[domain.EventEnvelope, ...]


def interleavings(width: int) -> Iterator[tuple[Completion, ...]]:
    """Every order of a generation's completions with each proposal before its evaluation."""

    events = [(member, kind) for member in range(width) for kind in (PROPOSAL, EVALUATION)]
    seen: set[tuple[Completion, ...]] = set()
    for order in permutations(events):
        if order in seen:
            continue
        position = {event: index for index, event in enumerate(order)}
        if all(
            position[(member, PROPOSAL)] < position[(member, EVALUATION)]
            for member in range(width)
        ):
            seen.add(order)
            yield order


def barrier_view(
    program: domain.SearchProgram | Callable[..., domain.SearchProgram],
    width: int,
    order: Sequence[Completion],
    *,
    budget: meta.Budget | None = None,
) -> BarrierView:
    """Commit a generation, complete it in `order`, and read the barrier.

    `program` is an instance, or a factory called with the proposer. `width` must
    be the width the program declares.
    """

    coordinator, prepared = _coordinator(program, budget)
    if prepared.cohort_width != width:
        raise ValueError(
            f"the program declares cohort width {prepared.cohort_width}, not {width}"
        )
    committed = commit_cohort(
        coordinator,
        prepared.program,
        prepared.program.next_cohort(coordinator.projection.search_state),
    )
    trials = [
        domain.Trial.from_decision_record(item.record, coordinator.run_id)
        for item in committed
        if isinstance(item.record.decision, domain.TrialSpec)
    ]
    for member, kind in order:
        if member >= len(trials):
            continue
        if kind == PROPOSAL:
            _complete_proposal(coordinator, trials[member])
        else:
            _complete_evaluation(coordinator, trials[member])

    state = coordinator.projection.search_state
    if coordinator.projection.stop is not None:
        # The generation was a stop: there is no barrier and nothing follows it.
        following, recorded = (), ()
    else:
        following = prepared.program.next_cohort(state)
        recorded = commit_cohort(coordinator, prepared.program, following)
    objective = coordinator.task.objectives[0]
    ranked = rank_evaluations(
        objective,
        [item.evaluation for item in coordinator.projection.completed_evaluations],
    )
    return BarrierView(
        state=state,
        next_cohort=tuple(following),
        recorded=tuple(item.record.decision for item in recorded),
        ranking=tuple(item.artifact_id for item in ranked),
        winner=ranked[0].artifact_id if ranked else None,
        run_id=coordinator.run_id,
        events=tuple(coordinator.events.read(coordinator.run_id)),
    )


def _coordinator(program, budget):
    proposer = CallableProposer(_propose)
    codecs = CodecIndex.builtin()
    task = domain.Task(
        evaluator=_evaluate, budget=budget or meta.Budget(evaluations=12, trials=12)
    )
    if not hasattr(program, "next") and callable(program):
        program = program(_propose)
    prepared = prepare_search(program, proposer=proposer.component, budget=task.budget)
    coordinator = SequentialCoordinator(
        run_id=domain.RunId("run-cohort-conformance"),
        task_id=domain.TaskId("task-cohort-conformance"),
        task=task,
        run_budget=task.budget,
        random_seed=13,
        search=prepared.spec,
        proposer_runner=DecodedValueProposerRunner(proposer, proposer.component, codecs),
        proposer_ref=proposer.component,
        evaluator=CallableEvaluator(_evaluate, task.objectives),
        storage=meta.Storage.in_memory(),
        codecs=codecs,
    )
    coordinator.start(0)
    return coordinator, prepared


def _complete_proposal(coordinator, trial: domain.Trial) -> None:
    parents = tuple(coordinator.artifacts.get(item) for item in trial.spec.parent_ids)
    encoded = LocalProposalExecutor(
        coordinator.proposer_runner, coordinator.codecs, coordinator.task
    ).propose(
        parents,
        ProposalRequest(
            random_seed=trial.spec.random_seed,
            step=trial.logical_step,
            objectives=coordinator.task.objectives,
        ),
    )
    built = build_proposal_completion(
        coordinator,
        ProposalWork(trial=trial, completion_key=completion_key_for(trial.id)),
        encoded,
    )
    coordinator.commit_batch(
        list(built.bodies),
        occurrences=built.occurrences,
        correlation=correlation_for_trial(trial.id),
    )


def _complete_evaluation(coordinator, trial: domain.Trial) -> None:
    projection = coordinator.projection
    completed = projection.completed_trial(trial.id)
    # Only an authorized evaluation is owed: a failed proposal or a terminally
    # skipped evaluation has nothing to complete, whatever the order says.
    if (
        completed is None
        or not completed.outcome.artifact_ids
        or projection.disposition_for(trial.id) is not True
    ):
        return
    artifact = coordinator.artifacts.get(completed.outcome.artifact_ids[0])
    result = LocalEvaluationExecutor(coordinator.evaluator, coordinator.codecs).evaluate(
        artifact
    )
    evidence, evaluation = build_evaluation(
        projection,
        completed.trial,
        artifact.id,
        task=coordinator.task,
        result=result,
        run_budget=coordinator.run_budget,
    )
    coordinator.commit_batch(
        [*evidence, evaluation], correlation=correlation_for_trial(trial.id)
    )


__all__ = [
    "EVALUATION",
    "PROPOSAL",
    "BarrierView",
    "barrier_view",
    "interleavings",
]
