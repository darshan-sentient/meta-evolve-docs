"""Conformance suites an extension author runs against their own components.

pytest-native, on the pandas ``ExtensionArray`` model: each suite is a plain
class whose collaborators arrive as fixtures. Subclass it, name the subclass
``Test...`` so pytest collects it, override the fixtures, and the suite runs
against your implementation. The base classes are deliberately *not* named
``Test...``, so importing one never runs it twice.

``pytest`` is required to import this package, and this package is the only
place in ``meta_evolve`` that imports it — installing the library never pulls
a test runner in, and nothing imports ``meta_evolve.conformance`` for you.
Install it with the extra::

    pip install "meta-evolve[conformance]"

**What is covered.** Every extension component family, plus the mutation
surfaces M8 and M9 added:

- artifact codecs — :class:`~meta_evolve.conformance.codecs.ArtifactCodecTests`;
- repository-editing proposers, with and without audited experience pull —
  :class:`~meta_evolve.conformance.providers.RepositoryProposerTests`,
  :class:`~meta_evolve.conformance.providers.PullRepositoryProposerTests`;
- evaluators — :class:`~meta_evolve.conformance.evaluators.EvaluatorTests`;
- search programs —
  :class:`~meta_evolve.conformance.search_programs.SearchProgramTests`;
- context policies —
  :class:`~meta_evolve.conformance.context_policies.ContextPolicyTests`;
- workspaces —
  :class:`~meta_evolve.conformance.workspaces.WorkspaceProviderTests`;
- sandboxes —
  :class:`~meta_evolve.conformance.sandboxes.SandboxProviderTests`, including
  timeout, independent byte-bound, partial-output, and usage laws;
- harness and policy mutation surfaces —
  :class:`~meta_evolve.conformance.mutation_surfaces.MutationSurfaceTests`.

Store adapters keep an internal function-based suite in ``tests/``. They are
not one of the extension families above and are not published from here.

``tests/`` subclasses every published class — the built-in codecs, all four
mutation surfaces, every shipped search program, both workspace and sandbox
providers, every selecting context policy, and the two proposer suites via
in-repository reference callables (no first-party provider adapter ships) —
so the kit and the kernel's own conformance are the same code and cannot
drift.

**How a law observes its subject.** Through kernel records — content digests,
committed events, canonical serialized bytes — or through projections supplied
by the *subclass author*, who is trusted (they could rewrite the law itself);
never through the subject's own ``__eq__``, copy, or self-report, which a
broken implementation could lie with. A value type usually ships with the
subject, so its equality is the subject's code too — the codec suite compares
values only through ``value_state``. A law that still
observes through a subject-influenced channel says so on the law.

**The subclass contract, uniformly.** A required hook raises
``NotImplementedError`` naming what to supply. An optional law that goes
unexercised skips visibly or is cross-checked against a declaration — never a
silent green pass on zero iterations. A law that needs an uncontaminated
second subject asks for a factory and refuses the same object twice. Teeth
builders are zero-arg: a class is its own builder; wrap a plain function as
``lambda: fn``. (One known divergence: ``registry`` is a fixture in
``EvaluatorTests`` and a method hook in ``ContextPolicyTests``; unification is
tracked as a follow-up.)

Each suite states the laws it does not check — sampling limits, in-process
tripwires, structural blind spots — on the law or class where the limit
lives. The codec suite's repeated calls are in-process and its patched
file/socket entry points are intentionally common-I/O tripwires: scoped
evidence, not a proof of purity.
"""

import pytest

# Registered before the submodules are imported, so pytest rewrites their
# assertions like a test module's: a failing law then shows the compared
# values instead of a bare AssertionError an outside author cannot act on.
pytest.register_assert_rewrite(
    "meta_evolve.conformance.codecs",
    "meta_evolve.conformance.context_policies",
    "meta_evolve.conformance.evaluators",
    "meta_evolve.conformance.mutation_surfaces",
    "meta_evolve.conformance.providers",
    "meta_evolve.conformance.sandboxes",
    "meta_evolve.conformance.search_programs",
    "meta_evolve.conformance.workspaces",
)

from .codecs import ArtifactCodecTests
from .context_policies import ContextPolicyTests
from .evaluators import EvaluatorTests
from .mutation_surfaces import MutationSurfaceTests
from .providers import PullRepositoryProposerTests, RepositoryProposerTests
from .sandboxes import SandboxProviderTests
from .search_programs import SearchProgramTests
from .workspaces import WorkspaceProviderTests

__all__ = [
    "ArtifactCodecTests",
    "ContextPolicyTests",
    "EvaluatorTests",
    "MutationSurfaceTests",
    "PullRepositoryProposerTests",
    "RepositoryProposerTests",
    "SandboxProviderTests",
    "SearchProgramTests",
    "WorkspaceProviderTests",
]
