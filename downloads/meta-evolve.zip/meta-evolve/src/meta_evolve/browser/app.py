"""Starlette routes over the browser-owned read-only storage reader."""

from __future__ import annotations

from contextlib import asynccontextmanager
from importlib.resources import files
from pathlib import Path

import meta_evolve as meta
from jinja2 import Environment, PackageLoader, select_autoescape
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, Response
from starlette.routing import Route

from .artifacts import artifact_page, diff_page
from .models import MissingArtifact
from .presentation import comparison_page, inspection_page
from .reader import BrowserReader, MissingRun, UnstableComparison
from .security import SecurityHeaders


_TEMPLATES = Environment(
    loader=PackageLoader("meta_evolve.browser", "templates"),
    autoescape=select_autoescape(("html", "xml")),
)
_ASSETS = files("meta_evolve.browser").joinpath("assets")
_CSS = _ASSETS.joinpath("browser.css").read_text()
_JS = _ASSETS.joinpath("browser.js").read_text()


def _html(template: str, *, status: int = 200, **context: object) -> HTMLResponse:
    return HTMLResponse(
        _TEMPLATES.get_template(template).render(**context), status_code=status
    )


def _reader(request: Request) -> BrowserReader:
    return request.app.state.browser_reader


async def catalog(request: Request) -> Response:
    query = request.query_params.get("q", "")
    result = await _reader(request).catalog(query)
    return _html(
        "catalog.html",
        title="Run catalog",
        query=query,
        cards=result.cards,
        poll_version=result.poll_version,
    )


async def run_detail(request: Request) -> Response:
    run_id = request.path_params["run_id"]
    reader = _reader(request)
    snapshot = await reader.inspection(run_id)
    choices = await reader.run_ids()
    return _html(
        "run.html",
        title=f"Run {run_id}",
        **inspection_page(snapshot, choices),
    )


async def compare(request: Request) -> Response:
    left = request.query_params.get("left")
    right = request.query_params.get("right")
    if not left or not right:
        raise MissingRun("comparison requires left and right run ids")
    result = await _reader(request).comparison(left, right)
    return _html(
        "compare.html",
        title="Run comparison",
        **comparison_page(result),
    )


async def artifact_detail(request: Request) -> Response:
    run_id = request.path_params["run_id"]
    artifact_id = request.path_params["artifact_id"]
    snapshot = await _reader(request).artifact(run_id, artifact_id)
    return _html(
        "artifact.html",
        title=f"Artifact {artifact_id}",
        **artifact_page(snapshot),
    )


def _find_artifact(snapshot: object, artifact_id: str) -> meta.ArtifactView:
    found = next(
        (item for item in snapshot.artifacts if str(item.id) == artifact_id), None
    )
    if found is None:
        raise MissingArtifact(artifact_id)
    return found


class DiffRefused(ValueError):
    """A requested pair is present but not an allowed direct-family diff."""


async def artifact_diff(request: Request) -> Response:
    run_id = request.path_params["run_id"]
    parent_id = request.query_params.get("parent")
    child_id = request.query_params.get("child")
    if not parent_id or not child_id:
        raise DiffRefused("diff requires explicit parent and child occurrence ids")
    snapshot = await _reader(request).artifact(run_id, child_id)
    parent = _find_artifact(snapshot, parent_id)
    try:
        context = diff_page(run_id, parent, snapshot.artifact)
    except ValueError as error:
        raise DiffRefused(str(error)) from None
    return _html("diff.html", title="Artifact diff", **context)


async def artifact_raw(request: Request) -> Response:
    run_id = request.path_params["run_id"]
    artifact_id = request.path_params["artifact_id"]
    snapshot = await _reader(request).artifact(run_id, artifact_id)
    digest = snapshot.artifact.digest
    filename = f"artifact-{digest[:16]}.canonical-payload-v1.json"
    return Response(
        meta.artifact_payload_bytes(snapshot.artifact),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


async def poll_catalog(request: Request) -> Response:
    version = await _reader(request).poll_catalog()
    return JSONResponse({"version": version})


async def poll_run(request: Request) -> Response:
    run_id = request.path_params["run_id"]
    version = await _reader(request).poll_run(run_id)
    return JSONResponse({"run_id": run_id, "version": version})


async def stylesheet(_request: Request) -> Response:
    return Response(_CSS, media_type="text/css")


async def script(_request: Request) -> Response:
    return Response(_JS, media_type="text/javascript")


def _error_page(status: int, title: str, message: str) -> HTMLResponse:
    return _html(
        "error.html", status=status, title=title, heading=title, message=message
    )


async def _missing(_request: Request, _error: Exception) -> Response:
    return _error_page(
        404, "Not found", "The requested run or artifact is not available."
    )


async def _refusal(_request: Request, error: Exception) -> Response:
    return _error_page(422, "Request refused", str(error))


async def _capability(_request: Request, error: Exception) -> Response:
    message = str(error)
    if "no artifact codec registered" in message:
        message = (
            "Artifact codec unavailable. Restart the browser with "
            "--module MODULE to load the experiment registry."
        )
    return _error_page(422, "Run unavailable", message)


async def _unavailable(_request: Request, _error: Exception) -> Response:
    return _error_page(
        503, "Temporarily unavailable", "The request can be retried safely."
    )


async def _defect(_request: Request, _error: Exception) -> Response:
    return _error_page(
        500, "Unable to display run", "Stored details were not exposed."
    )


def create_app(
    storage: Path | str,
    *,
    reader: BrowserReader | None = None,
    registry: meta.Registry | None = None,
) -> Starlette:
    """Build the read-only ASGI application; storage opens in its lifespan."""

    browser_reader = reader or BrowserReader(storage, registry=registry)

    @asynccontextmanager
    async def lifespan(application: Starlette):
        try:
            await browser_reader.start()
        except Exception:
            await browser_reader.close()
            raise
        application.state.browser_reader = browser_reader
        try:
            yield
        finally:
            await browser_reader.close()

    routes = [
        Route("/", catalog, methods=["GET"]),
        Route("/runs/{run_id}", run_detail, methods=["GET"]),
        Route(
            "/runs/{run_id}/artifacts/{artifact_id}",
            artifact_detail,
            methods=["GET"],
        ),
        Route(
            "/runs/{run_id}/artifacts/{artifact_id}/raw",
            artifact_raw,
            methods=["GET"],
        ),
        Route("/runs/{run_id}/diff", artifact_diff, methods=["GET"]),
        Route("/compare", compare, methods=["GET"]),
        Route("/poll/catalog", poll_catalog, methods=["GET"]),
        Route("/poll/runs/{run_id}", poll_run, methods=["GET"]),
        Route("/assets/browser.css", stylesheet, methods=["GET"]),
        Route("/assets/browser.js", script, methods=["GET"]),
    ]
    return Starlette(
        debug=False,
        routes=routes,
        lifespan=lifespan,
        middleware=[Middleware(SecurityHeaders)],
        exception_handlers={
            MissingRun: _missing,
            MissingArtifact: _missing,
            meta.RunNotFound: _missing,
            meta.RunsNotComparable: _refusal,
            meta.NoSuccessfulEvaluation: _refusal,
            DiffRefused: _refusal,
            meta.CapabilityError: _capability,
            UnstableComparison: _unavailable,
            meta.DurableCorruption: _defect,
            meta.DurableStoreError: _unavailable,
            Exception: _defect,
        },
    )


__all__ = ["create_app"]
