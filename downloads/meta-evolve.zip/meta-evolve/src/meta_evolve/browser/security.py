"""Uniform browser response hardening without request-thread side effects."""

from __future__ import annotations

from starlette.types import ASGIApp, Message, Receive, Scope, Send


_HEADERS = (
    (
        b"content-security-policy",
        b"default-src 'none'; script-src 'self'; style-src 'self'; "
        b"connect-src 'self'; img-src 'self' data:; base-uri 'none'; "
        b"form-action 'self'; frame-ancestors 'none'",
    ),
    (b"x-content-type-options", b"nosniff"),
    (b"referrer-policy", b"no-referrer"),
    (b"x-frame-options", b"DENY"),
)


class SecurityHeaders:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        async def secured(message: Message) -> None:
            if message["type"] == "http.response.start":
                message["headers"] = [*message.get("headers", ()), *_HEADERS]
            await send(message)

        await self.app(scope, receive, secured)


__all__ = ["SecurityHeaders"]
