"""Translate inert artifact presentation records into template-only data."""

from __future__ import annotations

import meta_evolve as meta

from .presentation import artifact


def artifact_page(snapshot: object) -> dict[str, object]:
    value = snapshot.artifact
    presentation = meta.present_artifact(value)
    by_id = {str(item.id): item for item in snapshot.artifacts}
    parents = tuple(
        artifact(by_id[parent])
        for parent in map(str, value.parent_ids)
        if parent in by_id
    )
    return {
        "run_id": snapshot.run_id,
        "version": snapshot.version,
        "artifact": artifact(value),
        "parents": parents,
        "presentation": {
            "notice": presentation.notice,
            "omitted": presentation.omitted_documents,
            "aggregate_omitted": presentation.aggregate_omitted_documents,
            "sections": tuple(
                {
                    "label": section.label,
                    "fields": tuple(
                        {"label": field.label, "text": field.text}
                        for field in section.fields
                    ),
                    "documents": tuple(
                        {
                            "path": document.path,
                            "text": document.text,
                            "truncated": document.truncated,
                        }
                        for document in section.documents
                    ),
                }
                for section in presentation.sections
            ),
        },
    }


def diff_page(
    run_id: str, parent: meta.ArtifactView, child: meta.ArtifactView
) -> dict[str, object]:
    result = meta.diff_artifacts(parent, child)
    return {
        "run_id": run_id,
        "diff": {
            "parent_id": result.parent_id,
            "child_id": result.child_id,
            "parent_digest": result.parent_digest,
            "child_digest": result.child_digest,
            "kind": result.kind,
            "representation": result.representation,
            "omitted": result.omitted_files,
            "output_truncated": result.output_truncated,
            "files": tuple(
                {
                    "path": item.path,
                    "status": item.status,
                    "notice": item.notice,
                    "lines": tuple(
                        {
                            "kind": line.kind,
                            "old": line.old_line,
                            "new": line.new_line,
                            "text": line.text,
                            "marker": {
                                "added": "+",
                                "removed": "−",
                                "unchanged": " ",
                            }[line.kind],
                        }
                        for line in item.lines
                    ),
                }
                for item in result.files
            ),
        },
    }


__all__ = ["artifact_page", "diff_page"]
