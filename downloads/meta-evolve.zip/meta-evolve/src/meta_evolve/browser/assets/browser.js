(() => {
  const target = document.querySelector("[data-poll-url]");
  if (!target) return;

  const check = async () => {
    try {
      const response = await fetch(target.dataset.pollUrl, {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (!response.ok) return;
      const payload = await response.json();
      const observed = JSON.stringify(payload.version);
      if (observed !== target.dataset.pollVersion) window.location.reload();
    } catch (_error) {
      // The complete server-rendered page remains usable while polling is absent.
    }
  };

  window.setInterval(check, 3000);
})();
