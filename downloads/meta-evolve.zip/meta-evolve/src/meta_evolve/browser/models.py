"""Small browser-owned values that never carry decoded artifact content."""

from __future__ import annotations

import json
from dataclasses import dataclass

import meta_evolve as meta


@dataclass(frozen=True, slots=True)
class CatalogCard:
    run_id: str
    version: int | None
    task_id: str | None = None
    lifecycle: str | None = None
    rankability: str | None = None
    policy: str | None = None
    objective: str | None = None
    score: int | float | None = None
    artifact_kind: str | None = None
    # Already formatted by presentation.usage() so the catalog cannot drift
    # from the other usage views (and cannot omit spend).
    usage: str | None = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class CatalogResult:
    cards: tuple[CatalogCard, ...]
    poll_version: str


@dataclass(frozen=True, slots=True)
class InspectionSnapshot:
    inspection: meta.RunInspection
    version: int | None


@dataclass(frozen=True, slots=True)
class ArtifactSnapshot:
    run_id: str
    version: int | None
    artifact: meta.ArtifactView
    artifacts: tuple[meta.ArtifactView, ...]


class MissingRun(LookupError):
    """A route identity is not present in the current public run listing."""


class MissingArtifact(LookupError):
    """An occurrence is absent from the exact inspected run snapshot."""


class UnstableComparison(RuntimeError):
    """One of two streams changed throughout both comparison attempts."""


def poll_token(versions: list[tuple[str, int]]) -> str:
    return json.dumps(versions, separators=(",", ":"))


__all__ = [
    "CatalogCard",
    "CatalogResult",
    "ArtifactSnapshot",
    "InspectionSnapshot",
    "MissingArtifact",
    "MissingRun",
    "UnstableComparison",
    "poll_token",
]
