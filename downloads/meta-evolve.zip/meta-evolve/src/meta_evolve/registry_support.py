"""Private registry entries, built-in factories, and manifest projections."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from hashlib import sha256

from .domain import (
    ComponentManifest,
    ComponentRef,
    ContextSpec,
    SearchProgram,
    SearchSpec,
)
from .domain.values import _require_text
from .errors import CapabilityError
from .manifests import (
    SourceDependency,
    configuration_digest,
    implementation_digest,
)
from .policies import (
    AncestorsOnly,
    BestOfK,
    BestOfN,
    BestSibling,
    ContextPolicy,
    Greedy,
    Population,
    Specialists,
    TreeSearch,
)
from .policy.search import candidate_policy_factory
from .ports.codecs import ArtifactCodec

PolicyFactory = Callable[[Mapping[str, object]], SearchProgram]
ContextPolicyFactory = Callable[[ContextSpec], ContextPolicy]


def greedy_factory(configuration: Mapping[str, object]) -> SearchProgram:
    return Greedy(max_trials=configuration["max_trials"])


def best_of_n_factory(configuration: Mapping[str, object]) -> SearchProgram:
    return BestOfN(max_trials=configuration["max_trials"])


def best_of_k_factory(configuration: Mapping[str, object]) -> SearchProgram:
    return BestOfK(k=configuration["k"], max_trials=configuration["max_trials"])


def population_factory(configuration: Mapping[str, object]) -> SearchProgram:
    return Population(
        size=configuration["size"],
        tournament_size=configuration["tournament_size"],
        max_trials=configuration["max_trials"],
    )


def specialists_factory(configuration: Mapping[str, object]) -> SearchProgram:
    return Specialists(
        metrics=configuration["metrics"],
        max_trials=configuration["max_trials"],
    )


def tree_search_factory(configuration: Mapping[str, object]) -> SearchProgram:
    return TreeSearch(
        max_trials=configuration["max_trials"],
        exploration=configuration["exploration"],
    )


def ancestors_context_factory(spec: ContextSpec) -> ContextPolicy:
    return AncestorsOnly(max_records=spec.max_records, max_chars=spec.max_chars)


def best_sibling_context_factory(spec: ContextSpec) -> ContextPolicy:
    return BestSibling(max_records=spec.max_records, max_chars=spec.max_chars)


@dataclass(frozen=True, slots=True)
class ComponentEntry:
    fn: Callable[..., object]
    deterministic: bool
    retry_safe: bool
    dependencies: tuple[SourceDependency, ...] = ()
    configuration: Mapping[str, object] | None = None


@dataclass(frozen=True, slots=True)
class PolicyEntry:
    factory: PolicyFactory
    deterministic: bool
    retry_safe: bool
    dependencies: tuple[SourceDependency, ...] = ()


def _import_hint(fn: Callable[..., object]) -> str:
    module = getattr(fn, "__module__", None) or type(fn).__module__
    qualname = getattr(fn, "__qualname__", None) or getattr(
        fn, "__name__", type(fn).__qualname__
    )
    return f"{module}:{qualname}"


def resolve_component(
    table: dict[tuple[str, str], ComponentEntry],
    role: str,
    ref: ComponentRef,
) -> tuple[Callable[..., object], ComponentManifest]:
    if not isinstance(ref, ComponentRef) or ref.role != role:
        raise CapabilityError(f"{role} reference must be a {role} component reference")
    if ref.origin != "registered":
        raise CapabilityError(
            f"{role} reference must be a registered component reference, not "
            f"{ref.origin!r}: registry resolution is never ambient"
        )
    entry = table.get((ref.name, ref.version))
    if entry is None:
        raise CapabilityError(f"unregistered {role} {ref.name}@{ref.version}")
    return entry.fn, ComponentManifest(
        role=role,
        name=ref.name,
        version=ref.version,
        import_hint=_import_hint(entry.fn),
        implementation_digest=implementation_digest(
            entry.fn, dependencies=entry.dependencies
        ),
        configuration_digest=configuration_digest(entry.configuration),
        deterministic=entry.deterministic,
        retry_safe=entry.retry_safe,
    )


def validate_artifact_codec(codec: ArtifactCodec) -> None:
    """Confirm ``codec`` declares the shape ``ArtifactCodec`` requires.

    Pure structural check, independent of any ``Registry`` state — the
    built-in-override guard and collision rules stay in ``Registry``
    itself, since those are registry policy rather than codec shape.
    """

    for name in ("kind", "representation"):
        _require_text(getattr(codec, name, None), f"artifact codec {name}")
    interfaces = getattr(codec, "interfaces", None)
    if not isinstance(interfaces, tuple):
        raise TypeError("artifact codec interfaces must be a tuple of names")
    for item in interfaces:
        _require_text(item, "artifact codec interface name")
    if not callable(getattr(codec, "encode", None)) or not callable(
        getattr(codec, "decode", None)
    ):
        raise TypeError("artifact codec must implement encode and decode")


def _composed_digest(
    factory: Callable[..., object],
    resolved: object,
    dependencies: tuple[SourceDependency, ...],
) -> str:
    factory_digest = implementation_digest(factory, dependencies=dependencies)
    resolved_module = __import__(type(resolved).__module__, fromlist=[""])
    resolved_digest = implementation_digest(
        type(resolved), dependencies=(resolved_module,)
    )
    return sha256(f"{factory_digest}|{resolved_digest}".encode()).hexdigest()


def policy_manifest(entry: PolicyEntry, spec: SearchSpec) -> ComponentManifest:
    program = entry.factory(dict(spec.configuration))
    program_type = type(program)
    return ComponentManifest(
        role="policy",
        name=spec.policy.name,
        version=spec.policy.version,
        import_hint=f"{program_type.__module__}:{program_type.__qualname__}",
        implementation_digest=_composed_digest(
            entry.factory, program, entry.dependencies
        ),
        configuration_digest=configuration_digest(spec.configuration),
        deterministic=entry.deterministic,
        retry_safe=entry.retry_safe,
    )


def context_policy_manifest(
    entry: ComponentEntry,
    spec: ContextSpec,
    rebuilt: ContextPolicy,
) -> ComponentManifest:
    policy_type = type(rebuilt)
    return ComponentManifest(
        role="context-policy",
        name=spec.policy.name,
        version=spec.policy.version,
        import_hint=f"{policy_type.__module__}:{policy_type.__qualname__}",
        implementation_digest=_composed_digest(
            entry.fn, rebuilt, entry.dependencies
        ),
        configuration_digest=configuration_digest(
            {"max_records": spec.max_records, "max_chars": spec.max_chars}
        ),
        deterministic=entry.deterministic,
        retry_safe=entry.retry_safe,
    )


__all__ = [
    "ComponentEntry",
    "ContextPolicyFactory",
    "PolicyEntry",
    "PolicyFactory",
    "ancestors_context_factory",
    "best_of_k_factory",
    "best_of_n_factory",
    "best_sibling_context_factory",
    "candidate_policy_factory",
    "context_policy_manifest",
    "greedy_factory",
    "policy_manifest",
    "population_factory",
    "resolve_component",
    "specialists_factory",
    "tree_search_factory",
    "validate_artifact_codec",
]
