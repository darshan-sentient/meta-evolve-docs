"""Digest construction and verification for component manifests.

Kept outside ``domain`` so ``ComponentManifest`` (the immutable durable
record in ``domain/components.py``) never imports registry or filesystem
concerns. This module answers one question honestly: does this callable's
*source* look like the one a durable run recorded? Environment digests
(interpreter, dependency versions) stay out of scope here and live in
``environment.py``, which M11.2 added -- the two answer different questions and
a worker can fail either independently: this one asks whether the code is the
same, that one whether the environment is.
"""

from __future__ import annotations

import functools
import inspect
from collections.abc import Callable, Iterable, Mapping
from hashlib import sha256
from types import ModuleType

from .domain.components import ComponentManifest
from .domain.identity import ContentDigest
from .domain.values import freeze
from .errors import CapabilityError


SourceDependency = Callable[..., object] | ModuleType


def implementation_digest(
    fn: Callable[..., object],
    *,
    dependencies: Iterable[SourceDependency] = (),
) -> str:
    """Hash the source modules that make up one registered implementation.

    The defining callable is always included. Cross-module helpers are included
    only when explicitly declared through ``dependencies``; this keeps the
    manifest honest without pretending Python import graphs can be inferred
    reliably. A module may be supplied when its globals are part of the
    implementation. Each distinct source unit is hashed once, so dependency order
    and import aliases do not affect the result.

    Fails closed with ``CapabilityError`` for lambdas, ``functools.partial``,
    closures over local variables, decorated wrappers (detected via
    ``__wrapped__``), and callables with no resolvable module source
    (C-extensions, the REPL).
    """

    if not callable(fn):
        raise TypeError("component implementation must be callable")
    if isinstance(fn, functools.partial):
        raise CapabilityError("component implementation cannot be a functools.partial")
    if getattr(fn, "__name__", None) == "<lambda>":
        raise CapabilityError("component implementation cannot be a lambda")
    if hasattr(fn, "__wrapped__"):
        raise CapabilityError(
            "component implementation cannot be a decorated wrapper: its "
            "advertised module may not be where its behavior actually lives"
        )
    if getattr(fn, "__closure__", None):
        raise CapabilityError(
            "component implementation cannot be a closure over local variables"
        )

    parts = sorted(
        {_source_digest(value) for value in (fn, *tuple(dependencies))}
    )
    return sha256("|".join(parts).encode()).hexdigest()


def _source_digest(value: SourceDependency) -> str:
    if not isinstance(value, ModuleType) and not callable(value):
        raise TypeError("source dependencies must be callables or modules")
    try:
        source = inspect.getsource(value)
    except (OSError, TypeError) as error:
        raise CapabilityError(
            "component implementation has no resolvable source "
            "(C-extension or REPL callables cannot be verified)"
        ) from error
    return sha256(source.encode("utf-8")).hexdigest()


def require_source_function(
    fn: Callable[..., object],
    description: str,
    *,
    dependencies: Iterable[SourceDependency] = (),
) -> None:
    """Require ``fn`` be a plain, source-digestible, module-level function.

    Durable-local components (proposers, evaluators, policy factories) must be
    identifiable purely from their module source: a resumed run has to rebuild
    the *same* code that originally ran. That rules out lambdas, closures /
    nested functions (``<locals>`` in the qualname), ``functools.partial``,
    bound methods, and callable *instances* — all of which carry
    behavior-affecting state that no source digest can see (the exact hole
    behind ``Mutator(offset=1)`` vs ``Mutator(offset=10)`` passing
    verification). Confirms the callable is additionally digestible via
    :func:`implementation_digest`.
    """

    if not inspect.isfunction(fn):
        raise CapabilityError(
            f"{description} must be a plain module-level function, not a "
            f"{type(fn).__name__} (bound methods, callable instances, and "
            "functools.partial carry state no source digest can capture)"
        )
    if fn.__name__ == "<lambda>":
        raise CapabilityError(f"{description} must not be a lambda")
    if "<locals>" in fn.__qualname__:
        raise CapabilityError(
            f"{description} must be defined at module level, not a closure or "
            "nested function"
        )
    implementation_digest(
        fn, dependencies=dependencies
    )  # raises CapabilityError if any source is not digestible


def configuration_digest(config: Mapping[str, object] | None) -> str:
    """Digest declared configuration, or ``""`` when there is none."""

    if not config:
        return ""
    return ContentDigest.for_payload(freeze(config)).value


def components_admit(mode: str, manifests: Iterable[ComponentManifest]) -> bool:
    """Whether `mode` admits these components -- the flag's source of truth.

    `RunCapabilities.resumable` was written `True` at both durable sites, so it
    restated a conclusion rather than recording one. Deriving it from the same
    predicate the admission just applied means the recorded flag cannot claim
    more than the check allowed, and a future mode gets the right value without
    a third place remembering to say so.
    """

    try:
        require_components_for(mode, manifests)
    except CapabilityError:
        return False
    return True


def require_components_for(
    mode: str, manifests: Iterable[ComponentManifest]
) -> None:
    """The component rule for one mode, stated once for every caller.

    `prepare_start` and `prepare_resume` each enforce this, and they were each
    choosing a gate with their own `if mode == "distributed"`. Two independent
    copies of one policy is how a resume comes to admit more -- or less -- than
    the start that wrote the run, and a run stranded by a stricter resume than
    its own start is the worse of the two failures.

    `durable-local` requires both properties, for M4's interrupted-equals-
    uninterrupted guarantee. `distributed` requires retry-safety alone: the
    record says its trajectories are schedule-sensitive, so it never promised
    identical replay. `local` records no manifests to check.
    """

    if mode == "distributed":
        require_retry_safe(manifests)
    elif mode == "durable-local":
        require_resumable(manifests)


def require_retry_safe(manifests: Iterable[ComponentManifest]) -> None:
    """Raise ``CapabilityError`` unless every manifest is retry-safe.

    What a DISTRIBUTED run requires, and all of it. The dispatcher retries an
    attempt up to its bound, so "automatic retry of unsafe work is dishonest"
    -- but determinism is a different promise, and distributed does not make
    it. The record is explicit that its trajectories are schedule-sensitive:
    "a non-deterministic provider or a lease that expires under load will
    diverge".

    Split out because `require_resumable` sat in `prepare_start`'s shared
    durable block and the distributed branch was added below it, so distributed
    inherited the determinism half by position. That excluded every
    non-deterministic component -- which is to say every model-backed proposer,
    the workload this milestone exists to schedule. Epic #10 and the M11
    record's refusal table both name `retry_safe` alone.
    """

    for manifest in manifests:
        if not manifest.retry_safe:
            raise CapabilityError(
                "distributed requires retry-safe components; "
                f"{manifest.role} {manifest.name}@{manifest.version} declares "
                f"retry_safe={manifest.retry_safe}"
            )


def require_resumable(manifests: Iterable[ComponentManifest]) -> None:
    """Raise ``CapabilityError`` unless every manifest is deterministic and
    retry-safe.

    M4's interrupted ≡ uninterrupted guarantee is scoped to components that
    declare both: a non-deterministic component would reach a different result
    on resume, and a non-retry-safe one cannot be safely re-driven after a
    crash. Enforced at ``run(mode="durable-local")`` before any event is
    written *and* at ``resume`` before any further trial, so a run is never
    recorded ``resumable`` on an unsound component.
    """

    for manifest in manifests:
        if not manifest.deterministic or not manifest.retry_safe:
            raise CapabilityError(
                "durable-local requires deterministic and retry-safe "
                f"components; {manifest.role} {manifest.name}@{manifest.version} "
                f"declares deterministic={manifest.deterministic} "
                f"retry_safe={manifest.retry_safe}"
            )


def verify_manifests(
    recorded: Iterable[ComponentManifest], supplied: Iterable[ComponentManifest]
) -> None:
    """Raise ``CapabilityError`` unless ``supplied`` exactly matches ``recorded``.

    Compared as keyed ``(role, name, version)`` sets, not insertion order.
    Any missing, unexpected extra, or mismatched component fails closed. Every
    identity-bearing field is compared — ``import_hint``, both digests, and the
    ``deterministic``/``retry_safe`` safety declarations — so a run recorded
    against a retry-safe component cannot be resumed against one re-declared
    unsafe, and a relocated implementation is caught even at identical source
    bytes. Used by M4.4's ``meta.resume`` before executing any further trial.
    """

    def _by_key(
        manifests: Iterable[ComponentManifest],
    ) -> dict[tuple[str, str, str], ComponentManifest]:
        return {(item.role, item.name, item.version): item for item in manifests}

    recorded_by_key = _by_key(recorded)
    supplied_by_key = _by_key(supplied)

    missing = sorted(set(recorded_by_key) - set(supplied_by_key))
    if missing:
        raise CapabilityError(f"resume is missing recorded components: {missing!r}")

    extra = sorted(set(supplied_by_key) - set(recorded_by_key))
    if extra:
        raise CapabilityError(f"resume supplied unrecorded components: {extra!r}")

    compared_fields = (
        ("import_hint", "import hint mismatch", "was relocated to a different import path"),
        ("implementation_digest", "implementation digest mismatch", "was verified against different source"),
        ("configuration_digest", "configuration digest mismatch", "was verified against a different declared configuration"),
        ("deterministic", "deterministic declaration mismatch", "changed its deterministic safety declaration"),
        ("retry_safe", "retry-safe declaration mismatch", "changed its retry-safe safety declaration"),
        # Carried durably since M11.2, so compared here too: a field recorded and
        # never checked lets a run resume against a component demanding
        # different work than the one it recorded, which is the drift this whole
        # mechanism exists to prevent.
        ("work_requirements", "work requirement mismatch", "declares different work requirements"),
    )
    for key, recorded_manifest in recorded_by_key.items():
        supplied_manifest = supplied_by_key[key]
        for field_name, label, reason in compared_fields:
            if getattr(supplied_manifest, field_name) != getattr(
                recorded_manifest, field_name
            ):
                raise CapabilityError(f"{label} for {key!r}: the recorded run {reason}")


__all__ = [
    "configuration_digest",
    "implementation_digest",
    "components_admit",
    "require_components_for",
    "require_resumable",
    "require_retry_safe",
    "require_source_function",
    "SourceDependency",
    "verify_manifests",
]
