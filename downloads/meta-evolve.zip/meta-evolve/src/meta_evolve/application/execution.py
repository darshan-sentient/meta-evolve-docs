"""Dispatch one committed trial to its configured proposer runner."""

from __future__ import annotations

import random
from collections.abc import Sequence
from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    Budget,
    CorrelationId,
    ContextBundle,
    DecisionId,
    RunCapabilities,
    RunId,
    Task,
    Trial,
    TrialOutcome,
)
from meta_evolve.ports import ArtifactStore
from meta_evolve.ports.callables import Evaluator
from meta_evolve.ports.experience import ExperienceReader
from meta_evolve.ports.runners import ProposerRunner

from meta_evolve.errors import InvalidDecision
from .codecs import CodecIndex
from .evaluation_execution import (
    build_evaluation,
    evaluate_artifact,
)
from .identities import stable_id
from .proposal_completion import complete_work, resume_completed_trial
from .projections import RunProjection
from .work import (
    ProposalContext,
    ProposerContext,
    WorkItem,
    has_zero_resource,
)


class ExecutionHost(Protocol):
    run_id: RunId
    task: Task
    run_budget: Budget
    proposer_runner: ProposerRunner
    evaluator: Evaluator
    artifacts: ArtifactStore
    capabilities: RunCapabilities
    codecs: CodecIndex

    @property
    def projection(self) -> RunProjection: ...

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        occurrences: Sequence[Artifact] = (),
        correlation: CorrelationId,
    ) -> RunProjection: ...


def execute_trial(
    host: ExecutionHost,
    trial: Trial,
    bundle: ContextBundle,
    experience: ExperienceReader | None = None,
) -> TrialOutcome:
    spec = trial.spec
    try:
        parents = tuple(host.artifacts.get(item) for item in spec.parent_ids)
    except Exception as error:
        raise InvalidDecision("trial parent is unavailable from artifact storage") from error
    correlation = stable_id(CorrelationId, "correlation", trial.id.value)
    work = WorkItem(
        trial=trial,
        completion_key=stable_id(DecisionId, "completion", trial.id.value).value,
    )
    result = host.proposer_runner.execute(
        parents,
        ProposerContext(
            rng=random.Random(spec.random_seed),
            step=trial.logical_step,
            objectives=host.task.objectives,
            bundle=bundle,
            experience=experience,
        ),
    )
    return complete_work(host, work, result, correlation)


_resume_completed_trial = resume_completed_trial


__all__ = [
    "ProposerContext",
    "ProposalContext",
    "WorkItem",
    "build_evaluation",
    "complete_work",
    "evaluate_artifact",
    "execute_trial",
    "has_zero_resource",
]
