"""Work-table vocabulary shared by everything that writes one.

Named for what it holds rather than for where it started: it was "internal
sequential work values", and it now also carries the retry bound both enqueue
sites use, the details every terminal fact reports, and the enqueue derivation
a distributed cohort owes. Those belong together because each is a rule two
writers would otherwise state twice.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from meta_evolve.domain import Budget, Resources, Task, Trial, Usage
from meta_evolve.domain.evaluation import InfrastructureFailure
from meta_evolve.domain.work import WorkKind, WorkRow
from meta_evolve.domain.work_aborts import aborted
from meta_evolve.ports.work_store import AbortWork, EnqueueWork, TerminateWork
from meta_evolve.ports.proposers import ProposerContext

from .disposition import evaluation_authorized, has_zero_resource
from .projections import RunProjection

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .decisions import CommittedDecision, DecisionHost

# How many times a work item may be attempted before the reclaim step ends
# it. Here rather than beside either writer, because genesis and the decision
# cohort both enqueue and a second copy is how the two come to disagree about
# what a run's retry policy is.
DEFAULT_MAX_ATTEMPTS = 3


def terminal_details(row: WorkRow) -> dict[str, object]:
    """What a terminal fact says about a work item that ended without a result.

    The counts name the symptom; `last_failure` names the cause. Both terminal
    paths build this, so a reader comparing an exhausted proposal with an
    exhausted evaluation sees the same shape -- and neither can carry the cause
    while the other forgets.

    `exception_type` matches what the callable adapters record at their own
    conversion boundary (`adapters/evaluators.py`, `adapters/proposers.py`), so
    one vocabulary describes a failure whether it was typed by a component or
    caught by the scheduler.

    Absent rather than null when nothing was recorded: a row exhausted by
    expiry or rollover never passed through the release path that writes the
    columns, and reporting `exception_type: None` would claim a diagnosis was
    taken and found empty.
    """

    details: dict[str, object] = {
        "attempts": row.attempts,
        "work_kind": row.kind.value,
    }
    if row.last_failure is not None:
        details["exception_type"] = row.last_failure[0]
        details["exception_message"] = row.last_failure[1]
    return details


def exhaustion_failure(row: WorkRow) -> InfrastructureFailure:
    """The one sentence a run says about an item that ran out of attempts.

    Shared rather than spelled out at each terminal path, for the reason
    `terminal_details` is: a user-facing sentence written twice is a sentence
    two paths will eventually disagree about, and each path's own tests read
    only its own copy, so the disagreement would be invisible.

    `InfrastructureFailure`, never a score: an item the transport could not
    deliver is not a bad candidate, and collapsing the two is what makes a run
    look like it explored something it never ran.
    """

    return InfrastructureFailure(
        message=f"work item {row.item.value} exhausted {row.max_attempts} attempts",
        details=terminal_details(row),
    )


@dataclass(frozen=True, slots=True)
class WorkEnding:
    """How one row ends: the fact the stream gets, and the intent the table gets.

    One value because the two must never disagree. They were two functions, each
    asking `aborted` and each rebuilding the same "aborted:
    <cause>" string, so a row could be CANCELLED under one reason while the
    stream said another -- and the stream is what anyone reads afterwards. Asked
    once, answered once, used twice.
    """

    failure: InfrastructureFailure
    intent: AbortWork | TerminateWork


def terminal_ending(row: WorkRow) -> WorkEnding:
    """What a row that will never produce a result owes, fact and intent.

    Two endings. A row reaches one either because it ran out of attempts or
    because the attempt it did spend came back with a cause a re-run cannot
    clear, and an operator reading the stream needs to know WHICH -- "exhausted
    3 attempts" over a row that was tried once describes a run that never
    happened.

    Shared rather than branched at each terminal path, for the reason
    `terminal_details` is: a user-facing sentence written twice is a sentence
    two paths will eventually disagree about, and each path's own tests read
    only its own copy. The proposal path and the evaluation path both ask this.

    `InfrastructureFailure` on both branches, never a score. An item the
    transport could not deliver is not a bad candidate, and neither is one whose
    completion the coordinator refused; collapsing either into a low score is
    what makes a run look like it explored something it never ran.

    Choosing an intent is not establishing its precondition -- each one
    re-validates its own inside the transaction that writes the row.
    """

    if aborted(row):
        assert row.last_failure is not None  # `aborted` is False without one
        cause = row.last_failure[0]
        return WorkEnding(
            failure=InfrastructureFailure(
                message=f"work item {row.item.value} aborted: {cause}",
                details=terminal_details(row),
            ),
            intent=AbortWork(item=row.item, reason=f"aborted: {cause}"),
        )
    return WorkEnding(
        failure=exhaustion_failure(row),
        intent=TerminateWork(item=row.item, reason="retries exhausted"),
    )


def proposal_enqueues(
    host: DecisionHost, committed: Sequence[CommittedDecision]
) -> tuple[EnqueueWork, ...]:
    """The work a distributed generation owes, riding its own transaction.

    "Enqueue inserts work rows in the same transaction as the decision cohort or
    genesis" -- literally, through the seam the batch already has. The intents
    are derived here rather than passed in because the rows are keyed on trial
    ids this function mints from each member's decision id: a caller could not
    name them, and deriving them where the identity is makes it impossible to
    commit a generation and forget to enqueue it. A cohort refused on admission
    never reaches this line, so full-or-refuse covers the work table too.

    Empty for a local run, by mode rather than by omission: local execution
    drives its own trials, and in-memory storage refuses work rows outright.
    """

    if host.capabilities.mode != "distributed":
        return ()
    return tuple(
        EnqueueWork(
            row=WorkRow.enqueued(
                run_id=host.run_id,
                trial_id=decision.trial.id,
                kind=WorkKind.PROPOSAL,
                max_attempts=DEFAULT_MAX_ATTEMPTS,
            )
        )
        for decision in committed
        if decision.trial is not None
    )


def _resource_usage(resources: Resources) -> Usage:
    """Lower an author report once at the result-to-record boundary."""

    return Usage(tokens=resources.tokens, spend_micros=resources.spend_micros,
                 wall_seconds=resources.wall_seconds)


def action_usage(*, trials: int = 0, evaluations: int = 0, usage: Usage) -> Usage:
    # The counts are the coordinator's to mint; the measures are the
    # component's to report. `without_counts` is that split, named once.
    return Usage(trials=trials, evaluations=evaluations) + usage.without_counts


def would_exceed(
    usage: Usage,
    trial_budget: Budget,
    projection: RunProjection,
    *,
    run_budget: Budget,
    task: Task,
    trial_used: Usage = Usage(),
) -> bool:
    current = projection.search_state.usage if projection.ready else Usage()
    prospective = current + usage

    def exceeded(budget: Budget, measured: Usage) -> bool:
        # Unknown spend is not evidence of an overage and must not erase a valid
        # result. Admission and evaluation_authorized separately stop further
        # work under an unverifiable monetary ceiling, using the real budget.
        if measured.spend_micros is None:
            budget = replace(budget, spend_micros=None)
        return not budget.allows(measured)

    return (
        exceeded(run_budget, prospective)
        or (task.budget is not None and exceeded(task.budget, prospective))
        or exceeded(trial_budget, trial_used + usage)
    )


# Internal compatibility alias retained for earlier callable integrations.
ProposalContext = ProposerContext


@dataclass(frozen=True, slots=True)
class ProposalWork:
    """One trial's proposal delivery, with the key its completion is keyed by.

    Named for the kind it carries rather than for work in general: the M11 design
    record reserves ``WorkItem`` for the durable deliverable unit, whose identity
    is stable from the trial AND THE KIND, of which there are at most two per
    trial -- proposal and evaluation -- and this is the proposal one. Its
    ``completion_key`` is already that record's result key, which the record
    defines as stable from the work item and as being an idempotency key, never
    a credential.

    The derivation itself is :func:`identities.completion_key_for` and is NOT
    restated here: this docstring was the fifth place the formula appeared, and
    a formula written in prose beside four code copies is the one that goes
    stale silently, because nothing executes it.
    """

    trial: Trial
    completion_key: str


__all__ = [
    # Names other modules import from here. `DEFAULT_MAX_ATTEMPTS`,
    # `exhaustion_failure`, `terminal_details` and `proposal_enqueues` were
    # all absent while being imported elsewhere -- an export list that omits
    # what callers already use documents a smaller surface than the one that
    # exists, which is how a shared helper reads as private and gets copied.
    "DEFAULT_MAX_ATTEMPTS",
    "ProposalContext",
    "ProposalWork",
    "ProposerContext",
    "WorkEnding",
    "action_usage",
    "evaluation_authorized",
    "exhaustion_failure",
    "has_zero_resource",
    "proposal_enqueues",
    "terminal_details",
    "terminal_ending",
    "would_exceed",
]
