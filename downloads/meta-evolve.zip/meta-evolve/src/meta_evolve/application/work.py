"""Internal sequential work values and resource helpers."""

from __future__ import annotations

from dataclasses import dataclass, replace

from meta_evolve.domain import Budget, Task, Trial, Usage, spend_exhausted
from meta_evolve.ports.proposers import ProposerContext

from .projections import RunProjection


def action_usage(*, trials: int = 0, evaluations: int = 0, usage: Usage) -> Usage:
    # The counts are the coordinator's to mint; the measures are the
    # component's to report. `without_counts` is that split, named once.
    return Usage(trials=trials, evaluations=evaluations) + usage.without_counts


def has_zero_resource(budget: Budget, *, evaluation: bool = False) -> bool:
    fields = (budget.tokens, budget.wall_seconds)
    if evaluation:
        fields = (budget.evaluations, *fields)
    return any(value == 0 for value in fields if value is not None)


def evaluation_authorized(
    remaining_budget: Budget, trial_budget: Budget, used: Usage
) -> bool:
    """Whether a completed trial's evaluation still fits its effective budget.

    THE single source of the resume-equivalence-critical authorization calc:
    the successor path (``complete_work``), the crash-recovery path
    (``_resume_completed_trial``), and the recovery-frontier classifier
    (``classify_frontier``'s EVALUATION_PENDING predicate) all call this, so an
    uninterrupted run and a resumed run make byte-identical evaluate/skip
    decisions. ``remaining_budget`` is ``search_state.remaining_budget``,
    ``trial_budget`` the trial's ``spec.budget``, and ``used`` the trial
    outcome's ``usage``.

    Spend refusal uses the trial's own ``used`` usage so a free proposal under
    a ``$0`` ceiling still evaluates. Exhaustion caused by *earlier* trials is
    refused at admission instead, by ``_validate_trial`` -- against the
    aggregate ceiling via ``spend_exhausted``, and against a breached per-trial
    ceiling via ``SearchState.trial_spend_ceiling_breached``.
    """

    if not trial_budget.allows(used):
        return False
    narrowed = remaining_budget.narrow(trial_budget.remaining_after(used))
    return not has_zero_resource(narrowed, evaluation=True) and not spend_exhausted(
        remaining=narrowed, charged=used
    )


def would_exceed(
    usage: Usage,
    trial_budget: Budget,
    projection: RunProjection,
    *,
    run_budget: Budget,
    task: Task,
    trial_used: Usage = Usage(),
) -> bool:
    current = projection.search_state.usage if projection.ready else Usage()
    prospective = current + usage

    def exceeded(budget: Budget, measured: Usage) -> bool:
        # Unknown spend is not evidence of an overage and must not erase a valid
        # result. Admission and evaluation_authorized separately stop further
        # work under an unverifiable monetary ceiling, using the real budget.
        if measured.spend_micros is None:
            budget = replace(budget, spend_micros=None)
        return not budget.allows(measured)

    return (
        exceeded(run_budget, prospective)
        or (task.budget is not None and exceeded(task.budget, prospective))
        or exceeded(trial_budget, trial_used + usage)
    )


# Internal compatibility alias retained for earlier callable integrations.
ProposalContext = ProposerContext


@dataclass(frozen=True, slots=True)
class WorkItem:
    trial: Trial
    completion_key: str


__all__ = [
    "ProposalContext",
    "ProposerContext",
    "WorkItem",
    "action_usage",
    "evaluation_authorized",
    "has_zero_resource",
    "would_exceed",
]
