"""Fold an already-sequenced envelope as a committed fact."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain.events import EventEnvelope

from .experience_sources import records_for_event
from .run_projection import RunProjection
from .transitions import apply_event, invalid


def fold_committed(state: RunProjection, envelope: EventEnvelope) -> RunProjection:
    """Apply one envelope, record its identity, and project experience."""

    if envelope.id in state.event_ids:
        raise invalid(envelope.sequence, "event identity was already committed")
    previous = state
    state = apply_event(state, envelope)
    return replace(
        state,
        event_ids=state.event_ids + (envelope.id,),
        experience_records=state.experience_records
        + records_for_event(previous, envelope),
    )


__all__ = ["fold_committed"]
