"""Paced synchronous execution over one authoritative recovery frontier.

Past the ~300-line guideline by a little: start, resume and drive are one lifecycle, and the mode guards that differ between them only read as a set when they sit together.
"""

from __future__ import annotations

from collections.abc import Iterator
from types import TracebackType
from typing import Literal

from meta_evolve.domain import (
    Budget,
    PolicyDecisionMade,
    RunId,
    Stop,
    Trial,
    TrialCompleted,
)
from meta_evolve.errors import CapabilityError, DurableCorruption
from meta_evolve.registry import Registry

from .dispatcher import Dispatcher
from .experiment import Experiment
from .inspection import DecisionView, StopDecisionView, build_decision_view
from .recovery import RecoveryPhase
from .results import Run
from .run_support import ExecutionMode
from .session_preparation import (
    _PreparedSession,
    prepare_resume,
    prepare_start,
)
from .storage import Storage


_CLOSED_MESSAGE = "session execution scope has ended"
_FAILED_MESSAGE = (
    "session execution failed; the committed prefix remains inspectable, and "
    "durable work must reopen through Session.resume(...)"
)


class Session:
    """Pace execution or recovery one decision at a time.

    Create a handle with ``start()`` or ``resume()`` and use it as a context
    manager. ``step()`` completes one new or recovery-owed decision; ``run``
    exposes its inspectable result. Authority and budgets are fixed at start;
    callers cannot inject decisions. ``run()`` and ``resume()`` exhaust this
    same lifecycle for callers that do not need pacing.
    """

    __slots__ = (
        "_coordinator",
        "_program",
        "_run",
        "_phase",
        "_lifecycle",
        "_terminal",
    )
    _lifecycle: Literal["open", "closed", "failed"]
    _terminal: StopDecisionView | None

    def __init__(self) -> None:
        raise TypeError(
            "Session handles are created by Session.start() or Session.resume()"
        )

    @classmethod
    def _from_prepared(cls, prepared: _PreparedSession) -> Session:
        session = object.__new__(cls)
        session._coordinator = prepared.coordinator
        session._program = prepared.program
        session._run = prepared.run
        session._phase = prepared.phase
        session._lifecycle = "open"
        session._terminal = None
        return session

    @classmethod
    def start(
        cls,
        experiment: Experiment,
        /,
        *,
        storage: Storage | None = None,
        budget: Budget | None = None,
        mode: ExecutionMode = "local",
    ) -> Session:
        """Start an experiment; partial ``budget`` fields inherit task ceilings."""

        return cls._from_prepared(
            prepare_start(
                experiment,
                storage=storage,
                budget=budget,
                mode=mode,
            )
        )

    @classmethod
    def resume(
        cls,
        run_id: RunId,
        /,
        *,
        storage: Storage,
        registry: Registry,
    ) -> Session:
        """Reconstruct a durable frontier without completing pending work."""

        return cls._from_prepared(
            prepare_resume(run_id, storage=storage, registry=registry)
        )

    @property
    def run(self) -> Run:
        """The stable inspectable Run associated with this handle."""

        return self._run

    @property
    def stopped(self) -> bool:
        """Whether a terminal stop decision has been committed."""

        return self._coordinator.projection.stop is not None

    def step(self) -> DecisionView:
        """Complete exactly one owed or newly committed policy decision."""

        self._require_open()
        # Ahead of the latch, not inside it: this refusal executes nothing, so
        # latching it would replace the honest answer with "session execution
        # failed" on every later call, reporting damage to a session where
        # nothing happened.
        self._refuse_if_not_ready()
        try:
            return self._step()
        except BaseException:
            self._lifecycle = "failed"
            raise

    def _refuse_if_not_ready(self) -> None:
        """Refuse a run whose genesis is not complete.

        A pre-ready run is a legitimate state, not a corrupt store -- the design
        record says so -- so this is a profile mismatch and takes the same error
        the synchronous path already uses for a declaration it cannot step. The
        two acting branches in `_step` would otherwise reach for a
        `PolicyDecisionMade` the bootstrap does not have and raise `IndexError`
        or a bare `StopIteration`, which `__iter__` turns into `RuntimeError`.

        The message names the predicate and only the predicate. `ready` is false
        for four distinct reasons and this guard cannot tell which one holds --
        an earlier version asserted the owed bootstrap evaluation, which is
        flatly false on the missing-seed-artifact arm. Whichever reason it is,
        the sequential tail cannot serve it: draining an owed bootstrap
        evaluation belongs to the dispatcher that enqueued it, and
        `resume_completed_trial` would decline it anyway, gating on a
        disposition the bootstrap is never pinned.
        """

        projection = self._coordinator.projection
        if self._coordinator.capabilities.mode == "distributed":
            # Refused by MODE, not merely by readiness. A distributed run
            # becomes ready the moment its bootstrap evaluation drains, and
            # from then on a sequential step would silently work -- executing
            # trials inline while the work table it was meant to go through sat
            # untouched. Naming the mode is what keeps the two paths apart.
            raise CapabilityError(
                f"run {self._coordinator.run_id} is distributed: use "
                "Session.drive(), which schedules brokered work, rather than "
                "stepping decisions inline"
            )
        if not projection.ready and projection.start is not None:
            raise CapabilityError(
                f"run {self._coordinator.run_id} is not ready: its genesis is "
                "incomplete, so a sequential session has nothing it may step"
            )

    def _step(self) -> DecisionView:
        projection = self._coordinator.projection
        if self._phase is RecoveryPhase.STOPPED:
            if self._terminal is None:
                if not projection.decisions:  # pragma: no cover - recovery guard
                    raise DurableCorruption("stopped run has no terminal decision")
                view = self._view(projection.decisions[-1])
                if not isinstance(view, StopDecisionView):  # pragma: no cover
                    raise DurableCorruption("stopped run has no Stop decision")
                self._terminal = view
            return self._terminal

        if self._phase is RecoveryPhase.TRIAL_DECIDED:
            recorded = projection.decisions[-1]
            self._coordinator.execute(
                Trial.from_decision_record(recorded, self._coordinator.run_id)
            )
        elif self._phase is RecoveryPhase.EVALUATION_PENDING:
            completed = self._pending_evaluation()
            self._coordinator.resume_completed_trial(completed.trial)
            recorded = next(
                item
                for item in projection.decisions
                if item.trial_id == completed.trial.id
            )
        elif self._phase is RecoveryPhase.DECISION_READY:
            decision = self._program.next(projection.search_state)
            committed = self._coordinator.record_decision(self._program, decision)
            recorded = committed.record
            if isinstance(decision, Stop):
                self._phase = RecoveryPhase.STOPPED
                view = self._view(recorded)
                assert isinstance(view, StopDecisionView)
                self._terminal = view
                return view
            if committed.trial is not None:
                self._coordinator.execute(committed.trial)
        else:  # RUN_NOT_FOUND is rejected during preparation.
            raise DurableCorruption("session has no committed run to execute")

        self._phase = RecoveryPhase.DECISION_READY
        return self._view(recorded)

    def _pending_evaluation(self) -> TrialCompleted:
        pending = None
        projection = self._coordinator.projection
        for completed in projection.completed_trials:
            if completed.outcome.failure is None and (
                projection.evaluation_for(completed.trial.id) is None
            ):
                pending = completed
        if pending is None:  # pragma: no cover - guarded by recovery
            raise DurableCorruption(
                "EVALUATION_PENDING frontier has no unevaluated successful trial"
            )
        return pending

    def _view(self, recorded: PolicyDecisionMade) -> DecisionView:
        projection = self._coordinator.projection
        return build_decision_view(
            recorded,
            projection,
            self._run._views(projection),
        )

    def _require_open(self) -> None:
        if self._lifecycle == "closed":
            raise RuntimeError(_CLOSED_MESSAGE)
        if self._lifecycle == "failed":
            raise RuntimeError(_FAILED_MESSAGE)

    def __iter__(self) -> Iterator[DecisionView]:
        while not self.stopped:
            yield self.step()

    def drive(self) -> None:
        """Run a distributed session to its stop, through the dispatcher.

        A distributed run's unit of progress is a WORK ITEM, not a decision:
        the frontier has to empty before a generation can be produced, because
        every member is drawn from one complete committed history. So it cannot
        be iterated as decisions, and this is the loop instead.

        Serial in M11.2. The concurrency delivered is structural -- cohorts, the
        work table, leases, fences, retries and their terminal facts -- with one
        worker running each call inline. Thread-parallel execution needs the
        design's renewal-deadline wait, which arrives with the futures it exists
        to bound.
        """

        self._require_open()
        if self._coordinator.capabilities.mode != "distributed":
            raise CapabilityError(
                f"run {self._coordinator.run_id} is not distributed: drive() "
                "schedules brokered work, and a sequential session steps "
                "decisions instead"
            )
        try:
            broker = self._coordinator.work_broker()
            # The record's explicit recovery step, run unconditionally rather
            # than behind a "was this resumed" flag. Harmless on a fresh run --
            # no leases exist, the epoch goes 1 to 2 -- and load-bearing on a
            # resumed one: `WorkerId.for_slot` is a pure digest of
            # (run_id, slot), so a restarted process reconstructs the SAME
            # worker identity and generation. Without the rollover its own
            # dead lease counts against `max_concurrent_leases`, `acquire`
            # answers None, and the run stalls for a lease duration -- or
            # forever, on an injected clock that never passes the deadline.
            broker.rollover(self._coordinator.run_id)
            Dispatcher(
                self._coordinator,
                broker,
                program=self._program,
            ).drive()
        except BaseException:
            self._lifecycle = "failed"
            raise

    def __enter__(self) -> Session:
        self._require_open()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if self._lifecycle == "open":
            self._lifecycle = "closed"


__all__ = ["Session"]
