"""Paced synchronous execution over one authoritative recovery frontier."""

from __future__ import annotations

from collections.abc import Iterator
from types import TracebackType
from typing import Literal

from meta_evolve.domain import (
    Budget,
    PolicyDecisionMade,
    RunId,
    Stop,
    Trial,
    TrialCompleted,
)
from meta_evolve.errors import DurableCorruption
from meta_evolve.registry import Registry

from .experiment import Experiment
from .inspection import DecisionView, StopDecisionView, build_decision_view
from .recovery import RecoveryPhase
from .results import Run
from .run_support import ExecutionMode
from .session_preparation import (
    _PreparedSession,
    prepare_resume,
    prepare_start,
)
from .storage import Storage


_CLOSED_MESSAGE = "session execution scope has ended"
_FAILED_MESSAGE = (
    "session execution failed; the committed prefix remains inspectable, and "
    "durable work must reopen through Session.resume(...)"
)


class Session:
    """Pace execution or recovery one decision at a time.

    Create a handle with ``start()`` or ``resume()`` and use it as a context
    manager. ``step()`` completes one new or recovery-owed decision; ``run``
    exposes its inspectable result. Authority and budgets are fixed at start;
    callers cannot inject decisions. ``run()`` and ``resume()`` exhaust this
    same lifecycle for callers that do not need pacing.
    """

    __slots__ = (
        "_coordinator",
        "_program",
        "_run",
        "_phase",
        "_lifecycle",
        "_terminal",
    )
    _lifecycle: Literal["open", "closed", "failed"]
    _terminal: StopDecisionView | None

    def __init__(self) -> None:
        raise TypeError(
            "Session handles are created by Session.start() or Session.resume()"
        )

    @classmethod
    def _from_prepared(cls, prepared: _PreparedSession) -> Session:
        session = object.__new__(cls)
        session._coordinator = prepared.coordinator
        session._program = prepared.program
        session._run = prepared.run
        session._phase = prepared.phase
        session._lifecycle = "open"
        session._terminal = None
        return session

    @classmethod
    def start(
        cls,
        experiment: Experiment,
        /,
        *,
        storage: Storage | None = None,
        budget: Budget | None = None,
        mode: ExecutionMode = "local",
    ) -> Session:
        """Validate and bootstrap an experiment before returning its handle."""

        return cls._from_prepared(
            prepare_start(
                experiment,
                storage=storage,
                budget=budget,
                mode=mode,
            )
        )

    @classmethod
    def resume(
        cls,
        run_id: RunId,
        /,
        *,
        storage: Storage,
        registry: Registry,
    ) -> Session:
        """Reconstruct a durable frontier without completing pending work."""

        return cls._from_prepared(
            prepare_resume(run_id, storage=storage, registry=registry)
        )

    @property
    def run(self) -> Run:
        """The stable inspectable Run associated with this handle."""

        return self._run

    @property
    def stopped(self) -> bool:
        """Whether a terminal stop decision has been committed."""

        return self._coordinator.projection.stop is not None

    def step(self) -> DecisionView:
        """Complete exactly one owed or newly committed policy decision."""

        self._require_open()
        try:
            return self._step()
        except BaseException:
            self._lifecycle = "failed"
            raise

    def _step(self) -> DecisionView:
        projection = self._coordinator.projection
        if self._phase is RecoveryPhase.STOPPED:
            if self._terminal is None:
                if not projection.decisions:  # pragma: no cover - recovery guard
                    raise DurableCorruption("stopped run has no terminal decision")
                view = self._view(projection.decisions[-1])
                if not isinstance(view, StopDecisionView):  # pragma: no cover
                    raise DurableCorruption("stopped run has no Stop decision")
                self._terminal = view
            return self._terminal

        if self._phase is RecoveryPhase.TRIAL_DECIDED:
            recorded = projection.decisions[-1]
            self._coordinator.execute(
                Trial.from_decision_record(recorded, self._coordinator.run_id)
            )
        elif self._phase is RecoveryPhase.EVALUATION_PENDING:
            completed = self._pending_evaluation()
            self._coordinator.resume_completed_trial(completed.trial)
            recorded = next(
                item
                for item in projection.decisions
                if item.trial_id == completed.trial.id
            )
        elif self._phase is RecoveryPhase.DECISION_READY:
            decision = self._program.next(projection.search_state)
            committed = self._coordinator.record_decision(self._program, decision)
            recorded = committed.record
            if isinstance(decision, Stop):
                self._phase = RecoveryPhase.STOPPED
                view = self._view(recorded)
                assert isinstance(view, StopDecisionView)
                self._terminal = view
                return view
            if committed.trial is not None:
                self._coordinator.execute(committed.trial)
        else:  # RUN_NOT_FOUND is rejected during preparation.
            raise DurableCorruption("session has no committed run to execute")

        self._phase = RecoveryPhase.DECISION_READY
        return self._view(recorded)

    def _pending_evaluation(self) -> TrialCompleted:
        pending = None
        projection = self._coordinator.projection
        for completed in projection.completed_trials:
            if completed.outcome.failure is None and (
                projection.evaluation_for(completed.trial.id) is None
            ):
                pending = completed
        if pending is None:  # pragma: no cover - guarded by recovery
            raise DurableCorruption(
                "EVALUATION_PENDING frontier has no unevaluated successful trial"
            )
        return pending

    def _view(self, recorded: PolicyDecisionMade) -> DecisionView:
        projection = self._coordinator.projection
        return build_decision_view(
            recorded,
            projection,
            self._run._views(projection),
        )

    def _require_open(self) -> None:
        if self._lifecycle == "closed":
            raise RuntimeError(_CLOSED_MESSAGE)
        if self._lifecycle == "failed":
            raise RuntimeError(_FAILED_MESSAGE)

    def __iter__(self) -> Iterator[DecisionView]:
        while not self.stopped:
            yield self.step()

    def __enter__(self) -> Session:
        self._require_open()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if self._lifecycle == "open":
            self._lifecycle = "closed"


__all__ = ["Session"]
