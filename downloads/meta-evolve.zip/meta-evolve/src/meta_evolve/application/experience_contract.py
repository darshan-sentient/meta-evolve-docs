"""The deterministic pull contract shared by live calls and replay validation.

Everything here is a pure function of a request or of committed records, so
replay can hold successes to the same contract without re-running live
selection, traversal, filtering, or comparison logic.
"""

from __future__ import annotations

from itertools import zip_longest
from numbers import Real

from meta_evolve import serialization
from meta_evolve.domain import (
    ContextRecord,
    Evaluation,
    ExperienceComparison,
    ExperienceGrant,
    ExperienceOperationAttempted,
    ExperienceRef,
    ExperienceRequest,
    TrialSpec,
)
from meta_evolve.domain.evaluation import FAILURE_KINDS
from meta_evolve.domain.experience import (
    EXPERIENCE_KINDS,
    NON_CANDIDATE_EXPERIENCE_KINDS,
)
from meta_evolve.domain.source_tree import normalize_source_path

from .source_operations import source_success_violation


SOURCE_OPERATIONS = frozenset(
    {"list_source_paths", "read_source", "diff_source"}
)

CANDIDATE_EXPERIENCE_KINDS = frozenset(EXPERIENCE_KINDS) - NON_CANDIDATE_EXPERIENCE_KINDS


def request_is_malformed(request: ExperienceRequest) -> bool:
    return (
        (request.as_of is not None and request.as_of < 0)
        or (request.limit is not None and request.limit < 0)
        or any(
            kind not in CANDIDATE_EXPERIENCE_KINDS
            for kind in request.filters.record_kinds
        )
        or any(
            kind not in FAILURE_KINDS for kind in request.filters.failure_kinds
        )
        or (
            request.operation in SOURCE_OPERATIONS
            and (
                request.ref is None
                or request.ref.kind != "artifact"
                or (
                    request.operation == "diff_source"
                    and (
                        request.other_ref is None
                        or request.other_ref.kind != "artifact"
                    )
                )
                or (request.operation == "read_source" and not request.paths)
                or len(request.paths) != len(set(request.paths))
                or any(not _normalized_source_path(path) for path in request.paths)
            )
        )
    )


def _normalized_source_path(path: str) -> bool:
    try:
        return normalize_source_path(path) == path
    except (TypeError, ValueError):
        return False


def render_records(records: tuple[ContextRecord, ...]) -> str:
    return "\n".join(serialization.dumps(record) for record in records)


def interleave_records(
    left_records: tuple[ContextRecord, ...],
    right_records: tuple[ContextRecord, ...],
) -> tuple[tuple[str, ContextRecord], ...]:
    """Alternate sides; a prefix re-interleaves to itself, so replay can
    reconstruct the committed rendering order from the split record tuples."""

    paired = []
    for left_record, right_record in zip_longest(left_records, right_records):
        if left_record is not None:
            paired.append(("left", left_record))
        if right_record is not None:
            paired.append(("right", right_record))
    return tuple(paired)


def metric_deltas(
    left_records: tuple[ContextRecord, ...],
    right_records: tuple[ContextRecord, ...],
) -> dict[str, object]:
    left = _successful_evaluation(left_records)
    right = _successful_evaluation(right_records)
    if left is None or right is None:
        return {}
    common = set(left.metrics) & set(right.metrics)
    return {
        name: right.metrics[name] - left.metrics[name]
        for name in sorted(common)
        if _is_numeric(left.metrics[name]) and _is_numeric(right.metrics[name])
    }


def _is_numeric(value: object) -> bool:
    return isinstance(value, Real) and not isinstance(value, bool)


def _successful_evaluation(records: tuple[ContextRecord, ...]):
    return next(
        (
            record.value
            for record in records
            if isinstance(record.value, Evaluation)
            and record.value.failure is None
        ),
        None,
    )


def success_violation(
    state,
    grant: ExperienceGrant,
    attempt: ExperienceOperationAttempted,
    result: object,
) -> str | None:
    """Hold a committed success to the deterministic contract using only the
    committed sources in ``state``; live selection logic is never re-run."""

    request = attempt.request
    if request.as_of is not None and request.as_of > grant.as_of:
        return "experience success widened its logical-time grant"
    if request_is_malformed(request):
        return "experience success resolved a malformed request"
    if request.operation in SOURCE_OPERATIONS:
        return source_success_violation(state, grant, attempt, result)
    comparing = isinstance(result, ExperienceComparison)
    if comparing != (request.operation == "compare"):
        return "experience success has the wrong result shape"
    if result.usage.operations != attempt.usage.operations:
        return "experience success charged the wrong operation count"
    if _capacity_exceeded(grant.spec, attempt.usage, result.usage):
        return "experience success usage exceeds its grant"
    as_of = grant.as_of if request.as_of is None else request.as_of
    if comparing:
        ordered = tuple(
            record
            for _, record in interleave_records(
                result.left_records, result.right_records
            )
        )
        if dict(result.deltas) != metric_deltas(
            result.left_records, result.right_records
        ):
            return "experience comparison deltas are not derived"
    else:
        ordered = result.records
    if (
        result.usage.results - attempt.usage.results != len(result.references)
        or result.usage.records - attempt.usage.records != len(ordered)
        or result.usage.chars - attempt.usage.chars != len(result.rendered)
    ):
        return "experience success usage does not match its result"
    sources = {}
    for item in state.experience_records:
        sources.setdefault(item.ref, item)
    for record in ordered:
        source = sources.get(record.ref)
        if (
            source is None
            or record.value != source.value
            or record.logical_step != source.logical_step
            or record.event_sequence != source.event_sequence
        ):
            return "experience success does not match committed sources"
        if record.logical_step > as_of:
            return "experience success leaks future experience"
        if record.kind in NON_CANDIDATE_EXPERIENCE_KINDS:
            return "experience success returned non-candidate records"
    trial_steps = _visible_trial_steps(state)

    def visible_trial(ref: ExperienceRef) -> bool:
        step = trial_steps.get(ref.occurrence_id) if ref.kind == "trial" else None
        return ref.run_id == state.run_id and step is not None and step <= as_of

    if request.operation in {"search", "open"}:
        if result.references != tuple(record.ref for record in ordered):
            return "experience success references diverge"
        if request.operation == "open" and not (
            request.ref in sources and sources[request.ref].logical_step <= as_of
        ):
            return "experience success opened invisible experience"
    else:
        targets = (
            (request.ref, request.other_ref) if comparing else (request.ref,)
        )
        if any(not visible_trial(target) for target in targets):
            return "experience success targeted invisible trials"
        if comparing and result.references != targets[: len(result.references)]:
            return "experience success references diverge"
        if not comparing and any(
            not visible_trial(reference) for reference in result.references
        ):
            return "experience success references invisible trials"
    complete = render_records(ordered)
    if result.rendered != complete[: len(result.rendered)]:
        return "experience success does not match committed sources"
    return None


def _capacity_exceeded(spec, before, after) -> bool:
    return (
        after.results < before.results
        or after.records < before.records
        or after.chars < before.chars
        or after.results > spec.max_results
        or after.records > spec.max_records
        or after.chars > spec.max_chars
    )


def _visible_trial_steps(state) -> dict[str, int]:
    steps = {}
    if state.bootstrap is not None:
        trial = state.bootstrap.trial
        steps[trial.id.value] = trial.logical_step
    for decision in state.decisions:
        if isinstance(decision.decision, TrialSpec):
            steps[decision.trial_id.value] = decision.logical_step
    return steps


__all__ = [
    "CANDIDATE_EXPERIENCE_KINDS",
    "interleave_records",
    "metric_deltas",
    "render_records",
    "request_is_malformed",
    "SOURCE_OPERATIONS",
    "success_violation",
]
