"""Verified decoding of one already-authorized source artifact occurrence."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass

from meta_evolve.domain import (
    Artifact,
    ArtifactCreated,
    ContentDigest,
    SourceTree,
)
from meta_evolve.errors import (
    DurableCorruption,
    DurableStoreError,
    ExperienceAccessDenied,
)
from meta_evolve.ports import ArtifactNotFound, ArtifactStore


@dataclass(frozen=True, slots=True)
class ResolvedSourceTree:
    """Content identity and decoded value for one artifact occurrence."""

    digest: ContentDigest
    tree: SourceTree


def resolve_source_tree(
    artifacts: ArtifactStore,
    occurrence: object,
) -> ResolvedSourceTree:
    """Resolve an authorized artifact record without widening its authority.

    Visibility is proved before this edge is called. Missing occurrences and
    unsupported artifact schemas remain the same opaque access denial, while
    corrupt durable data and store failures retain their typed taxonomy.
    """

    ref = getattr(occurrence, "ref", None)
    created = getattr(occurrence, "value", None)
    if (
        getattr(ref, "kind", None) != "artifact"
        or not isinstance(created, ArtifactCreated)
        or ref.occurrence_id != created.artifact_id.value
    ):
        raise ExperienceAccessDenied()
    try:
        artifact = artifacts.get(created.artifact_id)
    except ArtifactNotFound:
        raise ExperienceAccessDenied() from None
    except DurableStoreError:
        raise
    except (OSError, sqlite3.Error) as error:
        raise DurableStoreError(
            "artifact storage failed while resolving authorized source"
        ) from error
    except Exception as error:
        raise DurableCorruption(
            "authorized source artifact could not be resolved"
        ) from error
    if not isinstance(artifact, Artifact):
        raise DurableCorruption("artifact store returned a non-artifact value")
    if (
        artifact.kind != SourceTree.KIND
        or artifact.representation != SourceTree.REPRESENTATION
    ):
        raise ExperienceAccessDenied()
    digest = ContentDigest.for_payload(artifact.payload)
    if artifact.digest != digest:
        raise DurableCorruption("authorized source artifact failed its digest check")
    try:
        tree = SourceTree.from_payload(artifact.payload)
    except Exception as error:
        raise DurableCorruption(
            "authorized source artifact payload failed to decode"
        ) from error
    return ResolvedSourceTree(digest=digest, tree=tree)


__all__ = ["ResolvedSourceTree", "resolve_source_tree"]
