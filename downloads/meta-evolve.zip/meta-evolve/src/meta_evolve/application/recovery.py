"""Ordered, exhaustive recovery-frontier classification for durable runs.

``meta.resume`` (M4.4 Task 5) uses ``classify_frontier`` to decide *where* an
interrupted durable run must resume. Classification has two stages:

* **Step A — structural validation.** Parse the ENTIRE ordered ``events`` stream
  against the coordinator's batch grammar (see ``coordinator.py``,
  ``execution.py``, ``decisions.py``). Because every logical step is committed
  as one atomic, preflight-validated batch, a partial batch is *never*
  committed; a malformed or incomplete tail therefore means corruption or a
  foreign writer, so we raise ``DurableCorruption``. This is defense-in-depth on
  top of the per-event ordering ``apply_event`` already enforced during replay:
  ``RunProjection`` groups facts by type and discards envelope order/causation,
  so only the ordered stream can prove the tail is a *whole* coordinator batch.

* **Step B — ordered first-match classification.** With the structure known
  valid, classify the replayed ``projection``'s final state. The ordering is
  load-bearing (e.g. ``STOPPED`` must win over a completed-and-evaluated tail).

The coordinator batch grammar (Tasks 1-3):

* Genesis batch (run creation):
  ``RunStarted, BootstrapPrepared, ArtifactCreated, TrialCompleted,
  EvidenceRecorded*, EvaluationCompleted``.
* Decision batch: ``PolicyDecisionMade, PolicyDecisionExplained``.
* Result batch (success):
  ``ProposalSubmitted, EvidenceRecorded*, ArtifactCreated, TrialCompleted``.
* Result batch (failure): ``ProposalSubmitted, EvidenceRecorded*, TrialCompleted``
  (no ``ArtifactCreated``).
* Evaluation batch (successor trials): ``EvidenceRecorded*, EvaluationCompleted``.

A valid stream is one genesis batch, then a sequence of rounds. Each round is a
decision batch, optionally followed — only when the decision was a ``TrialSpec``
— by a result batch, and — only when the result succeeded — by an evaluation
batch. The stream may legitimately END right after any COMPLETE batch.
"""

from __future__ import annotations

import enum
from collections.abc import Sequence

from meta_evolve.domain import (
    ArchiveUpdate,
    EvaluationCompleted,
    EventEnvelope,
    EvidenceRecorded,
    ProposalSubmitted,
    Stop,
    TrialCompleted,
    TrialSpec,
)
from meta_evolve.errors import DurableCorruption

from .batch_grammar import (
    M3_STANDALONE_FACTS as _M3_STANDALONE_FACTS,
    consume_decision,
    consume_evaluation,
    consume_genesis,
    consume_result,
    is_m3_fact,
)
from .projections import replay_run_projection
from .run_projection import RunProjection
from .work import evaluation_authorized

# M3 context/experience facts are each committed as their own 1-event batch (via
# SequentialCoordinator.append_fact). They legitimately appear between the
# genesis and the terminal Stop — declare_* right after genesis, ContextSelected
# / grant / pull-audit facts around a trial's execution — so the batch grammar
# accepts them as standalone batches wherever they occur rather than
# misclassifying a context/experience-bearing durable stream as corruption. (No
# durable-local run uses context/experience today; this is defensive so
# classification degrades gracefully if one ever does.) The shape matchers
# (``consume_*``) are shared with ``commit_batch`` via ``batch_grammar`` so the
# write-side preflight and this read-side recovery can never disagree on what a
# batch looks like.


class RecoveryPhase(enum.Enum):
    RUN_NOT_FOUND = "run_not_found"
    STOPPED = "stopped"
    TRIAL_DECIDED = "trial_decided"
    EVALUATION_PENDING = "evaluation_pending"
    DECISION_READY = "decision_ready"


class _BatchScanner:
    """Linear consume-a-batch-at-a-time parser over the ordered event bodies.

    Each ``_consume_*`` advances a single cursor and raises
    ``DurableCorruption`` the moment a required fact is missing or the wrong
    type appears — which is precisely how an incomplete tail (a batch cut off
    mid-way by a crash between the preflight fold and the store commit, or by a
    foreign writer) is detected: the required closing fact is absent, so
    ``_expect`` sees end-of-stream where a body was mandatory.
    """

    def __init__(self, bodies: Sequence[object]) -> None:
        self._bodies = list(bodies)
        self._i = 0

    @property
    def _done(self) -> bool:
        return self._i >= len(self._bodies)

    def _peek(self) -> object | None:
        return None if self._done else self._bodies[self._i]

    def _skip_m3_facts(self) -> None:
        """Advance past any run of standalone M3 context/experience batches."""

        while is_m3_fact(self._peek()):
            self._i += 1

    def scan(self) -> None:
        # An empty stream is NOT corruption; it classifies as RUN_NOT_FOUND in
        # Step B.
        if self._done:
            return
        self._i = consume_genesis(self._bodies, self._i)
        self._skip_m3_facts()
        while not self._done:
            self._consume_round()
            self._skip_m3_facts()

    def _consume_round(self) -> None:
        decision, self._i = consume_decision(self._bodies, self._i)
        if isinstance(decision, Stop):
            # Nothing may follow a committed Stop (apply_event enforces this on
            # replay; re-assert it structurally).
            if not self._done:
                found = type(self._peek()).__name__
                raise DurableCorruption(
                    f"a committed Stop decision cannot be followed by {found} "
                    f"at event {self._i}"
                )
            return
        if isinstance(decision, TrialSpec):
            self._consume_result_and_evaluation()
        elif not isinstance(decision, ArchiveUpdate):  # pragma: no cover
            raise DurableCorruption(
                f"unsupported decision {type(decision).__name__} at event "
                f"{self._i - 2} in stream"
            )
        # ArchiveUpdate carries no trailing batches; the next round (or end)
        # follows immediately.

    def _consume_result_and_evaluation(self) -> None:
        # ContextSelected / grant / pull-audit facts are committed between the
        # trial decision batch and the result batch (coordinator.execute selects
        # context and issues the reader before execute_trial). Skip them so the
        # result-batch expectation still lines up.
        self._skip_m3_facts()
        # The result batch is optional: the stream may legitimately end right
        # after the trial decision batch (the TRIAL_DECIDED frontier).
        if self._done:
            return
        if not isinstance(self._peek(), ProposalSubmitted):
            found = type(self._peek()).__name__
            raise DurableCorruption(
                "a trial decision must be followed by its result batch or end "
                f"of stream, found {found} at event {self._i}"
            )
        succeeded, self._i = consume_result(self._bodies, self._i)
        # Pull-audit facts may also trail the result batch; skip them before the
        # optional evaluation batch.
        self._skip_m3_facts()
        # An evaluation batch is optional and legal ONLY after a successful
        # result (a failed trial is never evaluated). If a failed result is
        # followed by evidence/evaluation, the next round's decision-batch
        # expectation will reject it as corruption.
        if succeeded and isinstance(
            self._peek(), (EvidenceRecorded, EvaluationCompleted)
        ):
            self._i = consume_evaluation(self._bodies, self._i)


def scan_batch_grammar(bodies: Sequence[object]) -> None:
    """Structurally validate ordered event ``bodies`` as a whole sequence of
    complete coordinator batches, raising ``DurableCorruption`` otherwise.

    This is the SAME whole-stream structural scan recovery uses in Step A;
    ``SequentialCoordinator.commit_batch`` reuses it (over its running list of
    committed bodies plus the new batch) so the write side rejects — before
    persisting — any batch that would leave the WHOLE stream ungrammatical
    (e.g. a valid-shaped evaluation batch committed AFTER a newer trial
    decision). Write-side preflight and read-side recovery therefore run the
    identical grammar over the identical ordered stream and cannot diverge.
    """

    _BatchScanner(bodies).scan()


def classify_frontier(
    events: Sequence[EventEnvelope], projection: RunProjection
) -> RecoveryPhase:
    """Validate the batch grammar of ``events``, then classify ``projection``.

    ``events`` is the ordered durable stream; ``projection`` is the already
    replayed ``RunProjection`` for the same run (in ``resume`` this is
    ``replay_run_projection(run_id, events)``, so per-event ordering is already
    validated). Raises ``DurableCorruption`` if the ordered stream is not a
    whole sequence of complete coordinator batches.
    """

    # Step A — structural validation FIRST.
    scan_batch_grammar([event.body for event in events])

    # Step B — ordered first-match classification.
    if projection.start is None:
        return RecoveryPhase.RUN_NOT_FOUND

    # An authorized-but-unevaluated successful trial is legitimate ONLY as the
    # tail EVALUATION_PENDING frontier. The executor always evaluates an
    # authorized success BEFORE producing the next decision (execution.py:
    # complete_work evaluates when evaluation_authorized), so a successful,
    # unevaluated, still-AUTHORIZED trial with a LATER decision (or Stop) after
    # it means an owed evaluation was silently abandoned — corruption, not a
    # recoverable frontier. This must be caught before STOPPED/DECISION_READY
    # would otherwise mask it. (An UNauthorized unevaluated success is fine —
    # the run legitimately skipped it — and the tail authorized success with no
    # later decision is the real EVALUATION_PENDING case below.)
    #
    # Authorization here MUST be judged AS OF the trial's completion, never
    # against the FINAL remaining budget: an evaluation that was authorized when
    # its trial completed, then abandoned, would look UNauthorized once LATER
    # trials deplete the budget — wrongly masking the corruption as
    # STOPPED/DECISION_READY. So for each unevaluated successful trial that a
    # later decision follows, replay the ordered prefix up to and including that
    # trial's TrialCompleted and authorize against THAT (as-of-completion)
    # remaining budget. For the tail EVALUATION_PENDING trial (no later
    # decision) as-of-completion equals the final budget, so the ordered
    # classification below (which uses the tail budget) is unaffected.
    completion_index = {
        event.body.trial.id: index
        for index, event in enumerate(events)
        if isinstance(event.body, TrialCompleted)
    }
    for completed in projection.completed_trials:
        if completed.outcome.failure is not None:
            continue
        if projection.evaluation_for(completed.trial.id) is not None:
            continue
        if not any(
            decision.logical_step > completed.trial.logical_step
            for decision in projection.decisions
        ):
            continue
        k = completion_index[completed.trial.id]
        as_of_completion = replay_run_projection(
            projection.run_id, events[: k + 1]
        ).search_state.remaining_budget
        if evaluation_authorized(
            as_of_completion,
            completed.trial.spec.budget,
            completed.outcome.usage,
        ):
            raise DurableCorruption(
                "a successful, authorized, unevaluated trial is followed by a "
                "later decision: the owed evaluation was abandoned "
                f"(trial {completed.trial.id.value})"
            )

    if projection.stop is not None:
        return RecoveryPhase.STOPPED
    if projection.decisions:
        last = projection.decisions[-1]
        if isinstance(last.decision, TrialSpec) and (
            projection.completed_trial(last.trial_id) is None
        ):
            return RecoveryPhase.TRIAL_DECIDED
    # Only the tail completed trial can be an unevaluated success: sequential
    # runs never decide with work in flight (transitions.py), so any earlier
    # successful trial was already evaluated (or the run stopped). Scanning for
    # the last success is therefore equivalent to inspecting the tail; the loop
    # is kept as defense-in-depth should a future policy drive multiple trials.
    last_success = None
    for completed in projection.completed_trials:
        if completed.outcome.failure is None:
            last_success = completed
    if last_success is not None and (
        projection.evaluation_for(last_success.trial.id) is None
    ):
        # The EVALUATION_PENDING predicate is the shared, resume-equivalence
        # -critical authorization calc (work.evaluation_authorized), NOT a
        # looser `remaining.evaluations > 0`.
        remaining = projection.search_state.remaining_budget
        if evaluation_authorized(
            remaining, last_success.trial.spec.budget, last_success.outcome.usage
        ):
            return RecoveryPhase.EVALUATION_PENDING
    return RecoveryPhase.DECISION_READY


__all__ = ["RecoveryPhase", "classify_frontier", "scan_batch_grammar"]
