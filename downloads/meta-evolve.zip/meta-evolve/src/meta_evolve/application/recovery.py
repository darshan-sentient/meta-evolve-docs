"""Ordered, exhaustive recovery-frontier classification for durable runs.

``meta.resume`` (M4.4 Task 5) uses ``classify_frontier`` to decide *where* an
interrupted durable run must resume. Classification has two stages:

* **Step A — structural validation.** Parse the ENTIRE ordered ``events`` stream
  against the coordinator's batch grammar (see ``coordinator.py``,
  ``execution.py``, ``decisions.py``). Because every logical step is committed
  as one atomic, preflight-validated batch, a partial batch is *never*
  committed; a malformed or incomplete tail therefore means corruption or a
  foreign writer, so we raise ``DurableCorruption``. This is defense-in-depth on
  top of the per-event ordering ``apply_event`` already enforced during replay:
  ``RunProjection`` groups facts by type and discards envelope order/causation,
  so only the ordered stream can prove the tail is a *whole* coordinator batch.

* **Step B — ordered first-match classification.** With the structure known
  valid, classify the replayed ``projection``'s final state. The ordering is
  load-bearing (e.g. ``STOPPED`` must win over a completed-and-evaluated tail).

This module no longer owns the grammar. Batch *shapes* live in
``batch_grammar`` and are shared with ``commit_batch``'s preflight, so the write
and read sides cannot disagree about what a batch looks like; the *ordering* of
batches lives in ``stream_grammar``, which this module calls through
``scan_batch_grammar``.

*Attribution* used to be positional -- a result was whatever followed a trial
decision -- which cannot describe a cohort, because a generation commits several
decisions together and their results arrive in any order. It is now keyed on
trial identity: a result is attributed by the trial its proposal and completion
both name, and an evaluation by the trial its own record names.

Ordering is not thereby abolished. Two rules here remain genuinely
event-order-dependent and say so at their own sites -- nothing may follow a
committed stop, and "followed by a later decision" below is a question about
event order, not logical order. Read ``stream_grammar`` for the rules themselves
rather than trusting a copy here.
"""

from __future__ import annotations

import enum
from collections.abc import Sequence

from meta_evolve.domain import (
    EventEnvelope,
    PolicyDecisionMade,
    TrialCompleted,
)
from meta_evolve.errors import DurableCorruption

from .disposition import outstanding_trial_ids
from .run_projection import RunProjection
from .stream_grammar import scan_batch_grammar


class RecoveryPhase(enum.Enum):
    RUN_NOT_FOUND = "run_not_found"
    STOPPED = "stopped"
    TRIAL_DECIDED = "trial_decided"
    EVALUATION_PENDING = "evaluation_pending"
    DECISION_READY = "decision_ready"


def classify_frontier(
    events: Sequence[EventEnvelope], projection: RunProjection
) -> RecoveryPhase:
    """Validate the batch grammar of ``events``, then classify ``projection``.

    ``events`` is the ordered durable stream; ``projection`` is the already
    replayed ``RunProjection`` for the same run (in ``resume`` this is
    ``replay_run_projection(run_id, events)``, so per-event ordering is already
    validated). Raises ``DurableCorruption`` if the ordered stream is not a
    whole sequence of complete coordinator batches.
    """

    # Step A — structural validation FIRST.
    scan_batch_grammar([event.body for event in events])

    # Step B — ordered first-match classification.
    if projection.start is None:
        return RecoveryPhase.RUN_NOT_FOUND

    # An owed evaluation that was silently abandoned is corruption, not a
    # recoverable frontier. The barrier now refuses the decision that would
    # abandon one, so the ordinary case cannot reach a committed stream at all.
    #
    # No PRODUCTION path reaches it, and it is deliberately kept -- the same
    # status as the provenance backstops in `decision_transitions.py`. The
    # load-bearing reason is not a caller census but a precondition every caller
    # meets: each pairs an event list with a projection replayed from THAT SAME
    # list, and such a projection cannot exist, because a completion that still
    # owes an authorized evaluation IS outstanding and the later decision raises
    # `InvalidSearchHistory` during that replay. That stays true when a caller is
    # added; "there is only one caller" would not.
    #
    # Being `replay_run_projection`-built is NOT the precondition, and an earlier
    # version of this comment said it was -- contradicting the paragraph directly
    # below, whose test reaches the raise with a projection built exactly that
    # way. What that test breaks is the pairing: it replays a PREFIX and then
    # hands the fold a fuller event list.
    #
    # It is still executed, and must stay so:
    # `test_an_owed_evaluation_before_a_later_decision_is_still_corruption`
    # reaches it by handing a prefix-built projection a fuller event list, so
    # deleting the raise or reverting the predicate each fail a test. A guard no
    # test runs is a comment with a `raise` in it.
    #
    # The predicate is stated on the PINNED disposition -- the same value the
    # barrier admits against -- never by re-deriving the overrun. Re-deriving is
    # how the two sides came to disagree
    # (#217): the fold pins *no answer* for a trial whose recorded usage exceeds
    # its own allocation, so that replay stays total on historical overages, and
    # a second `Budget.allows` here then called that same stream corrupt. Nothing
    # unowed can be abandoned, so only a trial pinned *evaluate* can be.
    # "Followed by a later decision" is an EVENT-ORDER question, not a logical
    # one. A cohort sibling carries a higher logical step yet was committed
    # before this trial completed -- comparing steps would call a legitimate
    # cohort abandonment.
    completion_at = {
        event.body.trial.id: event.sequence
        for event in events
        if isinstance(event.body, TrialCompleted)
    }
    decided_at = [
        event.sequence
        for event in events
        if isinstance(event.body, PolicyDecisionMade)
    ]
    for completed in projection.completed_trials:
        # `is not True` subsumes the failure check: a failed trial is pinned
        # *no answer*, never *evaluate*.
        if projection.disposition_for(completed.trial.id) is not True:
            continue
        if projection.evaluation_for(completed.trial.id) is not None:
            continue
        finished = completion_at.get(completed.trial.id)
        if finished is None or not any(at > finished for at in decided_at):
            continue
        raise DurableCorruption(
            "an authorized, unevaluated trial is followed by a later decision "
            f"(trial {completed.trial.id.value})"
        )

    if projection.stop is not None:
        return RecoveryPhase.STOPPED
    # The frontier is whatever the run still owes, read from the same
    # outstanding-work definition the barrier admits against -- so the read side
    # cannot classify a state the write side would have refused. A trial that
    # has not completed owes its result; one that has owes the evaluation its
    # pinned disposition authorized.
    outstanding = outstanding_trial_ids(projection)
    # Precedence, unchanged: an undelivered result outranks an owed evaluation.
    # At width one at most one trial is ever outstanding, so the order only
    # becomes observable once a cohort can leave both kinds pending at once.
    if any(projection.completed_trial(trial_id) is None for trial_id in outstanding):
        return RecoveryPhase.TRIAL_DECIDED
    if outstanding:
        return RecoveryPhase.EVALUATION_PENDING
    return RecoveryPhase.DECISION_READY


# `scan_batch_grammar` is re-exported: it moved to `stream_grammar`, and the
# coordinator and durable loader still reach it through this module.
__all__ = ["RecoveryPhase", "classify_frontier", "scan_batch_grammar"]
