"""Load one event stream through the complete durable integrity boundary."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import EventEnvelope, RunId
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.errors import (
    DurableCorruption,
    DurableStoreError,
    RunNotFound,
)

from .integrity import (
    check_artifact_declaration,
    check_artifact_references,
    check_declared_codec,
)
from .projections import RunProjection, replay_run_projection, verify_event_chain
from .recovery import scan_batch_grammar
from .source_verification import verify_source_results
from .storage import Storage


@dataclass(frozen=True, slots=True)
class LoadedRun:
    events: tuple[EventEnvelope, ...]
    projection: RunProjection


def load_validated_run(
    storage: Storage,
    run_id: RunId,
    *,
    require_existing: bool = False,
) -> LoadedRun:
    """Decode, authenticate, validate, replay, and resolve one run."""

    try:
        events = storage.events.read(run_id)
        if require_existing and not events:
            raise RunNotFound(f"no durable run exists under {run_id}")
        verify_event_chain(run_id, events)
        scan_batch_grammar([event.body for event in events])
        projection = replay_run_projection(run_id, events)
        if projection.start is None:
            # No declaration to check against, so the bare walk is the only
            # check there is. Reached only by a run with no `RunStarted`, which
            # the grammar above already refuses for a non-empty stream.
            check_artifact_references(storage.artifacts, projection.artifact_ids)
        else:
            # ONE walk: this resolves every artifact `check_artifact_references`
            # would -- same helper, same seed, same rule -- and also refuses a
            # foreign declaration, so running both would decode the graph twice.
            #
            # On every reader's path, not only resume: decoding dispatches on
            # the artifact's own (kind, representation), so a rewritten
            # occurrence steers `Run.best()` and `Run.inspect()` exactly as it
            # steers a resumed decode. Siting it here is what makes the two
            # agree about whether the same bytes are corrupt.
            check_artifact_declaration(
                storage.artifacts,
                projection.artifact_ids,
                kind=projection.start.task.artifact_kind,
                representation=projection.start.task.artifact_representation,
            )
            # Agreement is only half of it. The check above proves the stored
            # artifacts match the declaration; this one proves the declaration
            # was legal to record, which a coherent forge -- declaration and
            # occurrences rewritten together -- leaves untouched.
            check_declared_codec(
                mode=projection.start.capabilities.mode,
                kind=projection.start.task.artifact_kind,
                representation=projection.start.task.artifact_representation,
            )
        verify_source_results(storage.artifacts, projection)
    except (RunNotFound, DurableStoreError):
        raise
    except InvalidSearchHistory as error:
        raise DurableCorruption(
            f"durable run {run_id} has an invalid event history: {error}"
        ) from error
    except Exception as error:
        raise DurableCorruption(
            f"durable run {run_id} could not be decoded: {error}"
        ) from error
    return LoadedRun(events=events, projection=projection)


__all__ = ["LoadedRun", "load_validated_run"]
