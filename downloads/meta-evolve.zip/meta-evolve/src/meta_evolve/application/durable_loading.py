"""Load one event stream through the complete durable integrity boundary."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import EventEnvelope, RunId
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.errors import (
    DurableCorruption,
    DurableStoreError,
    RunNotFound,
)

from .integrity import check_artifact_references
from .projections import RunProjection, replay_run_projection, verify_event_chain
from .recovery import scan_batch_grammar
from .source_verification import verify_source_results
from .storage import Storage


@dataclass(frozen=True, slots=True)
class LoadedRun:
    events: tuple[EventEnvelope, ...]
    projection: RunProjection


def load_validated_run(
    storage: Storage,
    run_id: RunId,
    *,
    require_existing: bool = False,
) -> LoadedRun:
    """Decode, authenticate, validate, replay, and resolve one run."""

    try:
        events = storage.events.read(run_id)
        if require_existing and not events:
            raise RunNotFound(f"no durable run exists under {run_id}")
        verify_event_chain(run_id, events)
        scan_batch_grammar([event.body for event in events])
        projection = replay_run_projection(run_id, events)
        check_artifact_references(storage.artifacts, projection.artifact_ids)
        verify_source_results(storage.artifacts, projection)
    except (RunNotFound, DurableStoreError):
        raise
    except InvalidSearchHistory as error:
        raise DurableCorruption(
            f"durable run {run_id} has an invalid event history: {error}"
        ) from error
    except Exception as error:
        raise DurableCorruption(
            f"durable run {run_id} could not be decoded: {error}"
        ) from error
    return LoadedRun(events=events, projection=projection)


__all__ = ["LoadedRun", "load_validated_run"]
