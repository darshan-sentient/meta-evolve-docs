"""Commit each ended work row together with its terminal logical fact.

Expiry, rollover and release leave exhausted rows READY. Reclamation owns the
READY-to-CANCELLED transition because the failure fact must commit with it.
"""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain import RunId
from meta_evolve.domain.work import WorkKind, WorkRow, WorkState
from meta_evolve.domain.work_aborts import aborted
from meta_evolve.ports.work_store import WorkBroker

from .dispatch_evaluation import EvaluationDispatchHost, terminate_evaluation
from .dispatch_proposal import ProposalDispatchHost, terminate_proposal
from .identities import correlation_for_work


class ReclaimHost(EvaluationDispatchHost, ProposalDispatchHost, Protocol):
    """The proposal and evaluation completion capabilities needed by reclamation."""

    run_id: RunId


def terminate(host: ReclaimHost, row: WorkRow) -> None:
    """The terminal fact for this row's kind, and the intent, as one commit."""

    correlation = correlation_for_work(row.item.value)
    if row.kind is WorkKind.PROPOSAL:
        terminate_proposal(host, row, correlation=correlation)
    else:
        terminate_evaluation(host, row, correlation=correlation)


def is_ended(row: WorkRow) -> bool:
    """Whether exhaustion or a deterministic completion verdict ends this row.

    The dispatcher and reclamation use the same predicate so work awaiting its
    terminal fact cannot be offered for another attempt.
    """

    return row.is_exhausted or aborted(row)


def reclaim_ended(host: ReclaimHost, broker: WorkBroker) -> int:
    """Count ended rows committed with their terminal facts.

    Build the fact before changing the row; both changes share the commit.
    """

    reclaimed = 0
    for row in broker.rows(host.run_id):
        if row.state is not WorkState.READY:
            continue
        if not is_ended(row):
            continue
        terminate(host, row)
        reclaimed += 1
    return reclaimed


__all__ = ["ReclaimHost", "is_ended", "reclaim_ended", "terminate"]
