"""End the work a run can no longer make progress on, fact and row together.

The other half of D3's refinement, kept apart from `dispatcher.py` because it is
the other half of a division that already exists: the scheduler claims and runs
work, and this ends it. Expiry, rollover and `release` all leave an exhausted row
READY and unclaimable, because none of them is committing a batch and so none can
carry the terminal fact the record requires. This module is the only place that
can, so it is the only place that holds the `READY -> CANCELLED` edge.

Which fact a kind owes is still not decided here -- the facts live in
`dispatch_evaluation.py` and `dispatch_proposal.py`, and all this knows is that
each kind owes its own.
"""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain import RunId
from meta_evolve.domain.work import WorkKind, WorkState
from meta_evolve.ports.work_store import WorkBroker

from .dispatch_evaluation import EvaluationDispatchHost, terminate_evaluation
from .dispatch_proposal import ProposalDispatchHost, terminate_proposal
from .identities import correlation_for_work


class ReclaimHost(EvaluationDispatchHost, ProposalDispatchHost, Protocol):
    """Both kinds' terminal facts, since a scan meets rows of either kind.

    Composed rather than restated: this module adds only `run_id` of its own,
    and a hand-copied third list is how two of the three would come to disagree
    about what a coordinator owes.
    """

    run_id: RunId


def terminate(host: ReclaimHost, row) -> None:
    """The terminal fact for this row's kind, and the intent, as one commit."""

    correlation = correlation_for_work(row.item.value)
    if row.kind is WorkKind.PROPOSAL:
        terminate_proposal(host, row, correlation=correlation)
    else:
        terminate_evaluation(host, row, correlation=correlation)


def reclaim_exhausted(host: ReclaimHost, broker: WorkBroker) -> int:
    """Terminate every exhausted row, each with its terminal fact. Count.

    Ordered so the row is observed exhausted BEFORE the fact is built: a row
    terminated first would be a ledger-only edit for as long as the build took,
    which is the state this whole refinement exists to avoid.
    """

    reclaimed = 0
    for row in broker.rows(host.run_id):
        if row.state is not WorkState.READY:
            continue
        if not row.is_exhausted:
            continue
        terminate(host, row)
        reclaimed += 1
    return reclaimed


__all__ = ["ReclaimHost", "reclaim_exhausted", "terminate"]
