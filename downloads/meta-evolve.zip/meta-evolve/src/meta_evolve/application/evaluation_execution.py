"""Independent evaluation and evidence-event construction."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    Budget,
    CorrelationId,
    Evaluation,
    EvaluationCompleted,
    EvaluationId,
    Evidence,
    EvidenceId,
    EvidenceRecorded,
    ResourceExhausted,
    Task,
    Trial,
)
from meta_evolve.ports.callables import Evaluator, EvidenceDraft

from .codecs import CodecIndex
from .identities import stable_id
from .projections import RunProjection
from .work import action_usage, would_exceed


class EvaluationHost(Protocol):
    task: Task
    evaluator: Evaluator
    run_budget: Budget
    codecs: CodecIndex

    @property
    def projection(self) -> RunProjection: ...

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        correlation: CorrelationId,
    ) -> RunProjection: ...


def build_evaluation(
    projection: RunProjection,
    trial: Trial,
    artifact: Artifact,
    *,
    task: Task,
    evaluator: Evaluator,
    run_budget: Budget,
    codecs: CodecIndex,
) -> tuple[tuple[EvidenceRecorded, ...], EvaluationCompleted]:
    """Run an evaluator and build, but do not commit, its durable facts."""

    result = evaluator.evaluate(codecs.decode(artifact))
    evidence_records, evidence_ids = evidence_bodies(
        result.evidence, owner=f"evaluation:{trial.id.value}"
    )
    usage = action_usage(evaluations=1, usage=result.usage)
    failure = result.failure
    completed = projection.completed_trial(trial.id)
    assert completed is not None
    if would_exceed(
        usage,
        trial.spec.budget,
        projection,
        run_budget=run_budget,
        task=task,
        trial_used=completed.outcome.usage,
    ):
        failure = ResourceExhausted(
            message="evaluator usage exceeded its effective budget",
            details={"reported_failure": failure.kind if failure else None},
        )
    values = {
        "id": stable_id(EvaluationId, "evaluation", trial.id.value),
        "trial_id": trial.id,
        "artifact_id": artifact.id,
        "evaluator": task.evaluator,
        "evidence_ids": evidence_ids,
        "usage": usage,
    }
    if failure is None:
        evaluation = Evaluation.succeeded(
            **values, metrics=result.metrics, uncertainty=result.uncertainty
        )
    else:
        evaluation = Evaluation.failed(**values, failure=failure)
    return tuple(evidence_records), EvaluationCompleted(evaluation=evaluation)


def evaluate_artifact(
    host: EvaluationHost,
    trial: Trial,
    artifact: Artifact,
    correlation: CorrelationId,
) -> Evaluation:
    evidence, completed = build_evaluation(
        host.projection,
        trial,
        artifact,
        task=host.task,
        evaluator=host.evaluator,
        run_budget=host.run_budget,
        codecs=host.codecs,
    )
    host.commit_batch([*evidence, completed], correlation=correlation)
    return completed.evaluation


def evidence_bodies(
    drafts: tuple[EvidenceDraft, ...],
    *,
    owner: str,
) -> tuple[list[EvidenceRecorded], tuple[EvidenceId, ...]]:
    bodies: list[EvidenceRecorded] = []
    ids: list[EvidenceId] = []
    for index, draft in enumerate(drafts):
        evidence = Evidence(
            id=stable_id(EvidenceId, "evidence", owner, index),
            kind=draft.kind,
            data=draft.data,
            uri=draft.uri,
        )
        bodies.append(EvidenceRecorded(evidence=evidence))
        ids.append(evidence.id)
    return bodies, tuple(ids)


__all__ = ["build_evaluation", "evaluate_artifact", "evidence_bodies"]
