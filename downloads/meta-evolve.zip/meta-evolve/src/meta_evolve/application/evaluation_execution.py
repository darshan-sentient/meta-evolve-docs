"""Independent evaluation and evidence-event construction."""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    ArtifactId,
    Budget,
    CorrelationId,
    Evaluation,
    EvaluationCompleted,
    EvaluationId,
    Evidence,
    EvidenceId,
    EvidenceRecorded,
    ResourceExhausted,
    Task,
    Trial,
)
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.callables import EvaluationResult, Evaluator, EvidenceDraft

from .hosts import CommitBatchHost
from .codecs import CodecIndex
from .identities import stable_id
from .projections import RunProjection
from .work import _resource_usage, action_usage, would_exceed


class EvaluationHost(CommitBatchHost, Protocol):
    task: Task
    evaluator: Evaluator
    run_budget: Budget
    codecs: CodecIndex

    @property
    def projection(self) -> RunProjection: ...


def build_evaluation(
    projection: RunProjection,
    trial: Trial,
    artifact_id: ArtifactId,
    *,
    task: Task,
    result: EvaluationResult,
    run_budget: Budget,
) -> tuple[tuple[EvidenceRecorded, ...], EvaluationCompleted]:
    """Build, but do not commit, one evaluation's durable facts.

    Takes the component's `EvaluationResult` rather than calling the evaluator,
    which is what lets a dispatcher run that call on a worker and build the
    facts where the projection, the budget and the identities are.

    Mirrors `build_proposal_completion` on the proposal side, and the symmetry
    is the point: the worker computes a boundary record, a build turns it into
    durable facts, the caller commits. One rule for both component calls.

    Takes an `ArtifactId`, NOT an `Artifact`. It only ever needed the id, and
    demanding the whole object forced `terminate_evaluation` to read the blob
    back out of storage purely to hand over `artifact.id` -- on the one path
    whose job is to END a row whose attempts died on that very read. A
    persistently unavailable artifact store therefore made the terminal fact
    unbuildable, `reclaim()` raised out of `Dispatcher.drive()`, and the row
    was left both unclaimable and unterminable. An over-wide parameter was the
    whole cause.
    """

    evidence_records, evidence_ids = evidence_bodies(
        result.evidence, owner=f"evaluation:{trial.id.value}"
    )
    usage = action_usage(evaluations=1, usage=_resource_usage(result.usage))
    failure = result.failure
    completed = projection.completed_trial(trial.id)
    if completed is None:
        # NOT `assert`: under `-O` the assertion vanishes and this degrades to
        # an `AttributeError` seven lines down, where the cause is no longer
        # legible. A trial that is not completed here means the caller and the
        # stream disagree, which is the typed failure both callers already
        # raise for the same condition.
        raise DurableCorruption(
            f"evaluation build for trial {trial.id.value}, which the stream "
            "does not record as completed"
        )
    if would_exceed(
        usage,
        trial.spec.budget,
        projection,
        run_budget=run_budget,
        task=task,
        trial_used=completed.outcome.usage,
    ):
        failure = ResourceExhausted(
            message="evaluator usage exceeded its effective budget",
            details={"reported_failure": failure.kind if failure else None},
        )
    values = {
        "id": stable_id(EvaluationId, "evaluation", trial.id.value),
        "trial_id": trial.id,
        "artifact_id": artifact_id,
        "evaluator": task.evaluator,
        "evidence_ids": evidence_ids,
        "usage": usage,
    }
    if failure is None:
        evaluation = Evaluation.succeeded(
            **values, metrics=result.metrics, uncertainty=result.uncertainty
        )
    else:
        evaluation = Evaluation.failed(**values, failure=failure)
    return tuple(evidence_records), EvaluationCompleted(evaluation=evaluation)


def evaluate_artifact(
    host: EvaluationHost,
    trial: Trial,
    artifact: Artifact,
    correlation: CorrelationId,
) -> Evaluation:
    evidence, completed = build_evaluation(
        host.projection,
        trial,
        artifact.id,
        task=host.task,
        result=host.evaluator.evaluate(host.codecs.decode(artifact)),
        run_budget=host.run_budget,
    )
    host.commit_batch([*evidence, completed], correlation=correlation)
    return completed.evaluation


def evidence_bodies(
    drafts: tuple[EvidenceDraft, ...],
    *,
    owner: str,
) -> tuple[list[EvidenceRecorded], tuple[EvidenceId, ...]]:
    bodies: list[EvidenceRecorded] = []
    ids: list[EvidenceId] = []
    for index, draft in enumerate(drafts):
        evidence = Evidence(
            id=stable_id(EvidenceId, "evidence", owner, index),
            kind=draft.kind,
            data=draft.data,
            uri=draft.uri,
        )
        bodies.append(EvidenceRecorded(evidence=evidence))
        ids.append(evidence.id)
    return bodies, tuple(ids)


__all__ = ["build_evaluation", "evaluate_artifact", "evidence_bodies"]
