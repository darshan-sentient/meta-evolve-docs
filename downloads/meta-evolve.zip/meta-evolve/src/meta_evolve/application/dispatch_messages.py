"""The one message protocol every dispatch backend speaks.

D2: backends are event sources on ONE protocol. The inline backend hands these
objects over in process; a wire endpoint encodes the same objects as frames
(`distributed/messages.py`). So the loop that consumes them never knows which
backend a result came from -- which is what "one completion path" means.

Worker to host: `Pull`, `Heartbeat`, and one outcome per `Work` -- `Completed`,
`AttemptFailed`, `CompletionFailed` or `Escaped`. Host to worker: `Work`, and
an `Answer` to each submission. An `Answer` is also sent when a renewal is
refused, so a worker drops a result that can no longer be accepted.

Declared in `application/` beside the loop, never in `distributed/`: the
application layer imports nothing from the transport, and the transport imports
this.
"""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import Artifact
from meta_evolve.domain.work import Lease, WorkItemId
from meta_evolve.ports.callables import EvaluationResult
from meta_evolve.ports.work_store import Acknowledgment
from meta_evolve.ports.work_submission import Duplicate, Stale

from .executors import EncodedProposal, ProposalRequest


#: The release cause of every lease a failed connection held.
WORKER_DISCONNECTED = "WorkerDisconnected"

#: The release cause when the worker itself said why it left (design PD6).
WORKER_INTERRUPTED = "WorkerInterrupted"


class TransportFailure(Exception):
    """A connection broke the protocol, or broke, or said goodbye.

    An undecodable or oversized frame, an invalid message, EOF, a write past
    its deadline, silence past the heartbeat threshold, a submission for an
    item this run does not hold. The connection's leases are released and the
    connection is closed; other connections continue. Never raised out of a
    drive: it is the loop's to handle.

    `cause` is the release cause the leases carry, and it travels on the
    failure because only the connection knows which one applies: a worker that
    sent `Goodbye` was INTERRUPTED, and a reader that met EOF saw a
    DISCONNECT. Recorded against the attempt, so whoever asks why an item was
    retried reads what actually happened.

    Its message never quotes the frame it refused -- a frame can carry a
    lease's secret.
    """

    def __init__(self, message: str, *, cause: str = WORKER_DISCONNECTED) -> None:
        super().__init__(message)
        self.cause = cause


def _require(value, kinds, what: str) -> None:
    """A field of the type it is declared as, or a `TypeError` naming it.

    The messages check their own fields because the wire decodes them: an
    annotation is not enforced, so a well-formed frame naming the right class
    with the wrong contents would otherwise reach the loop and fail there, far
    from the connection that sent it. A `TypeError` here is what the decoder
    turns into that connection's `TransportFailure`.
    """

    if not isinstance(value, kinds):
        raise TypeError(f"{what} must be a {' or '.join(k.__name__ for k in kinds)}")


def _require_cause(cause) -> None:
    if not (
        isinstance(cause, tuple)
        and len(cause) == 2
        and all(isinstance(part, str) for part in cause)
    ):
        raise TypeError("a cause must be a (type, message) pair of strings")


# -- worker to host ---------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Pull:
    """One more item wanted."""


@dataclass(frozen=True, slots=True)
class Heartbeat:
    """Still here; renew what I hold."""


@dataclass(frozen=True, slots=True, kw_only=True)
class Goodbye:
    """This end is going away on purpose, and why.

    Both directions (design PD6). From a worker: its component was
    interrupted, so the host releases what it held with cause
    `WorkerInterrupted` rather than waiting out a silence it already knows the
    answer to. From the host: the run finished, so an external worker exits
    instead of reconnecting -- which is how it tells a finished run from a
    dispatcher that died, since both close the socket.
    """

    reason: str

    def __post_init__(self) -> None:
        _require(self.reason, (str,), "Goodbye.reason")


@dataclass(frozen=True, slots=True, kw_only=True)
class Completed:
    """The component answered. Still to be classified, built and committed."""

    lease: Lease
    result: EvaluationResult | EncodedProposal

    def __post_init__(self) -> None:
        _require(self.lease, (Lease,), "Completed.lease")
        _require(self.result, (EvaluationResult, EncodedProposal), "Completed.result")


@dataclass(frozen=True, slots=True, kw_only=True)
class AttemptFailed:
    """The component raised an ordinary exception: an attempt failure.

    Carries the cause pair, computed where the exception was raised by
    `reportable_cause`, so inline and wire record the same two strings.
    """

    lease: Lease
    cause: tuple[str, str]

    def __post_init__(self) -> None:
        _require(self.lease, (Lease,), "AttemptFailed.lease")
        _require_cause(self.cause)


@dataclass(frozen=True, slots=True, kw_only=True)
class CompletionFailed:
    """The component answered, but its answer could not be completed where it ran.

    Either encoding the proposer's candidate failed (a codec bug), or the
    result cannot cross the wire (over the frame bound, or a value the wire
    codec refuses). Both recur on every retry, so both are completion
    failures -- recorded and propagated, never re-run.

    `cause` is the pair recorded against the lease, computed where the error
    was raised: the wire rebuilds `error` from a closed table, which keeps its
    type and message but not its `__cause__`, and the recorded pair must name
    the real fault on both backends alike. `None` computes it from `error`.
    """

    lease: Lease
    error: BaseException
    cause: tuple[str, str] | None = None

    def __post_init__(self) -> None:
        _require(self.lease, (Lease,), "CompletionFailed.lease")
        _require(self.error, (BaseException,), "CompletionFailed.error")
        if self.cause is not None:
            _require_cause(self.cause)
            # The decoded exception may be a mapped BASE of what the peer
            # raised, while the cause pair crossed verbatim naming the
            # subclass. `__wire_origin__` is the peer's word for that class,
            # set only by the decoder; a locally built error carries none, so
            # local construction keeps the exact-class check through this same
            # branch, with no second code path.
            names = {type(self.error).__name__}
            origin = getattr(self.error, "__wire_origin__", None)
            if isinstance(origin, str):
                names.add(origin)
            if self.cause[0] not in names:
                raise TypeError(
                    "CompletionFailed.cause must name the error it records"
                )


@dataclass(frozen=True, slots=True, kw_only=True)
class Escaped:
    """The component raised past the normalization boundary: abort the drive."""

    lease: Lease
    error: BaseException

    def __post_init__(self) -> None:
        _require(self.lease, (Lease,), "Escaped.lease")
        _require(self.error, (BaseException,), "Escaped.error")


# -- host to worker ---------------------------------------------------------


@dataclass(frozen=True, slots=True)
class EvaluationCall:
    artifact: Artifact

    def __post_init__(self) -> None:
        _require(self.artifact, (Artifact,), "EvaluationCall.artifact")


@dataclass(frozen=True, slots=True)
class ProposalCall:
    parents: tuple[Artifact, ...]
    request: ProposalRequest

    def __post_init__(self) -> None:
        _require(self.parents, (tuple,), "ProposalCall.parents")
        for parent in self.parents:
            _require(parent, (Artifact,), "ProposalCall.parents[]")
        _require(self.request, (ProposalRequest,), "ProposalCall.request")


@dataclass(frozen=True, slots=True, kw_only=True)
class Work:
    """One claimed item: the lease it runs under, and its resolved inputs."""

    lease: Lease
    call: EvaluationCall | ProposalCall

    def __post_init__(self) -> None:
        _require(self.lease, (Lease,), "Work.lease")
        _require(self.call, (EvaluationCall, ProposalCall), "Work.call")


@dataclass(frozen=True, slots=True)
class Accepted:
    """The submission was committed; this is what it was acknowledged with."""

    acknowledgment: Acknowledgment

    def __post_init__(self) -> None:
        _require(self.acknowledgment, (Acknowledgment,), "Accepted.acknowledgment")


@dataclass(frozen=True, slots=True, kw_only=True)
class Answer:
    """What became of a submission, or of a lease whose renewal was refused."""

    item: WorkItemId
    outcome: Accepted | Duplicate | Stale

    def __post_init__(self) -> None:
        _require(self.item, (WorkItemId,), "Answer.item")
        _require(self.outcome, (Accepted, Duplicate, Stale), "Answer.outcome")


#: The four messages that SETTLE a bound lease. A worker sends one of these
#: per item and no more, and the loop routes every one of them through
#: `Settler.settle`; the rest of `Message` is traffic, not an outcome.
Submission = Completed | AttemptFailed | CompletionFailed | Escaped

Message = (
    Pull
    | Heartbeat
    | Goodbye
    | Completed
    | AttemptFailed
    | CompletionFailed
    | Escaped
    | Work
    | Answer
)

MESSAGE_TYPES: tuple[type, ...] = (
    Pull,
    Heartbeat,
    Goodbye,
    Completed,
    AttemptFailed,
    CompletionFailed,
    Escaped,
    Work,
    Answer,
)


@dataclass(frozen=True, slots=True)
class StepOverrun:
    """A blocking loop step that ran past `lease // 4` broker-seconds.

    Ephemeral: kept on the dispatcher for the life of the drive, never written
    to the stream or the work table (D10 rule 3).
    """

    step: str
    seconds: int


__all__ = [
    "WORKER_DISCONNECTED",
    "WORKER_INTERRUPTED",
    "Accepted",
    "Answer",
    "AttemptFailed",
    "Completed",
    "CompletionFailed",
    "Escaped",
    "EvaluationCall",
    "Goodbye",
    "Heartbeat",
    "MESSAGE_TYPES",
    "Message",
    "ProposalCall",
    "Pull",
    "StepOverrun",
    "TransportFailure",
    "Work",
]
