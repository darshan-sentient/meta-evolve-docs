"""Unit-of-work commit strategies backing ``Storage.commit``.

Four strategies exist, selected once at ``Storage`` construction time (never
by runtime code inspecting concrete adapter types — see ``Storage.is_durable``
and ``Storage.is_read_only`` in ``storage.py``):

- :class:`InMemoryUnitOfWork` — a locked, copy-on-write commit over the
  paired in-memory stores. Used by ``Storage.in_memory()``.
- :class:`DurableUnitOfWork` — one SQLite transaction spanning occurrence
  rows and events, with content-addressed blobs written (and fsynced)
  first. Used by ``Storage.durable(...)``.
- :class:`LocalOnlyUnitOfWork` — the fallback for a hand-built
  ``Storage(artifact_store, event_store)`` pair with no real transactional
  seam: an up-front version check, then put-then-append. This gives **no**
  cross-store atomicity guarantee across a crash between the two writes.
- :class:`ReadOnlyUnitOfWork` — a capability boundary which has durable read
  access but refuses commit authority. Used by ``Storage.read_only(...)``.

On length: past the ~300 guideline, and deliberately not split. The four
strategies are one decision table -- which storage may commit what, and
with what atomicity -- and every one of them is defined against the
others: `LocalOnlyUnitOfWork` refuses work rows because it has no
transaction, and that sentence only means anything beside
`DurableUnitOfWork`, which does.
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Iterable
from typing import Protocol

from meta_evolve.adapters.filesystem import DurableArtifactStore
from meta_evolve.adapters.memory import InMemoryArtifactStore, InMemoryEventStore
from meta_evolve.adapters.sqlite.connection import transaction
from meta_evolve.adapters.sqlite.event_store import SqliteEventStore
from meta_evolve.adapters.sqlite.occurrences import _put_occurrence_in_txn
from meta_evolve.adapters.sqlite.work_intents import apply_intent_in_txn
from meta_evolve.domain import Artifact, EventEnvelope, RunId
from meta_evolve.ports.work_store import refuse_multiple_acceptances, WorkBroker, WorkIntent
from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.domain.work import DEFAULT_LEASE_SECONDS
from meta_evolve.errors import CapabilityError
from meta_evolve.ports import ArtifactStore, EventStore, EventStreamConflict


class CommitStrategy(Protocol):
    """What `Storage` commits through.

    Both optional parameters are declared because `Storage` may pass either.
    Neither is required of an implementer. `Storage` decides from the signature
    what it may hand over and refuses rather than guessing, so a strategy
    declaring neither is a perfectly good local one.
    """

    is_durable: bool

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
        work: Iterable[WorkIntent] = (),
        event_store: object | None = None,
    ) -> int: ...

    def can_bind(self, event_store: object) -> str | None:
        """Why ``event_store`` cannot receive this strategy's writes, or None.

        Asked of the strategy, because only it knows what it calls: an explicit
        capability, as `is_durable` is, rather than an inference about a store.
        """
        ...


class ReadOnlyUnitOfWork:
    """Durable inspection handle with no commit authority."""

    is_durable = True
    is_read_only = True

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
        work: Iterable[WorkIntent] = (),
        # Declared, not honoured: `storage.py` types `_commit_strategy` as
        # `CommitStrategy | None` and assigns this class to it, so a signature
        # narrower than the Protocol's is an implementer that cannot accept
        # every call the Protocol permits. It refuses before reading anything.
        event_store: object | None = None,
    ) -> int:
        raise CapabilityError("read-only storage cannot commit")

    def can_bind(self, event_store: object) -> str | None:
        """Never: this strategy refuses to commit at all, bound or not."""

        return "read-only storage cannot commit, so it cannot bind a store"


class InMemoryUnitOfWork:
    """A locked copy-on-write commit over the paired in-memory stores.

    Under one lock, validates *all* events (contiguity, run scope, type) and
    *all* occurrence conflicts (including within the batch itself) against
    snapshots of both stores; only if everything validates does it swap in
    the new state -- artifacts, then the stream. A commit that raises its own
    error changed nothing: a stream install failure restores the stream,
    re-reads it, then restores the artifacts. If the stream is not back to its
    snapshot, the commit raises a group, no event references a missing
    artifact, and the storage refuses every later commit. Two concurrent commits
    never interleave: the lock fully serializes them, so the loser always
    re-validates against the winner's already-installed state.
    """

    is_durable = False

    def __init__(self, artifacts: InMemoryArtifactStore, events: InMemoryEventStore) -> None:
        self._artifacts = artifacts
        self._events = events
        self._lock = threading.Lock()
        self._torn: BaseException | None = None

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
        work: Iterable[WorkIntent] = (),
        event_store=None,
    ) -> int:
        """``event_store`` overrides the reference captured at construction.

        A bound store must forward `_snapshot`/`_validate`/`_install`, and its
        `_install` must accept its own snapshot back: that is how a failed
        install is rolled back. If it cannot, the commit raises a group and
        keeps its artifacts as unreferenced orphans.
        """

        stream = event_store if event_store is not None else self._events
        events = tuple(events)
        occurrences = tuple(occurrences)
        # Refused because nothing in production can hand this class work: a
        # distributed run requires durable storage, so the only caller would be
        # a test driving `Storage.commit(work=...)` directly.
        if tuple(work):
            raise CapabilityError(
                f"{type(self).__name__} cannot commit work rows: nothing in a "
                "distributed run can reach it, because distributed runs "
                "require Storage.durable(...)"
            )
        with self._lock:
            if self._torn is not None:
                raise CapabilityError(
                    "this in-memory storage refuses commits after a failed rollback "
                    "left its stores possibly disagreeing"
                ) from self._torn
            artifact_snapshot = self._artifacts._snapshot()
            event_snapshot = stream._snapshot()

            # Validate everything before mutating anything.
            new_artifacts = self._artifacts._validate(artifact_snapshot, occurrences)
            new_stream = stream._validate(
                event_snapshot, run_id, expected_version, events
            )

            # Only now, with both batches fully valid, swap in new state --
            # ARTIFACTS FIRST, into the store this strategy owns, whose install
            # is a reference swap. The stream may be a bound third-party store
            # that fails before OR after delegating, so the invariant kept on
            # every path is that no event references an artifact that is not
            # installed: artifacts are rolled back only once the stream is.
            new_streams = dict(event_snapshot)
            new_streams[run_id] = new_stream
            self._artifacts._install(new_artifacts)
            try:
                stream._install(new_streams)
            except BaseException as error:
                rollback_errors: list[BaseException] = []
                try:
                    stream._install(event_snapshot)
                except BaseException as raised:
                    rollback_errors.append(raised)
                # Re-read either way: a bound store can raise from a restore that
                # took effect, or return from one that did not.
                try:
                    restored = stream._snapshot() == event_snapshot
                except BaseException as raised:
                    restored = False
                    rollback_errors.append(raised)
                if not restored:
                    # The stream may still hold the new events, so its artifacts
                    # stay -- at worst unreferenced orphans -- and the storage
                    # latches: no later commit runs against stores that may
                    # disagree.
                    self._torn = BaseExceptionGroup(
                        "commit failed and restoring the event stream failed; "
                        "the event and artifact stores may disagree, but no "
                        "event references a missing artifact",
                        [
                            error,
                            *(
                                rollback_errors
                                or [RuntimeError("the event stream restore did not take effect")]
                            ),
                        ],
                    )
                    raise self._torn from error
                # The stores agree again. Nothing a third-party exception does
                # runs before this, so none of it can skip the rollback.
                self._artifacts._install(artifact_snapshot)
                for raised in rollback_errors:
                    # An interrupt outranks the install error it interrupted.
                    if not isinstance(raised, Exception):
                        raise raised from error
                if rollback_errors:
                    try:
                        error.add_note(
                            "restoring the event stream raised "
                            f"{type(rollback_errors[0]).__name__} after it took effect"
                        )
                    except Exception:
                        pass  # a note is diagnostic; the rollback already happened
                raise
            return len(new_stream)

    def can_bind(self, event_store: object) -> str | None:
        """A bound store must forward the snapshot/validate/install triple."""

        missing = [
            name
            for name in ("_snapshot", "_validate", "_install")
            if not callable(getattr(event_store, name, None))
        ]
        if missing:
            return (
                f"{type(event_store).__name__} does not forward "
                f"{', '.join(missing)}, which this strategy writes through"
            )
        return None


class DurableUnitOfWork:
    """All-or-none commit over a shared SQLite connection plus content-
    addressed payload blobs.

    Blobs are written and fsynced *before* the transaction opens; a blob
    written for a batch whose occurrence row never commits is an allowed
    orphan (blobs are content-addressed and never migrated in place, so an
    orphan is inert, not corrupt). Occurrence rows and the event batch then
    commit together in one transaction via the same private,
    no-transaction helpers the standalone ``put``/``append`` use —
    ``Storage.commit`` never calls the public ``append`` (no nested
    ``BEGIN``).
    """

    is_durable = True

    def __init__(
        self,
        connection: sqlite3.Connection,
        artifacts: DurableArtifactStore,
        events: SqliteEventStore,
    ) -> None:
        self._conn = connection
        self._artifacts = artifacts
        self._events = events

    def work_broker(
        self, *, lease_seconds: int = DEFAULT_LEASE_SECONDS
    ) -> WorkBroker:
        """This strategy's work table — the `WorkTransactor` capability.

        A method, so a caller can ask `isinstance(strategy, WorkTransactor)`.

        The SQLite import is deferred to keep module import order unchanged.
        """

        from meta_evolve.adapters.sqlite.work_broker import SqliteWorkBroker

        return SqliteWorkBroker(self._conn, lease_seconds=lease_seconds)

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
        work: Iterable[WorkIntent] = (),
        event_store=None,
    ) -> int:
        """``event_store`` overrides the reference captured at construction.

        Only `Storage.compose(bind_event_store=True)` passes it, and `compose`
        refuses a strategy that cannot accept it -- so a caller who wraps an
        event store to observe WRITES gets the wrapper here, rather than the
        store this strategy happened to be built with. Defaulted, so every
        existing caller is unaffected.

        The wrapper must forward `_append_in_txn`: that is the method this
        commit calls, documented in the adapters as the integration surface with
        `Storage` rather than as part of the `EventStore` port. An `EventStore`
        alone sees reads and misses every write.
        """

        events = tuple(events)
        occurrences = tuple(occurrences)
        # `work` is read twice (the acceptance guard, then the apply loop), so a
        # generator must be materialised or the loop would apply nothing.
        work = tuple(work)
        for artifact in occurrences:
            self._artifacts.blob_store.put(
                artifact.digest, canonical_payload_bytes(artifact.payload)
            )
        refuse_multiple_acceptances(run_id, work)
        with transaction(self._conn):
            for artifact in occurrences:
                _put_occurrence_in_txn(self._conn, artifact)
            # The append goes FIRST because it is what carries the
            # optimistic-concurrency check, and the two refusals mean opposite
            # things: `EventStreamConflict` is "re-read and retry",
            # `InvalidWorkAppend` is "this intent is illegal". A commit that is
            # both stale and carrying a conflicting intent -- a dispatcher
            # resubmitting a cohort after an ambiguous commit is precisely that
            # caller -- must get the retriable answer. Applying work first gave
            # the intent rules the first word and the conflict was never
            # reached.
            appender = event_store if event_store is not None else self._events
            version = appender._append_in_txn(run_id, expected_version, events)
            # Inside the same transaction as the append, so a rejected intent
            # rolls the events back with it. `DuplicateCompletion` propagates:
            # it is an answer for the caller that submitted the duplicate, and
            # swallowing it would report success over a rolled-back batch.
            for intent in work:
                apply_intent_in_txn(self._conn, intent, run_id=run_id)
            return version

    def can_bind(self, event_store: object) -> str | None:
        """Forwards `_append_in_txn`, AND shares this strategy's connection.

        The connection is the load-bearing half. `_append_in_txn` runs inside
        `with transaction(self._conn)`, so a store backed by a DIFFERENT
        connection is outside that transaction entirely: its rows can persist
        while the commit raises and everything else rolls back.
        """

        if not callable(getattr(event_store, "_append_in_txn", None)):
            return (
                f"{type(event_store).__name__} does not forward "
                "_append_in_txn, which this strategy writes through"
            )
        conn = getattr(event_store, "_conn", None)
        if conn is not self._conn:
            return (
                f"{type(event_store).__name__} is backed by a different SQLite "
                "connection, so its writes would fall outside the transaction "
                "this strategy commits in -- they could persist while the "
                "commit rolls back"
            )
        return None


class LocalOnlyUnitOfWork:
    """Fallback commit for a hand-built ``Storage(artifact_store,
    event_store)`` pair without a real transactional unit of work: an
    up-front version check, then put-then-append. **Local-only** — gives no
    cross-store atomicity guarantee across a crash between the two writes.
    Durable-local atomicity requires ``Storage.durable(...)``.

    Tearing is bounded and inert. A crash/failure *between* the occurrence
    ``put`` and the event ``append`` can leave occurrence rows written whose
    referencing ``ArtifactCreated`` event never committed — an UNREFERENCED
    occurrence orphan, exactly analogous to the documented blob orphans of the
    durable unit of work. It is inert: every read path resolves an occurrence
    by ``artifact_id`` (``ArtifactStore.get``), and the resume-time integrity
    walk (``check_artifact_references``) only visits ids ENUMERATED FROM THE
    EVENT STREAM (the seed, each ``ArtifactCreated``, and their transitive
    ``parent_ids``) — nothing enumerates the occurrence table, so an orphan
    with no referencing event is never looked up. A re-run recreates the same
    ``stable_id``-derived occurrence, so the write is idempotent (no conflict).
    This inertness holds only BECAUSE such a pair is ``is_durable=False``
    (``Storage`` enforces the coherence invariant) and ``resume`` requires
    ``is_durable`` storage — so the non-atomic seam is never on a
    resume/recovery path. A hand-built pair structurally CANNOT be made atomic
    across two independent stores; durable-local therefore requires
    ``Storage.durable(...)`` (one SQLite transaction spanning both writes).
    """

    is_durable = False

    def __init__(self, artifacts: ArtifactStore, events: EventStore) -> None:
        self._artifacts = artifacts
        self._events = events

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
        work: Iterable[WorkIntent] = (),
        # Port-only binding: the read and the append go to this store. There is
        # no cross-store atomicity to extend, and none is promised.
        event_store: object | None = None,
    ) -> int:
        # Refused because this class has no atomic unit: a work row committed
        # here could survive a crash that lost the events authorising it, and a
        # broker would then lease work for a run that does not exist.
        if tuple(work):
            raise CapabilityError(
                f"{type(self).__name__} cannot commit work rows: it has no "
                "single transaction to put them in; distributed runs require "
                "Storage.durable(...)"
            )
        # Both the read and the append go to the bound stream, or the version
        # check guards a store the write never reaches.
        stream = event_store if event_store is not None else self._events
        events = tuple(events)
        actual_version = len(stream.read(run_id))
        if expected_version != actual_version:
            raise EventStreamConflict(run_id, expected_version, actual_version)
        for artifact in occurrences:
            self._artifacts.put(artifact)
        return stream.append(run_id, expected_version, events)

    def can_bind(self, event_store: object) -> str | None:
        """Writes through the PORT only, so any `EventStore` will do."""

        missing = [
            name
            for name in ("read", "append")
            if not callable(getattr(event_store, name, None))
        ]
        if missing:
            return (
                f"{type(event_store).__name__} does not implement "
                f"{', '.join(missing)}"
            )
        return None
