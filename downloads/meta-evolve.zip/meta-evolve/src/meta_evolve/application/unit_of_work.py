"""Unit-of-work commit strategies backing ``Storage.commit``.

Four strategies exist, selected once at ``Storage`` construction time (never
by runtime code inspecting concrete adapter types — see ``Storage.is_durable``
and ``Storage.is_read_only`` in ``storage.py``):

- :class:`InMemoryUnitOfWork` — a locked, copy-on-write commit over the
  paired in-memory stores. Used by ``Storage.in_memory()``.
- :class:`DurableUnitOfWork` — one SQLite transaction spanning occurrence
  rows and events, with content-addressed blobs written (and fsynced)
  first. Used by ``Storage.durable(...)``.
- :class:`LocalOnlyUnitOfWork` — the fallback for a hand-built
  ``Storage(artifact_store, event_store)`` pair with no real transactional
  seam: an up-front version check, then put-then-append. This gives **no**
  cross-store atomicity guarantee across a crash between the two writes.
- :class:`ReadOnlyUnitOfWork` — a capability boundary which has durable read
  access but refuses commit authority. Used by ``Storage.read_only(...)``.
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Iterable
from pathlib import Path
from typing import Protocol

from meta_evolve.adapters.filesystem import DurableArtifactStore
from meta_evolve.adapters.memory import InMemoryArtifactStore, InMemoryEventStore
from meta_evolve.adapters.sqlite.connection import transaction
from meta_evolve.adapters.sqlite.event_store import SqliteEventStore
from meta_evolve.adapters.sqlite.occurrences import _put_occurrence_in_txn
from meta_evolve.domain import Artifact, EventEnvelope, RunId
from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.errors import CapabilityError
from meta_evolve.ports import ArtifactStore, EventStore, EventStreamConflict


class CommitStrategy(Protocol):
    is_durable: bool

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
    ) -> int: ...


class ReadOnlyUnitOfWork:
    """Durable inspection handle with no commit authority."""

    is_durable = True
    is_read_only = True

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
    ) -> int:
        raise CapabilityError("read-only storage cannot commit")


class InMemoryUnitOfWork:
    """A locked copy-on-write commit over the paired in-memory stores.

    Under one lock, validates *all* events (contiguity, run scope, type) and
    *all* occurrence conflicts (including within the batch itself) against
    snapshots of both stores; only if everything validates does it swap in
    the new state for both stores together. Two concurrent commits never
    interleave: the lock fully serializes them, so the loser always
    re-validates against the winner's already-installed state.
    """

    is_durable = False

    def __init__(self, artifacts: InMemoryArtifactStore, events: InMemoryEventStore) -> None:
        self._artifacts = artifacts
        self._events = events
        self._lock = threading.Lock()

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
    ) -> int:
        events = tuple(events)
        occurrences = tuple(occurrences)
        with self._lock:
            artifact_snapshot = self._artifacts._snapshot()
            event_snapshot = self._events._snapshot()

            # Validate everything before mutating anything.
            new_artifacts = self._artifacts._validate(artifact_snapshot, occurrences)
            new_stream = self._events._validate(
                event_snapshot, run_id, expected_version, events
            )

            # Only now, with both batches fully valid, swap in new state.
            self._artifacts._install(new_artifacts)
            new_streams = dict(event_snapshot)
            new_streams[run_id] = new_stream
            self._events._install(new_streams)
            return len(new_stream)


class DurableUnitOfWork:
    """All-or-none commit over a shared SQLite connection plus content-
    addressed payload blobs.

    Blobs are written and fsynced *before* the transaction opens; a blob
    written for a batch whose occurrence row never commits is an allowed
    orphan (blobs are content-addressed and never migrated in place, so an
    orphan is inert, not corrupt). Occurrence rows and the event batch then
    commit together in one transaction via the same private,
    no-transaction helpers the standalone ``put``/``append`` use —
    ``Storage.commit`` never calls the public ``append`` (no nested
    ``BEGIN``).
    """

    is_durable = True

    def __init__(
        self,
        connection: sqlite3.Connection,
        artifacts: DurableArtifactStore,
        events: SqliteEventStore,
    ) -> None:
        self._conn = connection
        self._artifacts = artifacts
        self._events = events

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
    ) -> int:
        events = tuple(events)
        occurrences = tuple(occurrences)
        for artifact in occurrences:
            self._artifacts.blob_store.put(
                artifact.digest, canonical_payload_bytes(artifact.payload)
            )
        with transaction(self._conn):
            for artifact in occurrences:
                _put_occurrence_in_txn(self._conn, artifact)
            return self._events._append_in_txn(run_id, expected_version, events)


class LocalOnlyUnitOfWork:
    """Fallback commit for a hand-built ``Storage(artifact_store,
    event_store)`` pair without a real transactional unit of work: an
    up-front version check, then put-then-append. **Local-only** — gives no
    cross-store atomicity guarantee across a crash between the two writes.
    Durable-local atomicity requires ``Storage.durable(...)``.

    Tearing is bounded and inert. A crash/failure *between* the occurrence
    ``put`` and the event ``append`` can leave occurrence rows written whose
    referencing ``ArtifactCreated`` event never committed — an UNREFERENCED
    occurrence orphan, exactly analogous to the documented blob orphans of the
    durable unit of work. It is inert: every read path resolves an occurrence
    by ``artifact_id`` (``ArtifactStore.get``), and the resume-time integrity
    walk (``check_artifact_references``) only visits ids ENUMERATED FROM THE
    EVENT STREAM (the seed, each ``ArtifactCreated``, and their transitive
    ``parent_ids``) — nothing enumerates the occurrence table, so an orphan
    with no referencing event is never looked up. A re-run recreates the same
    ``stable_id``-derived occurrence, so the write is idempotent (no conflict).
    This inertness holds only BECAUSE such a pair is ``is_durable=False``
    (``Storage`` enforces the coherence invariant) and ``resume`` requires
    ``is_durable`` storage — so the non-atomic seam is never on a
    resume/recovery path. A hand-built pair structurally CANNOT be made atomic
    across two independent stores; durable-local therefore requires
    ``Storage.durable(...)`` (one SQLite transaction spanning both writes).
    """

    is_durable = False

    def __init__(self, artifacts: ArtifactStore, events: EventStore) -> None:
        self._artifacts = artifacts
        self._events = events

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
    ) -> int:
        events = tuple(events)
        actual_version = len(self._events.read(run_id))
        if expected_version != actual_version:
            raise EventStreamConflict(run_id, expected_version, actual_version)
        for artifact in occurrences:
            self._artifacts.put(artifact)
        return self._events.append(run_id, expected_version, events)
