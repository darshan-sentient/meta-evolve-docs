"""Shared normalization, identity, and driving for run creation and resume."""

from __future__ import annotations

from collections.abc import Callable
from hashlib import sha256
from typing import Literal, TypeAlias

from meta_evolve import serialization
from meta_evolve.adapters import (
    CallableEvaluator,
    CallableProposer,
    DecodedValueProposerRunner,
)
from meta_evolve.domain import (
    Artifact,
    ArtifactId,
    Budget,
    ComponentRef,
    ContextSpec,
    ExperienceSpec,
    Objective,
    PolicyRef,
    RunId,
    Task,
)
from meta_evolve.errors import CapabilityError
from meta_evolve.policies.context import ContextPolicy, NoMemory
from meta_evolve.ports.callables import Evaluator, Proposer
from meta_evolve.ports.experience import ExperienceAccess
from meta_evolve.ports.runners import ProposerRunner, validate_run_hook
from meta_evolve.registry import Registry

from .codecs import CodecIndex


ProposerLike: TypeAlias = (
    ComponentRef
    | Callable[[object], object]
    | Callable[[object, object], object]
    | Proposer
    | ProposerRunner
)
ExecutionMode: TypeAlias = Literal["local", "durable-local", "distributed"]
EXECUTION_MODES = ("local", "durable-local", "distributed")
_MISSING = object()


def _decoded_runner(
    adapter: CallableProposer, codecs: CodecIndex
) -> tuple[ProposerRunner, ComponentRef]:
    runner = DecodedValueProposerRunner(adapter, adapter.component, codecs)
    return runner, adapter.component


def _declared_proposer_ref(value: object) -> ComponentRef:
    declared = getattr(value, "component", _MISSING)
    if declared is _MISSING:
        return ComponentRef.local_proposer(value)
    if (
        not isinstance(declared, ComponentRef)
        or declared.role != "proposer"
        or declared.origin != "local"
        or declared.adapter is not value
    ):
        raise TypeError(
            "declared proposer component must be a local proposer ComponentRef "
            "retaining that proposer"
        )
    return declared


def component_proposer(
    value: ProposerLike, codecs: CodecIndex
) -> tuple[ProposerRunner, ComponentRef]:
    """Resolve any accepted proposer form without invoking run validation.

    An object providing ``execute`` and a proposer ``component`` is used as a
    runner directly, even if it also defines ``propose``. Below that,
    ``propose`` takes precedence over ``__call__``: an object defining both is
    driven through its structural proposer method.
    """

    execute = getattr(value, "execute", None)
    if callable(execute):
        component = getattr(value, "component", None)
        if not isinstance(component, ComponentRef) or component.role != "proposer":
            raise TypeError("proposer runner must declare a proposer component")
        # A custom runner's own ``validate_run`` is reached through
        # ``validate_proposer_run``, which rejects a non-callable hook there.
        return value, component  # type: ignore[return-value]
    if isinstance(value, CallableProposer):
        return _decoded_runner(value, codecs)
    if isinstance(value, ComponentRef):
        return _decoded_runner(CallableProposer(value), codecs)
    propose = getattr(value, "propose", None)
    if callable(propose):
        return _decoded_runner(
            CallableProposer.declared(_declared_proposer_ref(value), propose), codecs
        )
    if callable(value):
        if getattr(value, "component", _MISSING) is not _MISSING:
            return _decoded_runner(
                CallableProposer.declared(_declared_proposer_ref(value), value), codecs
            )
        return _decoded_runner(CallableProposer(value), codecs)
    raise TypeError("proposer must be callable or implement propose(parent, context)")


def resolve_registered_components(
    registry: Registry, proposer_ref: ComponentRef, task: Task, codecs: CodecIndex
) -> tuple[ProposerRunner, Evaluator]:
    proposer_fn, _ = registry.resolve_proposer(proposer_ref)
    proposer = CallableProposer.registered(proposer_ref, proposer_fn)
    runner, _ = _decoded_runner(proposer, codecs)
    evaluator_fn, _ = registry.resolve_evaluator(task.evaluator)
    evaluator = CallableEvaluator.registered(
        task.evaluator, evaluator_fn, task.objectives
    )
    return runner, evaluator


def validate_proposer_run(
    runner: ProposerRunner,
    *,
    artifact_kind: str,
    artifact_representation: str,
    objectives: tuple[Objective, ...],
    budget: Budget,
    experience: ExperienceSpec | None,
) -> None:
    """Invoke one optional proposer preflight without leaking its exception text."""

    validator = validate_run_hook(runner)
    if validator is None:
        return
    try:
        validator(
            artifact_kind=artifact_kind,
            artifact_representation=artifact_representation,
            objectives=objectives,
            budget=budget,
            experience=experience,
        )
    except CapabilityError:
        raise
    except Exception as error:
        raise CapabilityError("proposer validation failed") from error


def run_id_for(
    task: Task,
    seed: object,
    proposer: ComponentRef,
    policy: PolicyRef,
    budget: Budget,
    random_seed: int,
    search_key: str,
    context: ContextSpec | None = None,
    experience: ExperienceSpec | None = None,
    cohort_width: int = 1,
) -> RunId:
    seed_digest = Artifact(id=ArtifactId("seed"), payload=seed).digest
    values = (
        serialization.identity_content(task),
        serialization.identity_content(proposer),
        serialization.identity_content(policy),
        serialization.identity_content(budget),
        seed_digest.value if seed_digest is not None else "",
        str(random_seed),
        search_key,
    )
    payload = "|".join(values)
    if context is not None:
        payload = f"{payload}|{serialization.identity_content(context)}"
    if experience is not None:
        payload = f"{payload}|{serialization.identity_content(experience)}"
    if cohort_width > 1:
        # Contributed by the kernel, not taken from `search_key`: a conforming
        # policy supplies its identity key independently of its configuration
        # and could record a wide cohort while returning the narrow key.
        #
        # Framed as a domain-separated digest rather than appended as more text.
        # `search_key` is policy-controlled and the join is unescaped, so a bare
        # `|cohort_width=2` suffix could be impersonated by a policy whose
        # identity key simply ended in those characters -- defeating the very
        # reason the kernel contributes the width. Nesting the legacy digest
        # cannot be forged: the legacy payload always begins with serialized
        # task JSON, never this domain token.
        payload = (
            "meta-evolve/run-identity/cohort/v1"
            f"|{sha256(payload.encode()).hexdigest()}"
            f"|{cohort_width}"
        )
    # Width one appends nothing and hashes the legacy payload unchanged, so
    # every recorded run identity is where it was.
    return RunId(f"run-{sha256(payload.encode()).hexdigest()}")


def normalize_context(
    value: ContextPolicy | None,
) -> tuple[ContextPolicy | None, ContextSpec | None]:
    if value is None or isinstance(value, NoMemory):
        return None, None
    select = getattr(value, "select", None)
    policy = getattr(value, "policy", None)
    if not callable(select):
        raise TypeError("context must implement select(task, candidate, graph, spec)")
    if not isinstance(policy, PolicyRef):
        raise TypeError("context policy must declare a PolicyRef")
    return value, ContextSpec(
        policy=policy,
        max_records=getattr(value, "max_records", 20),
        max_chars=getattr(value, "max_chars", 8_000),
    )


def normalize_experience(value: ExperienceAccess | None) -> ExperienceSpec | None:
    if value is None:
        return None
    declaration = getattr(value, "experience_spec", None)
    if not callable(declaration):
        raise TypeError("experience must implement experience_spec()")
    spec = declaration()
    if not isinstance(spec, ExperienceSpec):
        raise TypeError("experience_spec() must return an ExperienceSpec")
    return spec


__all__ = [
    "EXECUTION_MODES",
    "ExecutionMode",
    "ProposerLike",
    "component_proposer",
    "normalize_context",
    "normalize_experience",
    "resolve_registered_components",
    "run_id_for",
    "validate_proposer_run",
]
