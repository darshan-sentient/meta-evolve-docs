"""When the policy may be asked: the work table hints, the stream decides.

The dispatcher asks the policy only once nothing is claimable, in
flight or reclaimable. At that moment two readings must agree before anything
is decided:

* the work table -- the HINT -- must hold no READY or LEASED row.
  A LEASED row still there is an orphan, bound to no call of this
  dispatcher, so nothing here will ever settle it: waiting would hang on an injected clock
  that never passes its deadline, and spin a clock-floor write per poll on the
  wall clock. It is refused by name instead, and a READY row no endpoint
  could claim is refused apart from it;
* the stream -- the AUTHORITY -- must owe no trial its work. The
  table empty while the stream still owes work is the two durable stores
  disagreeing, which is corruption, not a race to wait out.

`commit_cohort`'s own barrier still decides admission; these only keep the
policy from being asked on a frontier that is not really empty.
"""

from __future__ import annotations

from meta_evolve.domain.work import WorkState
from meta_evolve.errors import CapabilityError, DurableCorruption

from .disposition import outstanding_trial_ids


def refuse_an_undecidable_frontier(coordinator, broker) -> None:
    """Raise unless the table and the stream agree the frontier is empty."""

    rows = broker.rows(coordinator.run_id)
    orphans = [row for row in rows if row.state is WorkState.LEASED]
    if orphans:
        raise CapabilityError(
            "work items are leased to no call of this dispatcher, so the next "
            "generation cannot be decided: "
            + ", ".join(f"{row.item.value} (attempt {row.attempts})" for row in orphans)
            + ". Resume the run, which returns them to ready"
        )
    # Not orphans: a READY row still here is one no endpoint could claim -- a
    # slot held elsewhere, or a claim refused inside the broker. Named apart,
    # because what it needs is not the same.
    unclaimed = [row for row in rows if row.state is WorkState.READY]
    if unclaimed:
        raise CapabilityError(
            "work items are ready but no endpoint of this dispatcher could claim "
            "them, so the next generation cannot be decided: "
            + ", ".join(row.item.value for row in unclaimed)
        )
    if outstanding_trial_ids(coordinator.projection):
        raise DurableCorruption(
            "the work table and the stream disagree about outstanding work: "
            "no row is ready or leased, yet the stream owes a trial its work"
        )


__all__ = ["refuse_an_undecidable_frontier"]
