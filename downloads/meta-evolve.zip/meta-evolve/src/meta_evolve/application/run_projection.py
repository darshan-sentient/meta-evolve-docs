"""Validated kernel lifecycle records and their policy-facing view."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain.events import (
    BootstrapPrepared,
    ContextPolicyDeclared,
    ContextSelected,
    EvaluationCompleted,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    EvidenceRecorded,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    ProposalSubmitted,
    RunStarted,
    TrialCompleted,
    SourceHistoryMounted,
)
from meta_evolve.domain.identity import (
    ArtifactId,
    DecisionId,
    EvidenceId,
    EventId,
    RunId,
    TrialId,
)
from meta_evolve.domain.context import ContextRecord
from meta_evolve.domain.experience_access import ExperienceUsage
from meta_evolve.domain.search import SearchNotStarted, SearchState
from meta_evolve.domain.trial import Proposal, Stop


@dataclass(frozen=True, slots=True, kw_only=True)
class RunProjection:
    run_id: RunId
    version: int = 0
    event_ids: tuple[EventId, ...] = ()
    experience_records: tuple[ContextRecord, ...] = ()
    start: RunStarted | None = None
    bootstrap: BootstrapPrepared | None = None
    artifact_ids: tuple[ArtifactId, ...] = ()
    decisions: tuple[PolicyDecisionMade, ...] = ()
    explanations: tuple[PolicyDecisionExplained, ...] = ()
    context_declaration: ContextPolicyDeclared | None = None
    context_selections: tuple[ContextSelected, ...] = ()
    experience_declaration: ExperienceAccessDeclared | None = None
    experience_grants: tuple[ExperienceGrantIssued, ...] = ()
    experience_attempts: tuple[ExperienceOperationAttempted, ...] = ()
    experience_successes: tuple[ExperienceOperationSucceeded, ...] = ()
    experience_denials: tuple[ExperienceOperationDenied, ...] = ()
    experience_exhaustions: tuple[ExperienceOperationBudgetExhausted, ...] = ()
    source_history_mounts: tuple[SourceHistoryMounted, ...] = ()
    experience_cursor_version: int = 0
    proposals: tuple[ProposalSubmitted, ...] = ()
    evidence: tuple[EvidenceRecorded, ...] = ()
    completed_trials: tuple[TrialCompleted, ...] = ()
    completed_evaluations: tuple[EvaluationCompleted, ...] = ()

    @classmethod
    def empty(cls, run_id: RunId) -> RunProjection:
        if not isinstance(run_id, RunId):
            raise TypeError("run projection id must be a RunId")
        return cls(run_id=run_id)

    @property
    def ready(self) -> bool:
        if self.start is None or self.bootstrap is None:
            return False
        trial_id = self.bootstrap.trial.id
        return (
            self.start.seed_artifact_id in self.artifact_ids
            and self.completed_trial(trial_id) is not None
            and self.evaluation_for(trial_id) is not None
        )

    @property
    def search_state(self) -> SearchState:
        if not self.ready:
            raise SearchNotStarted(f"search run {self.run_id} is not bootstrapped")
        return SearchState(
            run_id=self.run_id,
            version=self.version,
            start=self.start,
            artifact_ids=self.artifact_ids,
            decisions=self.decisions,
            completed_trials=self.completed_trials,
            completed_evaluations=self.completed_evaluations,
        )

    @property
    def stop(self) -> Stop | None:
        if self.decisions and isinstance(self.decisions[-1].decision, Stop):
            return self.decisions[-1].decision
        return None

    def proposal_for(self, trial_id: TrialId) -> Proposal | None:
        if self.bootstrap is not None and self.bootstrap.trial.id == trial_id:
            return self.bootstrap.proposal
        return next(
            (
                item.proposal
                for item in self.proposals
                if item.proposal.trial_id == trial_id
            ),
            None,
        )

    def completed_trial(self, trial_id: TrialId) -> TrialCompleted | None:
        return next(
            (item for item in self.completed_trials if item.trial.id == trial_id),
            None,
        )

    def evaluation_for(self, trial_id: TrialId) -> EvaluationCompleted | None:
        return next(
            (
                item
                for item in self.completed_evaluations
                if item.evaluation.trial_id == trial_id
            ),
            None,
        )

    def explanation_for(
        self, decision_id: DecisionId
    ) -> PolicyDecisionExplained | None:
        return next(
            (
                item
                for item in self.explanations
                if item.decision_id == decision_id
            ),
            None,
        )

    def selection_for(self, trial_id: TrialId) -> ContextSelected | None:
        return next(
            (item for item in self.context_selections if item.trial_id == trial_id),
            None,
        )

    def context_for(self, trial_id: TrialId):
        selected = self.selection_for(trial_id)
        return selected.bundle if selected is not None else None

    def grant_for(self, trial_id: TrialId):
        issued = next(
            (item for item in self.experience_grants if item.grant.trial_id == trial_id),
            None,
        )
        return issued.grant if issued is not None else None

    def resolution_for(self, operation_id):
        return next(
            (
                item
                for item in (
                    *self.experience_successes,
                    *self.experience_denials,
                    *self.experience_exhaustions,
                )
                if item.operation_id == operation_id
            ),
            None,
        )

    def operations_for(self, trial_id: TrialId):
        return tuple(
            (
                attempt,
                self.resolution_for(attempt.operation_id),
            )
            for attempt in self.experience_attempts
            if attempt.trial_id == trial_id
        )

    def source_history_for(self, trial_id: TrialId) -> SourceHistoryMounted | None:
        return next(
            (item for item in self.source_history_mounts if item.trial_id == trial_id),
            None,
        )

    def experience_usage_for(self, trial_id: TrialId) -> ExperienceUsage:
        operations = self.operations_for(trial_id)
        if not operations:
            return ExperienceUsage()
        resolution = operations[-1][1]
        if resolution is None:
            return operations[-1][0].usage
        result = getattr(resolution, "result", None)
        return result.usage if result is not None else resolution.usage

    def evidence_by_id(self, evidence_id: EvidenceId):
        return next(
            (
                item.evidence
                for item in self.evidence
                if item.evidence.id == evidence_id
            ),
            None,
        )


__all__ = ["RunProjection"]
