"""One commitment path for trial, archive, and stop decisions."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Protocol

from meta_evolve.domain import (
    ArchiveUpdate,
    Artifact,
    ComponentRef,
    CorrelationId,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    SearchDecision,
    SearchProgram,
    SearchSpec,
    SearchState,
    Stop,
    TaskId,
    Trial,
    TrialId,
    TrialSpec,
    Usage,
)
from meta_evolve.domain import spend
from meta_evolve.domain.decision_description import DecisionDescription, humanize_reason
from meta_evolve.errors import BudgetUnavailable, InvalidDecision

from .archive_transitions import archive_transition_error
from .identities import stable_id
from .run_projection import RunProjection
from .work import has_zero_resource


class DecisionHost(Protocol):
    search: SearchSpec
    task_id: TaskId
    proposer_ref: ComponentRef

    @property
    def projection(self) -> RunProjection: ...

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        occurrences: Sequence[Artifact] = (),
        correlation: CorrelationId,
    ) -> RunProjection: ...


@dataclass(frozen=True, slots=True)
class CommittedDecision:
    record: PolicyDecisionMade
    trial: Trial | None


def _fallback_description(decision: SearchDecision) -> DecisionDescription:
    if isinstance(decision, TrialSpec):
        return DecisionDescription("execute the next bounded trial", ("trial",))
    if isinstance(decision, Stop):
        return DecisionDescription(humanize_reason(decision.reason))
    transition = "admit" if decision.admitted else "reject"
    return DecisionDescription(f"{transition} evaluated candidate")


def _description(
    program: SearchProgram, state: SearchState, decision: SearchDecision
) -> DecisionDescription:
    describe = getattr(program, "describe_decision", None)
    if describe is None:
        return _fallback_description(decision)
    if not callable(describe):
        raise TypeError("search describe_decision capability must be callable")
    result = describe(state, decision)
    if not isinstance(result, DecisionDescription):
        raise TypeError("describe_decision must return a DecisionDescription")
    return result


def commit_decision(
    host: DecisionHost,
    program: SearchProgram,
    decision: SearchDecision,
) -> CommittedDecision:
    if not isinstance(decision, (TrialSpec, ArchiveUpdate, Stop)):
        raise InvalidDecision("search returned an unsupported decision")
    projection = host.projection
    state = projection.search_state
    if isinstance(decision, TrialSpec):
        _validate_trial(host, state, decision)
    description = _description(program, state, decision)
    seeds = {
        name: state.randomness.seed(name) for name in description.random_streams
    }
    if isinstance(decision, TrialSpec) and seeds.get("trial") != decision.random_seed:
        raise InvalidDecision(
            "trial decision must declare and use the named trial random stream"
        )
    if isinstance(decision, ArchiveUpdate):
        error = archive_transition_error(projection, decision)
        if error is not None:
            raise InvalidDecision(error)

    decision_id = state.next_decision_id
    trial_id = (
        stable_id(TrialId, "trial", decision_id.value)
        if isinstance(decision, TrialSpec)
        else None
    )
    record = PolicyDecisionMade(
        decision_id=decision_id,
        logical_step=state.next_logical_step,
        observed_version=state.version,
        policy=host.search.policy,
        decision=decision,
        trial_id=trial_id,
        random_seeds=seeds,
    )
    # Reconstruct the authorized trial from the record so this live path and
    # resume's TRIAL_DECIDED recovery build byte-identical Trials.
    trial = (
        Trial.from_decision_record(record, state.run_id)
        if trial_id is not None
        else None
    )
    correlation_owner = trial_id.value if trial_id is not None else decision_id.value
    correlation = stable_id(CorrelationId, "correlation", correlation_owner)
    host.commit_batch(
        [
            record,
            PolicyDecisionExplained(
                decision_id=decision_id,
                rationale=description.rationale,
            ),
        ],
        correlation=correlation,
    )
    return CommittedDecision(record=record, trial=trial)


def _validate_trial(
    host: DecisionHost, state: SearchState, spec: TrialSpec
) -> None:
    if spec.task_id != host.task_id:
        raise InvalidDecision("trial belongs to another task")
    if spec.proposer != host.proposer_ref:
        raise InvalidDecision("trial selected an unauthorized proposer")
    if len(spec.parent_ids) != 1 or any(
        parent not in state.artifact_ids for parent in spec.parent_ids
    ):
        raise InvalidDecision("M1 trials require one committed parent")
    required = Usage(trials=1, evaluations=1)
    remaining = state.remaining_budget
    # Hoisted, and handed the folds it would otherwise redo: `state.spend_blocked`
    # recomputes `remaining_budget` and `usage` internally, and the reason line
    # below asked for the whole predicate a second time.
    spend_stopped = spend.blocked(state, remaining=remaining, charged=state.usage)
    if (
        not remaining.allows(required)
        or not spec.budget.allows(required)
        or spec.budget.narrow(remaining) != spec.budget
        or has_zero_resource(spec.budget, evaluation=True)
        or spend_stopped
    ):
        reason = "spend ceiling reached" if spend_stopped else "budget"
        raise BudgetUnavailable(
            f"trial cannot fit within its effective budget ({reason})"
        )


__all__ = ["CommittedDecision", "commit_decision"]
