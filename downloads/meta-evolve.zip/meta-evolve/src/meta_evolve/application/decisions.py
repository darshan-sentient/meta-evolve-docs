"""One commitment path for trial, archive, and stop decisions."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Protocol

from meta_evolve.domain import (
    ArchiveUpdate,
    ComponentRef,
    CorrelationId,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    RunCapabilities,
    RunId,
    SearchDecision,
    SearchProgram,
    SearchSpec,
    SearchState,
    Stop,
    TaskId,
    Trial,
    TrialId,
    TrialSpec,
    Usage,
)
from meta_evolve.domain import spend
from meta_evolve.domain.decision_description import DecisionDescription, humanize_reason
from meta_evolve.errors import BudgetUnavailable, InvalidDecision

from .hosts import CommitBatchHost
from .archive_transitions import archive_transition_error
from .disposition import less_reserved, reserved_usage, trial_allocation
from .identities import stable_id
from .run_projection import RunProjection
from .work import has_zero_resource, proposal_enqueues


class DecisionHost(CommitBatchHost, Protocol):
    """What this module needs of a coordinator, and now all of it.

    `run_id`, `capabilities` and `commit_batch`'s `work` were used by
    `commit_cohort` and `_proposal_enqueues` without being declared, so an
    object satisfying this Protocol as written would fail at runtime -- the
    contract described less than the module required. Each is declared exactly
    as `BootstrapHost` declares it (`bootstrap.py`), which makes this a strict
    subset of that Protocol rather than a new shape.
    """

    run_id: RunId
    search: SearchSpec
    task_id: TaskId
    proposer_ref: ComponentRef
    capabilities: RunCapabilities

    @property
    def projection(self) -> RunProjection: ...


@dataclass(frozen=True, slots=True)
class CommittedDecision:
    record: PolicyDecisionMade
    trial: Trial | None


def _fallback_description(decision: SearchDecision) -> DecisionDescription:
    if isinstance(decision, TrialSpec):
        return DecisionDescription("execute the next bounded trial", ("trial",))
    if isinstance(decision, Stop):
        return DecisionDescription(humanize_reason(decision.reason))
    transition = "admit" if decision.admitted else "reject"
    return DecisionDescription(f"{transition} evaluated candidate")


def _description(
    program: SearchProgram, state: SearchState, decision: SearchDecision
) -> DecisionDescription:
    describe = getattr(program, "describe_decision", None)
    if describe is None:
        return _fallback_description(decision)
    if not callable(describe):
        raise TypeError("search describe_decision capability must be callable")
    result = describe(state, decision)
    if not isinstance(result, DecisionDescription):
        raise TypeError("describe_decision must return a DecisionDescription")
    return result


def commit_decision(
    host: DecisionHost,
    program: SearchProgram,
    decision: SearchDecision,
) -> CommittedDecision:
    """Commit one decision -- the cohort of one.

    Every production run takes this path, so the cohort writer below is not
    test-only machinery: it is the same code, exercised at width one on every
    step, which is what makes the wide case something more than a self-fed
    double.
    """

    return commit_cohort(host, program, (decision,))[0]


def commit_cohort(
    host: DecisionHost,
    program: SearchProgram,
    members: Sequence[SearchDecision],
) -> tuple[CommittedDecision, ...]:
    """Commit a generation of decisions as one atomic batch.

    Every member is produced from the *same* committed state -- that is what
    makes them a generation -- so each derives its identity, logical step and
    randomness from that base plus its own ordinal. What each member *records*
    as its observed version is its own head, `base + 2i`, because a decision
    batch is two events per member and every recorded field must stay true; the
    base it actually read is carried separately by `cohort_base`, and only from
    the second member on, where the two differ.

    Admission is cumulative: member *i* is validated against capacity the
    earlier members have already claimed but not yet committed, which no fold
    over committed facts can see.
    """

    if not members:
        raise InvalidDecision("a cohort must contain at least one decision")
    projection = host.projection
    state = projection.search_state
    base_version = state.version
    base_step = state.next_logical_step

    bodies: list[object] = []
    committed: list[CommittedDecision] = []
    claimed = Usage()
    for ordinal, decision in enumerate(members):
        if not isinstance(decision, (TrialSpec, ArchiveUpdate, Stop)):
            raise InvalidDecision("search returned an unsupported decision")
        # Keyed on the batch, not the position, so this is exactly
        # `consume_cohort`'s rule: above one member every decision must be a
        # trial. Testing `ordinal` instead let a LEADING stop through, and the
        # batch then failed deep in the fold on "facts cannot follow a committed
        # Stop" -- a true statement about the wrong thing, naming the sibling
        # rather than the composition that was never allowed to be written.
        if len(members) > 1 and not isinstance(decision, TrialSpec):
            raise InvalidDecision("only trial decisions can join a cohort")
        if isinstance(decision, TrialSpec):
            _validate_trial(host, state, decision, extra_reserved=claimed)
        description = _description(program, state, decision)
        randomness = state.member_randomness(ordinal)
        seeds = {name: randomness.seed(name) for name in description.random_streams}
        if (
            isinstance(decision, TrialSpec)
            and seeds.get("trial") != decision.random_seed
        ):
            raise InvalidDecision(
                "trial decision must declare and use the named trial random stream"
            )
        if isinstance(decision, ArchiveUpdate):
            error = archive_transition_error(projection, decision)
            if error is not None:
                raise InvalidDecision(error)

        decision_id = randomness.decision_id
        trial_id = (
            stable_id(TrialId, "trial", decision_id.value)
            if isinstance(decision, TrialSpec)
            else None
        )
        record = PolicyDecisionMade(
            decision_id=decision_id,
            logical_step=base_step + ordinal,
            observed_version=base_version + 2 * ordinal,
            policy=host.search.policy,
            decision=decision,
            trial_id=trial_id,
            random_seeds=seeds,
            cohort_base=None if ordinal == 0 else base_version,
        )
        # Reconstruct the authorized trial from the record so this live path and
        # resume's TRIAL_DECIDED recovery build byte-identical Trials.
        trial = (
            Trial.from_decision_record(record, state.run_id)
            if trial_id is not None
            else None
        )
        bodies.extend(
            (
                record,
                PolicyDecisionExplained(
                    decision_id=decision_id, rationale=description.rationale
                ),
            )
        )
        committed.append(CommittedDecision(record=record, trial=trial))
        if isinstance(decision, TrialSpec):
            claimed = claimed + trial_allocation(decision)

    # One correlation per batch, keyed on the first member exactly as a single
    # decision has always been -- so a width-one batch is byte-identical.
    first = committed[0]
    owner = (
        first.record.trial_id.value
        if first.record.trial_id is not None
        else first.record.decision_id.value
    )
    host.commit_batch(
        bodies,
        correlation=stable_id(CorrelationId, "correlation", owner),
        work=proposal_enqueues(host, committed),
    )
    return tuple(committed)


def _validate_trial(
    host: DecisionHost,
    state: SearchState,
    spec: TrialSpec,
    *,
    extra_reserved: Usage = Usage(),
) -> None:
    if spec.task_id != host.task_id:
        raise InvalidDecision("trial belongs to another task")
    if spec.proposer != host.proposer_ref:
        raise InvalidDecision("trial selected an unauthorized proposer")
    if len(spec.parent_ids) != 1 or any(
        parent not in state.artifact_ids for parent in spec.parent_ids
    ):
        raise InvalidDecision("M1 trials require one committed parent")
    required = Usage(trials=1, evaluations=1)
    # Admission is exact over committed facts: capacity already held by a trial
    # that is still outstanding cannot be handed to a new one. At width one
    # nothing is ever outstanding at decision time, so the reservation is empty
    # and this is the shipped rule unchanged.
    # `extra_reserved` carries what earlier members of this cohort have already
    # claimed: they are validated before any of them is committed, so no fold
    # over committed facts can see their allocations yet.
    reserved = reserved_usage(host.projection) + extra_reserved
    remaining = less_reserved(state.remaining_budget, reserved)
    # Spend is adjudicated against the run's OWN fold, never the reduced one:
    # `spend.blocked` documents that anything but `state`'s folds is a bug, and
    # reservations govern only the count dimensions by design. Hoisted, and
    # handed the folds it would otherwise redo, since the reason line below
    # would ask for the whole predicate a second time.
    spend_stopped = spend.blocked(
        state, remaining=state.remaining_budget, charged=state.usage
    )
    if (
        not remaining.allows(required)
        or not spec.budget.allows(required)
        or spec.budget.narrow(remaining) != spec.budget
        or has_zero_resource(spec.budget, evaluation=True)
        or spend_stopped
    ):
        reason = "spend ceiling reached" if spend_stopped else "budget"
        raise BudgetUnavailable(
            f"trial cannot fit within its effective budget ({reason})"
        )


__all__ = ["CommittedDecision", "commit_cohort", "commit_decision"]
