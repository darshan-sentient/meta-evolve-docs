"""Immutable public views over committed run records."""

from __future__ import annotations

from typing import TYPE_CHECKING

from meta_evolve.domain import RunId, Usage

from .codecs import CodecIndex
from .comparisons import RunComparison, RunSummary, compare_runs, summarize_run
from .durable_loading import load_validated_run
from .experience_usage import RunExperienceUsage, aggregate_experience_usage
from .inspection import RunInspection, inspect_run
from .projections import RunProjection
from .storage import Storage
from .views import ArtifactView, EvidenceView, TrialView, ViewBuilder

if TYPE_CHECKING:
    from meta_evolve.registry import Registry


class Run:
    """Read-only queries over an executed experiment.

    Returned by ``improve``, ``run``, or ``resume``. Construct a Run from its ID
    and storage to read retained results without executing components. Use
    ``best().value`` for the winner and ``inspect()`` when no winner exists.
    """

    __slots__ = ("id", "_storage", "_token", "_codecs")

    def __init__(
        self,
        run_id: RunId,
        storage: Storage,
        *,
        registry: Registry | None = None,
    ) -> None:
        from meta_evolve.registry import Registry

        if registry is not None and not isinstance(registry, Registry):
            raise TypeError("registry must be a Registry")
        self.id = run_id
        self._storage = storage
        self._token = object()
        self._codecs = (
            CodecIndex.with_extras(registry.artifact_types())
            if registry is not None
            else CodecIndex.builtin()
        )

    @classmethod
    def _reopen(
        cls, run_id: RunId, storage: Storage, codecs: CodecIndex
    ) -> Run:
        """Reopen an active result with the exact codec index that produced it."""

        reopened = cls(run_id, storage)
        reopened._codecs = codecs
        return reopened

    def _projection(self) -> RunProjection:
        return load_validated_run(self._storage, self.id).projection

    def best(self, objective: str | None = None) -> ArtifactView:
        """Return the best measured artifact; its ``value`` is the candidate content.

        :param objective: Metric to rank by; defaults to the primary objective.
        :raises NoSuccessfulEvaluation: If no successful evaluation can be ranked.
        :raises ValueError: If the objective is unknown.
        """

        projection = self._projection()
        views = self._views(projection)
        return views.artifact(views.best_evaluation(objective).artifact_id)

    def best_trial(self, objective: str | None = None) -> TrialView:
        """Return the winning attempt with its measurements, evidence, and usage.

        :param objective: Metric to rank by; defaults to the primary objective.
        :raises NoSuccessfulEvaluation: If nothing can be ranked.
        """

        projection = self._projection()
        views = self._views(projection)
        return views.trial(views.best_evaluation(objective).trial_id)

    def inspect(self) -> RunInspection:
        """Read one immutable aggregate from one validated replay.

        Includes declarations, attempts, evidence, decisions, failures, and usage.
        Works for incomplete and unrankable runs without calling ``best()`` or
        executing components.
        """

        return inspect_run(self._storage, self.id, self._codecs, self._token)

    def trials(self) -> tuple[TrialView, ...]:
        """Every committed attempt in commit order, seed trial first.

        The winner-shaped queries answer "what came out of this run"; this one
        answers "what happened in it", so it reports losers, failed proposals,
        and trials the budget never authorised for evaluation, and it is the
        one query that never raises ``NoSuccessfulEvaluation``. Read
        ``TrialView.state`` to tell those apart.
        """

        projection = self._projection()
        return self._views(projection).trials()

    def summary(self) -> RunSummary:
        """Summarize the winner, declarations, causal lineage, and usage.

        :raises NoSuccessfulEvaluation: If nothing ranked. Use ``usage()`` or
            ``inspect()`` to read costs even when all measurements failed.
        """

        return summarize_run(self)

    def compare(self, other: Run) -> RunComparison:
        """Compare compatible runs, returning an explicit winner or an exact tie.

        :raises RunsNotComparable: If declared controls prevent fair comparison.
        :raises NoSuccessfulEvaluation: If either run has no rankable result.
        """

        return compare_runs(self, other)

    def usage(self) -> Usage:
        """Everything this run consumed, including work that failed to rank.

        Use this rather than ``summary().usage`` whenever a caller is
        accumulating -- a roll-up over inner runs, or any total that must
        survive a bad episode. ``summary()`` raises ``NoSuccessfulEvaluation``
        when a run scored nothing, which unwinds the caller and discards the
        resources already accumulated from *earlier* episodes as well as this
        one's. This reports the same figure as
        ``inspect().overview.task_usage`` and never raises for that reason.

        A run that does not exist raises ``RunNotFound``, as ``inspect()`` does.
        That is the point of ``require_existing``: without it the unbootstrapped
        projection leaks a bare ``SearchNotStarted``, and this accessor promises
        the same answers *and* the same errors as the aggregate it stands in for.
        """

        loaded = load_validated_run(self._storage, self.id, require_existing=True)
        return loaded.projection.search_state.usage

    def experience_usage(self) -> RunExperienceUsage:
        """Read pushed-context and audited-pull consumption from committed facts."""

        return aggregate_experience_usage(self._projection())

    def lineage(
        self, artifact: ArtifactView | TrialView | None = None
    ) -> tuple[TrialView, ...]:
        """Trace an artifact's causal ancestors, seed first.

        :param artifact: A view returned by this Run handle; defaults to the winner.
        :returns: Producing attempts, including ancestors that were not improvements.
        :raises ValueError: If the view belongs to another handle or has no artifact.
        :raises NoSuccessfulEvaluation: If tracing the default winner and none exists.
        """

        if artifact is None:
            target = self.best().id
        elif isinstance(artifact, ArtifactView):
            self._require_token(artifact._run_token)
            target = artifact.id
        elif isinstance(artifact, TrialView):
            self._require_token(artifact._run_token)
            if artifact.artifact is None:
                raise ValueError("a failed trial has no artifact lineage")
            target = artifact.artifact.id
        else:
            raise TypeError("artifact must be a view returned by this run")

        projection = self._projection()
        return self._views(projection).lineage(target)

    def _best_evaluation(self, objective_name: str | None):
        projection = self._projection()
        return self._views(projection).best_evaluation(objective_name)

    def _views(self, projection: RunProjection) -> ViewBuilder:
        return ViewBuilder(projection, self._storage, self._codecs, self._token)

    def _require_token(self, token: object) -> None:
        if token is not self._token:
            raise ValueError("that view does not belong to this run")


__all__ = [
    "ArtifactView",
    "EvidenceView",
    "Run",
    "RunExperienceUsage",
    "Storage",
    "TrialView",
]
