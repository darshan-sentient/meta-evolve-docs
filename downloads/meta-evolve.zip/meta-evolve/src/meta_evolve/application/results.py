"""Immutable public views over committed run records."""

from __future__ import annotations

from typing import TYPE_CHECKING

from meta_evolve.domain import RunId, Usage
from meta_evolve.domain.search import _recorded_usage

from .codecs import CodecIndex
from .comparisons import RunComparison, RunSummary, compare_runs, summarize_run
from .durable_loading import load_validated_run
from .experience_usage import RunExperienceUsage, aggregate_experience_usage
from .inspection import RunInspection, inspect_run
from .projections import RunProjection
from .storage import Storage
from .views import ArtifactView, EvidenceView, TrialView, ViewBuilder

if TYPE_CHECKING:
    from meta_evolve.registry import Registry


class Run:
    """Read-only queries over an executed experiment.

    Returned by [improve][meta_evolve.improve], [run][meta_evolve.run], or
    [resume][meta_evolve.resume]; ``session.run`` also reads an active session.
    Queries do not advance execution. Construct a Run from its ID and storage
    to read retained history; this neither reruns components nor resumes work.

    Use ``best().value`` for selected content, ``best_trial()`` for that attempt's
    measurements, and ``trials()`` for all completed attempts. ``summary()``,
    ``inspect()``, and ``usage()`` work even when nothing ranks. A returned Run does not guarantee
    a successful evaluation or an improvement over the seed.

    :param run_id: Recorded run identity to inspect.
    :param storage: Storage containing that run's committed facts.
    :param registry: Optional codecs for decoding custom artifact values.
    """

    __slots__ = ("id", "_storage", "_token", "_codecs")

    def __init__(
        self,
        run_id: RunId,
        storage: Storage,
        *,
        registry: Registry | None = None,
    ) -> None:
        from meta_evolve.registry import Registry

        if registry is not None and not isinstance(registry, Registry):
            raise TypeError("registry must be a Registry")
        self.id = run_id
        self._storage = storage
        self._token = object()
        self._codecs = (
            CodecIndex.with_extras(registry.artifact_types())
            if registry is not None
            else CodecIndex.builtin()
        )

    @classmethod
    def _reopen(
        cls, run_id: RunId, storage: Storage, codecs: CodecIndex
    ) -> Run:
        """Reopen an active result with the exact codec index that produced it."""

        reopened = cls(run_id, storage)
        reopened._codecs = codecs
        return reopened

    def _projection(self) -> RunProjection:
        return load_validated_run(self._storage, self.id).projection

    def best(self, objective: str | None = None) -> ArtifactView:
        """Return the best measured artifact; its ``value`` is the candidate content.

        The seed participates in selection. Exact ties keep the earliest
        successful evaluation in logical order; failed evaluations never rank.

        :param objective: Declared metric name; ``None`` uses the first task objective.
            Selecting another objective here does not change the search history.
        :returns: [ArtifactView][meta_evolve.ArtifactView] with decoded ``value``,
            occurrence identity, content digest, and parent identities.
        :raises NoSuccessfulEvaluation: If no successful evaluation can be ranked.
        :raises ValueError: If the objective is unknown.
        """

        projection = self._projection()
        views = self._views(projection)
        return views.artifact(views.best_evaluation(objective).artifact_id)

    def best_trial(self, objective: str | None = None) -> TrialView:
        """Return the winning attempt with its measurements, evidence, and usage.

        :param objective: Metric to rank by; defaults to the primary objective.
        :returns: [TrialView][meta_evolve.TrialView] with the selected ``artifact``,
            ``metrics``, evidence, and usage. Uses the same tie rule as ``best()``.
        :raises NoSuccessfulEvaluation: If nothing can be ranked.
        :raises ValueError: If the objective is not declared by the task.
        """

        projection = self._projection()
        views = self._views(projection)
        return views.trial(views.best_evaluation(objective).trial_id)

    def inspect(self) -> RunInspection:
        """Read one immutable aggregate from one validated replay.

        Includes declarations, attempts, evidence, decisions, failures, and usage.
        Works for incomplete and unrankable runs without calling ``best()`` or
        executing components.
        """

        return inspect_run(self._storage, self.id, self._codecs, self._token)

    def trials(self) -> tuple[TrialView, ...]:
        """Every committed attempt in logical order, seed trial first.

        Includes regressions, ties, failed proposals, failed evaluations, and
        attempts whose evaluation was not authorized. Read [TrialView.state][meta_evolve.TrialView]
        to distinguish them. Unlike ``usage().trials``, this tuple includes the
        seed. Like ``inspect()`` and ``usage()``, it remains available when no
        evaluation succeeded. In-progress attempts without a committed outcome
        are not yet included.
        """

        projection = self._projection()
        return self._views(projection).trials()

    def summary(self) -> RunSummary:
        """Report lifecycle, rankability, declarations, and committed usage.

        Reads one validated snapshot, including incomplete runs and pending seed
        evaluation. If nothing ranks, ``primary_score`` is ``None`` and
        ``winning_lineage`` is empty. Use ``inspect()`` for detailed failures.

        :raises RunNotFound: If the run does not exist.
        """

        return summarize_run(self)

    def compare(self, other: Run) -> RunComparison:
        """Compare compatible runs, returning an explicit winner or an exact tie.

        :raises RunsNotComparable: If declared controls prevent fair comparison.
        :raises NoSuccessfulEvaluation: If either run has no rankable result.
        """

        return compare_runs(self, other)

    def usage(self) -> Usage:
        """Everything this run consumed, including work that failed to rank.

        This does not raise ``NoSuccessfulEvaluation``. Use it for accounting
        even when measurements failed or the seed evaluation is pending. Forward
        ``usage().resources`` when aggregating resources from an inner run.

        :returns: Aggregated [Usage][meta_evolve.Usage], also available as
            ``inspect().overview.task_usage``. Unknown billed spend remains unknown.
        :raises RunNotFound: If the run does not exist.
        """

        loaded = load_validated_run(self._storage, self.id, require_existing=True)
        projection = loaded.projection
        return _recorded_usage(projection.completed_trials, projection.completed_evaluations)

    def experience_usage(self) -> RunExperienceUsage:
        """Read pushed-context and audited-pull consumption from committed facts."""

        return aggregate_experience_usage(self._projection())

    def lineage(
        self, artifact: ArtifactView | TrialView | None = None
    ) -> tuple[TrialView, ...]:
        """Trace an artifact's causal ancestors, seed first.

        :param artifact: A view returned by this Run handle; defaults to the winner.
        :returns: Producing attempts, including ancestors that were not improvements.
        :raises ValueError: If the view belongs to another handle or has no artifact.
        :raises NoSuccessfulEvaluation: If tracing the default winner and none exists.
        """

        if artifact is None:
            target = self.best().id
        elif isinstance(artifact, ArtifactView):
            self._require_token(artifact._run_token)
            target = artifact.id
        elif isinstance(artifact, TrialView):
            self._require_token(artifact._run_token)
            if artifact.artifact is None:
                raise ValueError("a failed trial has no artifact lineage")
            target = artifact.artifact.id
        else:
            raise TypeError("artifact must be a view returned by this run")

        projection = self._projection()
        return self._views(projection).lineage(target)

    def _views(self, projection: RunProjection) -> ViewBuilder:
        return ViewBuilder(projection, self._storage, self._codecs, self._token)

    def _require_token(self, token: object) -> None:
        if token is not self._token:
            raise ValueError("that view does not belong to this run")


__all__ = [
    "ArtifactView",
    "EvidenceView",
    "Run",
    "RunExperienceUsage",
    "Storage",
    "TrialView",
]
