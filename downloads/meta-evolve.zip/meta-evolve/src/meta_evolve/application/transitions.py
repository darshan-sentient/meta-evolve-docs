"""Validation and application of one kernel lifecycle event."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain.events import (
    ArtifactCreated,
    BootstrapPrepared,
    ContextPolicyDeclared,
    ContextSelected,
    EvaluationCompleted,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    EventEnvelope,
    EvidenceRecorded,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    ProposalSubmitted,
    RunStarted,
    TrialCompleted,
    SourceHistoryMounted,
)
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.domain.trial import ArchiveUpdate, TrialSpec

from .archive_transitions import archive_transition_error
from .context_transitions import (
    declare_context as context_declaration_transition,
    select_context as context_selection_transition,
)
from .experience_transitions import (
    attempt_operation,
    declare_access,
    issue_grant,
    resolve_operation,
)
from .run_projection import RunProjection
from .proposal_transitions import submit_proposal
from .source_history_transitions import mount_source_history


def invalid(sequence: int, reason: str) -> InvalidSearchHistory:
    return InvalidSearchHistory(
        f"invalid search history at sequence {sequence}: {reason}"
    )


def _run_budget_narrows_task(start: RunStarted) -> bool:
    return start.task.budget is None or (
        start.task.budget.narrow(start.run_budget) == start.run_budget
    )


def apply_event(state: RunProjection, event: EventEnvelope) -> RunProjection:
    sequence = event.sequence
    body = event.body
    unresolved = (
        state.experience_attempts
        and state.resolution_for(state.experience_attempts[-1].operation_id) is None
    )
    if unresolved and not isinstance(
        body,
        (
            ExperienceOperationSucceeded,
            ExperienceOperationDenied,
            ExperienceOperationBudgetExhausted,
        ),
    ):
        raise invalid(sequence, "experience attempt must resolve immediately")
    if isinstance(body, RunStarted):
        if state.start is not None or sequence != 1:
            raise invalid(sequence, "RunStarted must be the first and only start fact")
        if event.causation_id is not None:
            raise invalid(sequence, "RunStarted must not have a cause")
        if not _run_budget_narrows_task(body):
            raise invalid(sequence, "run budget cannot widen the task budget")
        return replace(state, version=sequence, start=body)

    if state.start is None:
        raise invalid(sequence, "RunStarted must precede other facts")
    if event.causation_id not in state.event_ids:
        raise invalid(sequence, "fact must reference a previously committed cause")
    if isinstance(body, PolicyDecisionExplained):
        decision = state.decisions[-1] if state.decisions else None
        if decision is None or decision.decision_id != body.decision_id:
            raise invalid(sequence, "explanation references an unknown decision")
        if state.explanation_for(body.decision_id) is not None:
            raise invalid(sequence, "decision was already explained")
        if decision.observed_version + 1 != state.version:
            raise invalid(sequence, "explanation must immediately follow its decision")
        return replace(
            state,
            version=sequence,
            explanations=state.explanations + (body,),
        )
    if isinstance(body, ContextPolicyDeclared):
        return context_declaration_transition(state, body, sequence)
    if isinstance(body, ExperienceAccessDeclared):
        return declare_access(state, body, sequence, event.correlation_id)
    if state.stop is not None:
        raise invalid(sequence, "facts cannot follow a committed Stop")

    if isinstance(body, BootstrapPrepared):
        trial = body.trial
        if state.bootstrap is not None:
            raise invalid(sequence, "bootstrap was already prepared")
        if state.artifact_ids or state.decisions or state.completed_trials:
            raise invalid(sequence, "bootstrap must precede run lifecycle facts")
        if trial.run_id != state.run_id or trial.spec.task_id != state.start.task_id:
            raise invalid(sequence, "bootstrap belongs to another run or task")
        if body.proposal.derived_from:
            raise invalid(sequence, "bootstrap proposal cannot declare derivation")
        return replace(state, version=sequence, bootstrap=body)

    if isinstance(body, ArtifactCreated):
        if body.artifact_id in state.artifact_ids:
            raise invalid(sequence, "artifact occurrence was already recorded")
        if state.bootstrap is None:
            raise invalid(sequence, "bootstrap must precede artifact creation")
        if not state.artifact_ids:
            if body.artifact_id != state.start.seed_artifact_id:
                raise invalid(sequence, "the first artifact must be the run seed")
        elif not any(
            state.completed_trial(item.proposal.trial_id) is None
            for item in state.proposals
        ):
            raise invalid(sequence, "successor artifact has no pending proposal")
        return replace(
            state,
            version=sequence,
            artifact_ids=state.artifact_ids + (body.artifact_id,),
        )

    if isinstance(body, PolicyDecisionMade):
        if not state.ready:
            raise invalid(sequence, "bootstrap evaluation must precede policy decisions")
        if any(
            isinstance(item.decision, TrialSpec)
            and state.completed_trial(item.trial_id) is None
            for item in state.decisions
        ):
            raise invalid(sequence, "sequential runs cannot decide with work in flight")
        search = state.search_state
        if body.policy != state.start.search.policy:
            raise invalid(sequence, "decision policy does not match the run policy")
        if body.logical_step != search.next_logical_step:
            raise invalid(sequence, "policy decision logical step is not contiguous")
        if body.decision_id != search.next_decision_id:
            raise invalid(sequence, "policy decision id is not reproducible")
        if body.observed_version != state.version:
            raise invalid(sequence, "decision observed the wrong stream version")
        for name, recorded_seed in body.random_seeds.items():
            if recorded_seed != search.randomness.seed(name):
                raise invalid(sequence, f"recorded random seed {name!r} is invalid")
        if isinstance(body.decision, TrialSpec):
            if body.decision.task_id != state.start.task_id:
                raise invalid(sequence, "trial decision belongs to another task")
            if body.decision.proposer != state.start.search.proposer:
                raise invalid(sequence, "trial decision selected an unauthorized proposer")
            if any(parent not in state.artifact_ids for parent in body.decision.parent_ids):
                raise invalid(sequence, "trial decision references an unknown parent")
            if any(item.trial_id == body.trial_id for item in state.decisions):
                raise invalid(sequence, "trial identity was already committed")
            if body.random_seeds.get("trial") != body.decision.random_seed:
                raise invalid(sequence, "trial decision seed does not match its record")
            declaration = state.context_declaration
            declared_policy = (
                declaration.spec.policy if declaration is not None else None
            )
            if body.decision.context_policy != declared_policy:
                raise invalid(
                    sequence,
                    "trial context policy does not match the run declaration",
                )
        elif isinstance(body.decision, ArchiveUpdate):
            error = archive_transition_error(state, body.decision)
            if error is not None:
                raise invalid(sequence, error)
        return replace(state, version=sequence, decisions=state.decisions + (body,))

    if isinstance(body, ContextSelected):
        return context_selection_transition(state, body, sequence)
    if isinstance(body, ExperienceGrantIssued):
        return issue_grant(state, body, sequence, event.correlation_id)
    if isinstance(body, ExperienceOperationAttempted):
        return attempt_operation(state, body, sequence, event.correlation_id)
    if isinstance(
        body,
        (
            ExperienceOperationSucceeded,
            ExperienceOperationDenied,
            ExperienceOperationBudgetExhausted,
        ),
    ):
        return resolve_operation(state, body, sequence, event.correlation_id)

    if isinstance(body, SourceHistoryMounted):
        return mount_source_history(state, body, sequence, event.correlation_id)

    if isinstance(body, ProposalSubmitted):
        return submit_proposal(state, body, sequence)

    if isinstance(body, EvidenceRecorded):
        if state.evidence_by_id(body.evidence.id) is not None:
            raise invalid(sequence, "evidence was already recorded")
        return replace(state, version=sequence, evidence=state.evidence + (body,))

    if isinstance(body, TrialCompleted):
        trial = body.trial
        outcome = body.outcome
        if trial.run_id != state.run_id:
            raise invalid(sequence, "completed trial belongs to another run")
        if outcome.usage.evaluations != 0:
            raise invalid(sequence, "trial usage cannot count evaluations")
        if state.completed_trial(trial.id) is not None:
            raise invalid(sequence, "trial was already completed")
        if state.bootstrap is not None and trial.id == state.bootstrap.trial.id:
            if trial != state.bootstrap.trial or outcome.usage.trials != 0:
                raise invalid(sequence, "bootstrap completion does not match trial 0")
            if outcome.failure is not None:
                raise invalid(sequence, "bootstrap artifact commitment cannot fail")
            if outcome.proposal_id != state.bootstrap.proposal.id:
                raise invalid(sequence, "bootstrap outcome references another proposal")
            if outcome.artifact_ids != (state.start.seed_artifact_id,):
                raise invalid(sequence, "bootstrap outcome must commit the seed artifact")
        else:
            decision = next(
                (item for item in state.decisions if item.trial_id == trial.id),
                None,
            )
            if decision is None or not isinstance(decision.decision, TrialSpec):
                raise invalid(sequence, "completed trial has no prior trial decision")
            if outcome.usage.trials != 1:
                raise invalid(sequence, "successor usage must count exactly one trial")
            if (
                trial.decision_id != decision.decision_id
                or trial.logical_step != decision.logical_step
                or trial.spec != decision.decision
            ):
                raise invalid(sequence, "completed trial does not match its decision")
            proposal = state.proposal_for(trial.id)
            if proposal is None or outcome.proposal_id != proposal.id:
                raise invalid(sequence, "completed trial does not match its proposal")
        if any(item not in state.artifact_ids for item in outcome.artifact_ids):
            raise invalid(sequence, "completed trial references an unrecorded artifact")
        if any(state.evidence_by_id(item) is None for item in outcome.evidence_ids):
            raise invalid(sequence, "trial references unrecorded evidence")
        return replace(
            state,
            version=sequence,
            completed_trials=state.completed_trials + (body,),
        )

    if isinstance(body, EvaluationCompleted):
        evaluation = body.evaluation
        if evaluation.usage.evaluations != 1 or evaluation.usage.trials != 0:
            raise invalid(sequence, "evaluation usage must count one evaluation only")
        if any(item.evaluation.id == evaluation.id for item in state.completed_evaluations):
            raise invalid(sequence, "evaluation was already completed")
        if state.evaluation_for(evaluation.trial_id) is not None:
            raise invalid(sequence, "M1 supports one evaluation per trial")
        completed = state.completed_trial(evaluation.trial_id)
        if completed is None or completed.outcome.failure is not None:
            raise invalid(sequence, "evaluation requires a successful completed trial")
        if evaluation.artifact_id not in completed.outcome.artifact_ids:
            raise invalid(sequence, "evaluation artifact was not produced by its trial")
        if evaluation.evaluator != state.start.task.evaluator:
            raise invalid(sequence, "evaluation used an unauthorized evaluator")
        if any(state.evidence_by_id(item) is None for item in evaluation.evidence_ids):
            raise invalid(sequence, "evaluation references unrecorded evidence")
        if evaluation.failure is None:
            missing = tuple(
                objective.metric
                for objective in state.start.task.objectives
                if objective.metric not in evaluation.metrics
            )
            if missing:
                raise invalid(sequence, f"evaluation is missing objective {missing[0]!r}")
        return replace(
            state,
            version=sequence,
            completed_evaluations=state.completed_evaluations + (body,),
        )

    raise invalid(sequence, f"unsupported fact {type(body).__name__}")


__all__ = ["apply_event", "invalid"]
