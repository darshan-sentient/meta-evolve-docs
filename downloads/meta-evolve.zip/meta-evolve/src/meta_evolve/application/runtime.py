"""Compatibility normalization for the public synchronous run call."""

from __future__ import annotations

from typing import overload

from meta_evolve.domain import Budget, SearchProgram, Task
from meta_evolve.errors import RunNotFound
from meta_evolve.policies.context import ContextPolicy
from meta_evolve.ports.experience import ExperienceAccess
from meta_evolve.registry import Registry

from .comparisons import RunComparison, RunSummary
from .experience_usage import RunExperienceUsage
from .experiment import Experiment, _UNSET, _normalize_experiment
from .inspection import (
    ArchiveDecisionView,
    DecisionView,
    RunDeclaration,
    RunInspection,
    RunOverview,
    StopDecisionView,
    TrialDecisionView,
)
from .results import ArtifactView, EvidenceView, Run, Storage, TrialView
from .resume import resume
from .run_support import ExecutionMode, ProposerLike
from .session import Session


@overload
def run(
    experiment: Experiment,
    /,
    *,
    storage: Storage | None = None,
    budget: Budget | None = None,
    mode: ExecutionMode = "local",
) -> Run: ...


@overload
def run(
    *,
    task: Task,
    seed: object,
    proposer: ProposerLike,
    search: SearchProgram | None = None,
    context: ContextPolicy | None = None,
    experience: ExperienceAccess | None = None,
    storage: Storage | None = None,
    budget: Budget | None = None,
    random_seed: int = 0,
    mode: ExecutionMode = "local",
    registry: Registry | None = None,
) -> Run: ...


def run(
    experiment: Experiment | object = _UNSET,
    /,
    *,
    task: Task | object = _UNSET,
    seed: object = _UNSET,
    proposer: ProposerLike | object = _UNSET,
    search: SearchProgram | None | object = _UNSET,
    context: ContextPolicy | None | object = _UNSET,
    experience: ExperienceAccess | None | object = _UNSET,
    storage: Storage | None = None,
    budget: Budget | None = None,
    random_seed: int | object = _UNSET,
    mode: ExecutionMode = "local",
    registry: Registry | None | object = _UNSET,
) -> Run:
    """Run one evaluated improvement search and return its inspectable history.

    Call either ``run(experiment, ...)`` with one positional-only
    :class:`~meta_evolve.Experiment`, or use its declaration fields as keywords.
    The keyword form retains the effective defaults ``search=None``,
    ``context=None``, ``experience=None``, ``random_seed=0``, and
    ``registry=None``. The default search therefore remains
    ``Greedy(max_trials=20)``. Both forms prepare and exhaust the same
    :class:`~meta_evolve.Session` used for paced and resumed execution.

    :param experiment: Typed declaration. It cannot be combined with declaration
        keywords.
    :param task: See :class:`~meta_evolve.Experiment`.
    :param seed: See :class:`~meta_evolve.Experiment`.
    :param proposer: See :class:`~meta_evolve.Experiment`.
    :param search: See :class:`~meta_evolve.Experiment`.
    :param context: See :class:`~meta_evolve.Experiment`.
    :param experience: See :class:`~meta_evolve.Experiment`.
    :param storage: Artifact and event storage; defaults to isolated memory storage.
    :param budget: Run budget, which may narrow but never widen the task budget.
    :param random_seed: See :class:`~meta_evolve.Experiment`.
    :param mode: ``"local"`` or ``"durable-local"`` execution.
    :param registry: See :class:`~meta_evolve.Experiment`.
    :returns: A :class:`Run` for result, trial, lineage, usage, and comparison queries.
    :raises TypeError: If a declared public input has the wrong type.
    :raises ValueError: If declarations conflict or the task budget is widened.
    :raises CapabilityError: If durable-local requirements cannot be satisfied.

    Invalid proposals and ordinary proposer or evaluator failures are recorded as
    typed trial outcomes; they are not converted to exceptions or low scores.
    """

    declaration = _normalize_experiment(
        experiment,
        task=task,
        seed=seed,
        proposer=proposer,
        search=search,
        context=context,
        experience=experience,
        random_seed=random_seed,
        registry=registry,
    )
    with Session.start(
        declaration,
        storage=storage,
        budget=budget,
        mode=mode,
    ) as session:
        if mode == "distributed":
            # A distributed run's unit of progress is a work item, not a
            # decision, so it is driven rather than iterated. Same call, same
            # returned `Run` -- the mode is the only thing that differs.
            session.drive()
        else:
            for _decision in session:
                pass
    return session.run


__all__ = [
    "ArchiveDecisionView",
    "ArtifactView",
    "DecisionView",
    "EvidenceView",
    "ExecutionMode",
    "ProposerLike",
    "Run",
    "RunComparison",
    "RunDeclaration",
    "RunExperienceUsage",
    "RunInspection",
    "RunNotFound",
    "RunOverview",
    "RunSummary",
    "Session",
    "Storage",
    "StopDecisionView",
    "TrialDecisionView",
    "TrialView",
    "resume",
    "run",
]
