"""Prepend dispatcher epoch authority to each atomic commit.

Rollover installs the fence. Genesis and sequential execution have no fence.
RequireEpoch precedes other intents so a superseded dispatcher hears the epoch
refusal before a lease refusal caused by that same rollover.
"""

from __future__ import annotations

from collections.abc import Iterable

from meta_evolve.ports.work_store import RequireEpoch, WorkIntent


class Fence:
    """The epoch this dispatcher rolled the run over to, once it has one."""

    __slots__ = ("_epoch",)

    def __init__(self) -> None:
        self._epoch: int | None = None

    @property
    def epoch(self) -> int | None:
        return self._epoch

    def install(self, epoch: int) -> None:
        """Hold a positive epoch without moving this dispatcher's authority backward."""

        if isinstance(epoch, bool) or not isinstance(epoch, int) or epoch < 1:
            raise ValueError("a fence holds a positive integer epoch")
        if self._epoch is not None and epoch < self._epoch:
            raise ValueError(
                f"a fence cannot move from epoch {self._epoch} back to {epoch}"
            )
        self._epoch = epoch

    def guard(self, work: Iterable[WorkIntent]) -> tuple[WorkIntent, ...]:
        """`work`, led by the epoch check when this fence holds one."""

        if self._epoch is None:
            return tuple(work)
        return (RequireEpoch(epoch=self._epoch), *work)


__all__ = ["Fence"]
