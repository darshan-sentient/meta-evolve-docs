"""Winner-independent aggregate inspection over one validated replay."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, TypeAlias

from meta_evolve.domain import (
    ArtifactId,
    Budget,
    ComponentRef,
    ContextSpec,
    DecisionId,
    ExperienceSpec,
    FrozenMap,
    Objective,
    PolicyDecisionMade,
    RunCapabilities,
    RunId,
    SearchSpec,
    TaskId,
    TrialId,
    Usage,
)
from meta_evolve.domain.trial import ArchiveUpdate, Stop, TrialSpec
from meta_evolve.domain.search import _recorded_usage
from meta_evolve.errors import DurableCorruption

from .codecs import CodecIndex
from .durable_loading import load_validated_run
from .experience_usage import RunExperienceUsage, aggregate_experience_usage
from .projections import RunProjection
from .storage import Storage
from .views import ArtifactView, EvidenceView, TrialView, ViewBuilder


@dataclass(frozen=True, slots=True)
class RunOverview:
    """Lifecycle, selected trial, and costs captured by [Run.inspect][meta_evolve.Run.inspect].

    ``best_trial`` is ``None`` when no evaluation produced a rankable measurement.
    """

    run_id: RunId
    lifecycle: Literal["complete", "incomplete"]
    rankability: Literal["rankable", "unrankable"]
    best_trial: TrialView | None
    task_usage: Usage
    experience_usage: RunExperienceUsage
    stop_reason: str | None


@dataclass(frozen=True, slots=True)
class RunDeclaration:
    """The recorded seed, components, objectives, and limits of an inspected run.

    Read ``effective_budget`` for the limits actually used during execution.
    """

    task_id: TaskId
    objectives: tuple[Objective, ...]
    artifact_kind: str
    artifact_representation: str
    seed: ArtifactView
    evaluator: ComponentRef
    proposer: ComponentRef
    search: SearchSpec
    task_budget: Budget | None
    effective_budget: Budget
    capabilities: RunCapabilities
    context: ContextSpec | None
    experience: ExperienceSpec | None
    random_seed: int


@dataclass(frozen=True, slots=True)
class TrialDecisionView:
    """A recorded search decision to try a revision of the listed parents.

    ``trial`` is ``None`` while that attempt has not completed.
    """

    id: DecisionId
    logical_step: int
    rationale: str
    randomness: FrozenMap
    parents: tuple[ArtifactView, ...]
    trial_id: TrialId
    trial: TrialView | None

    @property
    def parent_ids(self) -> tuple[ArtifactId, ...]:
        return tuple(item.id for item in self.parents)

    @property
    def kind(self) -> Literal["trial"]:
        return "trial"


@dataclass(frozen=True, slots=True)
class ArchiveDecisionView:
    """A recorded archive decision and the resulting ordered member identities.

    ``eviction`` identifies a single removed artifact, or is ``None``.
    """

    id: DecisionId
    logical_step: int
    rationale: str
    randomness: FrozenMap
    candidate: ArtifactView
    admitted: bool
    eviction: ArtifactView | None
    member_ids: tuple[ArtifactId, ...]

    @property
    def kind(self) -> Literal["archive"]:
        return "archive"


@dataclass(frozen=True, slots=True)
class StopDecisionView:
    """A recorded search decision to stop, with its reason and rationale."""

    id: DecisionId
    logical_step: int
    rationale: str
    randomness: FrozenMap
    reason: str

    @property
    def kind(self) -> Literal["stop"]:
        return "stop"


DecisionView: TypeAlias = TrialDecisionView | ArchiveDecisionView | StopDecisionView


@dataclass(frozen=True, slots=True)
class RunInspection:
    """One snapshot of a run's declaration, attempts, decisions, and evidence.

    Returned by [Run.inspect][meta_evolve.Run.inspect], including when no
    evaluation succeeded. ``overview`` summarizes the same captured history.
    """

    overview: RunOverview
    declaration: RunDeclaration
    trials: tuple[TrialView, ...]
    decisions: tuple[DecisionView, ...]
    evidence: tuple[EvidenceView, ...]
    artifacts: tuple[ArtifactView, ...]


def build_decision_view(
    recorded: PolicyDecisionMade,
    projection: RunProjection,
    builder: ViewBuilder,
) -> DecisionView:
    """Build one immutable decision view from an authoritative projection."""

    explanation = projection.explanation_for(recorded.decision_id)
    if explanation is None:
        raise DurableCorruption(
            f"durable decision {recorded.decision_id} has no explanation"
        )
    common = {
        "id": recorded.decision_id,
        "logical_step": recorded.logical_step,
        "rationale": explanation.rationale,
        "randomness": recorded.random_seeds,
    }
    decision = recorded.decision
    if isinstance(decision, TrialSpec):
        assert recorded.trial_id is not None
        completed = projection.completed_trial(recorded.trial_id)
        return TrialDecisionView(
            **common,
            parents=tuple(builder.artifact(item) for item in decision.parent_ids),
            trial_id=recorded.trial_id,
            trial=(
                builder.trial(recorded.trial_id) if completed is not None else None
            ),
        )
    if isinstance(decision, ArchiveUpdate):
        return ArchiveDecisionView(
            **common,
            candidate=builder.artifact(decision.candidate_id),
            admitted=decision.admitted,
            eviction=(
                builder.artifact(decision.evicted_artifact_id)
                if decision.evicted_artifact_id is not None
                else None
            ),
            member_ids=decision.member_ids,
        )
    if isinstance(decision, Stop):
        return StopDecisionView(**common, reason=decision.reason)
    # Replay owns the closed durable sum type; nothing else can reach here.
    raise DurableCorruption(  # pragma: no cover
        "durable run contains an unknown decision type"
    )


def inspect_run(
    storage: Storage,
    run_id: RunId,
    codecs: CodecIndex,
    run_token: object,
) -> RunInspection:
    """Compose one aggregate from exactly one authoritative validated replay."""

    projection = load_validated_run(storage, run_id, require_existing=True).projection
    start = projection.start
    if start is None:
        raise DurableCorruption(f"durable run {run_id} has no start declaration")
    builder = ViewBuilder(projection, storage, codecs, run_token)
    artifacts = builder.artifacts()
    trials = builder.trials()
    evidence = builder.all_evidence()

    decisions = [
        build_decision_view(recorded, projection, builder)
        for recorded in projection.decisions
    ]

    successful = tuple(
        item.evaluation
        for item in projection.completed_evaluations
        if item.evaluation.failure is None
    )
    best_trial = None
    if successful:
        best = builder.best_evaluation()
        best_trial = builder.trial(best.trial_id)
    stop = projection.stop
    overview = RunOverview(
        run_id=run_id,
        lifecycle="complete" if stop is not None else "incomplete",
        rankability="rankable" if successful else "unrankable",
        best_trial=best_trial,
        task_usage=_recorded_usage(projection.completed_trials, projection.completed_evaluations),
        experience_usage=aggregate_experience_usage(projection),
        stop_reason=stop.reason if stop is not None else None,
    )
    declaration = RunDeclaration(
        task_id=start.task_id,
        objectives=start.task.objectives,
        artifact_kind=start.task.artifact_kind,
        artifact_representation=start.task.artifact_representation,
        seed=builder.artifact(start.seed_artifact_id),
        evaluator=start.task.evaluator,
        proposer=start.search.proposer,
        search=start.search,
        task_budget=start.task.budget,
        effective_budget=start.run_budget,
        capabilities=start.capabilities,
        context=(
            projection.context_declaration.spec
            if projection.context_declaration is not None
            else None
        ),
        experience=(
            projection.experience_declaration.spec
            if projection.experience_declaration is not None
            else None
        ),
        random_seed=start.random_seed,
    )
    return RunInspection(
        overview=overview,
        declaration=declaration,
        trials=trials,
        decisions=tuple(decisions),
        evidence=evidence,
        artifacts=artifacts,
    )


__all__ = [
    "ArchiveDecisionView",
    "DecisionView",
    "RunDeclaration",
    "RunInspection",
    "RunOverview",
    "StopDecisionView",
    "TrialDecisionView",
    "build_decision_view",
    "inspect_run",
]
