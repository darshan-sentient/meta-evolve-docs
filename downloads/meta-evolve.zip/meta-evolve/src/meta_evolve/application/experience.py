"""Read-only causal and temporal views over committed run experience."""

from __future__ import annotations

from dataclasses import dataclass, replace

from meta_evolve.domain.experience import EXPERIENCE_KINDS, ExperienceRef
from meta_evolve.domain.identity import RunId, TaskId, TrialId
from meta_evolve.errors import ExperienceAccessDenied


_KIND_ORDER = {kind: index for index, kind in enumerate(EXPERIENCE_KINDS)}
@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceQuery:
    """Scope a graph query to one task and run, optionally at an event sequence.

    ``as_of`` bounds the visible committed history; ``None`` uses all of it.
    """

    task_id: TaskId
    run_id: RunId
    as_of: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.task_id, TaskId):
            raise TypeError("experience query task id must be a TaskId")
        if not isinstance(self.run_id, RunId):
            raise TypeError("experience query run id must be a RunId")
        if self.as_of is not None and (
            isinstance(self.as_of, bool)
            or not isinstance(self.as_of, int)
            or self.as_of < 0
        ):
            raise ValueError("experience query as_of must be a non-negative integer")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceRecord:
    """One committed observation with its reference, value, and history position."""

    ref: ExperienceRef
    task_id: TaskId
    logical_step: int
    event_sequence: int
    value: object

    @property
    def kind(self) -> str:
        return self.ref.kind

    def __post_init__(self) -> None:
        if not isinstance(self.ref, ExperienceRef):
            raise TypeError("experience record ref must be an ExperienceRef")
        if not isinstance(self.task_id, TaskId):
            raise TypeError("experience record task id must be a TaskId")
        for value, name in (
            (self.logical_step, "logical step"),
            (self.event_sequence, "event sequence"),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"experience record {name} must be non-negative")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceNode:
    """A trial in the experience graph, with its records and derivation references."""

    ref: ExperienceRef
    task_id: TaskId
    trial_id: TrialId
    logical_step: int
    records: tuple[ExperienceRecord, ...] = ()
    derived_from: tuple[ExperienceRef, ...] = ()

    @property
    def run_id(self) -> RunId:
        return self.ref.run_id

    def __post_init__(self) -> None:
        if not isinstance(self.ref, ExperienceRef) or self.ref.kind != "trial":
            raise TypeError("experience node ref must identify a trial")
        if not isinstance(self.task_id, TaskId):
            raise TypeError("experience node task id must be a TaskId")
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("experience node trial id must be a TrialId")
        if self.ref.occurrence_id != self.trial_id.value:
            raise ValueError("experience node ref must match its trial id")
        if (
            isinstance(self.logical_step, bool)
            or not isinstance(self.logical_step, int)
            or self.logical_step < 0
        ):
            raise ValueError("experience node logical step must be non-negative")
        if not isinstance(self.records, tuple) or any(
            not isinstance(item, ExperienceRecord) for item in self.records
        ):
            raise TypeError("experience node records must be ExperienceRecords")
        if not isinstance(self.derived_from, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.derived_from
        ):
            raise TypeError("experience node derivation must contain ExperienceRefs")
        if len(set(self.derived_from)) != len(self.derived_from):
            raise ValueError("experience node derivation references must be unique")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceState:
    """The nodes and records visible at an [ExperienceQuery][meta_evolve.ExperienceQuery]."""

    query: ExperienceQuery
    nodes: tuple[ExperienceNode, ...]
    records: tuple[ExperienceRecord, ...]


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceGraph:
    """Immutable graph projection; synthetic access sets are test-only seams."""

    run_id: RunId
    task_id: TaskId
    _records: tuple[ExperienceRecord, ...]
    _nodes: tuple[ExperienceNode, ...]
    _parents: tuple[tuple[ExperienceRef, tuple[ExperienceRef, ...]], ...]
    _record_owners: tuple[tuple[ExperienceRef, ExperienceRef | None], ...]
    _hidden_refs: frozenset[ExperienceRef] = frozenset()
    _retracted_refs: frozenset[ExperienceRef] = frozenset()
    _non_local_refs: frozenset[ExperienceRef] = frozenset()

    def _deny_bad_query(self, query: ExperienceQuery) -> None:
        if (
            not isinstance(query, ExperienceQuery)
            or query.run_id != self.run_id
            or query.task_id != self.task_id
        ):
            raise ExperienceAccessDenied()

    def _step_for(self, ref: ExperienceRef) -> int | None:
        node = next((item for item in self._nodes if item.ref == ref), None)
        if node is not None:
            return node.logical_step
        record = next((item for item in self._records if item.ref == ref), None)
        return record.logical_step if record is not None else None

    def _accessible(self, ref: ExperienceRef, query: ExperienceQuery) -> bool:
        step = self._step_for(ref)
        return (
            ref.run_id == self.run_id
            and query.run_id == self.run_id
            and query.task_id == self.task_id
            and step is not None
            and (query.as_of is None or step <= query.as_of)
            and ref not in self._hidden_refs
            and ref not in self._retracted_refs
            and ref not in self._non_local_refs
        )

    def _require_node(
        self, ref: ExperienceRef, query: ExperienceQuery
    ) -> ExperienceNode:
        self._deny_bad_query(query)
        if not isinstance(ref, ExperienceRef) or ref.kind != "trial":
            raise ExperienceAccessDenied()
        node = next((item for item in self._nodes if item.ref == ref), None)
        if node is None or not self._accessible(ref, query):
            raise ExperienceAccessDenied()
        return node

    def _parent_refs(self, ref: ExperienceRef) -> tuple[ExperienceRef, ...]:
        return next((parents for child, parents in self._parents if child == ref), ())

    def _child_refs(self, ref: ExperienceRef) -> tuple[ExperienceRef, ...]:
        return tuple(child for child, parents in self._parents if ref in parents)

    def _ordered_nodes(
        self, refs: set[ExperienceRef], query: ExperienceQuery
    ) -> tuple[ExperienceNode, ...]:
        selected = [
            item
            for item in self._nodes
            if item.ref in refs and self._accessible(item.ref, query)
        ]
        selected.sort(key=lambda item: (item.logical_step, item.trial_id.value))
        return tuple(self._view(item, query) for item in selected)

    def _view(self, node: ExperienceNode, query: ExperienceQuery) -> ExperienceNode:
        records = tuple(
            item
            for item in node.records
            if self._accessible(item.ref, query)
        )
        derived_from = tuple(
            reference
            for reference in node.derived_from
            if self._accessible(reference, query)
        )
        return replace(node, records=records, derived_from=derived_from)

    def node(self, ref: ExperienceRef, query: ExperienceQuery) -> ExperienceNode:
        return self._view(self._require_node(ref, query), query)

    def ancestors(
        self, ref: ExperienceRef, query: ExperienceQuery
    ) -> tuple[ExperienceNode, ...]:
        self._require_node(ref, query)
        found: set[ExperienceRef] = set()
        pending = list(self._parent_refs(ref))
        while pending:
            parent = pending.pop(0)
            if parent in found or not self._accessible(parent, query):
                continue
            found.add(parent)
            pending.extend(self._parent_refs(parent))
        return self._ordered_nodes(found, query)

    def children(
        self, ref: ExperienceRef, query: ExperienceQuery
    ) -> tuple[ExperienceNode, ...]:
        self._require_node(ref, query)
        return self._ordered_nodes(set(self._child_refs(ref)), query)

    def siblings(
        self, ref: ExperienceRef, query: ExperienceQuery
    ) -> tuple[ExperienceNode, ...]:
        self._require_node(ref, query)
        found = {ref}
        for parent in self._parent_refs(ref):
            if self._accessible(parent, query):
                found.update(self._child_refs(parent))
        return self._ordered_nodes(found, query)

    def _reachable_refs(self, query: ExperienceQuery) -> set[ExperienceRef]:
        roots = [item.ref for item in self._nodes if not self._parent_refs(item.ref)]
        reached: set[ExperienceRef] = set()
        pending = roots
        while pending:
            ref = pending.pop(0)
            if ref in reached or not self._accessible(ref, query):
                continue
            reached.add(ref)
            pending.extend(self._child_refs(ref))
        return reached

    def frontier(self, query: ExperienceQuery) -> tuple[ExperienceNode, ...]:
        self._deny_bad_query(query)
        reached = self._reachable_refs(query)
        leaves = {
            ref
            for ref in reached
            if not any(child in reached for child in self._child_refs(ref))
        }
        return self._ordered_nodes(leaves, query)

    def trace(
        self, ref: ExperienceRef, query: ExperienceQuery
    ) -> tuple[ExperienceRecord, ...]:
        node = self._require_node(ref, query)
        nodes = self.ancestors(ref, query) + (self._view(node, query),)
        records = [record for item in nodes for record in item.records]
        records.sort(
            key=lambda item: (item.event_sequence, _KIND_ORDER[item.ref.kind])
        )
        return tuple(records)

    def state_at(self, query: ExperienceQuery) -> ExperienceState:
        self._deny_bad_query(query)
        reached = self._reachable_refs(query)
        nodes = self._ordered_nodes(reached, query)
        owner_by_ref = dict(self._record_owners)
        records = tuple(
            item
            for item in self._records
            if self._accessible(item.ref, query)
            and (
                owner_by_ref.get(item.ref) is None
                or owner_by_ref[item.ref] in reached
            )
        )
        return ExperienceState(query=query, nodes=nodes, records=records)


__all__ = [
    "ExperienceAccessDenied",
    "ExperienceGraph",
    "ExperienceNode",
    "ExperienceQuery",
    "ExperienceRecord",
    "ExperienceState",
]
