"""Canonical metadata recovery and occurrence selection for source history."""

from __future__ import annotations

import json
from dataclasses import dataclass

from meta_evolve.domain import (
    ArchiveUpdate,
    ArtifactCreated,
    ArtifactId,
    Evaluation,
    ExperienceObservation,
    ExperienceRef,
    PolicyDecisionMade,
    Proposal,
    SourceHistoryBounds,
    SourceHistoryEntry,
    Trial,
    TrialOutcome,
)


HISTORY_RECORD_KINDS = (
    "artifact",
    "decision",
    "evaluation",
    "outcome",
    "proposal",
    "trial",
)


class SourceHistoryUnavailable(ValueError):
    """The authorized audit prefix cannot yield one complete history mount."""


@dataclass(frozen=True, slots=True)
class HistoryCandidate:
    artifact_ref: ExperienceRef
    distance: int | None
    archive_position: int | None


def _ref(run_id, kind: str, value) -> ExperienceRef:
    return ExperienceRef(
        run_id=run_id,
        kind=kind,
        occurrence_id=getattr(value, "value", value),
    )


class SourceHistoryFacts:
    def __init__(self, head_ref: ExperienceRef, observation: ExperienceObservation):
        self.run_id = head_ref.run_id
        values = tuple(record.value for record in observation.records)
        self.trials = {
            value.id: value for value in values if isinstance(value, Trial)
        }
        self.proposals = {
            value.trial_id: value for value in values if isinstance(value, Proposal)
        }
        self.outcomes = {
            value.trial_id: value for value in values if isinstance(value, TrialOutcome)
        }
        self.evaluations = {
            value.trial_id: value for value in values if isinstance(value, Evaluation)
        }
        self.artifact_refs = {
            ArtifactId(record.ref.occurrence_id): record.ref
            for record in observation.records
            if record.ref.kind == "artifact" and isinstance(record.value, ArtifactCreated)
        }
        self.artifact_trials = {
            artifact_id: trial_id
            for trial_id, outcome in self.outcomes.items()
            for artifact_id in outcome.artifact_ids
        }
        head_id = ArtifactId(head_ref.occurrence_id)
        try:
            self.head_trial_id = self.artifact_trials[head_id]
        except KeyError as error:
            raise SourceHistoryUnavailable(
                "source history head has no completed producing trial"
            ) from error
        self.head_trial_ref = _ref(self.run_id, "trial", self.head_trial_id)
        decisions = [
            value for value in values if isinstance(value, PolicyDecisionMade)
        ]
        self.archive = next(
            (
                value.decision.member_ids
                for value in reversed(decisions)
                if isinstance(value.decision, ArchiveUpdate)
            ),
            (),
        )
        self._require_metadata(head_id)

    def _require_metadata(self, artifact_id: ArtifactId) -> None:
        trial_id = self.artifact_trials.get(artifact_id)
        if (
            trial_id is None
            or trial_id not in self.trials
            or trial_id not in self.proposals
            or trial_id not in self.evaluations
            or artifact_id not in self.artifact_refs
        ):
            raise SourceHistoryUnavailable(
                "source history occurrence metadata is incomplete"
            )

    def select(
        self, bounds: SourceHistoryBounds, ancestors: ExperienceObservation
    ) -> tuple[HistoryCandidate, ...]:
        head_id = next(
            artifact_id
            for artifact_id, trial_id in self.artifact_trials.items()
            if trial_id == self.head_trial_id
            and self.artifact_refs.get(artifact_id) is not None
        )
        head_ref = self.artifact_refs[head_id]
        allowed_trials = set(ancestors.references)
        pending = [(parent, 1) for parent in self.trials[self.head_trial_id].spec.parent_ids]
        seen: set[ArtifactId] = set()
        ancestor_candidates: list[HistoryCandidate] = []
        while pending:
            artifact_id, distance = pending.pop(0)
            if artifact_id in seen:
                continue
            seen.add(artifact_id)
            self._require_metadata(artifact_id)
            trial_id = self.artifact_trials[artifact_id]
            if _ref(self.run_id, "trial", trial_id) not in allowed_trials:
                raise SourceHistoryUnavailable(
                    "source history ancestor traversal omitted a causal parent"
                )
            ancestor_candidates.append(
                HistoryCandidate(self.artifact_refs[artifact_id], distance, None)
            )
            pending.extend(
                (parent, distance + 1)
                for parent in self.trials[trial_id].spec.parent_ids
            )

        combined = [
            HistoryCandidate(head_ref, None, None),
            *ancestor_candidates[: bounds.max_ancestors],
        ]
        for position, artifact_id in enumerate(
            self.archive[: bounds.max_archive_members], start=1
        ):
            self._require_metadata(artifact_id)
            combined.append(
                HistoryCandidate(self.artifact_refs[artifact_id], None, position)
            )
        unique: list[HistoryCandidate] = []
        selected: set[ExperienceRef] = set()
        for candidate in combined:
            if candidate.artifact_ref in selected:
                continue
            selected.add(candidate.artifact_ref)
            unique.append(candidate)
        return tuple(unique)

    def entry(self, candidate, digest, retained_refs) -> SourceHistoryEntry:
        artifact_id = ArtifactId(candidate.artifact_ref.occurrence_id)
        trial_id = self.artifact_trials[artifact_id]
        trial = self.trials[trial_id]
        proposal = self.proposals[trial_id]
        evaluation = self.evaluations[trial_id]
        parents = tuple(
            self.artifact_refs[parent]
            for parent in trial.spec.parent_ids
            if self.artifact_refs.get(parent) in retained_refs
        )
        if candidate.distance is not None:
            rationale = f"ancestor distance {candidate.distance}"
        elif candidate.archive_position is not None:
            rationale = f"archive position {candidate.archive_position}"
        else:
            rationale = "selected parent"
        return SourceHistoryEntry(
            artifact_ref=candidate.artifact_ref,
            digest=digest,
            parent_refs=parents,
            logical_step=trial.logical_step,
            proposal_ref=_ref(self.run_id, "proposal", proposal.id),
            evaluation_ref=_ref(self.run_id, "evaluation", evaluation.id),
            selection_rationale=rationale,
        )

    def message(self, artifact_ref: ExperienceRef) -> tuple[str | None, str]:
        artifact_id = ArtifactId(artifact_ref.occurrence_id)
        trial_id = self.artifact_trials[artifact_id]
        evaluation = self.evaluations[trial_id]
        failure = evaluation.failure.kind if evaluation.failure is not None else None
        summary = json.dumps(
            {
                "failure": failure,
                "metrics": dict(evaluation.metrics.items()),
                "uncertainty": dict(evaluation.uncertainty.items()),
            },
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        return self.proposals[trial_id].hypothesis, summary


__all__ = [
    "HISTORY_RECORD_KINDS",
    "HistoryCandidate",
    "SourceHistoryFacts",
    "SourceHistoryUnavailable",
]
