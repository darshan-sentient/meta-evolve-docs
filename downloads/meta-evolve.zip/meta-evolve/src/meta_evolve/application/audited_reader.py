"""Grant-bound experience reader with durable operation auditing."""

from __future__ import annotations

from dataclasses import replace
from typing import Callable

from meta_evolve.domain import (
    ExperienceFilter,
    ExperienceGrant,
    ExperienceObservation,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationId,
    ExperienceOperationSucceeded,
    ExperienceRequest,
    ExperienceUsage,
    SourceHistoryManifest,
    SourceHistoryMounted,
)
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.errors import ExperienceAccessDenied, ExperienceBudgetExhausted

from .experience import ExperienceGraph
from .experience_contract import request_is_malformed
from .experience_operations import execute_request
from .identities import stable_id
from .run_projection import RunProjection


class AuditedExperienceReader:
    """A capability scoped to one grant and its committed operations."""

    def __init__(
        self,
        *,
        grant: ExperienceGrant,
        projection: Callable[[], RunProjection],
        graph: Callable[[], ExperienceGraph],
        append: Callable[[object], object],
        resolve_source: Callable[[object], object] | None = None,
    ) -> None:
        self._grant = grant
        self._projection = projection
        self._graph = graph
        self._append = append
        self._resolve_source = resolve_source
        self._cursor = 0
        self._graph_view: ExperienceGraph | None = None

    @property
    def grant(self) -> ExperienceGrant:
        return self._grant

    def search(
        self,
        *,
        record_kinds=(),
        failure_kinds=(),
        as_of=None,
        limit=None,
    ) -> ExperienceObservation:
        return self._call(
            ExperienceRequest(
                operation="search",
                filters=ExperienceFilter(
                    record_kinds=record_kinds,
                    failure_kinds=failure_kinds,
                ),
                as_of=as_of,
                limit=limit,
            )
        )

    def open(self, ref, *, as_of=None) -> ExperienceObservation:
        return self._call(
            ExperienceRequest(operation="open", ref=ref, as_of=as_of)
        )

    def ancestors(self, trial_ref, *, as_of=None, limit=None):
        return self._call(
            ExperienceRequest(
                operation="ancestors",
                ref=trial_ref,
                as_of=as_of,
                limit=limit,
            )
        )

    def siblings(self, trial_ref, *, as_of=None, limit=None):
        return self._call(
            ExperienceRequest(
                operation="siblings",
                ref=trial_ref,
                as_of=as_of,
                limit=limit,
            )
        )

    def compare(self, left_trial_ref, right_trial_ref, *, as_of=None):
        return self._call(
            ExperienceRequest(
                operation="compare",
                ref=left_trial_ref,
                other_ref=right_trial_ref,
                as_of=as_of,
            )
        )

    def list_source_paths(self, artifact_ref, *, as_of=None, limit=None):
        return self._call(
            ExperienceRequest(
                operation="list_source_paths",
                ref=artifact_ref,
                as_of=as_of,
                limit=limit,
            )
        )

    def read_source(self, artifact_ref, *, paths, as_of=None):
        return self._call(
            ExperienceRequest(
                operation="read_source",
                ref=artifact_ref,
                paths=paths,
                as_of=as_of,
            )
        )

    def diff_source(
        self,
        older_artifact_ref,
        newer_artifact_ref,
        *,
        paths=(),
        as_of=None,
    ):
        return self._call(
            ExperienceRequest(
                operation="diff_source",
                ref=older_artifact_ref,
                other_ref=newer_artifact_ref,
                paths=paths,
                as_of=as_of,
            )
        )

    def _mount_source_history(self, manifest: SourceHistoryManifest) -> None:
        """Commit or replay the one mount fact owned by this reader's trial."""

        if not isinstance(manifest, SourceHistoryManifest):
            raise TypeError("source history mount requires a SourceHistoryManifest")
        projection = self._projection()
        existing = projection.source_history_for(self._grant.trial_id)
        if existing is not None:
            if existing.manifest != manifest:
                raise InvalidSearchHistory(
                    "committed source history mount does not match replay"
                )
            return
        self._append(
            SourceHistoryMounted(
                trial_id=self._grant.trial_id,
                observed_version=projection.version,
                manifest=manifest,
            )
        )

    def _scoped_graph(self) -> ExperienceGraph:
        if self._graph_view is None:
            self._graph_view = self._graph()
        return self._graph_view

    def _call(self, request: ExperienceRequest):
        committed = self._projection().operations_for(self._grant.trial_id)
        if self._cursor < len(committed):
            attempt, resolution = committed[self._cursor]
            is_trailing = self._cursor == len(committed) - 1
            self._cursor += 1
            if attempt.request != request:
                raise InvalidSearchHistory(
                    "committed experience operation does not match replay request"
                )
            if resolution is not None:
                return _committed_outcome(resolution)
            if not is_trailing:
                raise InvalidSearchHistory(
                    "unresolved experience operation is not trailing"
                )
            return self._resolve(attempt.operation_id, attempt.usage, request)

        prior = _last_usage(committed)
        operation_id = stable_id(
            ExperienceOperationId,
            "experience-operation",
            self._grant.trial_id.value,
            len(committed) + 1,
        )
        attempted = replace(prior, operations=prior.operations + 1)
        self._append(
            ExperienceOperationAttempted(
                operation_id=operation_id,
                trial_id=self._grant.trial_id,
                request=request,
                usage=attempted,
            )
        )
        self._cursor += 1
        return self._resolve(operation_id, attempted, request)

    def _resolve(self, operation_id, attempted, request: ExperienceRequest):
        if attempted.operations > self._grant.spec.max_operations:
            return self._exhaust(operation_id, attempted)
        if request_is_malformed(request):
            return self._deny(operation_id, attempted)
        if request.as_of is not None and request.as_of > self._grant.as_of:
            return self._deny(operation_id, attempted)
        effective = replace(
            request,
            as_of=self._grant.as_of if request.as_of is None else request.as_of,
        )
        try:
            result = execute_request(
                self._scoped_graph(),
                effective,
                attempted,
                max_results=self._grant.spec.max_results,
                max_records=self._grant.spec.max_records,
                max_chars=self._grant.spec.max_chars,
                resolve_source=self._resolve_source,
            )
        except ExperienceAccessDenied:
            return self._deny(operation_id, attempted)
        except ExperienceBudgetExhausted:
            return self._exhaust(operation_id, attempted)
        self._append(
            ExperienceOperationSucceeded(
                operation_id=operation_id,
                trial_id=self._grant.trial_id,
                result=result,
            )
        )
        return result

    def _deny(self, operation_id, usage):
        self._append(
            ExperienceOperationDenied(
                operation_id=operation_id,
                trial_id=self._grant.trial_id,
                usage=usage,
            )
        )
        raise ExperienceAccessDenied()

    def _exhaust(self, operation_id, usage):
        self._append(
            ExperienceOperationBudgetExhausted(
                operation_id=operation_id,
                trial_id=self._grant.trial_id,
                usage=usage,
            )
        )
        raise ExperienceBudgetExhausted()


def _last_usage(operations) -> ExperienceUsage:
    if not operations:
        return ExperienceUsage()
    resolution = operations[-1][1]
    assert resolution is not None
    if isinstance(resolution, ExperienceOperationSucceeded):
        return resolution.result.usage
    return resolution.usage


def _committed_outcome(resolution):
    if isinstance(resolution, ExperienceOperationSucceeded):
        return resolution.result
    if isinstance(resolution, ExperienceOperationBudgetExhausted):
        raise ExperienceBudgetExhausted()
    raise ExperienceAccessDenied()


__all__ = ["AuditedExperienceReader"]
