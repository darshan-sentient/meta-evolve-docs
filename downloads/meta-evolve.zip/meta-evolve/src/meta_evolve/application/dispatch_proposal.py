"""Execute and commit proposal work independently of dispatcher scheduling."""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    CorrelationId,
    RunId,
    Task,
    Trial,
    TrialId,
)
from meta_evolve.domain.work import Lease
from meta_evolve.ports import ArtifactStore
from meta_evolve.ports.runners import ProposerRunner
from meta_evolve.domain.work import WorkKind, WorkRow
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.work_store import (
    AcceptCompletion,
    Acknowledgment,
    EnqueueWork,
    WorkIntent,
)

from .committed_fold import fold_committed
from .batch_envelopes import batch_envelopes
from .execution import ExecutionHost, load_parents
from .executors import EncodedProposal, ProposalExecutor, ProposalRequest
from .run_projection import RunProjection
from .identities import completion_key_for
from .proposal_building import build_proposal_completion
from .work import (
    DEFAULT_MAX_ATTEMPTS,
    ProposalWork,
    terminal_ending,
)


class ProposalDispatchHost(ExecutionHost, Protocol):
    """Coordinator state and commit authority needed for proposal work."""

    run_id: RunId
    task: Task
    proposer_runner: ProposerRunner
    artifacts: ArtifactStore

    @property
    def projection(self) -> RunProjection: ...


def complete_proposal(
    host: ProposalDispatchHost,
    row: WorkRow,
    lease: Lease,
    *,
    executor: ProposalExecutor,
    correlation: CorrelationId,
    keepalive: Callable[[], tuple[Lease, int]],
) -> None:
    """Resolve, execute and finish one proposal, with no failure boundary.

    The dispatcher calls the three stages itself, because a fault before the
    component returns and a fault after it are handled differently.
    """

    trial, parents, request = resolve_proposal(host, row)
    finish_proposal(
        host,
        lease,
        trial,
        executor.propose(parents, request),
        parents,
        correlation=correlation,
        keepalive=keepalive,
    )


def resolve_proposal(
    host: ProposalDispatchHost, row: WorkRow
) -> tuple[Trial, tuple[Artifact, ...], ProposalRequest]:
    """Input resolution: the decided trial, its loaded parents, and the request."""

    trial = decided_trial(host, row.trial_id)
    request = ProposalRequest(
        random_seed=trial.spec.random_seed,
        step=trial.logical_step,
        objectives=host.task.objectives,
    )
    return trial, load_parents(host.artifacts, trial.spec.parent_ids), request


def finish_proposal(
    host: ProposalDispatchHost,
    lease: Lease,
    trial: Trial,
    encoded: EncodedProposal,
    parents: tuple[Artifact, ...],
    *,
    correlation: CorrelationId,
    keepalive: Callable[[], tuple[Lease, int]],
) -> None:
    """Commit a proposal's facts, the acceptance, and the evaluation it makes owed
    -- as one transaction.

    "Completion validates, appends the logical batch, enqueues dependent
    evaluation work, and stores an acknowledgment -- all atomically."

    The dependent enqueue is CONDITIONAL: only a trial whose disposition
    says *evaluate* owes one. That disposition is pinned by the very batch
    being committed, so it is read from a provisional fold of these bodies
    rather than back off the store afterwards. The same pure function on the
    same events, which is why it cannot disagree with what the fold decides
    -- and why the enqueue can ride the transaction instead of chasing it.
    """

    work = ProposalWork(
        trial=trial,
        completion_key=completion_key_for(trial.id),
    )
    built = build_proposal_completion(host, work, encoded, parents=parents)

    provisional = host.projection
    for envelope in batch_envelopes(
        host.run_id, built.bodies, correlation, provisional
    ):
        provisional = fold_committed(provisional, envelope)

    # AFTER the build and the fold, immediately before the commit: the lease
    # this batch is accepted under must still be ours, and the reading that
    # proves it is the one the intent carries into the transaction. Checking
    # before the build would leave the build, the fold and the disposition read
    # unguarded. REQUIRED, not defaulted -- an optional safety check is one a
    # future caller drops by forgetting it.
    live, now = keepalive()

    intents: list[WorkIntent] = [
        AcceptCompletion(
            lease=live,
            now=now,
            acknowledgment=Acknowledgment({"trial_id": trial.id.value}),
        )
    ]
    # `is True` rather than truthiness: the disposition is three-valued and
    # only *evaluate* authorizes the dependent work. #217 came from reading
    # a three-valued answer as if it were two-valued.
    if provisional.disposition_for(trial.id) is True:
        intents.append(
            EnqueueWork(
                row=WorkRow.enqueued(
                    run_id=host.run_id,
                    trial_id=trial.id,
                    kind=WorkKind.EVALUATION,
                    max_attempts=DEFAULT_MAX_ATTEMPTS,
                )
            )
        )

    host.commit_batch(
        list(built.bodies),
        occurrences=built.occurrences,
        correlation=correlation,
        work=tuple(intents),
    )


def terminate_proposal(
    host: ProposalDispatchHost, row: WorkRow, *, correlation: CorrelationId
) -> None:
    """The exhausted proposal's facts, through the one builder that makes them.

    Deliberately NOT hand-built. `build_proposal_completion` already knows
    the shape a failed proposal takes -- the submitted proposal the fold
    requires a completed trial to match, the trial count the coordinator
    mints, the usage adjudication -- and writing a second way to produce a
    failed trial is how the two come to disagree. Handing it a typed failure
    is the whole difference between this and an ordinary failed attempt.
    """

    ending = terminal_ending(row)
    trial = decided_trial(host, row.trial_id)
    work = ProposalWork(
        trial=trial,
        completion_key=completion_key_for(trial.id),
    )
    built = build_proposal_completion(
        host,
        work,
        EncodedProposal.failed(host.task, ending.failure),
    )
    host.commit_batch(
        list(built.bodies),
        occurrences=built.occurrences,
        correlation=correlation,
        work=(ending.intent,),
    )


def decided_trial(host: ProposalDispatchHost, trial_id: TrialId) -> Trial:
    """The trial a decision authorized, rebuilt from its record.

    `Trial.from_decision_record`, exactly as the writer and resume both do,
    so all three build byte-identical trials from one recorded decision.
    """

    for record in host.projection.decisions:
        if record.trial_id == trial_id:
            return Trial.from_decision_record(
                record, host.run_id
            )
    raise DurableCorruption(
        f"proposal work for undecided trial {trial_id.value}"
    )


__all__ = [
    "complete_proposal",
    "decided_trial",
    "finish_proposal",
    "resolve_proposal",
    "terminate_proposal",
]
