"""Prepare fresh and recovered execution behind one Session boundary.

This order-sensitive module stays whole slightly beyond the usual file-size
guideline: start and resume must return the same prepared value while retaining
their established, independently tested validation order.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256

from meta_evolve import serialization
from meta_evolve.adapters import CallableEvaluator
from meta_evolve.domain import (
    Budget,
    ComponentRef,
    LEGACY_LOCAL_CAPABILITIES,
    PolicyRef,
    RunCapabilities,
    RunId,
    SearchProgram,
    Task,
    TaskId,
)
from meta_evolve.errors import CapabilityError, RunError
from meta_evolve.manifests import require_resumable, verify_manifests
from meta_evolve.policies import Greedy
from meta_evolve.ports.callables import Evaluator
from meta_evolve.ports.runners import ProposerRunner
from meta_evolve.registry import Registry

from .codecs import BUILTIN_CODECS, CodecIndex
from .context_search import ContextSearchProgram
from .coordinator import SequentialCoordinator
from .durable_loading import load_validated_run
from .experiment import Experiment
from .recovery import RecoveryPhase, classify_frontier
from .results import Run
from .run_support import (
    EXECUTION_MODES,
    ExecutionMode,
    component_proposer,
    normalize_context,
    normalize_experience,
    resolve_registered_components,
    run_id_for,
    validate_proposer_run,
)
from .search_preparation import prepare_search
from .storage import Storage


@dataclass(frozen=True, slots=True)
class _PreparedSession:
    coordinator: SequentialCoordinator
    program: SearchProgram
    run: Run
    phase: RecoveryPhase


def prepare_start(
    experiment: Experiment,
    /,
    *,
    storage: Storage | None = None,
    budget: Budget | None = None,
    mode: ExecutionMode = "local",
) -> _PreparedSession:
    """Validate and atomically bootstrap one fresh execution session."""

    if not isinstance(experiment, Experiment):
        raise TypeError("experiment must be an Experiment")
    task = experiment.task
    proposer = experiment.proposer
    registry = experiment.registry
    if not isinstance(task, Task):
        raise TypeError("task must be a Task")
    if registry is not None and not isinstance(registry, Registry):
        raise TypeError("registry must be a Registry")
    stores = storage or Storage.in_memory()
    if not isinstance(stores, Storage):
        raise TypeError("storage must be Storage")
    if stores.is_read_only:
        raise CapabilityError(
            "run requires writable storage; Storage.read_only(...) has no "
            "execution or commit authority"
        )
    codecs = (
        CodecIndex.with_extras(registry.artifact_types())
        if registry is not None
        else CodecIndex.builtin()
    )
    seed_payload = codecs.encode(
        task.artifact_kind, task.artifact_representation, experiment.seed
    )
    if mode not in EXECUTION_MODES:
        raise ValueError(f"run mode must be one of {EXECUTION_MODES}, got {mode!r}")
    if isinstance(experiment.random_seed, bool) or not isinstance(
        experiment.random_seed, int
    ):
        raise TypeError("random_seed must be an integer")
    if budget is not None and not isinstance(budget, Budget):
        raise TypeError("budget must be a Budget")
    effective = budget or task.budget or Budget()
    if task.budget is not None and task.budget.narrow(effective) != effective:
        raise ValueError("run budget cannot widen the task budget")
    experience_spec = normalize_experience(experiment.experience)

    proposer_runner: ProposerRunner
    evaluator: Evaluator
    if mode == "durable-local":
        # Everything below must be validated before coordinator.start is
        # ever called: a bad durable-local configuration writes no events.
        if not stores.is_durable:
            raise CapabilityError(
                "durable-local mode requires durable storage (Storage.durable(...))"
            )
        if registry is None:
            raise CapabilityError("durable-local mode requires a component registry")
        if not isinstance(proposer, ComponentRef) or proposer.origin != "registered":
            raise CapabilityError(
                "durable-local mode requires a registered proposer component "
                "reference (name@version), not a plain callable or local closure"
            )
        if (
            not isinstance(task.evaluator, ComponentRef)
            or task.evaluator.origin != "registered"
        ):
            raise CapabilityError(
                "durable-local mode requires a registered evaluator component "
                "reference (name@version): task.evaluator must not be a plain "
                "callable or local closure"
            )
        if (task.artifact_kind, task.artifact_representation) not in BUILTIN_CODECS:
            # A custom codec is a live object, not a source function, so it
            # carries no manifest and resume cannot verify that the code
            # rebuilding a payload is the code that wrote it.
            raise CapabilityError(
                "durable-local mode requires a built-in artifact "
                "(kind, representation): a registered artifact codec carries "
                "no manifest, so a resumed run cannot verify it"
            )
        proposer_ref = proposer
        proposer_runner, evaluator = resolve_registered_components(
            registry, proposer_ref, task, codecs
        )
    else:
        proposer_runner, proposer_ref = component_proposer(proposer, codecs)
        try:
            evaluator = CallableEvaluator(task.evaluator, task.objectives)
        except (TypeError, ValueError) as error:
            raise ValueError(
                "M1 local runs require a live callable evaluator"
            ) from error

    validate_proposer_run(
        proposer_runner,
        artifact_kind=task.artifact_kind,
        artifact_representation=task.artifact_representation,
        objectives=task.objectives,
        budget=effective,
        experience=experience_spec,
    )
    prepared_search = prepare_search(
        experiment.search if experiment.search is not None else Greedy(),
        proposer=proposer_ref,
        budget=effective,
    )
    context_selector, context_spec = normalize_context(experiment.context)

    if mode == "durable-local":
        assert registry is not None
        # Execute the *registry-resolved* program, never the caller's search
        # object. A caller-supplied program can advertise a registered policy
        # ref plus matching configuration yet implement arbitrary next(); that
        # would record a manifest describing code that never ran and diverge
        # from resume (which rebuilds from the registry). resolve_policy
        # rebuilds the bound program from the registry and asserts the rebuilt
        # SearchSpec equals the declaration, so what runs is what is recorded.
        prepared_search = registry.resolve_policy(
            prepared_search.spec, budget=effective
        )
        if context_spec is not None:
            # Rebuild the context selector from the registry too, so fresh and
            # resumed sessions drive the IDENTICAL resolved ContextPolicy
            # rather than the caller's live object. An unregistered context
            # policy fails closed here (resolve_context_policy raises
            # CapabilityError) BEFORE any event is written.
            context_selector = registry.resolve_context_policy(context_spec)
        # Experience needs no registry: its only user surface is the recorded
        # ExperienceSpec (bounds), and the reader is deterministic kernel code
        # rebuilt from the spec alone on resume. So it carries no manifest.
        manifests = registry.manifests_for(
            proposer=proposer_ref,
            evaluator=task.evaluator,
            search=prepared_search.spec,
            context=context_spec,
        )
        # A run is never recorded resumable on a component declared
        # non-deterministic or non-retry-safe (equivalence is scoped to both).
        # The context manifest, when present, flows through this gate too.
        require_resumable(manifests)
        capabilities = RunCapabilities(
            mode="durable-local",
            resumable=True,
            component_manifests=manifests,
        )
    else:
        capabilities = LEGACY_LOCAL_CAPABILITIES

    program = _with_context(
        prepared_search.program,
        context_spec.policy if context_spec is not None else None,
    )
    run_id = run_id_for(
        task,
        seed_payload,
        proposer_ref,
        prepared_search.spec.policy,
        effective,
        experiment.random_seed,
        prepared_search.identity_key,
        context_spec,
        experience_spec,
    )
    if stores.events.read(run_id):
        raise RunError("an identical run already exists in this storage")
    task_digest = sha256(serialization.identity_content(task).encode()).hexdigest()
    coordinator = SequentialCoordinator(
        run_id=run_id,
        task_id=TaskId(f"task-{task_digest}"),
        task=task,
        run_budget=effective,
        random_seed=experiment.random_seed,
        search=prepared_search.spec,
        proposer_runner=proposer_runner,
        proposer_ref=proposer_ref,
        evaluator=evaluator,
        storage=stores,
        codecs=codecs,
        capabilities=capabilities,
        context_selector=context_selector,
        experience_spec=experience_spec,
    )
    if mode == "durable-local":
        # Fold the context/experience declarations INTO the atomic genesis
        # batch so a durable-local run exists IFF its declarations are present
        # (closes the genesis-only window). No separate declare_* commits here.
        coordinator.start(
            seed_payload,
            context_spec=context_spec,
            experience_spec=experience_spec,
        )
    else:
        # Local mode is UNCHANGED: genesis stays declaration-free and the
        # declarations commit as separate standalone facts, byte-identically.
        coordinator.start(seed_payload)
        coordinator.declare_context(context_spec)
        coordinator.declare_experience(experience_spec)
    return _PreparedSession(
        coordinator=coordinator,
        program=program,
        run=Run._reopen(run_id, stores, codecs),
        phase=RecoveryPhase.DECISION_READY,
    )


def prepare_resume(
    run_id: RunId,
    /,
    *,
    storage: Storage,
    registry: Registry,
) -> _PreparedSession:
    """Validate and reconstruct a durable session without completing work."""

    if not isinstance(storage, Storage):
        raise TypeError("storage must be Storage")
    if not storage.is_durable:
        raise CapabilityError(
            "resume requires durable storage (Storage.durable(...))"
        )
    if storage.is_read_only:
        raise CapabilityError(
            "resume requires writable storage; Storage.read_only(...) has no "
            "execution or commit authority"
        )
    if not isinstance(registry, Registry):
        raise CapabilityError("resume requires a component registry")
    # Resuming a run whose artifact kind is not in this index fails closed at
    # the first decode, inside ``CodecIndex.resolve``.
    codecs = CodecIndex.with_extras(registry.artifact_types())
    loaded = load_validated_run(storage, run_id, require_existing=True)
    projection = loaded.projection
    start = projection.start
    assert start is not None
    caps = start.capabilities
    if caps.mode != "durable-local" or not caps.resumable:
        raise CapabilityError(
            f"run {run_id} is not resumable (mode={caps.mode!r}, "
            f"resumable={caps.resumable}): only durable-local runs resume"
        )
    context_spec = (
        projection.context_declaration.spec
        if projection.context_declaration is not None
        else None
    )
    experience_spec = (
        projection.experience_declaration.spec
        if projection.experience_declaration is not None
        else None
    )
    supplied = registry.manifests_for(
        proposer=start.search.proposer,
        evaluator=start.task.evaluator,
        search=start.search,
        context=context_spec,
    )
    verify_manifests(caps.component_manifests, supplied)
    require_resumable(caps.component_manifests)
    prepared_search = registry.resolve_policy(start.search, budget=start.run_budget)
    proposer_runner, evaluator = resolve_registered_components(
        registry, start.search.proposer, start.task, codecs
    )
    validate_proposer_run(
        proposer_runner,
        artifact_kind=start.task.artifact_kind,
        artifact_representation=start.task.artifact_representation,
        objectives=start.task.objectives,
        budget=start.run_budget,
        experience=experience_spec,
    )
    context_selector = (
        registry.resolve_context_policy(context_spec)
        if context_spec is not None
        else None
    )
    coordinator = SequentialCoordinator(
        run_id=run_id,
        task_id=start.task_id,
        task=start.task,
        run_budget=start.run_budget,
        random_seed=start.random_seed,
        search=start.search,
        proposer_runner=proposer_runner,
        proposer_ref=start.search.proposer,
        evaluator=evaluator,
        storage=storage,
        codecs=codecs,
        capabilities=caps,
        projection=projection,
        committed_bodies=[event.body for event in loaded.events],
        context_selector=context_selector,
        experience_spec=experience_spec,
    )
    return _PreparedSession(
        coordinator=coordinator,
        program=_with_context(
            prepared_search.program,
            context_spec.policy if context_spec is not None else None,
        ),
        run=Run._reopen(run_id, storage, codecs),
        phase=classify_frontier(loaded.events, projection),
    )


def _with_context(
    program: SearchProgram, policy: PolicyRef | None
) -> SearchProgram:
    """Push a declared context policy to the proposer; drive bare otherwise."""

    return ContextSearchProgram(program, policy) if policy is not None else program


__all__ = ["prepare_resume", "prepare_start"]
