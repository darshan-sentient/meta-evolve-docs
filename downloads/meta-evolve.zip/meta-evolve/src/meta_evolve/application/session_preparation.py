"""Prepare fresh and recovered execution behind one Session boundary.

This order-sensitive module is kept whole well past the ~300-line guideline
because start and resume must return the same prepared value while retaining
their established, independently tested validation order. Its ceiling lives in
`tests/_file_length_baseline.py`, not here, so this note cannot go stale.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256

from meta_evolve import serialization
from meta_evolve.adapters import CallableEvaluator
from meta_evolve.domain import (
    Budget,
    ComponentRef,
    LEGACY_LOCAL_CAPABILITIES,
    PolicyRef,
    RunCapabilities,
    RunId,
    SearchProgram,
    Task,
    TaskId,
)
from meta_evolve.errors import CapabilityError, RunError
from meta_evolve.manifests import (
    components_admit,
    require_components_for,
    verify_manifests,
)
from meta_evolve.policies import Greedy
from meta_evolve.ports.callables import Evaluator
from meta_evolve.ports.runners import ProposerRunner
from meta_evolve.registry import Registry

from .codecs import BUILTIN_CODECS, CodecIndex
from .context_search import ContextSearchProgram
from .coordinator import SequentialCoordinator
from .durable_loading import load_validated_run
from .experiment import Experiment
from .recovery import RecoveryPhase, classify_frontier
from .results import Run
from meta_evolve.environment import environment_fingerprint

from .distributed_admission import check_distributed_admission
from .run_support import (
    EXECUTION_MODES,
    ExecutionMode,
    component_proposer,
    normalize_context,
    normalize_experience,
    resolve_registered_components,
    run_id_for,
    validate_proposer_run,
)
from .search_preparation import prepare_search, refuse_wide_cohort
from .storage import Storage
from .resume_admission import require_resumable_run


@dataclass(frozen=True, slots=True)
class _PreparedSession:
    coordinator: SequentialCoordinator
    program: SearchProgram
    run: Run
    phase: RecoveryPhase


def _resolve_run_budget(task_budget: Budget | None, override: Budget | None) -> Budget:
    """Inherit omitted task ceilings while refusing explicitly wider limits."""

    if task_budget is None:
        return override if override is not None else Budget()
    if override is None:
        return task_budget
    for name in ("evaluations", "trials", "tokens", "spend_micros", "wall_seconds"):
        ceiling, supplied = getattr(task_budget, name), getattr(override, name)
        if ceiling is not None and supplied is not None and supplied > ceiling:
            raise ValueError("run budget cannot widen the task budget")
    return task_budget.narrow(override)


def prepare_start(
    experiment: Experiment,
    /,
    *,
    storage: Storage | None = None,
    budget: Budget | None = None,
    mode: ExecutionMode = "local",
) -> _PreparedSession:
    """Validate and atomically bootstrap one fresh execution session."""

    if not isinstance(experiment, Experiment):
        raise TypeError("experiment must be an Experiment")
    task = experiment.task
    proposer = experiment.proposer
    registry = experiment.registry
    if not isinstance(task, Task):
        raise TypeError("task must be a Task")
    if registry is not None and not isinstance(registry, Registry):
        raise TypeError("registry must be a Registry")
    stores = storage or Storage.in_memory()
    if not isinstance(stores, Storage):
        raise TypeError("storage must be Storage")
    if stores.is_read_only:
        raise CapabilityError(
            "run requires writable storage; Storage.read_only(...) has no "
            "execution or commit authority"
        )
    codecs = (
        CodecIndex.with_extras(registry.artifact_types())
        if registry is not None
        else CodecIndex.builtin()
    )
    seed_payload = codecs.encode(
        task.artifact_kind, task.artifact_representation, experiment.seed
    )
    if mode not in EXECUTION_MODES:
        raise ValueError(f"run mode must be one of {EXECUTION_MODES}, got {mode!r}")
    if isinstance(experiment.random_seed, bool) or not isinstance(
        experiment.random_seed, int
    ):
        raise TypeError("random_seed must be an integer")
    if budget is not None and not isinstance(budget, Budget):
        raise TypeError("budget must be a Budget")
    effective = _resolve_run_budget(task.budget, budget)
    experience_spec = normalize_experience(experiment.experience)

    proposer_runner: ProposerRunner
    evaluator: Evaluator
    # `distributed` adopts durable-local's component discipline whole --
    # registered components, manifests, built-in codecs -- hence membership
    # rather than equality.
    if mode in ("durable-local", "distributed"):
        # Everything below must be validated before coordinator.start is
        # ever called: a bad configuration writes no events.
        if not stores.is_durable:
            raise CapabilityError(
                f"{mode} mode requires durable storage (Storage.durable(...))"
            )
        if registry is None:
            raise CapabilityError(f"{mode} mode requires a component registry")
        if not isinstance(proposer, ComponentRef) or proposer.origin != "registered":
            raise CapabilityError(
                f"{mode} mode requires a registered proposer component "
                "reference (name@version), not a plain callable or local closure"
            )
        if (
            not isinstance(task.evaluator, ComponentRef)
            or task.evaluator.origin != "registered"
        ):
            raise CapabilityError(
                f"{mode} mode requires a registered evaluator component "
                "reference (name@version): task.evaluator must not be a plain "
                "callable or local closure"
            )
        if (task.artifact_kind, task.artifact_representation) not in BUILTIN_CODECS:
            # A custom codec is a live object, not a source function, so it
            # carries no manifest and resume cannot verify that the code
            # rebuilding a payload is the code that wrote it.
            raise CapabilityError(
                f"{mode} mode requires a built-in artifact "
                "(kind, representation): a registered artifact codec carries "
                "no manifest, so a resumed run cannot verify it"
            )
        proposer_ref = proposer
        proposer_runner, evaluator = resolve_registered_components(
            registry, proposer_ref, task, codecs
        )
    else:
        proposer_runner, proposer_ref = component_proposer(proposer, codecs)
        try:
            evaluator = CallableEvaluator(task.evaluator, task.objectives)
        except (TypeError, ValueError) as error:
            raise ValueError(
                "M1 local runs require a live callable evaluator"
            ) from error

    validate_proposer_run(
        proposer_runner,
        artifact_kind=task.artifact_kind,
        artifact_representation=task.artifact_representation,
        objectives=task.objectives,
        budget=effective,
        experience=experience_spec,
    )
    prepared_search = prepare_search(
        experiment.search if experiment.search is not None else Greedy(),
        proposer=proposer_ref,
        budget=effective,
    )
    context_selector, context_spec = normalize_context(experiment.context)

    if mode in ("durable-local", "distributed"):
        assert registry is not None
        # Execute the *registry-resolved* program, never the caller's search
        # object. A caller-supplied program can advertise a registered policy
        # ref plus matching configuration yet implement arbitrary next(); that
        # would record a manifest describing code that never ran and diverge
        # from resume (which rebuilds from the registry). resolve_policy
        # rebuilds the bound program from the registry and asserts the rebuilt
        # SearchSpec equals the declaration, so what runs is what is recorded.
        prepared_search = registry.resolve_policy(
            prepared_search.spec, budget=effective
        )
        if context_spec is not None:
            # Rebuild the context selector from the registry too, so fresh and
            # resumed sessions drive the IDENTICAL resolved ContextPolicy
            # rather than the caller's live object. An unregistered context
            # policy fails closed here (resolve_context_policy raises
            # CapabilityError) BEFORE any event is written.
            context_selector = registry.resolve_context_policy(context_spec)
        # Experience needs no registry: its only user surface is the recorded
        # ExperienceSpec (bounds), and the reader is deterministic kernel code
        # rebuilt from the spec alone on resume. So it carries no manifest.
        manifests = registry.manifests_for(
            proposer=proposer_ref,
            evaluator=task.evaluator,
            search=prepared_search.spec,
            context=context_spec,
        )
        # Each mode's own promise. `durable-local` claims interrupted equals
        # uninterrupted, so it requires deterministic and retry-safe components.
        # `distributed` trajectories are schedule-sensitive by design, so it
        # requires retry-safety alone. The context manifest, when present, flows
        # through whichever gate applies.
        require_components_for(mode, manifests)
        if mode == "distributed":
            # The five refusals durable-local does not already make. Before the
            # capabilities are built and long before genesis, so a refused
            # configuration writes no events -- the same rule the block above
            # follows for its own checks.
            check_distributed_admission(
                search=prepared_search.program,
                budget=effective,
                context_spec=context_spec,
                experience_spec=experience_spec,
                fingerprint=environment_fingerprint(),
            )
            capabilities = RunCapabilities(
                mode="distributed",
                # Derived from the admission rule above, so the durable flag
                # cannot outlive the rule that earned it.
                resumable=components_admit("distributed", manifests),
                component_manifests=manifests,
                environment_fingerprint=environment_fingerprint(),
            )
        else:
            capabilities = RunCapabilities(
                mode="durable-local",
                resumable=components_admit("durable-local", manifests),
                component_manifests=manifests,
            )
    else:
        capabilities = LEGACY_LOCAL_CAPABILITIES

    if mode != "distributed":
        # The sequential path refuses a declared width above one: without that
        # refusal one declaration would stop early sequentially and run wide
        # distributed, under a single run identity.
        refuse_wide_cohort(prepared_search.cohort_width)
    else:
        # The broker capability, checked before genesis: durability and
        # work-table capability are independent, so a durable but brokerless
        # strategy would otherwise commit a run that nothing can drive.
        storage.work_broker()
    program = _with_context(
        prepared_search.program,
        context_spec.policy if context_spec is not None else None,
    )
    run_id = run_id_for(
        task,
        seed_payload,
        proposer_ref,
        prepared_search.spec.policy,
        effective,
        experiment.random_seed,
        prepared_search.identity_key,
        context_spec,
        experience_spec,
        cohort_width=prepared_search.cohort_width,
    )
    if stores.events.read(run_id):
        raise RunError("an identical run already exists in this storage")
    task_digest = sha256(serialization.identity_content(task).encode()).hexdigest()
    coordinator = SequentialCoordinator(
        run_id=run_id,
        task_id=TaskId(f"task-{task_digest}"),
        task=task,
        run_budget=effective,
        random_seed=experiment.random_seed,
        search=prepared_search.spec,
        proposer_runner=proposer_runner,
        proposer_ref=proposer_ref,
        evaluator=evaluator,
        storage=stores,
        codecs=codecs,
        capabilities=capabilities,
        context_selector=context_selector,
        experience_spec=experience_spec,
    )
    if mode in ("durable-local", "distributed"):
        # Fold the context/experience declarations INTO the atomic genesis
        # batch so a durable-local run exists IFF its declarations are present
        # (closes the genesis-only window). No separate declare_* commits here.
        coordinator.start(
            seed_payload,
            context_spec=context_spec,
            experience_spec=experience_spec,
        )
    else:
        # Local mode is UNCHANGED: genesis stays declaration-free and the
        # declarations commit as separate standalone facts, byte-identically.
        coordinator.start(seed_payload)
        coordinator.declare_context(context_spec)
        coordinator.declare_experience(experience_spec)
    return _PreparedSession(
        coordinator=coordinator,
        program=program,
        run=Run._reopen(run_id, stores, codecs),
        phase=RecoveryPhase.DECISION_READY,
    )


def prepare_resume(
    run_id: RunId,
    /,
    *,
    storage: Storage,
    registry: Registry,
) -> _PreparedSession:
    """Validate and reconstruct a durable session without completing work."""

    if not isinstance(storage, Storage):
        raise TypeError("storage must be Storage")
    if not storage.is_durable:
        raise CapabilityError(
            "resume requires durable storage (Storage.durable(...))"
        )
    if storage.is_read_only:
        raise CapabilityError(
            "resume requires writable storage; Storage.read_only(...) has no "
            "execution or commit authority"
        )
    if not isinstance(registry, Registry):
        raise CapabilityError("resume requires a component registry")
    # A kind this index does not hold fails closed at the first decode. A kind
    # a caller registered a custom codec for is refused by
    # ``check_declared_codec`` inside ``load_validated_run`` on the next line.
    codecs = CodecIndex.with_extras(registry.artifact_types())
    loaded = load_validated_run(storage, run_id, require_existing=True)
    projection = loaded.projection
    start = projection.start
    assert start is not None
    caps = start.capabilities
    # Which reason refuses it, not merely that something does. `RunCapabilities`
    # already refuses a resumable local run, so `resumable` alone decides.
    require_resumable_run(run_id, caps)
    context_spec = (
        projection.context_declaration.spec
        if projection.context_declaration is not None
        else None
    )
    experience_spec = (
        projection.experience_declaration.spec
        if projection.experience_declaration is not None
        else None
    )
    supplied = registry.manifests_for(
        proposer=start.search.proposer,
        evaluator=start.task.evaluator,
        search=start.search,
        context=context_spec,
    )
    verify_manifests(caps.component_manifests, supplied)
    # The same split as at start, because the epic asks for every distributed
    # refusal to be revalidated on resume -- with the same rule, not a stricter
    # one that would strand a run its own start admitted.
    require_components_for(caps.mode, caps.component_manifests)
    prepared_search = registry.resolve_policy(start.search, budget=start.run_budget)
    # One validated width: `prepare_search` already refuses a program whose
    # structural declaration disagrees with the recorded configuration, so a
    # recorded wide run cannot reach this as a narrow rebuild.
    if caps.mode != "distributed":
        # Only the synchronous path refuses a cohort wider than one.
        refuse_wide_cohort(prepared_search.cohort_width, resumed=True)
    else:
        check_distributed_admission(
            search=prepared_search.program,
            budget=start.run_budget,
            context_spec=context_spec,
            experience_spec=experience_spec,
            fingerprint=caps.environment_fingerprint,
        )
        # The broker capability, checked HERE rather than at first use. Storage
        # durability and work-table capability are independent: a composed
        # durable-but-brokerless strategy would prepare cleanly and fail once
        # `drive()` was already underway.
        storage.work_broker()
    proposer_runner, evaluator = resolve_registered_components(
        registry, start.search.proposer, start.task, codecs
    )
    validate_proposer_run(
        proposer_runner,
        artifact_kind=start.task.artifact_kind,
        artifact_representation=start.task.artifact_representation,
        objectives=start.task.objectives,
        budget=start.run_budget,
        experience=experience_spec,
    )
    context_selector = (
        registry.resolve_context_policy(context_spec)
        if context_spec is not None
        else None
    )
    coordinator = SequentialCoordinator(
        run_id=run_id,
        task_id=start.task_id,
        task=start.task,
        run_budget=start.run_budget,
        random_seed=start.random_seed,
        search=start.search,
        proposer_runner=proposer_runner,
        proposer_ref=start.search.proposer,
        evaluator=evaluator,
        storage=storage,
        codecs=codecs,
        capabilities=caps,
        projection=projection,
        committed_bodies=[event.body for event in loaded.events],
        context_selector=context_selector,
        experience_spec=experience_spec,
    )
    return _PreparedSession(
        coordinator=coordinator,
        program=_with_context(
            prepared_search.program,
            context_spec.policy if context_spec is not None else None,
        ),
        run=Run._reopen(run_id, storage, codecs),
        phase=classify_frontier(loaded.events, projection),
    )


def _with_context(
    program: SearchProgram, policy: PolicyRef | None
) -> SearchProgram:
    """Push a declared context policy to the proposer; drive bare otherwise."""

    return ContextSearchProgram(program, policy) if policy is not None else program


__all__ = ["prepare_resume", "prepare_start"]
