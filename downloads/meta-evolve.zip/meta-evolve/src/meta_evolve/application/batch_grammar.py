"""The single source of truth for coordinator batch *shapes*.

Two independent code paths must agree on what a well-formed committed batch
looks like, or the "committed ⟹ recoverable" invariant breaks:

* ``SequentialCoordinator.commit_batch`` (write side) must refuse to persist any
  batch the recovery grammar would later reject — e.g. a lone
  ``PolicyDecisionMade(Stop)`` with no ``PolicyDecisionExplained`` — because a
  preflight *fold* validates per-event semantics but not the batch *grammar*.
* ``recovery.classify_frontier`` (read side) parses the whole ordered stream
  into batches to position ``resume``.

Both import the ``consume_*`` shape matchers below, so preflight and recovery can
never diverge on batch shapes again. Recovery keeps its own *ordering* rules
(genesis first; a result only after a ``TrialSpec`` decision; an evaluation only
after a successful result) layered on top of these shape matchers.

The recognized batch shapes (design §; see ``recovery.py``):

* Genesis: ``RunStarted, BootstrapPrepared, ArtifactCreated, TrialCompleted,
  EvidenceRecorded*, EvaluationCompleted``; distributed genesis ends at
  ``TrialCompleted`` and defers the evaluation to its own batch.
* Decision: ``PolicyDecisionMade, PolicyDecisionExplained``.
* Result (success): ``ProposalSubmitted, EvidenceRecorded*, ArtifactCreated,
  TrialCompleted``.
* Result (failure): ``ProposalSubmitted, EvidenceRecorded*, TrialCompleted``.
* Evaluation: ``EvidenceRecorded*, EvaluationCompleted``.
* A single standalone M3 fact (committed one-per-batch via ``commit_batch``).

Past the ~300-line guideline, and one file deliberately. Every function here is
one clause of a single grammar, and a clause can only be checked against its
neighbours: what `consume_result` may enclose is defined by what
`consume_evaluation` claims, and the cohort rule exists to say which of them a
decision may be adjacent to. Split by clause, the grammar stops being readable
as a grammar -- and the defect this file most recently carried was exactly a
clause licensing an attribution the clause beside it never checked, then
checking it in one direction only.
"""

from __future__ import annotations

from collections.abc import Sequence

from meta_evolve.domain import (
    ArtifactCreated,
    BootstrapPrepared,
    ContextPolicyDeclared,
    ContextSelected,
    EvaluationCompleted,
    EvidenceRecorded,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    ProposalSubmitted,
    RunStarted,
    TrialCompleted,
    TrialId,
    TrialSpec,
    SourceHistoryMounted,
)
from meta_evolve.errors import DurableCorruption

# M3 context/experience facts each use their own one-event ``commit_batch``.
M3_STANDALONE_FACTS = (
    ContextPolicyDeclared,
    ContextSelected,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationSucceeded,
    ExperienceOperationDenied,
    ExperienceOperationBudgetExhausted,
    SourceHistoryMounted,
)


def is_m3_fact(body: object) -> bool:
    return isinstance(body, M3_STANDALONE_FACTS)


def _expect(bodies: Sequence[object], i: int, kind: type, context: str) -> int:
    body = bodies[i] if i < len(bodies) else None
    if not isinstance(body, kind):
        found = type(body).__name__ if body is not None else "end-of-stream"
        raise DurableCorruption(
            f"{context} at event {i}: expected {kind.__name__}, found {found}"
        )
    return i + 1


def _consume_evidence(bodies: Sequence[object], i: int) -> int:
    while i < len(bodies) and isinstance(bodies[i], EvidenceRecorded):
        i += 1
    return i


def _enclosed_evidence_ids(bodies: Sequence[object], start: int, stop: int) -> list:
    # Compared to the claimed ids as ORDERED tuples: the same ids in another
    # order are refused. The writer emits them in claim order.
    return [
        body.evidence.id
        for body in bodies[start:stop]
        if isinstance(body, EvidenceRecorded)
    ]


def consume_genesis(bodies: Sequence[object], i: int) -> int:
    # The lead body is BOUND rather than discarded, which `_expect` alone would
    # do: a distributed genesis is allowed to stop before its bootstrap
    # evaluation, and the only thing entitled to say so is the run's own
    # RECORDED capability. Reading it from the stream rather than from a
    # caller's argument is what keeps the split from becoming a way to write a
    # truncated genesis in any other mode -- `consume_result` and
    # `consume_decision` already bind their leads the same way.
    lead = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, RunStarted, "genesis batch")
    i = _expect(bodies, i, BootstrapPrepared, "genesis batch")
    created = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, ArtifactCreated, "genesis batch")
    completed = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, TrialCompleted, "genesis batch")
    # The seed artifact carries no trial id, so enclosure is its only
    # attribution, as in a result batch. This half holds in BOTH modes, so it is
    # asserted before the distributed split below.
    assert isinstance(completed, TrialCompleted) and isinstance(created, ArtifactCreated)
    if tuple(completed.outcome.artifact_ids) != (created.artifact_id,):
        raise DurableCorruption(
            f"genesis claims artifacts "
            f"{[item.value for item in completed.outcome.artifact_ids]} but "
            f"encloses {created.artifact_id.value}; a batch may claim exactly "
            "what it encloses"
        )
    if lead.capabilities.mode == "distributed":
        # The deferred evaluation owns any following evidence. Exact-batch
        # recognition still refuses evidence inside the genesis write itself.
        return i
    evidence_start = i
    i = _consume_evidence(bodies, i)
    evidence_ids = _enclosed_evidence_ids(bodies, evidence_start, i)
    evaluated = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, EvaluationCompleted, "genesis batch")
    # ... and the evidence half, which only exists where an evaluation does.
    assert isinstance(evaluated, EvaluationCompleted)
    if tuple(evaluated.evaluation.evidence_ids) != tuple(evidence_ids):
        raise DurableCorruption(
            f"genesis claims evidence "
            f"{[item.value for item in evaluated.evaluation.evidence_ids]} but "
            f"encloses {[item.value for item in evidence_ids]}; a batch may "
            "claim exactly what it encloses"
        )
    # A durable-local run FOLDS its context/experience declarations into the
    # atomic genesis batch (coordinator.start), so consume an OPTIONAL trailing
    # ContextPolicyDeclared then an OPTIONAL ExperienceAccessDeclared here. This
    # single edit lets commit_batch's preflight accept the folded genesis AND
    # lets recovery parse it. The facts are OPTIONAL so the shape still matches
    # a bare genesis batch: in local mode (and a durable-local run with no M3
    # declarations) the declarations arrive as separate standalone 1-event
    # batches AFTER genesis, consumed by the stream grammar —
    # BOTH the folded and the bare-genesis-plus-standalone streams parse.
    if i < len(bodies) and isinstance(bodies[i], ContextPolicyDeclared):
        i += 1
    if i < len(bodies) and isinstance(bodies[i], ExperienceAccessDeclared):
        i += 1
    return i


def consume_decision(bodies: Sequence[object], i: int) -> tuple[object, int]:
    """Consume a decision batch, returning ``(decision, next_index)`` where
    ``decision`` is the ``PolicyDecisionMade.decision`` payload."""

    record = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, PolicyDecisionMade, "decision batch")
    i = _expect(bodies, i, PolicyDecisionExplained, "decision batch")
    return record.decision, i


def consume_result(bodies: Sequence[object], i: int) -> tuple[TrialId, bool, int]:
    """Consume a result batch, returning ``(trial_id, succeeded, next_index)``.

    A success carries an ``ArtifactCreated`` before its ``TrialCompleted``; a
    failure does not.

    The batch names its trial twice -- on the opening proposal and the closing
    completion -- and both are checked, because the pair is what lets an
    ordering-free grammar attribute the evidence and artifact between them. The
    two interior facts carry no trial id of their own, so enclosure is the only
    attribution available for them.
    """

    opened = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, ProposalSubmitted, "result batch")
    evidence_start = i
    i = _consume_evidence(bodies, i)
    evidence_ids = _enclosed_evidence_ids(bodies, evidence_start, i)
    succeeded = False
    created = None
    if i < len(bodies) and isinstance(bodies[i], ArtifactCreated):
        created = bodies[i]
        i += 1
        succeeded = True
    closed = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, TrialCompleted, "result batch")
    assert isinstance(opened, ProposalSubmitted) and isinstance(closed, TrialCompleted)
    if opened.proposal.trial_id != closed.trial.id:
        raise DurableCorruption(
            "result batch opens and closes on different trials: "
            f"{opened.proposal.trial_id.value} then {closed.trial.id.value}"
        )
    # ... and the interior must be exactly what the completion CLAIMS, in both
    # directions. The fold only asks that a referenced id exist somewhere in the
    # stream, so a completion claiming an earlier trial's artifact -- instead of
    # or alongside its own -- would record two trials producing one artifact and
    # feed that lineage to the policy.
    outcome = closed.outcome
    enclosed_artifacts = () if created is None else (created.artifact_id,)
    if tuple(outcome.artifact_ids) != enclosed_artifacts:
        raise DurableCorruption(
            f"result batch for trial {closed.trial.id.value} claims artifacts "
            f"{[item.value for item in outcome.artifact_ids]} but encloses "
            f"{[item.value for item in enclosed_artifacts]}; a batch may claim "
            "exactly what it encloses"
        )
    if tuple(outcome.evidence_ids) != tuple(evidence_ids):
        raise DurableCorruption(
            f"result batch for trial {closed.trial.id.value} claims evidence "
            f"{[item.value for item in outcome.evidence_ids]} but encloses "
            f"{[item.value for item in evidence_ids]}; a batch may claim "
            "exactly what it encloses"
        )
    return closed.trial.id, succeeded, i


def consume_evaluation(bodies: Sequence[object], i: int) -> tuple[TrialId, int]:
    """Consume an evaluation batch, returning ``(trial_id, next_index)``.

    Its enclosed evidence is attributed the same way a result batch's is, and
    for the same reason: the evidence carries no trial id of its own, so
    enclosure is the only attribution there is. This discarded the enclosed ids
    entirely, which left an evaluation free to claim evidence recorded by an
    earlier trial or an earlier evaluation while passing both the grammar and
    the fold -- the fold asks only whether the id exists somewhere.
    """

    evidence_start = i
    i = _consume_evidence(bodies, i)
    evidence_ids = _enclosed_evidence_ids(bodies, evidence_start, i)
    closed = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, EvaluationCompleted, "evaluation batch")
    assert isinstance(closed, EvaluationCompleted)
    if tuple(closed.evaluation.evidence_ids) != tuple(evidence_ids):
        raise DurableCorruption(
            f"evaluation batch for trial {closed.evaluation.trial_id.value} "
            f"claims evidence {[item.value for item in closed.evaluation.evidence_ids]} "
            f"but encloses {[item.value for item in evidence_ids]}; a batch may "
            "claim exactly what it encloses"
        )
    return closed.evaluation.trial_id, i


def consume_cohort(bodies: Sequence[object], i: int) -> tuple[tuple[object, ...], int]:
    """Consume one or more decision pairs committed as a single batch.

    A generational cohort commits its members together, so the decision batch is
    no longer exactly one pair. Above one member every decision must be a
    ``TrialSpec``: a stop is a singleton by definition, and an archive update
    carries no trailing work to run concurrently. Refusing the mixed forms here
    rather than in prose makes the composition rule structural.

    Whether consecutive decision pairs were committed as one cohort or as
    separate batches is not recoverable from the stream, which carries no batch
    delimiters -- so being adjacent IS the cohort signature on read, and the
    fold's barrier is what decides whether they legitimately share a base.
    """

    decisions: list[object] = []
    while i < len(bodies) and isinstance(bodies[i], PolicyDecisionMade):
        decision, i = consume_decision(bodies, i)
        decisions.append(decision)
        if not isinstance(decision, TrialSpec):
            # Only trial decisions cohort. A stop and an archive update each end
            # their batch: the stream carries no batch delimiters, so
            # consecutive decision pairs are otherwise indistinguishable from
            # one cohort, and a stop followed by anything would read as a mixed
            # cohort -- hiding the sharper rule that nothing may follow a
            # committed stop at all.
            break
    if not decisions:
        _expect(bodies, i, PolicyDecisionMade, "decision batch")
    if len(decisions) > 1 and not all(
        isinstance(item, TrialSpec) for item in decisions
    ):
        # Name the member that broke it. The stream carries no batch
        # delimiters, so this fires on ADJACENCY -- and the commonest way to
        # reach it is not a malformed cohort at all but a `Stop` committed
        # while trial decisions ahead of it were still outstanding, which
        # leaves the two adjacent. Reporting only "must be all trial
        # decisions" sends the reader looking for a composition bug; the
        # fold's decision barrier is what diagnoses the real one.
        position, offender = next(
            (index, item)
            for index, item in enumerate(decisions)
            if not isinstance(item, TrialSpec)
        )
        raise DurableCorruption(
            "a decision batch above one member must be all trial decisions; "
            f"found {type(offender).__name__} at member {position + 1} of "
            f"{len(decisions)}"
        )
    return tuple(decisions), i


def recognized_batch_shape(bodies: Sequence[object]) -> str | None:
    """Return the shape name if ``bodies`` is EXACTLY one recognized batch (or a
    single standalone M3 fact), else ``None``.

    Used by ``commit_batch`` to reject — before persisting — any batch the
    recovery grammar would later reject. It intentionally recognizes a *single*
    complete batch: every coordinator write commits exactly one batch, and each
    M3 fact commits as its own 1-event batch.
    """

    if not bodies:
        return None
    if len(bodies) == 1 and is_m3_fact(bodies[0]):
        return "m3-fact"
    lead = bodies[0]
    try:
        if isinstance(lead, RunStarted):
            end, name = consume_genesis(bodies, 0), "genesis"
        elif isinstance(lead, PolicyDecisionMade):
            (_, end), name = consume_cohort(bodies, 0), "decision"
        elif isinstance(lead, ProposalSubmitted):
            (_, _, end), name = consume_result(bodies, 0), "result"
        elif isinstance(lead, (EvidenceRecorded, EvaluationCompleted)):
            (_, end), name = consume_evaluation(bodies, 0), "evaluation"
        else:
            return None
    except DurableCorruption:
        return None
    return name if end == len(bodies) else None


__all__ = [
    "M3_STANDALONE_FACTS",
    "consume_decision",
    "consume_evaluation",
    "consume_genesis",
    "consume_result",
    "is_m3_fact",
    "recognized_batch_shape",
]
