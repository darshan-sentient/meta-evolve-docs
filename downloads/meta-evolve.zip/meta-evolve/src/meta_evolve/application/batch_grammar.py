"""The single source of truth for coordinator batch *shapes*.

Two independent code paths must agree on what a well-formed committed batch
looks like, or the "committed ⟹ recoverable" invariant breaks:

* ``SequentialCoordinator.commit_batch`` (write side) must refuse to persist any
  batch the recovery grammar would later reject — e.g. a lone
  ``PolicyDecisionMade(Stop)`` with no ``PolicyDecisionExplained`` — because a
  preflight *fold* validates per-event semantics but not the batch *grammar*.
* ``recovery.classify_frontier`` (read side) parses the whole ordered stream
  into batches to position ``resume``.

Both import the ``consume_*`` shape matchers below, so preflight and recovery can
never diverge on batch shapes again. Recovery keeps its own *ordering* rules
(genesis first; a result only after a ``TrialSpec`` decision; an evaluation only
after a successful result) layered on top of these shape matchers.

The recognized batch shapes (design §; see ``recovery.py``):

* Genesis: ``RunStarted, BootstrapPrepared, ArtifactCreated, TrialCompleted,
  EvidenceRecorded*, EvaluationCompleted``.
* Decision: ``PolicyDecisionMade, PolicyDecisionExplained``.
* Result (success): ``ProposalSubmitted, EvidenceRecorded*, ArtifactCreated,
  TrialCompleted``.
* Result (failure): ``ProposalSubmitted, EvidenceRecorded*, TrialCompleted``.
* Evaluation: ``EvidenceRecorded*, EvaluationCompleted``.
* A single standalone M3 fact (committed one-per-batch via
  ``SequentialCoordinator.append_fact``).
"""

from __future__ import annotations

from collections.abc import Sequence

from meta_evolve.domain import (
    ArtifactCreated,
    BootstrapPrepared,
    ContextPolicyDeclared,
    ContextSelected,
    EvaluationCompleted,
    EvidenceRecorded,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    ProposalSubmitted,
    RunStarted,
    TrialCompleted,
    SourceHistoryMounted,
)
from meta_evolve.errors import DurableCorruption

# M3 context/experience facts are each committed as their own 1-event batch (via
# ``SequentialCoordinator.append_fact``).
M3_STANDALONE_FACTS = (
    ContextPolicyDeclared,
    ContextSelected,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationSucceeded,
    ExperienceOperationDenied,
    ExperienceOperationBudgetExhausted,
    SourceHistoryMounted,
)


def is_m3_fact(body: object) -> bool:
    return isinstance(body, M3_STANDALONE_FACTS)


def _expect(bodies: Sequence[object], i: int, kind: type, context: str) -> int:
    body = bodies[i] if i < len(bodies) else None
    if not isinstance(body, kind):
        found = type(body).__name__ if body is not None else "end-of-stream"
        raise DurableCorruption(
            f"{context} at event {i}: expected {kind.__name__}, found {found}"
        )
    return i + 1


def _consume_evidence(bodies: Sequence[object], i: int) -> int:
    while i < len(bodies) and isinstance(bodies[i], EvidenceRecorded):
        i += 1
    return i


def consume_genesis(bodies: Sequence[object], i: int) -> int:
    i = _expect(bodies, i, RunStarted, "genesis batch")
    i = _expect(bodies, i, BootstrapPrepared, "genesis batch")
    i = _expect(bodies, i, ArtifactCreated, "genesis batch")
    i = _expect(bodies, i, TrialCompleted, "genesis batch")
    i = _consume_evidence(bodies, i)
    i = _expect(bodies, i, EvaluationCompleted, "genesis batch")
    # A durable-local run FOLDS its context/experience declarations into the
    # atomic genesis batch (coordinator.start), so consume an OPTIONAL trailing
    # ContextPolicyDeclared then an OPTIONAL ExperienceAccessDeclared here. This
    # single edit lets commit_batch's preflight accept the folded genesis AND
    # lets recovery parse it. The facts are OPTIONAL so the shape still matches
    # a bare genesis batch: in local mode (and a durable-local run with no M3
    # declarations) the declarations arrive as separate standalone 1-event
    # batches AFTER genesis, consumed by the scanner's ``_skip_m3_facts`` —
    # BOTH the folded and the bare-genesis-plus-standalone streams parse.
    if i < len(bodies) and isinstance(bodies[i], ContextPolicyDeclared):
        i += 1
    if i < len(bodies) and isinstance(bodies[i], ExperienceAccessDeclared):
        i += 1
    return i


def consume_decision(bodies: Sequence[object], i: int) -> tuple[object, int]:
    """Consume a decision batch, returning ``(decision, next_index)`` where
    ``decision`` is the ``PolicyDecisionMade.decision`` payload."""

    record = bodies[i] if i < len(bodies) else None
    i = _expect(bodies, i, PolicyDecisionMade, "decision batch")
    i = _expect(bodies, i, PolicyDecisionExplained, "decision batch")
    return record.decision, i


def consume_result(bodies: Sequence[object], i: int) -> tuple[bool, int]:
    """Consume a result batch, returning ``(succeeded, next_index)``.

    A success carries an ``ArtifactCreated`` before its ``TrialCompleted``; a
    failure does not.
    """

    i = _expect(bodies, i, ProposalSubmitted, "result batch")
    i = _consume_evidence(bodies, i)
    succeeded = False
    if i < len(bodies) and isinstance(bodies[i], ArtifactCreated):
        i += 1
        succeeded = True
    i = _expect(bodies, i, TrialCompleted, "result batch")
    return succeeded, i


def consume_evaluation(bodies: Sequence[object], i: int) -> int:
    i = _consume_evidence(bodies, i)
    i = _expect(bodies, i, EvaluationCompleted, "evaluation batch")
    return i


def recognized_batch_shape(bodies: Sequence[object]) -> str | None:
    """Return the shape name if ``bodies`` is EXACTLY one recognized batch (or a
    single standalone M3 fact), else ``None``.

    Used by ``commit_batch`` to reject — before persisting — any batch the
    recovery grammar would later reject. It intentionally recognizes a *single*
    complete batch: every coordinator write commits exactly one batch, and each
    M3 fact commits as its own 1-event batch.
    """

    if not bodies:
        return None
    if len(bodies) == 1 and is_m3_fact(bodies[0]):
        return "m3-fact"
    lead = bodies[0]
    try:
        if isinstance(lead, RunStarted):
            end, name = consume_genesis(bodies, 0), "genesis"
        elif isinstance(lead, PolicyDecisionMade):
            (_, end), name = consume_decision(bodies, 0), "decision"
        elif isinstance(lead, ProposalSubmitted):
            (_, end), name = consume_result(bodies, 0), "result"
        elif isinstance(lead, (EvidenceRecorded, EvaluationCompleted)):
            end, name = consume_evaluation(bodies, 0), "evaluation"
        else:
            return None
    except DurableCorruption:
        return None
    return name if end == len(bodies) else None


__all__ = [
    "M3_STANDALONE_FACTS",
    "consume_decision",
    "consume_evaluation",
    "consume_genesis",
    "consume_result",
    "is_m3_fact",
    "recognized_batch_shape",
]
