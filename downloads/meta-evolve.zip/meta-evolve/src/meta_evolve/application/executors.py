"""Executors: what runs a component on a work item's resolved inputs.

An executor holds its component and the codecs it needs, and nothing that
belongs to the run -- no coordinator, storage, clock or broker -- so the same
executor runs inline, on a helper thread, or inside a worker process. Its inputs
and outputs can cross a wire: artifacts and a `ProposalRequest` in, an
`EvaluationResult` or an `EncodedProposal` out.

Decoding and encoding happen here, on the executor's side, because only this side
holds the decoded value. Loading the inputs (input resolution), minting ids and
building durable facts stay with the dispatcher.
"""

from __future__ import annotations

import random
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    Failure,
    InvalidOutput,
    Objective,
    Task,
    Usage,
)
from meta_evolve.domain.context import ContextBundle
from meta_evolve.domain.experience_access import ExperienceRef
from meta_evolve.domain.values import FrozenMap
from meta_evolve.ports.callables import (
    EvaluationResult,
    EvidenceDraft,
    Evaluator,
    ProposalResult,
)
from meta_evolve.ports.proposers import ProposerContext
from meta_evolve.ports.runners import ProposerRunner

from meta_evolve.ports.escapes import escapes_normalization

from .codecs import CodecIndex


class CandidateEncodingError(RuntimeError):
    """A codec fault while encoding a candidate the proposer already returned.

    Raised from the fault it wraps, so the dispatcher can tell it from the
    proposer's own raise: the component answered, so this is a completion
    failure and the proposer is not run again.
    """


@dataclass(frozen=True, slots=True)
class ProposalRequest:
    """What a proposal executor is told about the attempt, and all of it.

    The seed rather than a live `random.Random`, so the request serializes; the
    executor builds the proposer's context from it. Distributed mode declares no
    context policy and no experience, so neither travels.
    """

    random_seed: int
    step: int
    objectives: tuple[Objective, ...]


@dataclass(frozen=True, slots=True, kw_only=True)
class EncodedProposal:
    """A proposer's answer with its candidate already encoded, minting no id.

    `failure` is the proposer's own typed failure. `encoding_failure` is the
    codec refusing the candidate: a value, because it describes the candidate,
    and kept apart from `failure` so the builder can apply budget and derivation
    checks first, exactly as it did when it encoded.
    """

    kind: str
    representation: str
    payload: object = None
    failure: Failure | None = None
    encoding_failure: InvalidOutput | None = None
    hypothesis: str | None = None
    predicted_outcomes: FrozenMap | Mapping[str, object] = field(
        default_factory=FrozenMap
    )
    metadata: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence: tuple[EvidenceDraft, ...] = ()
    usage: Usage = Usage()
    derived_from: tuple[ExperienceRef, ...] = ()

    @classmethod
    def failed(cls, task: Task, failure: Failure) -> EncodedProposal:
        """A proposal that failed before it had a candidate to encode."""

        return cls(
            kind=task.artifact_kind,
            representation=task.artifact_representation,
            failure=failure,
        )


def encode_candidate(
    codecs: CodecIndex, task: Task, result: ProposalResult
) -> EncodedProposal:
    """Encode a proposal result's candidate under the task's declared codec.

    A value the codec rejects -- `TypeError` or `ValueError`, the codec
    contract's "not mine" -- becomes an `InvalidOutput` naming the candidate's
    type. Any other exception is a codec bug and propagates.
    """

    payload: object = None
    encoding_failure: InvalidOutput | None = None
    if result.failure is None:
        try:
            payload = codecs.encode(
                task.artifact_kind, task.artifact_representation, result.candidate
            )
        except (TypeError, ValueError) as error:
            encoding_failure = InvalidOutput(
                message="proposer returned invalid output",
                details={
                    "error": str(error),
                    "output_type": type(result.candidate).__name__,
                },
            )
    return EncodedProposal(
        kind=task.artifact_kind,
        representation=task.artifact_representation,
        payload=payload,
        failure=result.failure,
        encoding_failure=encoding_failure,
        hypothesis=result.hypothesis,
        predicted_outcomes=result.predicted_outcomes,
        metadata=result.metadata,
        evidence=result.evidence,
        usage=result.usage,
        derived_from=result.derived_from,
    )


class EvaluationExecutor(Protocol):
    def evaluate(self, artifact: Artifact) -> EvaluationResult: ...


class ProposalExecutor(Protocol):
    def propose(
        self, parents: tuple[Artifact, ...], request: ProposalRequest
    ) -> EncodedProposal: ...


@dataclass(frozen=True, slots=True)
class LocalEvaluationExecutor:
    """Decode, then evaluate, in this process.

    The decode sits outside the evaluator's own failure normalization, so a
    payload that cannot decode escapes as `DurableCorruption` rather than being
    recorded as a failed candidate.
    """

    evaluator: Evaluator
    codecs: CodecIndex

    def evaluate(self, artifact: Artifact) -> EvaluationResult:
        return self.evaluator.evaluate(self.codecs.decode(artifact))


@dataclass(frozen=True, slots=True)
class LocalProposalExecutor:
    """Run the proposer on its parents, then encode its candidate, in this process."""

    runner: ProposerRunner
    codecs: CodecIndex
    task: Task

    def propose(
        self, parents: tuple[Artifact, ...], request: ProposalRequest
    ) -> EncodedProposal:
        context = ProposerContext(
            rng=random.Random(request.random_seed),
            step=request.step,
            objectives=request.objectives,
            bundle=ContextBundle(),
            experience=None,
        )
        result = self.runner.execute(parents, context)
        try:
            return encode_candidate(self.codecs, self.task, result)
        except Exception as error:
            if escapes_normalization(error):
                raise
            raise CandidateEncodingError(
                "encoding the proposer's candidate failed"
            ) from error


__all__ = [
    "CandidateEncodingError",
    "EncodedProposal",
    "EvaluationExecutor",
    "LocalEvaluationExecutor",
    "LocalProposalExecutor",
    "ProposalExecutor",
    "ProposalRequest",
    "encode_candidate",
]
