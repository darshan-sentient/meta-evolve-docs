"""Resolve inputs, claim work, execute with renewal, then commit its completion.

The dispatcher resolves inputs, claims work, and hands the call to an
endpoint; everything touching identity, budgets, storage or the stream goes
through the coordinator. A work kind's facts live in `dispatch_evaluation.py`
and `dispatch_proposal.py`, settling an outcome in `dispatch_submission.py`,
the loop that waits and renews in `dispatch_loop.py`, ending an exhausted row
in `dispatch_reclaim.py`. The injected clock shares the broker's deadline
authority.

Kept together beyond 300 lines so claiming, the order items are offered in,
and when the policy may be asked can be read as the one control flow they are.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, cast

from meta_evolve.domain.search import SearchProgram
from meta_evolve.domain.work import Lease, WorkItemId, WorkKind, WorkRow, WorkState
from meta_evolve.errors import CapabilityError
from meta_evolve.domain.workers import WorkerId, WorkerRegistration
from meta_evolve.ports.escapes import escapes_normalization
from meta_evolve.ports.work_store import WorkBroker

from .decisions import commit_cohort
from .dispatch_frontier import refuse_an_undecidable_frontier
from .dispatch_clock import (
    ManualClock,
    keepalive_for,
    wall_clock,
)
from .dispatch_evaluation import resolve_evaluation
from .dispatch_admission import Workers
from .dispatch_loop import POLL_SECONDS, DispatchLoop, Endpoint
from .dispatch_messages import StepOverrun
from .dispatch_outcomes import reportable_cause
from .dispatch_proposal import resolve_proposal
from .dispatch_binding import (
    EvaluationInputs,
    ProposalInputs,
    ResolvedInputs,
    bind_work,
)
from .dispatch_submission import Settler
from .executors import (
    EvaluationExecutor,
    LocalEvaluationExecutor,
    LocalProposalExecutor,
    ProposalExecutor,
)
from .dispatch_reclaim import is_ended, reclaim_ended
from .inline_backend import InlineEndpoint

if TYPE_CHECKING:  # pragma: no cover - typing only
    from _typeshed import SupportsRichComparison

    from .coordinator import SequentialCoordinator
    from .distributed_admission import CohortProgram

DEFAULT_WORKERS = 1


class Dispatcher:
    """Drives one run's brokered work to a terminal frontier."""

    def __init__(
        self,
        coordinator: SequentialCoordinator,
        broker: WorkBroker,
        *,
        clock: Callable[[], int] = wall_clock,
        program: SearchProgram | None = None,
        workers: int = DEFAULT_WORKERS,
        evaluation_executor: EvaluationExecutor | None = None,
        proposal_executor: ProposalExecutor | None = None,
        claim_order: Callable[[WorkRow], SupportsRichComparison] | None = None,
        endpoints: Sequence[Endpoint] | None = None,
        admission: Workers | None = None,
    ) -> None:
        if workers < 1:
            raise ValueError("a dispatcher needs at least one worker")
        # Work transitions and their authorizing facts must share a transaction.
        if not broker.shares_transaction_with(coordinator.work_broker()):
            raise CapabilityError(
                "this broker belongs to another store: a dispatcher drives the "
                "broker its own coordinator's storage hands out, because a work "
                "transition has to commit with the batch that authorizes it"
            )
        self._coordinator = coordinator
        self._broker = broker
        self._clock = clock
        self._program = program
        self._claim_order = claim_order
        # One worker per executor slot, one lease each. That keeps the
        # aggregate capacity inequality load-bearing rather than decorative,
        # and makes "two concurrent claims cannot both succeed" a two-call
        # test. A multidimensional resource model is M11.4.
        self._workers = tuple(
            WorkerRegistration(
                worker=WorkerId.for_slot(coordinator.run_id, slot),
                generation=1,
                max_concurrent_leases=1,
                environment_fingerprint=(
                    coordinator.capabilities.environment_fingerprint
                ),
            )
            for slot in range(workers)
        )
        # Built from the run's components alone, so the executor holds no
        # coordinator: a replacement runs the same inputs anywhere. Replaced,
        # not joined, when endpoints are given: one run is driven through one
        # kind of backend.
        self._inline: InlineEndpoint | None = None
        if endpoints is None:
            self._inline = InlineEndpoint(
                registrations=self._workers,
                evaluation=evaluation_executor
                or LocalEvaluationExecutor(coordinator.evaluator, coordinator.codecs),
                proposal=proposal_executor
                or LocalProposalExecutor(
                    coordinator.proposer_runner, coordinator.codecs, coordinator.task
                ),
            )
            driving: Sequence[Endpoint] = (self._inline,)
        else:
            driving = endpoints
        # A closure over the coordinator, not `self._epoch`: a bound method would
        # make the dispatcher and its loop a cycle, holding the loop's descriptors
        # until the cyclic collector ran rather than until the last reference went.
        self._settler = Settler(
            coordinator, broker, clock, lambda: coordinator.fence.epoch
        )
        self._loop = DispatchLoop(
            clock=clock,
            lease_seconds=broker.lease_seconds,
            settler=self._settler,
            admission=admission,
        )
        # Asked, never counted: an endpoint set that is empty because nobody
        # has connected YET is not the same as one that is empty because every
        # worker failed, and only the backend knows which (design PD2).
        self._admission = admission
        for endpoint in driving:
            self._loop.register(endpoint)

    @property
    def overruns(self) -> tuple[StepOverrun, ...]:
        """Blocking steps that ran past `lease // 4`; ephemeral (D10 rule 3)."""

        return tuple(self._loop.overruns)

    def close(self) -> None:
        """Release the loop's descriptors. A call still running is dropped."""

        self._loop.abandon()
        self._loop.close()
        for endpoint in self._loop.endpoints:
            endpoint.close()

    def drain_once(self) -> bool:
        """Resolve one ready item's inputs, claim it, run it, and settle it.

        The answer is "was there work", not "did it commit": a failed attempt
        is progress, so a loop reading the other meaning would stop on the first
        failure and strand a retryable row. One item per call, so a caller can
        inspect the stream between steps.
        """

        try:
            endpoint = self._puller()
            if endpoint is None:
                return False
            claimed = self._claim(endpoint)
            if claimed is None:
                return False
            while self._loop.holds(claimed):
                self._loop.pump(POLL_SECONDS)
            return True
        except BaseException:
            self._loop.abandon()
            raise

    def step(self, timeout: float = 0.0) -> bool:
        """One loop iteration: wait up to `timeout`, settle, renew, then claim
        for every endpoint that wants work. True if anything was claimed.

        What `drive` repeats; public so a host driving its own connections
        (and a law scripting one) can advance the loop without a whole drive.
        """

        self._loop.pump(timeout)
        claimed = [self._claim(endpoint) for endpoint in self._loop.wanting_work()]
        return any(item is not None for item in claimed)

    def _awaited(self) -> bool:
        """Whether a worker could still take the work that is left."""

        return bool(self._loop.endpoints) or (
            self._admission is not None and self._admission.may_admit()
        )

    def _puller(self) -> Endpoint | None:
        """An endpoint wanting work, waiting for a pull while work is claimable."""

        self._loop.pump(0)
        while True:
            wanting = self._loop.wanting_work()
            if wanting:
                return wanting[0]
            if not self._awaited() or not self._claimable():
                return None
            self._loop.pump(POLL_SECONDS)

    def _claim(self, endpoint: Endpoint) -> WorkItemId | None:
        """Resolve, then claim, one item for `endpoint`: the item, or None.

        Resolution comes FIRST, and that is the whole point of the ordering: a
        store this dispatcher cannot read is not the attempt's fault, so it
        must not cost the attempt. The claim then names the item resolved --
        between the two, a sweep can make an earlier row claimable, and a bare
        claim would lease an item whose inputs nobody resolved. The first of
        the endpoint's registrations that admits takes the claim: inline, the
        dispatcher's slots in slot order; on the wire, the one registration the
        connection was admitted with.
        """

        run_id = self._coordinator.run_id
        for worker in endpoint.registrations:
            for row in self._claimable():
                try:
                    with self._loop.blocking("resolve"):
                        resolved = self._resolve(row)
                    resolve_error = None
                except Exception as error:
                    if escapes_normalization(error):
                        # A store this dispatcher cannot read. Nothing is
                        # claimed, so nothing is spent and a resumed run meets
                        # the same refusal rather than exhausting the row.
                        raise
                    resolve_error = error
                # The resolve step drains every connection and can fail any of
                # them, this one included. Checked BEFORE the claim, so a
                # connection that is gone costs the row no attempt.
                if endpoint not in self._loop.endpoints:
                    return None
                if resolve_error is not None:
                    # An ordinary fault reading inputs is still the attempt's:
                    # a retry can clear it, so it is claimed and released with
                    # its cause like any other attempt failure.
                    lease = self._broker.acquire(
                        run_id, worker, now=self._clock(), item=row.item, epoch=self._epoch()
                    )
                    if lease is None:
                        continue
                    self._settler.fail_attempt(lease, reportable_cause(resolve_error))
                    return lease.item
                lease = self._broker.acquire(
                    run_id, worker, now=self._clock(), item=row.item, epoch=self._epoch()
                )
                if lease is None:
                    # Claimed, expired or cancelled since the scan. Nothing
                    # was spent, so the next candidate is tried rather than
                    # the whole drain reporting an empty frontier.
                    continue
                self._start(endpoint, lease, row, resolved)
                return lease.item
        return None

    def _start(
        self, endpoint: Endpoint, lease: Lease, row: WorkRow, resolved: ResolvedInputs
    ) -> None:
        """Bind the lease and start its call on `endpoint`."""

        binding, work = bind_work(
            endpoint, lease, row, resolved,
            broker=self._broker, run_id=self._coordinator.run_id,
            keepalive=keepalive_for(
                self._broker, self._coordinator.run_id, lease, self._clock,
                epoch=self._epoch(),
            ),
        )
        self._loop.start(binding, work)

    def _epoch(self) -> int | None:
        """The epoch this dispatcher's coordinator holds, or None when unfenced.

        Read at every write rather than captured once, because the fence is
        installed by whoever rolled the epoch over -- `Session.drive()` does so
        before constructing this dispatcher, a test may do so after.
        """

        return self._coordinator.fence.epoch

    def _claimable(self) -> tuple[WorkRow, ...]:
        """Ready rows still owed an attempt, in the order they are offered.

        `is_ended`, not `is_exhausted`: a row whose last attempt came back with
        a deterministic cause still has attempts and must not be handed out
        anyway. The broker's claimable SELECT cannot ask this, which is why the
        filter is here and the transition is re-validated inside the commit.

        `claim_order`, when given, is a sort key over these already-eligible
        rows -- prioritising eligible work is all it can do, and it is how the
        cohort oracle drives completions in a chosen order (design SD3).
        """

        rows = tuple(
            row
            for row in self._broker.rows(self._coordinator.run_id)
            if row.state is WorkState.READY and not is_ended(row)
        )
        if self._claim_order is None:
            return rows
        return tuple(sorted(rows, key=self._claim_order))

    def _resolve(self, row: WorkRow) -> ResolvedInputs:
        """This item's inputs, read before anything is claimed.

        An escaping raise here aborts the run untouched: no lease, no attempt,
        no diagnosis. A resumed run meets the same refusal rather than spending
        the retry bound on a store that was never readable.
        """

        if row.kind is WorkKind.EVALUATION:
            trial, artifact = resolve_evaluation(self._coordinator, row)
            return EvaluationInputs(trial=trial, artifact=artifact)
        trial, parents, request = resolve_proposal(self._coordinator, row)
        return ProposalInputs(trial=trial, parents=parents, request=request)

    def drive(self) -> None:
        """Drain and reclaim until the work frontier is terminal.

        Each pass drains an item, reclaims one, or asks for the next
        generation; a pass that does none of these is the terminal frontier. The
        retry bound and reclaim together keep a deterministically broken
        component from spinning forever.

        Each call runs on the inline endpoint's helper thread while the loop
        renews its lease every `lease // 4`, so a component slower than its
        lease completes. The lease is re-verified once more after the call
        returns and before anything is committed (`dispatch_clock.keepalive_for`).
        """

        try:
            while True:
                if self.step(POLL_SECONDS if self._loop.in_flight() else 0):
                    continue
                if self._loop.in_flight():
                    continue
                if not self._loop.wanting_work() and self._awaited() and self._claimable():
                    # Work is ready and no endpoint has pulled: wait for one.
                    self._loop.pump(POLL_SECONDS)
                    continue
                if self.reclaim():
                    continue
                # After reclaim, so an item exhausted by transport failures
                # still gets its terminal fact; and only while there is work
                # left that nothing here can run.
                if not self._awaited() and self._claimable():
                    raise CapabilityError(
                        "every worker connection of this dispatcher has failed, "
                        "so the work left cannot run: resume the run"
                    )
                if not self._decide():
                    return
        except BaseException:
            self._loop.abandon()
            raise

    def _decide(self) -> bool:
        """Ask the policy for the next generation. True if one was committed.

        Only reached with nothing claimable and nothing to reclaim. The work
        table is the HINT that the frontier is empty (no READY or LEASED row);
        the stream-derived outstanding work is the authority, and the two
        disagreeing is corruption (design SD13). A LEASED row bound to no call
        of this dispatcher cannot be waited out -- an injected clock may never
        pass its deadline -- so it is refused by name (SD15). Without a
        program the dispatcher only drains what is already enqueued.
        """

        if self._program is None:
            return False
        if self._coordinator.projection.stop is not None:
            return False
        refuse_an_undecidable_frontier(self._coordinator, self._broker)
        state = self._coordinator.projection.search_state
        with self._loop.blocking("decide"):
            commit_cohort(
                self._coordinator,
                self._program,
                cast("CohortProgram", self._program).next_cohort(state),
            )
        return True

    def reclaim(self) -> int:
        """Terminate every ended row, each with its terminal fact. Count."""

        with self._loop.blocking("reclaim"):
            return reclaim_ended(self._coordinator, self._broker)


__all__ = [
    "DEFAULT_WORKERS",
    "Dispatcher",
    "ManualClock",
    "wall_clock",
]
