"""Schedule brokered work; the coordinator stays the sole stream writer.

The dispatcher claims work, resolves its inputs, hands them to an executor, and
does everything that touches identity, budget, storage or the stream through the
coordinator, which keeps envelope sequencing, grammar preflight and version
handling in one place. What a work kind's facts look like lives in
`dispatch_evaluation.py` and `dispatch_proposal.py`; ending an exhausted row is
`dispatch_reclaim.py`.

The clock is a parameter: deadlines live in one clock domain the broker owns, so
a scheduler reading its own clock would be a second authority.

Past the ~300-line guideline by a little: the drive loop and the per-kind steps
it dispatches to are one control flow, and a reader asking what happens to a
lease that fails needs both in view.
"""

from __future__ import annotations


from meta_evolve.domain.work import Lease, WorkKind
from meta_evolve.errors import DurableCorruption
from meta_evolve.domain.workers import WorkerId, WorkerRegistration
from meta_evolve.ports.escapes import escapes_normalization

from .decisions import commit_cohort
from .dispatch_clock import (
    ManualClock,
    keepalive_for,
    wall_clock,
)
from .dispatch_evaluation import finish_evaluation, resolve_evaluation
from .dispatch_proposal import finish_proposal, resolve_proposal
from .executors import (
    CandidateEncodingError,
    EvaluationExecutor,
    LocalEvaluationExecutor,
    LocalProposalExecutor,
    ProposalExecutor,
)
from .dispatch_reclaim import reclaim_exhausted
from .identities import correlation_for_work

DEFAULT_WORKERS = 1


class Dispatcher:
    """Drives one run's brokered work to a terminal frontier."""

    def __init__(
        self,
        coordinator,
        broker,
        *,
        clock=wall_clock,
        program=None,
        workers: int = DEFAULT_WORKERS,
        evaluation_executor: EvaluationExecutor | None = None,
        proposal_executor: ProposalExecutor | None = None,
    ) -> None:
        if workers < 1:
            raise ValueError("a dispatcher needs at least one worker")
        self._coordinator = coordinator
        self._broker = broker
        self._clock = clock
        self._program = program
        # Built from the run's components alone, so the executor holds no
        # coordinator: a replacement runs the same inputs anywhere.
        self._evaluation_executor = evaluation_executor or LocalEvaluationExecutor(
            coordinator.evaluator, coordinator.codecs
        )
        self._proposal_executor = proposal_executor or LocalProposalExecutor(
            coordinator.proposer_runner, coordinator.codecs, coordinator.task
        )
        # One worker per executor slot, one lease each. That keeps the
        # aggregate capacity inequality load-bearing rather than decorative,
        # and makes "two concurrent claims cannot both succeed" a two-call
        # test. A multidimensional resource model is M11.4.
        self._workers = tuple(
            WorkerRegistration(
                worker=WorkerId.for_slot(coordinator.run_id, slot),
                generation=1,
                max_concurrent_leases=1,
                environment_fingerprint=(
                    coordinator.capabilities.environment_fingerprint
                ),
            )
            for slot in range(workers)
        )

    def drain_once(self) -> bool:
        """Claim one ready item and run it. True if there was one to claim.

        The answer is "was there work", not "did it commit": a failed attempt
        is progress, so a loop reading the other meaning would stop on the first
        failure and strand a retryable row. One item per call, so a caller can
        inspect the stream between steps.
        """

        run_id = self._coordinator.run_id
        for worker in self._workers:
            lease = self._broker.acquire(run_id, worker, now=self._clock())
            if lease is None:
                continue
            self._execute(lease)
            return True
        return False

    def drive(self) -> None:
        """Drain and reclaim until the work frontier is terminal.

        Each pass drains an item, reclaims one, or asks for the next
        generation; a pass that does none of these is the terminal frontier. The
        retry bound and reclaim together keep a deterministically broken
        component from spinning forever.

        Executors run inline, so a component slower than its lease (60 seconds
        by default) outlives it; the lease is re-verified after the component
        returns and before anything is committed (`dispatch_clock.keepalive_for`).
        """

        while True:
            if self.drain_once() or self.reclaim():
                continue
            if not self._decide():
                return

    def _decide(self) -> bool:
        """Ask the policy for the next generation. True if one was committed.

        Only reached with an empty frontier, so every member is produced from
        one complete committed history. Without a program the dispatcher only
        drains what is already enqueued. No readiness guard: the bootstrap
        evaluation is drained or reclaimed before this is reached, and a policy
        asked too early raises `SearchNotStarted` rather than looking finished.
        """

        if self._program is None:
            return False
        if self._coordinator.projection.stop is not None:
            return False
        state = self._coordinator.projection.search_state
        commit_cohort(
            self._coordinator, self._program, self._program.next_cohort(state)
        )
        return True

    def reclaim(self) -> int:
        """Terminate every exhausted row, each with its terminal fact. Count."""

        return reclaim_exhausted(self._coordinator, self._broker)

    def _execute(self, lease: Lease) -> None:
        """Run one claimed item: an attempt, then its completion.

        Three outcomes. An escaping-set exception while resolving inputs or
        inside the executor aborts: it propagates with no release and no cause.
        Any other fault there is an attempt failure: the lease is released with
        its cause and the retry bound decides. A fault after the component
        returned -- building its facts, the provisional fold, the keepalive, the
        commit -- is a completion failure: the dispatcher does not run the
        component again, the cause is recorded against the lease, and the error
        propagates. The row stays LEASED until expiry or rollover returns it to
        READY, after which a later drain may run it again (M11.3 closes that).

        `Exception`, never `BaseException`: an operator's interrupt is neither
        released nor diagnosed, so the next drain does not pick it straight back up.
        """

        # A claimed row missing from the table means the broker and the
        # dispatcher disagree: corruption, not a retry.
        row = next(
            (
                item for item in self._broker.rows(self._coordinator.run_id)
                if item.item == lease.item
            ),
            None,
        )
        if row is None:
            raise DurableCorruption(
                f"leased work item {lease.item.value} is absent from the work "
                "table"
            )
        host = self._coordinator
        correlation = correlation_for_work(row.item.value)
        keepalive = keepalive_for(
            self._broker, self._coordinator.run_id, lease, self._clock
        )
        # The attempt: input resolution and the executor. A raise here is an
        # attempt failure -- released with its cause, and the retry bound decides.
        try:
            if row.kind is WorkKind.EVALUATION:
                trial, artifact = resolve_evaluation(host, row)
                result = self._evaluation_executor.evaluate(artifact)
            else:
                trial, parents, request = resolve_proposal(host, row)
                result = self._proposal_executor.propose(parents, request)
        except CandidateEncodingError as error:
            # The proposer answered; only encoding its candidate failed.
            self._record_completion_failure(lease, error)
            raise
        except Exception as error:
            if escapes_normalization(error):
                raise
            # The cause travels with the release: `_terminate` builds the
            # terminal fact from the row in a later pass, possibly in another
            # process. The answer is not read -- a lease already gone has
            # nothing left to return, and the cause is recorded either way.
            self._broker.release(
                self._coordinator.run_id,
                lease,
                now=self._clock(),
                failure=_reportable_cause(error),
            )
            return
        # The completion: building, validating and committing the result. A
        # raise here is a completion failure. The component already ran, so the
        # dispatcher does not run it again: the cause is recorded against the
        # lease and the error propagates, leaving the row LEASED until expiry or
        # rollover.
        try:
            if row.kind is WorkKind.EVALUATION:
                finish_evaluation(
                    host, lease, trial, artifact.id, result,
                    correlation=correlation, keepalive=keepalive,
                )
            else:
                finish_proposal(
                    host, lease, trial, result, parents,
                    correlation=correlation, keepalive=keepalive,
                )
        except Exception as error:
            self._record_completion_failure(lease, error)
            raise

    def _record_completion_failure(self, lease: Lease, error: Exception) -> None:
        """Write the cause without ever replacing the error being propagated."""

        try:
            self._broker.record_failure(
                self._coordinator.run_id,
                lease,
                now=self._clock(),
                cause=_reportable_cause(error),
            )
        except Exception as secondary:
            try:
                error.add_note(
                    f"recording this failure's cause also failed: "
                    f"{type(secondary).__name__}"
                )
            except Exception:
                pass  # a note is diagnostic; the original still propagates

def _reportable_cause(error: BaseException) -> tuple[str, str]:
    """The failure pair, following one `__cause__` link.

    `complete_proposal` raises `InvalidDecision("trial parent is unavailable
    from artifact storage") from error`, so the wrapper names the symptom and
    the real storage error is one link away. Recording only the wrapper put a
    generic sentence on the row and in the terminal fact, which is the thing
    the diagnostics work exists to stop.

    ONE link, not a walk to the root: the immediate cause is the one the
    wrapper chose to attach, and a deeper chain is the cause's own business.
    """

    cause = error.__cause__
    if cause is None:
        return (type(error).__name__, str(error))
    # The TYPE field stays a bare class name: `application/work.py` documents
    # that `exception_type` matches what the callable adapters record, and they
    # record `type(error).__name__`. The chain belongs in the message.
    return (
        type(error).__name__,
        f"{error} (caused by {type(cause).__name__}: {cause})",
    )


__all__ = [
    "DEFAULT_WORKERS",
    "Dispatcher",
    "ManualClock",
    "wall_clock",
]


