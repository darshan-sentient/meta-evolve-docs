"""Issue grants and expose a narrowly bound, fully audited reader."""

from __future__ import annotations

import sqlite3
from typing import Callable, Protocol

from meta_evolve.domain import (
    CorrelationId,
    ExperienceAccessDeclared,
    ExperienceGrant,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    ExperienceSpec,
    RunId,
    TaskId,
    Trial,
    SourceHistoryMounted,
)
from meta_evolve.errors import (
    ExperienceStoreUnavailable,
)
from meta_evolve.ports import ArtifactStore

from .audited_reader import AuditedExperienceReader
from .experience_replay import replay_experience_graph
from .identities import correlation_for_run, correlation_for_trial
from .run_projection import RunProjection
from .source_resolution import resolve_source_tree


class ExperienceHost(Protocol):
    run_id: RunId
    task_id: TaskId
    artifacts: ArtifactStore

    @property
    def projection(self) -> RunProjection: ...

    def read_events(self) -> tuple: ...

    def append_fact(self, body: object, *, correlation: CorrelationId): ...


def _audit_commit(append: Callable[[], object]) -> object:
    """Commit one reader audit event, re-raising a RAW store fault as the typed
    ``ExperienceStoreUnavailable`` infra sentinel.

    This is the only thing running inside a proposer call that commits to
    storage, so it is where an audit-store commit fault must be made
    distinguishable from a user-proposer error. A raw ``OSError`` /
    ``sqlite3.Error`` from the underlying commit is wrapped so the proposer
    adapter can let it ESCAPE, while a user proposer's own ``OSError`` (which
    never reaches here) stays a recoverable ``ProposerFailure``.

    The DOMAIN infra types (``EventStreamConflict``, ``DurableCorruption``,
    ``InvalidSearchHistory``) are NOT caught here -- they keep their own
    identity and propagate unwrapped (e.g. the two-resumer ``EventStreamConflict``
    semantics depend on it).
    """

    try:
        return append()
    except (OSError, sqlite3.Error) as error:
        raise ExperienceStoreUnavailable(
            "durable audit-event commit for an experience reader operation failed"
        ) from error


def declare_experience(host: ExperienceHost, spec: ExperienceSpec | None) -> None:
    if spec is None:
        return
    correlation = correlation_for_run(host.run_id)
    _audit_commit(
        lambda: host.append_fact(
            ExperienceAccessDeclared(spec=spec), correlation=correlation
        )
    )


def issue_or_load_reader(
    host: ExperienceHost,
    trial: Trial,
    spec: ExperienceSpec | None,
):
    if spec is None:
        return None
    correlation = correlation_for_trial(trial.id)
    grant = host.projection.grant_for(trial.id)
    if grant is None:
        grant = ExperienceGrant(
            run_id=host.run_id,
            task_id=host.task_id,
            trial_id=trial.id,
            as_of=trial.logical_step - 1,
            spec=spec,
        )
        _audit_commit(
            lambda: host.append_fact(
                ExperienceGrantIssued(grant=grant), correlation=correlation
            )
        )
        grant = host.projection.grant_for(trial.id)
        assert grant is not None

    def append_audit(body: object):
        if not isinstance(
            body,
            (
                ExperienceOperationAttempted,
                ExperienceOperationSucceeded,
                ExperienceOperationDenied,
                ExperienceOperationBudgetExhausted,
                SourceHistoryMounted,
            ),
        ):
            raise TypeError("experience reader may append only pull audit facts")
        return _audit_commit(
            lambda: host.append_fact(body, correlation=correlation)
        )

    return AuditedExperienceReader(
        grant=grant,
        projection=lambda: host.projection,
        graph=lambda: replay_experience_graph(host.run_id, host.read_events()),
        append=append_audit,
        resolve_source=lambda occurrence: resolve_source_tree(
            host.artifacts, occurrence
        ),
    )


__all__ = [
    "AuditedExperienceReader",
    "declare_experience",
    "issue_or_load_reader",
]
