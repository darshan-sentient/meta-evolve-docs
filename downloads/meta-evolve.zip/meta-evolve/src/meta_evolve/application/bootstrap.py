"""Build and atomically commit a run's evaluated bootstrap."""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    ArtifactCreated,
    ArtifactId,
    BootstrapPrepared,
    Budget,
    ComponentRef,
    ContextPolicyDeclared,
    ContextSpec,
    CorrelationId,
    DecisionId,
    ExperienceAccessDeclared,
    ExperienceSpec,
    OperatorSpec,
    Proposal,
    ProposalId,
    RunCapabilities,
    RunId,
    RunStarted,
    SearchSpec,
    Task,
    TaskId,
    Trial,
    TrialCompleted,
    TrialId,
    TrialOutcome,
    TrialSpec,
    Usage,
)
from meta_evolve.errors import BudgetUnavailable
from meta_evolve.ports.callables import Evaluator

from .codecs import CodecIndex
from .evaluation_execution import build_evaluation
from .identities import stable_id
from .projections import RunProjection
from .committed_fold import fold_committed
from .work import has_zero_resource


class BootstrapHost(Protocol):
    run_id: RunId
    task_id: TaskId
    task: Task
    run_budget: Budget
    random_seed: int
    search: SearchSpec
    evaluator: Evaluator
    capabilities: RunCapabilities
    codecs: CodecIndex

    @property
    def projection(self) -> RunProjection: ...

    def _batch_envelopes(
        self,
        bodies: list[object],
        correlation: CorrelationId,
        pre: RunProjection,
    ) -> list: ...

    def commit_batch(
        self,
        bodies: list[object],
        *,
        occurrences: tuple[Artifact, ...],
        correlation: CorrelationId,
    ) -> RunProjection: ...


def start_run(
    host: BootstrapHost,
    seed: object,
    *,
    context_spec: ContextSpec | None,
    experience_spec: ExperienceSpec | None,
) -> None:
    required = Usage(evaluations=1)
    if not host.run_budget.allows(required) or has_zero_resource(
        host.run_budget, evaluation=True
    ):
        raise BudgetUnavailable("effective budget cannot fund seed evaluation")
    if host.task.budget is not None and (
        not host.task.budget.allows(required)
        or has_zero_resource(host.task.budget, evaluation=True)
    ):
        raise BudgetUnavailable("task budget cannot fund seed evaluation")

    seed_id = stable_id(ArtifactId, "artifact", host.run_id.value, "seed")
    run_correlation = stable_id(CorrelationId, "correlation", host.run_id.value)
    run_started = RunStarted(
        task_id=host.task_id,
        task=host.task,
        seed_artifact_id=seed_id,
        run_budget=host.run_budget,
        random_seed=host.random_seed,
        search=host.search,
        capabilities=host.capabilities,
    )

    decision_id = stable_id(DecisionId, "bootstrap-decision", host.run_id.value)
    trial_id = stable_id(TrialId, "trial", decision_id.value)
    operator = OperatorSpec(kind="bootstrap")
    spec = TrialSpec(
        task_id=host.task_id,
        parent_ids=(),
        proposer=ComponentRef.proposer("meta_evolve:bootstrap", "1"),
        operator=operator,
        budget=Budget(evaluations=1),
        random_seed=host.random_seed,
    )
    trial = Trial(
        id=trial_id,
        run_id=host.run_id,
        decision_id=decision_id,
        logical_step=0,
        spec=spec,
    )
    proposal = Proposal(
        id=stable_id(ProposalId, "proposal", trial_id.value),
        trial_id=trial_id,
        parent_ids=(),
        operator=operator,
        metadata={"bootstrap": True},
    )
    artifact = Artifact(
        id=seed_id,
        payload=seed,
        kind=host.task.artifact_kind,
        representation=host.task.artifact_representation,
        provenance={
            "proposal_id": proposal.id.value,
            "run_id": host.run_id.value,
            "trial_id": trial.id.value,
        },
    )
    outcome = TrialOutcome.succeeded(
        trial_id=trial.id,
        proposal_id=proposal.id,
        artifact_ids=(artifact.id,),
    )
    prefix_bodies = [
        run_started,
        BootstrapPrepared(trial=trial, proposal=proposal),
        ArtifactCreated(artifact_id=artifact.id),
        TrialCompleted(trial=trial, outcome=outcome),
    ]

    provisional = host.projection
    for envelope in host._batch_envelopes(
        prefix_bodies, run_correlation, host.projection
    ):
        provisional = fold_committed(provisional, envelope)

    evidence_bodies, evaluation_completed = build_evaluation(
        provisional,
        trial,
        artifact,
        task=host.task,
        evaluator=host.evaluator,
        run_budget=host.run_budget,
        codecs=host.codecs,
    )
    genesis_bodies: list[object] = [
        *prefix_bodies,
        *evidence_bodies,
        evaluation_completed,
    ]
    if context_spec is not None:
        genesis_bodies.append(ContextPolicyDeclared(spec=context_spec))
    if experience_spec is not None:
        genesis_bodies.append(ExperienceAccessDeclared(spec=experience_spec))

    host.commit_batch(
        genesis_bodies,
        occurrences=(artifact,),
        correlation=run_correlation,
    )


__all__ = ["start_run"]
