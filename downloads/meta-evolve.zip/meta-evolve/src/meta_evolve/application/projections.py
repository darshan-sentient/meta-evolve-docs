"""Single-source replay for the kernel run lifecycle and policy view."""

from __future__ import annotations

from collections.abc import Iterable

from meta_evolve.domain.events import EventEnvelope
from meta_evolve.domain.identity import EventId, RunId
from meta_evolve.domain.search import InvalidSearchHistory, SearchState

from .identities import stable_id
from .run_projection import RunProjection
from .committed_fold import fold_committed
from .transitions import invalid


def replay_run_projection(
    run_id: RunId,
    events: Iterable[EventEnvelope],
) -> RunProjection:
    state = RunProjection.empty(run_id)
    for expected_sequence, event in enumerate(events, start=1):
        if not isinstance(event, EventEnvelope):
            raise InvalidSearchHistory("search history contains a non-event value")
        if event.run_id != run_id:
            raise invalid(event.sequence, "event belongs to another run")
        if event.sequence != expected_sequence:
            raise invalid(event.sequence, f"expected sequence {expected_sequence}")
        state = fold_committed(state, event)
    return state


def verify_event_chain(
    run_id: RunId,
    events: Iterable[EventEnvelope],
) -> None:
    """Verify each event's id is reproducible and its causation immediate.

    Every real event's id is ``stable_id(EventId, "event", run_id, sequence)``
    and every committed batch (a coordinator batch, or the 1-event append_fact
    shim) chains causation to the prior committed tail — i.e. the immediately
    preceding event (the first event -> ``None``). ``replay_run_projection``
    only checks per-event *semantics* and accepts any ``causation_id`` naming a
    prior event, so a durably-stored event whose id was rewritten, or whose
    cause was repointed away from its predecessor at the same sequence, would
    replay cleanly. The durable ``resume`` path calls this to reject such
    tampering with ``InvalidSearchHistory`` (which ``resume`` surfaces as
    ``DurableCorruption``). It is deliberately NOT folded into the shared
    ``replay_run_projection``: many in-memory callers legitimately replay
    hand-constructed streams (M3 experience/context replay rejections, core
    projection fixtures) whose synthetic ids are not derived from
    ``stable_id`` — the reproducible-id/immediate-causation guarantee is a
    property of the *durable store*, so it is enforced where a durable stream
    is read back and re-driven, not on every projection replay.
    """

    previous_id: EventId | None = None
    for event in events:
        if not isinstance(event, EventEnvelope):
            raise InvalidSearchHistory("search history contains a non-event value")
        expected_id = stable_id(EventId, "event", run_id.value, event.sequence)
        if event.id != expected_id:
            raise invalid(event.sequence, "event id is not reproducible")
        if event.causation_id != previous_id:
            raise invalid(
                event.sequence,
                "event causation must reference the immediate predecessor",
            )
        previous_id = event.id


def replay_search_state(
    run_id: RunId,
    events: Iterable[EventEnvelope],
) -> SearchState:
    """Rebuild the policy view through the single lifecycle projection."""

    return replay_run_projection(run_id, events).search_state


__all__ = [
    "RunProjection",
    "replay_run_projection",
    "replay_search_state",
    "verify_event_chain",
]
