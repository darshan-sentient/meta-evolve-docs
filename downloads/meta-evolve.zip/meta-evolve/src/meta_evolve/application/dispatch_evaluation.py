"""What the dispatcher does with EVALUATION work.

The sibling of `dispatch_proposal.py`, split for the same reason: this module
knows one work kind's facts and nothing about scheduling.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from meta_evolve.domain import Artifact, ArtifactId, Budget, CorrelationId, Task, Trial
from meta_evolve.domain.work import Lease, WorkRow
from meta_evolve.ports import ArtifactStore
from meta_evolve.ports.callables import Evaluator
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.callables import EvaluationResult
from meta_evolve.ports.work_store import (
    AcceptCompletion,
    Acknowledgment,
)

from .hosts import CommitBatchHost
from .codecs import CodecIndex
from .evaluation_execution import build_evaluation
from .executors import EvaluationExecutor
from .integrity import load_committed_artifact
from .run_projection import RunProjection
from .work import terminal_ending


class EvaluationDispatchHost(CommitBatchHost, Protocol):
    """What this module needs of a coordinator, and all of it.

    Declared because the completeness gate can only check a contract that
    exists: a module taking a bare `host` contributes nothing to check and
    passes vacuously, which is the defect `DecisionHost` was fixed for and this
    module reintroduced one commit later.
    """

    task: Task
    run_budget: Budget
    evaluator: Evaluator
    codecs: CodecIndex
    artifacts: ArtifactStore

    @property
    def projection(self) -> RunProjection: ...


def complete_evaluation(
    host: EvaluationDispatchHost,
    row: WorkRow,
    lease: Lease,
    *,
    executor: EvaluationExecutor,
    correlation: CorrelationId,
    keepalive: Callable[[], tuple[Lease, int]],
) -> None:
    """Resolve, execute and finish one evaluation, with no failure boundary.

    The dispatcher calls the three stages itself, because a fault before the
    component returns and a fault after it are handled differently.
    """

    trial, artifact = resolve_evaluation(host, row)
    finish_evaluation(
        host,
        lease,
        trial,
        artifact.id,
        executor.evaluate(artifact),
        correlation=correlation,
        keepalive=keepalive,
    )


def resolve_evaluation(
    host: EvaluationDispatchHost, row: WorkRow
) -> tuple[Trial, Artifact]:
    """Input resolution: the trial an evaluation is owed for, and its artifact."""

    completed = host.projection.completed_trial(row.trial_id)
    if completed is None:
        # Enqueue is atomic with the batch that completes the trial, so a
        # ready evaluation whose trial is missing means the row and the
        # stream disagree -- a corruption, not a race to retry.
        raise DurableCorruption(
            f"evaluation work for unknown trial {row.trial_id.value}"
        )
    if not completed.outcome.artifact_ids:
        # Only a trial whose disposition says *evaluate* is ever enqueued,
        # and a failed trial produced no artifact -- so a row that reaches
        # here means the enqueue and the disposition disagree. Said plainly
        # rather than left as an `IndexError` from a bare subscript, which
        # is what a mutation that ignored the disposition actually produced.
        raise DurableCorruption(
            f"evaluation work for trial {row.trial_id.value}, which has "
            "no artifact to evaluate"
        )
    return completed.trial, load_committed_artifact(
        host.artifacts, completed.outcome.artifact_ids[0]
    )


def finish_evaluation(
    host: EvaluationDispatchHost,
    lease: Lease,
    trial: Trial,
    artifact_id: ArtifactId,
    result: EvaluationResult,
    *,
    correlation: CorrelationId,
    keepalive: Callable[[], tuple[Lease, int]],
) -> None:
    """Build the evaluation's facts from its result and commit them with the acceptance."""

    evidence, evaluation = build_evaluation(
        host.projection,
        trial,
        artifact_id,
        task=host.task,
        result=result,
        run_budget=host.run_budget,
    )
    # AFTER the build, immediately before the commit: the lease this batch is
    # accepted under must still be ours, and the reading that proves it is the
    # one the intent carries into the transaction. Checking before the build
    # would leave the build itself unguarded. REQUIRED, not defaulted -- an
    # optional safety check is one a future caller drops by forgetting it.
    live, now = keepalive()

    host.commit_batch(
        [*evidence, evaluation],
        correlation=correlation,
        work=(
            AcceptCompletion(
                lease=live,
                now=now,
                acknowledgment=Acknowledgment(
                    {"evaluation_id": evaluation.evaluation.id.value}
                ),
            ),
        ),
    )


def terminate_evaluation(
    host: EvaluationDispatchHost, row: WorkRow, *, correlation: CorrelationId
) -> None:
    """The terminal fact for this row's kind, and the intent, as one commit.

    Each kind owes the fact its own kind takes. A proposal that burned its
    attempts produced no artifact, so what the stream is missing is the
    TRIAL; an evaluation that burned its attempts has a trial already, so
    what it is missing is the evaluation. Neither may be left as a bare
    CANCELLED row: that would strand the decision that authorized it with
    nothing in the stream accounting for it.
    """

    completed = host.projection.completed_trial(row.trial_id)
    if completed is None:
        raise DurableCorruption(
            f"evaluation work for unknown trial {row.trial_id.value}"
        )
    if not completed.outcome.artifact_ids:
        # The same guard `complete_evaluation` states, for the same reason, on
        # the path MORE likely to meet a failed trial -- this is the
        # retries-exhausted one. It was guarded there and left bare here, so
        # the identical corruption surfaced as an `IndexError` out of
        # `reclaim()` with no run id, item id or explanation, on the one path
        # that has no retry left to soften it.
        raise DurableCorruption(
            f"evaluation work for trial {row.trial_id.value}, which has "
            "no artifact to evaluate"
        )
    # NO DURABLE READ HERE -- this is the fix. This path previously did
    # `host.artifacts.get(...)`, re-running the very read whose failure
    # exhausted the row. Against a persistently unavailable artifact store the
    # read failed again, the error left `Dispatcher.drive()` entirely, and the
    # row was left both unclaimable (`attempts >= max_attempts`) and
    # unterminable, because every later reclaim re-raised in the same place.
    # The id is already in hand and it is all `build_evaluation` ever wanted.
    artifact_id = completed.outcome.artifact_ids[0]

    # Typed, and typed as what it is. The attempts died on raises the
    # normalization boundary did NOT let escape, which is infrastructure by
    # this repository's own taxonomy -- never a low score, and never
    # collapsed into a plain evaluator failure that would read as "the
    # candidate was bad".
    ending = terminal_ending(row)
    ended = EvaluationResult(failure=ending.failure)
    evidence, evaluation = build_evaluation(
        host.projection,
        completed.trial,
        artifact_id,
        task=host.task,
        result=ended,
        run_budget=host.run_budget,
    )
    # No keepalive here: reclaim runs over READY rows that hold no lease at
    # all -- either the attempts are spent or the row is diagnosed and will
    # never spend them -- so there is nothing to keep alive, and both intents
    # are fenced on the row rather than on a lease.
    host.commit_batch(
        [*evidence, evaluation],
        correlation=correlation,
        work=(ending.intent,),
    )


__all__ = [
    "complete_evaluation",
    "finish_evaluation",
    "resolve_evaluation",
    "terminate_evaluation",
]
