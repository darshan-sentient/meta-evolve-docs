"""Lease checks using the broker's deadline authority.

The injected clock supplies absolute seconds. The broker persists and clamps
that clock domain so a restart or clock rollback cannot revive an expired lease.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass

from meta_evolve.domain import RunId
from meta_evolve.domain.work import Lease
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.work_store import InvalidWorkAppend, WorkBroker
from meta_evolve.ports.work_submission import AlreadyAccepted, StaleCompletion

@dataclass(slots=True)
class ManualClock:
    """The deterministic clock every dispatcher test drives."""

    now: int = 0

    def __call__(self) -> int:
        return self.now

    def advance(self, seconds: int) -> int:
        self.now += seconds
        return self.now


def wall_clock() -> int:
    """Absolute seconds, preserving the meaning of deadlines across restarts."""

    return int(time.time())


def keepalive_for(
    broker: WorkBroker,
    run_id: RunId,
    lease: Lease,
    clock: Callable[[], int],
    *,
    epoch: int | None = None,
) -> Callable[[], tuple[Lease, int]]:
    """Build the renewal check used during execution and before commitment.

    One broker transaction renews the lease or returns its stale reason.
    Stale reasons become StaleCompletion; AlreadyAccepted or a missing item
    become DurableCorruption because they contradict this dispatcher's state.

    The dispatch loop (`dispatch_loop.py`) calls the same check every
    `lease // 4` while a component runs, so one rule serves both.

    Return the renewed lease with the clock sample used for the check so
    AcceptCompletion validates the same instant. Completion builders call this
    after building facts, keeping that work inside the lease check.
    """

    def check() -> tuple[Lease, int]:
        now = clock()
        try:
            answer = broker.renew_or_stale(run_id, lease, now=now, epoch=epoch)
        except InvalidWorkAppend as error:
            raise DurableCorruption(
                f"work item {lease.item.value} was claimed by this dispatcher and "
                "is no longer held by the run"
            ) from error
        if isinstance(answer, Lease):
            return answer, now
        if isinstance(answer, AlreadyAccepted):
            raise DurableCorruption(
                f"work item {lease.item.value} is recorded as already accepted "
                "under the lease this dispatcher still holds uncommitted"
            )
        raise StaleCompletion(lease.item, answer)

    return check


__all__ = ["ManualClock", "keepalive_for", "wall_clock"]
