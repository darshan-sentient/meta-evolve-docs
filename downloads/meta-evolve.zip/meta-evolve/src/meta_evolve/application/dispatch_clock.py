"""The dispatcher's clock domain, and the one decision it makes.

Split from `dispatcher.py` because time is a separate responsibility from
scheduling: the loop decides WHAT to run next, and this decides whether the
lease that work will be committed under is still ours. Both are small, and
keeping them together pushed one module past the length this repository asks
for.

The clock is a PARAMETER everywhere here, never read. The record puts deadlines
in a single clock domain the broker owns and clamps, so a scheduler reading its
own clock would be a second authority; and injected, every expiry in a test is
a value the test sets rather than a race it hopes to win.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from meta_evolve.domain import RunId
from meta_evolve.domain.work import Lease
from meta_evolve.errors import CapabilityError

@dataclass(slots=True)
class ManualClock:
    """The deterministic clock every dispatcher test drives."""

    now: int = 0

    def __call__(self) -> int:
        return self.now

    def advance(self, seconds: int) -> int:
        self.now += seconds
        return self.now


def wall_clock() -> int:
    """The shipped default: absolute seconds from a single authority.

    Absolute rather than `time.monotonic()`, whose origin is process-relative --
    so a restart rebases it and a persisted deadline becomes meaningless, which
    is the exact failure the broker's non-decreasing clamp exists to survive.
    """

    return int(time.time())


def keepalive_for(broker, run_id: RunId, lease: Lease, clock):
    """Re-verify the lease after the component returns, before committing.

    The dispatcher owns leases, so the check lives here and the fact modules
    receive it as a callable -- they know what facts a work kind takes and
    nothing about brokers.

    A component slower than its lease is a CONFIGURATION fault, not a transient
    one. Retrying it would spend the whole retry bound and then report
    "exhausted 3 attempts", naming the symptom and burying the cause, so this
    raises `CapabilityError` -- a member of `ESCAPING_EXCEPTIONS`, so
    `_execute` propagates it rather than releasing.

    Returns the renewed lease AND the exact clock sample it used, because
    `AcceptCompletion` carries `now` into the transaction: re-sampling at the
    commit would check a different instant than the one just verified.

    Called after the facts are built, not straight after the component: the
    build, the provisional fold and the commit all happen after the worker
    returns, and a check before them leaves that window unguarded.
    """

    def check() -> tuple[Lease, int]:
        now = clock()
        renewed = broker.renew(run_id, lease, now=now)
        if renewed is None:
            raise CapabilityError(
                f"work item {lease.item.value} no longer holds the lease its "
                "result would be committed under (wrong item, superseded "
                "attempt, token mismatch, stale epoch, or an expired deadline "
                "-- renew does not distinguish them), so the result cannot be "
                "committed safely"
            )
        return renewed, now

    return check


__all__ = ["ManualClock", "keepalive_for", "wall_clock"]
