"""Whole-stream validation: a dependency grammar keyed by trial.

``batch_grammar`` owns what a single batch may look like. This module owns what
an ORDER of batches may look like, and it is the half concurrency changes.

A generational cohort commits several decisions together, and their results
arrive in whatever order the work finishes, so the rules are asked of a *trial*
rather than of a position:

* genesis exactly once, first;
* nothing at all after a committed stop;
* a result batch only for a trial that was decided and has not completed;
* an evaluation batch only for a trial whose result succeeded and which has not
  been evaluated;
* standalone M3 facts anywhere between batches;
* the stream may end after any complete batch.

What is *not* enforced here is anything about budgets, authority or provenance:
this reads shapes and identities only. The fold owns the rest, and the decision
barrier owns whether a decision was admissible at all.
"""

from __future__ import annotations

import enum
from collections.abc import Sequence

from meta_evolve.domain import (
    BootstrapPrepared,
    ArchiveUpdate,
    EvaluationCompleted,
    EvidenceRecorded,
    PolicyDecisionMade,
    ProposalSubmitted,
    Stop,
    TrialId,
    TrialSpec,
)
from meta_evolve.errors import DurableCorruption

from .batch_grammar import (
    consume_cohort,
    consume_evaluation,
    consume_genesis,
    consume_result,
    is_m3_fact,
)


class _Trial(enum.Enum):
    """How far one trial has progressed through the stream."""

    DECIDED = "decided"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    EVALUATED = "evaluated"
    CLOSED = "closed"


class _StreamScanner:
    """Consume a batch at a time, tracking each trial rather than a position.

    Each ``consume_*`` raises ``DurableCorruption`` the moment a required fact is
    missing or the wrong type appears -- which is how an incomplete tail (a batch
    cut off by a crash between the preflight fold and the store commit, or by a
    foreign writer) is detected: the closing fact is absent, so the batch parser
    sees end-of-stream where a body was mandatory.
    """

    def __init__(self, bodies: Sequence[object]) -> None:
        self._bodies = list(bodies)
        self._i = 0
        self._trials: dict[TrialId, _Trial] = {}
        self._stopped = False

    @property
    def _done(self) -> bool:
        return self._i >= len(self._bodies)

    def _peek(self) -> object | None:
        return None if self._done else self._bodies[self._i]

    def _skip_m3_facts(self) -> None:
        """Advance past any run of standalone M3 context/experience batches."""

        while is_m3_fact(self._peek()):
            self._i += 1

    def scan(self) -> None:
        # An empty stream is NOT corruption; it classifies as RUN_NOT_FOUND.
        if self._done:
            return
        genesis_start = self._i
        self._i = consume_genesis(self._bodies, self._i)
        self._register_bootstrap(genesis_start)
        self._skip_m3_facts()
        while not self._done:
            self._consume_batch()
            # Check the terminator BEFORE skipping: a standalone fact after a
            # committed stop is exactly as forbidden as a batch, and skipping
            # first would consume it silently.
            self._refuse_after_stop()
            self._skip_m3_facts()

    def _register_bootstrap(self, start: int) -> None:
        """Teach the scanner about the trial genesis created.

        Every other trial reaches `self._trials` through the decision batch that
        minted it. The bootstrap has no decision -- it arrives as
        `BootstrapPrepared` inside genesis, which is consumed opaquely -- so
        without this it is a trial the scanner has never heard of.

        That costs nothing while genesis carries its own evaluation, because the
        evaluation is consumed as part of the same opaque batch. It costs
        everything the moment a distributed genesis defers it: the standalone
        evaluation batch that follows names a trial the scanner cannot place,
        and is refused as "not owed". A second, independent refusal from the
        mode gate, and the split needs both lifted.

        Recorded as SUCCEEDED because genesis only parses when it carries the
        bootstrap's `TrialCompleted`, and a genesis whose bootstrap failed is
        not a shape this grammar has ever admitted.
        """

        prepared = self._bodies[start + 1]
        assert isinstance(prepared, BootstrapPrepared)
        self._trials[prepared.trial.id] = _Trial.SUCCEEDED
        for body in self._bodies[start : self._i]:
            if isinstance(body, EvaluationCompleted):
                self._trials[prepared.trial.id] = _Trial.EVALUATED

    def _refuse_after_stop(self) -> None:
        if self._stopped and not self._done:
            found = type(self._peek()).__name__
            raise DurableCorruption(
                f"a committed Stop decision cannot be followed by {found} "
                f"at event {self._i}"
            )

    def _consume_batch(self) -> None:
        self._refuse_after_stop()
        head = self._peek()
        if isinstance(head, PolicyDecisionMade):
            self._consume_cohort()
        elif isinstance(head, ProposalSubmitted):
            self._consume_result()
        elif isinstance(head, (EvidenceRecorded, EvaluationCompleted)):
            self._consume_evaluation()
        else:
            # No pragma. "Every batch head is one of the above" is true of a
            # stream THIS process wrote, and this scanner exists for the ones it
            # did not: delete a result batch's `ProposalSubmitted` and the next
            # boundary lands on an `ArtifactCreated`, which arrives here. That is
            # the torn or foreign store the whole scan is for, so marking the arm
            # unreachable marked the defence as dead code.
            raise DurableCorruption(
                f"unexpected {type(head).__name__} at event {self._i}: a batch "
                "must open a decision, a result, or an evaluation"
            )

    def _consume_cohort(self) -> None:
        start = self._i
        # A decision opens a new generation, so anything the previous one left
        # successful-but-unevaluated is closed: its evaluation was skipped, and
        # a later one for it would be retroactive. Cohort members do not lose
        # their evaluations to this, because they are committed together BEFORE
        # any of their results.
        for trial_id, state in list(self._trials.items()):
            if state is _Trial.SUCCEEDED:
                self._trials[trial_id] = _Trial.CLOSED
        decisions, self._i = consume_cohort(self._bodies, self._i)
        records = self._bodies[start : self._i : 2]
        for record, decision in zip(records, decisions, strict=True):
            if isinstance(decision, Stop):
                self._stopped = True
            elif isinstance(decision, TrialSpec):
                assert isinstance(record, PolicyDecisionMade)
                trial_id = record.trial_id
                assert trial_id is not None
                if trial_id in self._trials:
                    raise DurableCorruption(
                        f"trial {trial_id.value} was already decided at event "
                        f"{start}"
                    )
                self._trials[trial_id] = _Trial.DECIDED
            elif not isinstance(decision, ArchiveUpdate):  # pragma: no cover
                raise DurableCorruption(
                    f"unsupported decision {type(decision).__name__} at event "
                    f"{start} in stream"
                )

    def _consume_result(self) -> None:
        start = self._i
        trial_id, succeeded, self._i = consume_result(self._bodies, self._i)
        state = self._trials.get(trial_id)
        if state is None:
            raise DurableCorruption(
                f"result batch at event {start} belongs to undecided trial "
                f"{trial_id.value}"
            )
        if state is not _Trial.DECIDED:
            raise DurableCorruption(
                f"trial {trial_id.value} already completed before the result "
                f"batch at event {start}"
            )
        self._trials[trial_id] = _Trial.SUCCEEDED if succeeded else _Trial.FAILED

    def _consume_evaluation(self) -> None:
        start = self._i
        trial_id, self._i = consume_evaluation(self._bodies, self._i)
        if self._trials.get(trial_id) is not _Trial.SUCCEEDED:
            raise DurableCorruption(
                f"evaluation batch at event {start} is not owed: trial "
                f"{trial_id.value} has no successful, unevaluated result"
            )
        self._trials[trial_id] = _Trial.EVALUATED


def scan_batch_grammar(bodies: Sequence[object]) -> None:
    """Validate the whole ordered stream, or raise ``DurableCorruption``.

    Shared by the write-side preflight and every read path, so "committed"
    cannot come apart from "recoverable".
    """

    _StreamScanner(bodies).scan()


__all__ = ["scan_batch_grammar"]
