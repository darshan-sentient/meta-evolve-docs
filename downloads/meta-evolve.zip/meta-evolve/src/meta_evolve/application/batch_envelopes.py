"""Build identical envelopes for provisional folds and committed batches.

Sequences continue from the projection's version, IDs derive from the run and
sequence, and each envelope's cause is the preceding event.
"""

from __future__ import annotations

from collections.abc import Sequence

from meta_evolve.domain import CorrelationId, EventEnvelope, EventId, RunId

from .identities import stable_id
from .run_projection import RunProjection


def batch_envelopes(
    run_id: RunId,
    bodies: Sequence[object],
    correlation: CorrelationId,
    pre: RunProjection,
) -> list[EventEnvelope]:
    """Contiguous envelopes for ``bodies``, starting after ``pre``."""

    pre_version = pre.version
    envelopes: list[EventEnvelope] = []
    previous_id = pre.event_ids[-1] if pre.event_ids else None
    for offset, body in enumerate(bodies, start=1):
        sequence = pre_version + offset
        envelope = EventEnvelope(
            id=stable_id(EventId, "event", run_id.value, sequence),
            run_id=run_id,
            sequence=sequence,
            correlation_id=correlation,
            causation_id=previous_id,
            body=body,
        )
        envelopes.append(envelope)
        previous_id = envelope.id
    return envelopes


__all__ = ["batch_envelopes"]
