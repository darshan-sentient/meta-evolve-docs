"""Build one batch's event envelopes.

Split from `coordinator.py`, which crossed 300 lines. Envelope construction is
its own responsibility and its own invariant: sequences are contiguous from the
projection's version, each id is derived from the run and the sequence, and the
causation chain links each envelope to the one before it.

A free function rather than a method because it needs only the run id and the
projection it is extending, and because both `commit_batch` and `start`'s
provisional prefix fold call it — a provisional fold that built envelopes
differently from the committed batch would make the two disagree about ids.
"""

from __future__ import annotations

from collections.abc import Sequence

from meta_evolve.domain import CorrelationId, EventEnvelope, EventId, RunId

from .identities import stable_id
from .run_projection import RunProjection


def batch_envelopes(
    run_id: RunId,
    bodies: Sequence[object],
    correlation: CorrelationId,
    pre: RunProjection,
) -> list[EventEnvelope]:
    """Contiguous envelopes for ``bodies``, starting after ``pre``."""

    pre_version = pre.version
    envelopes: list[EventEnvelope] = []
    previous_id = pre.event_ids[-1] if pre.event_ids else None
    for offset, body in enumerate(bodies, start=1):
        sequence = pre_version + offset
        envelope = EventEnvelope(
            id=stable_id(EventId, "event", run_id.value, sequence),
            run_id=run_id,
            sequence=sequence,
            correlation_id=correlation,
            causation_id=previous_id,
            body=body,
        )
        envelopes.append(envelope)
        previous_id = envelope.id
    return envelopes


__all__ = ["batch_envelopes"]
