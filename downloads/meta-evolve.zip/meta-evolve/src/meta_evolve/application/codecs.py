"""Built-in artifact codecs and the per-run resolution index."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping

from meta_evolve.domain.skill_set import SkillSet
from meta_evolve.domain.source_tree import SourceTree
from meta_evolve.domain.text import Text
from meta_evolve.domain.trial import Artifact
from meta_evolve.domain.evaluation import Failure
from meta_evolve.domain.values import FrozenValue, freeze
from meta_evolve.errors import CapabilityError, DurableCorruption
from meta_evolve.harness.codec import HarnessArtifactCodec
from meta_evolve.policy.codec import PolicyArtifactCodec
from meta_evolve.ports.codecs import ArtifactCodec


@dataclass(frozen=True, slots=True)
class PythonValueCodec:
    """The default codec: freezes any JSON-like value that is not a tree."""

    kind: str = "python-value"
    representation: str = "canonical-json"
    interfaces: tuple[str, ...] = ()

    def encode(self, value: object) -> FrozenValue:
        if isinstance(value, (SourceTree, SkillSet)):
            # Both are mappings, so ``freeze`` would otherwise accept them and
            # return a payload silently stripped of its type. Every codec's
            # encode is reached by seeds and by proposed candidates alike, so
            # these messages say "values" where the pre-codec dispatch could
            # only say "seeds".
            name = type(value).__name__
            raise ValueError(f"{name} values require Task(artifact={name})")
        return freeze(value)

    def decode(self, payload: FrozenValue) -> object:
        return payload


@dataclass(frozen=True, slots=True)
class SourceTreeCodec:
    """Translates ``SourceTree`` values to and from their frozen payload."""

    kind: str = SourceTree.KIND
    representation: str = SourceTree.REPRESENTATION
    interfaces: tuple[str, ...] = ()

    def encode(self, value: object) -> FrozenValue:
        # Named by kind, not representation: ``utf8-tree-v1`` now carries two
        # schemas, and only the kind says which one this task declared.
        if not isinstance(value, SourceTree):
            raise TypeError("source-tree tasks require a SourceTree value")
        return value.to_payload()

    def decode(self, payload: FrozenValue) -> object:
        return SourceTree.from_payload(payload)


@dataclass(frozen=True, slots=True)
class SkillSetCodec:
    """Translates ``SkillSet`` values to and from their frozen payload.

    Shares ``SourceTreeCodec``'s representation and differs only by kind: the
    same portable tree bytes, read under a different schema. The declared
    interface names what a consumer can rely on — skill documents addressable
    by name — rather than the kind, so a later artifact that also carries
    ``skills/<name>.md`` (M8's harness bundle) can declare it and reuse the
    same consumers.
    """

    kind: str = SkillSet.KIND
    representation: str = SkillSet.REPRESENTATION
    interfaces: tuple[str, ...] = ("skill-documents/v1",)

    def encode(self, value: object) -> FrozenValue:
        if not isinstance(value, SkillSet):
            raise TypeError("skill-set tasks require a SkillSet value")
        return value.to_payload()

    def decode(self, payload: FrozenValue) -> object:
        return SkillSet.from_payload(payload)


@dataclass(frozen=True, slots=True)
class TextCodec:
    """Translates prompt/document values to and from ``Text``."""

    kind: str = Text.KIND
    representation: str = Text.REPRESENTATION
    interfaces: tuple[str, ...] = ()

    def encode(self, value: object) -> FrozenValue:
        if not isinstance(value, str):
            raise TypeError("utf8-text-v1 tasks require a str value")
        return str(value)

    def decode(self, payload: FrozenValue) -> object:
        return Text.from_payload(payload)


BUILTIN_CODECS: Mapping[tuple[str, str], ArtifactCodec] = MappingProxyType(
    {
        (codec.kind, codec.representation): codec
        for codec in (
            PythonValueCodec(),
            SourceTreeCodec(),
            TextCodec(),
            SkillSetCodec(),
            HarnessArtifactCodec(),
            PolicyArtifactCodec(),
        )
    }
)


@dataclass(frozen=True, slots=True)
class CodecIndex:
    """Exact ``(kind, representation)`` resolution for one run's lifetime."""

    _codecs: Mapping[tuple[str, str], ArtifactCodec]

    @classmethod
    def builtin(cls) -> "CodecIndex":
        return cls(MappingProxyType(dict(BUILTIN_CODECS)))

    @classmethod
    def with_extras(
        cls, extras: Mapping[tuple[str, str], ArtifactCodec]
    ) -> "CodecIndex":
        # Built-ins last, deliberately: a built-in key must win however the
        # extras were assembled. ``Registry.register_artifact_type`` already
        # refuses to store one, but the non-overridability of a committed
        # kind's decode is worth holding structurally, at the one place the
        # two mappings meet, rather than in another module's guard alone.
        return cls(MappingProxyType({**extras, **BUILTIN_CODECS}))

    def resolve(self, kind: str, representation: str) -> ArtifactCodec:
        codec = self._codecs.get((kind, representation))
        if codec is None:
            raise CapabilityError(
                f"no artifact codec registered for kind {kind!r} with "
                f"representation {representation!r}; register that codec and "
                "pass registry=..."
            )
        return codec

    def encode(self, kind: str, representation: str, value: object) -> FrozenValue:
        """Translate one public value into its durable payload.

        Serves both value boundaries — the seed and every proposed candidate.
        ``TypeError``/``ValueError`` from the codec propagate unchanged: the
        seed boundary rejects the run, while the candidate boundary records a
        typed proposer failure.
        """

        return self.resolve(kind, representation).encode(value)

    def decode(self, artifact: Artifact) -> object:
        codec = self.resolve(artifact.kind, artifact.representation)
        try:
            return codec.decode(artifact.payload)
        except Exception as error:
            raise DurableCorruption(
                f"committed {artifact.kind!r} payload failed to decode"
            ) from error

    def validate_successor(
        self,
        kind: str,
        representation: str,
        parents: tuple[FrozenValue, ...],
        candidate: FrozenValue,
    ) -> Failure | None:
        """Invoke a codec's optional trusted transition validator."""

        validator = getattr(
            self.resolve(kind, representation), "validate_successor", None
        )
        if validator is None:
            return None
        if not callable(validator):
            raise TypeError("artifact codec validate_successor must be callable")
        result = validator(parents, candidate)
        if result is not None and not isinstance(result, Failure):
            raise TypeError(
                "artifact codec validate_successor must return Failure or None"
            )
        return result

    def has_successor_validator(self, kind: str, representation: str) -> bool:
        validator = getattr(
            self.resolve(kind, representation), "validate_successor", None
        )
        if validator is not None and not callable(validator):
            raise TypeError("artifact codec validate_successor must be callable")
        return validator is not None


__all__ = [
    "BUILTIN_CODECS",
    "CodecIndex",
    "PythonValueCodec",
    "SkillSetCodec",
    "SourceTreeCodec",
    "TextCodec",
    "HarnessArtifactCodec",
    "PolicyArtifactCodec",
]
