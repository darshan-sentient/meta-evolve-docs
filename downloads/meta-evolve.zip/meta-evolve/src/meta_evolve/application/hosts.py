"""What every module needs of the coordinator, declared once.

`commit_batch` was declared in SIX host protocols with FOUR different
signatures: with and without `occurrences`, with and without `work`, and once
with `list[object]` bodies and a required `tuple[Artifact, ...]`. Only one of
them matched `SequentialCoordinator.commit_batch`, which is the thing they all
describe -- and `decisions.py` carried a docstring claiming it "declares each
exactly as `BootstrapHost` does", which was not true of either.

Four spellings of one method is four chances for a module to declare a
signature the coordinator does not have, and the AST completeness gate can only
check a contract that is stated: it compares calls against the DECLARATION, so
a declaration that drifts from the implementation makes the gate agree with the
drift.

One declaration, inherited. A protocol says what a host must OFFER, not what
the inheriting module happens to use, so a module that never passes `work` is
still correctly described by a host that accepts it.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol

from meta_evolve.domain import Artifact, CorrelationId
from meta_evolve.ports.work_store import WorkIntent

from .run_projection import RunProjection


class CommitBatchHost(Protocol):
    """The one seam every fact-building module commits through.

    Matches `SequentialCoordinator.commit_batch` exactly. `occurrences` and
    `work` both default, so a caller that has neither writes the same call it
    always did -- which is what let the narrower spellings look correct for as
    long as they did.
    """

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        occurrences: Sequence[Artifact] = (),
        correlation: CorrelationId,
        work: Sequence[WorkIntent] = (),
    ) -> RunProjection: ...


__all__ = ["CommitBatchHost"]
