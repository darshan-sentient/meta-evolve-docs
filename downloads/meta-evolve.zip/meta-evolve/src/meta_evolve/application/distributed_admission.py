"""What a distributed run refuses at the door.

The record is explicit that every restriction on distributed mode is a refusal
naming its reason, never a silent degradation: a run that quietly ran without
the context it declared, or that handed one cohort member the whole token
allowance, would produce results the user had no way to distrust.

Two of the record's seven refusals are not here. Distributed adopts
durable-local's component discipline wholesale -- registered components,
manifests, built-in codecs -- which already refuses a custom codec and a
component not declaring `retry_safe`, and stating them twice is how the two
copies come to disagree.

That inheritance is `retry_safe` ONLY. Determinism belongs to durable-local's
resume guarantee, and applying it here refused every model-backed proposer --
which it did for a while, because the shared call sat above this branch.

Admission turns on a DECLARED CAPABILITY, never a named preset. Asking whether
the program is `BestOfN` would be the policy-specific coordinator branch the
constitution forbids, and would refuse a conforming policy someone else wrote.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from meta_evolve.domain import Budget
from meta_evolve.domain.search import SearchState
from meta_evolve.errors import CapabilityError

@runtime_checkable
class CohortProgram(Protocol):
    """The capability a distributed run requires of its policy, by name.

    Declared here rather than beside `SearchProgram` because it is what
    ADMISSION requires, it has one consumer, and `domain/search.py` is already
    at its length. If a second consumer appears it belongs beside the port.

    BOTH members, and `isinstance` sees both. A width alone is a claim with no
    producer behind it; a producer alone is a generation the fold cannot bound,
    because it bounds cohort length from durable configuration with no live
    registry.

    `runtime_checkable` checks that the members are PRESENT and nothing more:
    not that the width is an integer, and not that the producer is callable.
    So both value checks below stay, and the Protocol buys the one thing the
    two `getattr` calls could not -- a name a policy author implements against.
    """

    cohort_width: int

    def next_cohort(self, state: SearchState) -> object: ...


# The dimensions a cohort cannot divide. Counts are deliberately absent: trials
# and evaluations are what a cohort is SIZED against, so refusing them would
# refuse every distributed run.
MEASURED_DIMENSIONS = ("tokens", "wall_seconds", "spend_micros")


def check_distributed_admission(
    *,
    search: object,
    budget: Budget,
    context_spec: object | None,
    experience_spec: object | None,
    fingerprint: str,
) -> None:
    """Raise ``CapabilityError`` naming the first reason this run cannot be one."""

    if context_spec is not None:
        raise CapabilityError(
            "distributed mode refuses a declared context policy: pushed context "
            "binds a fact to an exact stream position, and its cutoff is strict "
            "where pull's is inclusive"
        )
    if experience_spec is not None:
        raise CapabilityError(
            "distributed mode refuses a declared experience access: pull "
            "experience appends audit facts synchronously from inside the "
            "proposer, behind stream-global guards"
        )

    width = getattr(search, "cohort_width", None)
    declared = (
        isinstance(search, CohortProgram)
        and isinstance(width, int)
        # `runtime_checkable` sees the NAME, not a method: a data protocol
        # accepts `next_cohort = 5`, which is not something a fold can call.
        and callable(search.next_cohort)
    )
    if not declared or isinstance(width, bool):
        # A declared width that is not an integer is not a declaration: the
        # fold sizes a generation from it, and `True` is an `int` that means
        # nothing as a width.
        raise CapabilityError(
            "distributed mode requires a policy declaring the cohort "
            "capability: a cohort_width in its durable configuration AND a "
            "next_cohort producer"
        )

    for dimension in MEASURED_DIMENSIONS:
        if getattr(budget, dimension, None) is not None:
            raise CapabilityError(
                f"distributed mode refuses a finite {dimension} ceiling: the "
                "shipped presets hand each trial the run's whole measured "
                "allowance, so a second cohort member computed from the same "
                "base has nothing left to allocate"
            )

    if not fingerprint:
        raise CapabilityError(
            "distributed mode requires an environment fingerprint: it is "
            "recorded on the run so a later slice can compare a worker's "
            "against it. The comparison is unimplemented as of M11.2 -- the "
            "value is recorded and declared, never compared -- so this "
            "refusal is presence, not drift detection"
        )


__all__ = ["MEASURED_DIMENSIONS", "CohortProgram", "check_distributed_admission"]
