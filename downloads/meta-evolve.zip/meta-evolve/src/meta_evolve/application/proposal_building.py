"""Build one proposal's durable facts, without committing them.

Split from `proposal_completion.py`, which reached 314 lines: this module turns
a worker's `ProposalResult` into facts, and that one commits them and drives the
dependent evaluation. The seam exists because a dispatcher needs the first half
alone -- it must attach work-table intents to the same transaction, which a
function that commits itself cannot offer.

Mirrors `build_evaluation` deliberately. One rule covers both component calls:
the worker computes a boundary record, a build turns it into durable facts, and
the caller commits.
"""

from __future__ import annotations

from dataclasses import dataclass

from typing import TYPE_CHECKING, cast

from meta_evolve.domain import (
    Artifact,
    ArtifactCreated,
    ArtifactId,
    PolicyViolation,
    Proposal,
    ProposalId,
    ProposalSubmitted,
    ResourceExhausted,
    TrialCompleted,
    TrialOutcome,
)
from meta_evolve.domain.evaluation import _FailureType
from meta_evolve.errors import InvalidDecision

from .integrity import load_committed_artifact
from .derivation import derivation_violation
from .evaluation_execution import (
    evidence_bodies as build_evidence_bodies,
)
from .identities import completion_key_for, stable_id
from .work import ProposalWork, action_usage, would_exceed

if TYPE_CHECKING:
    from .execution import ExecutionHost
    from .executors import EncodedProposal


def check_completion_key(work: ProposalWork) -> None:
    """Refuse a work item whose key is not derived from its own trial.

    Its own function because it is an authority check rather than a build step:
    `complete_work` runs it before deciding whether the trial is already
    complete, and the build half runs it for any caller that skips that path.
    Calling it twice is free; calling it in only one place is how a forged key
    on a completed trial became a replay.
    """

    expected = completion_key_for(work.trial.id)
    if work.completion_key != expected:
        raise InvalidDecision("work item has an invalid completion key")


@dataclass(frozen=True, slots=True)
class ProposalCompletion:
    """One proposal's durable facts, built but not committed.

    Carries its OCCURRENCES, not only its bodies. A successful proposal encodes
    an `Artifact` that must reach the same atomic commit, and neither
    `ArtifactCreated` nor `TrialOutcome.succeeded` holds the payload -- they hold
    ids. A commit missing the occurrence is not refused by anything: the run
    would carry an `ArtifactCreated` whose id `ArtifactStore.get` cannot resolve,
    failing the resume-time reference walk. Returning them together is what makes
    that unrepresentable rather than merely discouraged.
    """

    bodies: tuple[object, ...]
    occurrences: tuple[Artifact, ...]
    outcome: TrialOutcome


def build_proposal_completion(
    host: ExecutionHost,
    work: ProposalWork,
    encoded: EncodedProposal,
    *,
    parents: tuple[Artifact, ...] | None = None,
) -> ProposalCompletion:
    """Everything a proposal completion needs, up to but excluding the commit.

    Split from `complete_work` so a dispatcher can commit these bodies together
    with its work-table intents in ONE transaction, which `complete_work` cannot
    offer because it commits itself. The sequential path composes the two halves
    below and is unchanged in effect.

    Mirrors `build_evaluation`, deliberately: the worker computes a boundary
    record, this builds durable facts from it, and the caller commits. One rule
    for both sides rather than two paths with an asymmetry to remember.
    """

    check_completion_key(work)
    trial = work.trial
    usage = action_usage(trials=1, usage=encoded.usage)
    reported_failure = encoded.failure
    failure = reported_failure
    derived_from = encoded.derived_from
    if would_exceed(
        usage,
        trial.spec.budget,
        host.projection,
        run_budget=host.run_budget,
        task=host.task,
    ):
        failure = ResourceExhausted(
            message="proposer usage exceeded its effective budget",
            details={
                "reported_failure": (
                    reported_failure.kind if reported_failure else None
                )
            },
        )
        derived_from = ()
    else:
        violation = derivation_violation(
            host.projection, trial.id, encoded.derived_from
        )
        if violation is not None:
            details = (
                {"reported_failure": reported_failure.kind}
                if reported_failure is not None
                else {}
            )
            failure = PolicyViolation(
                message="proposal derivation violates observation authority",
                details=details,
            )
            derived_from = ()
    payload = encoded.payload
    if failure is None:
        # The executor encoded the candidate; a refusal applies only after the
        # budget and derivation checks above, as it did when this encoded.
        if encoded.encoding_failure is not None:
            failure = encoded.encoding_failure
            derived_from = ()
        if failure is None and host.codecs.has_successor_validator(
            host.task.artifact_kind,
            host.task.artifact_representation,
        ):
            # A dispatcher passes the parents it resolved before the call, so
            # nothing here reads the store after the component answered.
            loaded = parents if parents is not None else tuple(
                load_committed_artifact(host.artifacts, parent_id)
                for parent_id in trial.spec.parent_ids
            )
            failure = host.codecs.validate_successor(
                host.task.artifact_kind,
                host.task.artifact_representation,
                tuple(parent.payload for parent in loaded),
                payload,
            )
    proposal = Proposal(
        id=stable_id(ProposalId, "proposal", trial.id.value),
        trial_id=trial.id,
        parent_ids=trial.spec.parent_ids,
        operator=trial.spec.operator,
        hypothesis=encoded.hypothesis,
        predicted_outcomes=encoded.predicted_outcomes,
        metadata=encoded.metadata,
        derived_from=derived_from,
    )
    evidence_bodies, evidence_ids = build_evidence_bodies(
        encoded.evidence, owner=trial.id.value
    )
    if failure is not None:
        outcome = TrialOutcome.failed(
            trial_id=trial.id,
            proposal_id=proposal.id,
            evidence_ids=evidence_ids,
            usage=usage,
            # TrialOutcome validates the closed failure taxonomy at construction.
            failure=cast(_FailureType, failure),
        )
        return ProposalCompletion(
            bodies=(
                ProposalSubmitted(proposal=proposal),
                *evidence_bodies,
                TrialCompleted(trial=trial, outcome=outcome),
            ),
            occurrences=(),
            outcome=outcome,
        )

    artifact = Artifact(
        id=stable_id(ArtifactId, "artifact", trial.id.value),
        payload=payload,
        kind=host.task.artifact_kind,
        representation=host.task.artifact_representation,
        parent_ids=trial.spec.parent_ids,
        provenance={
            "proposal_id": proposal.id.value,
            "run_id": host.run_id.value,
            "trial_id": trial.id.value,
        },
    )
    outcome = TrialOutcome.succeeded(
        trial_id=trial.id,
        proposal_id=proposal.id,
        artifact_ids=(artifact.id,),
        evidence_ids=evidence_ids,
        usage=usage,
    )
    return ProposalCompletion(
        bodies=(
            ProposalSubmitted(proposal=proposal),
            *evidence_bodies,
            ArtifactCreated(artifact_id=artifact.id),
            TrialCompleted(trial=trial, outcome=outcome),
        ),
        occurrences=(artifact,),
        outcome=outcome,
    )
