"""Versioned deterministic identities for one local run."""

from __future__ import annotations

from hashlib import sha256
from typing import TypeVar

from meta_evolve.domain.values import canonical_payload_bytes


_Id = TypeVar("_Id")


def stable_id(id_type: type[_Id], domain: str, *parts: object) -> _Id:
    digest = sha256(
        canonical_payload_bytes(
            {"domain": f"meta-evolve/{domain}/v1", "parts": tuple(parts)}
        )
    ).hexdigest()
    return id_type(f"{domain}-{digest}")


__all__ = ["stable_id"]
