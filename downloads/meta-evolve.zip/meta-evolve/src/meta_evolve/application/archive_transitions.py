"""Generic validation for record-only archive membership transitions."""

from __future__ import annotations

from meta_evolve.domain import ArchiveUpdate

from .run_projection import RunProjection


def archive_transition_error(
    state: RunProjection, update: ArchiveUpdate
) -> str | None:
    evaluation = next(
        (
            item.evaluation
            for item in state.completed_evaluations
            if item.evaluation.id == update.evaluation_id
        ),
        None,
    )
    if evaluation is None:
        return "archive update references an unknown or future evaluation"
    if evaluation.artifact_id != update.candidate_id:
        return "archive candidate does not match its evaluation"
    if any(
        item.decision.evaluation_id == update.evaluation_id
        for item in state.decisions
        if isinstance(item.decision, ArchiveUpdate)
    ):
        return "evaluation already has an archive update"
    if len(set(update.member_ids)) != len(update.member_ids):
        return "archive members must be unique"

    evaluations_by_artifact = {
        item.evaluation.artifact_id: item.evaluation
        for item in state.completed_evaluations
    }
    for member_id in update.member_ids:
        member_evaluation = evaluations_by_artifact.get(member_id)
        if member_evaluation is None:
            return "archive member has not been evaluated"
        if member_evaluation.failure is not None:
            return "failed evaluations cannot be archive members"

    previous = state.search_state.archive_members
    if not update.admitted:
        if update.evicted_artifact_id is not None:
            return "rejected archive updates cannot evict a member"
        if update.member_ids != previous:
            return "rejected archive update must leave membership unchanged"
        return None

    previous_set = set(previous)
    resulting_set = set(update.member_ids)
    if update.candidate_id in previous_set:
        return "admission must add a new candidate"
    if resulting_set - previous_set != {update.candidate_id}:
        return "admission must add exactly its candidate"
    removed = previous_set - resulting_set
    if len(removed) == 1:
        if update.evicted_artifact_id != next(iter(removed)):
            return "archive eviction must name the removed member"
    elif update.evicted_artifact_id is not None:
        if removed:
            return "archive eviction must be empty for multiple removals"
        return "archive eviction names a member that was not removed"
    return None


__all__ = ["archive_transition_error"]
