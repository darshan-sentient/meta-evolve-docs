"""Workers arriving while a drive runs, and one worker's reconnect.

Declared here, in `application/`, and implemented in `distributed/`: the loop
owns what it needs of a backend, and the transport provides it (design SD5).
`Session.drive` hands the dispatcher a `Workers`, which is the whole of what
the loop knows about listeners, processes or keys -- nothing.

**Two phases, and the order is a promise** (PD2). `Execution.open` spawns and
admits every worker a run needs BEFORE the epoch rolls over, so a handshake
that fails leaves a genesis-only run that resumes with its epoch unchanged.
Only an open host admits later, one poll at a time, because only an operator's
workers arrive on their own schedule.

**Reattachment keeps acceptances, not work** (PD1). A lease is rebound only
inside the epoch that issued it, to a connection of the same worker, and only
while the binding still exists -- which is to say, only when the worker
reconnected before the loop judged its old connection dead. Everything else it
resends is answered from the store: `Duplicate` when the commit landed,
`Stale` when it did not.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Protocol

from meta_evolve.domain import RunId
from meta_evolve.domain.components import ComponentManifest
from meta_evolve.domain.context import ContextSpec
from meta_evolve.domain.events import RunStarted
from meta_evolve.domain.work import Lease

from .dispatch_endpoint import Endpoint


@dataclass(frozen=True, slots=True)
class HostTerms:
    """What a run tells its execution backend about itself.

    Everything here is the RUN's, never the transport's: the recorded start a
    worker rebuilds from, the manifests and fingerprint it is checked against,
    and the heartbeat cadence its lease duration implies. How a worker is
    reached -- a port, a key, a process -- is the backend's own business.
    """

    run_id: RunId
    started: RunStarted
    context: ContextSpec | None
    manifests: tuple[ComponentManifest, ...]
    fingerprint: str
    heartbeat_seconds: int
    live: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Joining:
    """One admitted connection, and the leases it says it still holds."""

    endpoint: Endpoint
    held: tuple[Lease, ...]
    incarnation: str


class Workers(Protocol):
    """One run's execution backend, as the dispatcher sees it."""

    #: Admitted before the epoch rolled over; empty for a host that listens.
    endpoints: tuple[Endpoint, ...]

    def admit(self) -> tuple[Joining, ...]:
        """Whoever finished a handshake since the last poll. Never blocks."""

    def may_admit(self) -> bool:
        """Whether another worker could still arrive.

        What separates "no workers yet" from "no workers left": an open host
        waits, and a spawned-worker run whose children have all died is
        refused by name rather than waiting for something that cannot come.
        """

    def finish(self, *, completed: bool) -> None:
        """Say goodbye if the run finished, then close everything."""


class Execution(Protocol):
    """What `Session.drive(execution=...)` takes."""

    def open(self, terms: HostTerms) -> Workers:
        """Bind, spawn and admit what this run needs, before its rollover."""


def admit_into(loop, admission: Workers | None) -> None:
    """Register whoever was admitted, superseding a worker's own old connection.

    Matching is by WORKER ID, which is what makes this a reconnect rather than
    a new worker: the ids are the run's own slots or an operator's, and the
    handshake has already refused a second live process using one (PD7).
    """

    if admission is None:
        return
    for joining in admission.admit():
        worker = joining.endpoint.registrations[0].worker
        old = next(
            (
                endpoint
                for endpoint in loop.endpoints
                if endpoint.registrations[0].worker == worker
            ),
            None,
        )
        if old is None:
            loop.register(joining.endpoint)
        else:
            loop.supersede(old, joining.endpoint, joining.held)


__all__ = [
    "Execution",
    "HostTerms",
    "Joining",
    "Workers",
    "admit_into",
]
