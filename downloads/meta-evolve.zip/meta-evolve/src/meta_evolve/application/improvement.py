"""The minimal beginner façade for one bounded local improvement run."""

from meta_evolve.domain import Task
from meta_evolve.policies import Greedy

from .experiment import Experiment
from .runtime import Run, run


def improve(
    *,
    seed,
    proposer,
    evaluator,
    trials: int = 20,
    storage=None,
    random_seed: int = 0,
) -> Run:
    """Run a bounded greedy improvement loop with a callable evaluator.

    This is declaration sugar for :class:`~meta_evolve.Task`,
    :class:`~meta_evolve.Experiment`, :class:`~meta_evolve.Greedy`, and
    :func:`~meta_evolve.run`. Use that expanded path when you need custom
    artifacts, objectives, budgets, search, context, experience, execution
    mode, or registry components.

    The seed is evaluated before successor attempts. Supplying durable
    storage preserves local history but does not make this run resumable.

    :param seed: Initial artifact value.
    :param proposer: Callable or local proposer adapter.
    :param evaluator: Callable that independently measures an artifact.
    :param trials: Maximum number of successor proposals; defaults to ``20``.
    :param storage: Artifact and event storage; defaults to isolated memory.
    :param random_seed: Integer seed for recorded deterministic choices.
    :returns: The same inspectable :class:`~meta_evolve.Run` as
        :func:`~meta_evolve.run`.
    """
    task = Task(evaluator=evaluator)
    search = Greedy(max_trials=trials)
    experiment = Experiment(
        task=task,
        seed=seed,
        proposer=proposer,
        search=search,
        random_seed=random_seed,
    )
    return run(experiment, storage=storage)


__all__ = ["improve"]
