"""The minimal beginner façade for one bounded local improvement run."""

from meta_evolve.domain import Maximize, Minimize, Task
from meta_evolve.policies import Greedy
from meta_evolve.policies.context import ContextPolicy

from .experiment import Experiment
from .runtime import Run, run


def improve(
    *,
    seed,
    proposer,
    evaluator,
    trials: int = 20,
    storage=None,
    random_seed: int = 0,
    objective: Maximize | Minimize | None = None,
    context: ContextPolicy | None = None,
) -> Run:
    """Run a bounded greedy improvement loop with a callable evaluator.

    This constructs [Task][meta_evolve.Task], [Experiment][meta_evolve.Experiment],
    and [Greedy][meta_evolve.Greedy], then calls [run][meta_evolve.run].
    By default it maximizes ``score`` with no satisfaction target and supplies
    no pushed feedback. Declare one objective or an explicit context policy
    here. Use the expanded path for multiple objectives, custom artifacts,
    budgets, search, pulled experience, execution mode, or registry components.

    The seed is evaluated before successor attempts. A tie or regression keeps
    the earlier best result; an attempt need not improve anything. Supplying
    durable storage preserves local history but does not make this run resumable.

    :param seed: Initial immutable JSON-like value, such as a string or number.
    :param proposer: Callable accepting ``(parent)`` or ``(parent, *, context)``,
        or a local proposer adapter. Return a candidate or
        [ProposalResult][meta_evolve.ProposalResult].
    :param evaluator: Independent callable returning a finite scalar measured
        under the objective's name, a mapping containing that metric, or
        [EvaluationResult][meta_evolve.EvaluationResult]. Missing measurements
        become typed evaluation failures, not scores.
    :param trials: Maximum number of successor proposals; defaults to ``20``.
        Zero evaluates only the seed. Failed proposals still count. Must be a
        non-negative integer; booleans and ``None`` are rejected.
    :param storage: Artifact and event storage; defaults to isolated memory.
    :param random_seed: Integer seed for recorded deterministic choices, default
        ``0``; does not make external providers deterministic.
    :param objective: One [Maximize][meta_evolve.Maximize] or
        [Minimize][meta_evolve.Minimize]; ``None`` uses ``Maximize("score")``
        without a satisfaction target. A satisfied seed needs no proposals.
    :param context: Explicit policy for bounded pushed feedback, such as
        [RecentAncestors][meta_evolve.RecentAncestors]. ``None`` and
        [NoMemory][meta_evolve.NoMemory] disable it. This never enables pull
        access. The proposer reads evidence through its keyword-only ``context``.
    :returns: A [Run][meta_evolve.Run], even if all evaluations failed. Winner
        queries then raise [NoSuccessfulEvaluation][meta_evolve.NoSuccessfulEvaluation];
        ``trials()``, ``inspect()``, and ``usage()`` remain available.
    :raises TypeError: If a declared input has an unsupported type.
    :raises ValueError: If a limit is negative or the declaration is invalid.
    """
    if trials is None:
        # Greedy accepts max_trials=None to inherit a finite Budget.trials, but
        # this façade exposes no budget and builds an unbudgeted Task, so there
        # is never anything to inherit. Reject it here to keep the façade's
        # long-standing TypeError rather than surfacing a bind-time
        # BudgetUnavailable that callers do not catch. Every other bad value
        # still falls through to Greedy and fails exactly as Greedy fails.
        raise TypeError(
            "improve trials must be an integer: improve declares no budget, so "
            "the presets' max_trials=None budget inheritance has nothing to "
            "resolve against. Use meta.run with an explicit Budget(trials=...) "
            "to inherit a trial limit."
        )
    task = (
        Task(evaluator=evaluator)
        if objective is None
        else Task(evaluator=evaluator, objectives=(objective,))
    )
    search = Greedy(max_trials=trials)
    experiment = Experiment(
        task=task,
        seed=seed,
        proposer=proposer,
        search=search,
        random_seed=random_seed,
        context=context,
    )
    return run(experiment, storage=storage)


__all__ = ["improve"]
