"""The minimal beginner façade for one bounded local improvement run."""

from meta_evolve.domain import Task
from meta_evolve.policies import Greedy

from .experiment import Experiment
from .runtime import Run, run


def improve(
    *,
    seed,
    proposer,
    evaluator,
    trials: int = 20,
    storage=None,
    random_seed: int = 0,
) -> Run:
    """Run a bounded greedy improvement loop with a callable evaluator.

    This is declaration sugar for :class:`~meta_evolve.Task`,
    :class:`~meta_evolve.Experiment`, :class:`~meta_evolve.Greedy`, and
    :func:`~meta_evolve.run`. Use that expanded path when you need custom
    artifacts, objectives, budgets, search, context, experience, execution
    mode, or registry components.

    The seed is evaluated before successor attempts. Supplying durable
    storage preserves local history but does not make this run resumable.

    :param seed: Initial artifact value.
    :param proposer: Callable or local proposer adapter.
    :param evaluator: Callable that independently measures an artifact.
    :param trials: Maximum number of successor proposals; defaults to ``20``.
        Always an integer here. The presets accept ``max_trials=None`` to
        inherit a finite ``Budget.trials`` (#163), but this façade declares no
        budget for that to resolve against, so ``None`` is rejected with
        ``TypeError`` exactly as it always has been.
    :param storage: Artifact and event storage; defaults to isolated memory.
    :param random_seed: Integer seed for recorded deterministic choices.
    :returns: The same inspectable :class:`~meta_evolve.Run` as
        :func:`~meta_evolve.run`.
    """
    if trials is None:
        # Greedy accepts max_trials=None to inherit a finite Budget.trials, but
        # this façade exposes no budget and builds an unbudgeted Task, so there
        # is never anything to inherit. Reject it here to keep the façade's
        # long-standing TypeError rather than surfacing a bind-time
        # BudgetUnavailable that callers do not catch. Every other bad value
        # still falls through to Greedy and fails exactly as Greedy fails.
        raise TypeError(
            "improve trials must be an integer: improve declares no budget, so "
            "the presets' max_trials=None budget inheritance has nothing to "
            "resolve against. Use meta.run with an explicit Budget(trials=...) "
            "to inherit a trial limit."
        )
    task = Task(evaluator=evaluator)
    search = Greedy(max_trials=trials)
    experiment = Experiment(
        task=task,
        seed=seed,
        proposer=proposer,
        search=search,
        random_seed=random_seed,
    )
    return run(experiment, storage=storage)


__all__ = ["improve"]
