"""Compose live search programs with their durable run declaration."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from meta_evolve import serialization
from meta_evolve.domain import (
    Budget,
    ComponentRef,
    FrozenMap,
    PolicyRef,
    SearchProgram,
    SearchSpec,
)
from meta_evolve.domain.components import RUN_LOCAL_VERSION


@dataclass(frozen=True, slots=True)
class PreparedSearch:
    program: SearchProgram
    spec: SearchSpec
    identity_key: str


def _policy(program: SearchProgram) -> PolicyRef:
    policy = getattr(program, "policy", None)
    if isinstance(policy, PolicyRef):
        return policy
    cls = type(program)
    return PolicyRef(
        f"{cls.__module__}:{cls.__qualname__}", RUN_LOCAL_VERSION, origin="local"
    )


def _bound(
    program: SearchProgram, proposer: ComponentRef, budget: Budget
) -> SearchProgram:
    """A program offering ``bind`` must declare the whole preset contract."""

    bind = getattr(program, "bind", None)
    if bind is None:
        return program
    if not callable(bind) or not all(
        hasattr(program, name) for name in ("configuration", "identity_key")
    ):
        raise TypeError(
            "a bindable search preset must declare bind(proposer, budget), "
            "configuration, and identity_key"
        )
    return bind(proposer, budget)


def prepare_search(
    program: SearchProgram,
    *,
    proposer: ComponentRef,
    budget: Budget,
) -> PreparedSearch:
    """Bind a capable preset and retain its executable and durable forms."""

    program = _bound(program, proposer, budget)
    if not callable(getattr(program, "next", None)):
        raise TypeError("search must implement next(state)")

    configuration = getattr(program, "configuration", FrozenMap())
    if not isinstance(configuration, Mapping):
        raise TypeError("search configuration must be a mapping")
    spec = SearchSpec(
        policy=_policy(program),
        configuration=configuration,
        proposer=proposer,
    )
    identity_key = getattr(program, "identity_key", None)
    if identity_key is None:
        identity_key = serialization.identity_content(spec)
    if not isinstance(identity_key, str) or not identity_key:
        raise TypeError("search identity key must be non-empty text")
    return PreparedSearch(program=program, spec=spec, identity_key=identity_key)


__all__ = ["PreparedSearch", "prepare_search"]
