"""Compose live search programs with their durable run declaration."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from meta_evolve import serialization
from meta_evolve.errors import CapabilityError
from meta_evolve.domain import (
    Budget,
    ComponentRef,
    FrozenMap,
    PolicyRef,
    SearchProgram,
    SearchSpec,
)
from meta_evolve.domain.components import RUN_LOCAL_VERSION


@dataclass(frozen=True, slots=True)
class PreparedSearch:
    program: SearchProgram
    spec: SearchSpec
    identity_key: str
    cohort_width: int = 1


def _policy(program: SearchProgram) -> PolicyRef:
    policy = getattr(program, "policy", None)
    if isinstance(policy, PolicyRef):
        return policy
    cls = type(program)
    return PolicyRef(
        f"{cls.__module__}:{cls.__qualname__}", RUN_LOCAL_VERSION, origin="local"
    )


def _valid_width(value: object, source: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{source} cohort_width must be an integer")
    if value < 1:
        raise ValueError(f"{source} cohort_width must be at least one")
    return value


def declared_cohort_width(
    program: SearchProgram, configuration: Mapping[str, object]
) -> int:
    """The generational cohort width this search declares, validated once.

    A data declaration rather than a method, because the width is data: a
    policy that never mentions it, in either place, means one -- the way an
    absent context bound means the shipped default.

    Both places must agree, in both directions. The structural attribute is
    what the running program will actually do; the configuration is what gets
    recorded and what a registry rebuild reads back. A program that declares one
    and records the other would run at one width and resume at another, so the
    disagreement is refused here rather than surfacing at resume.

    A width above one must also be *recorded*: omitting it would leave the
    declaration invisible to a registry rebuild, which would read back one and
    silently narrow the search. Presence is tested with ``in`` rather than a
    defaulted ``get``, so an explicitly recorded ``None`` is refused as
    malformed instead of passing as absent. Silently reading any of these as one
    would be a capability downgrade.
    """

    structural = _valid_width(getattr(program, "cohort_width", 1), "search")
    if "cohort_width" not in configuration:
        if structural > 1:
            raise ValueError(
                f"search declares cohort_width={structural} but does not record "
                "it: a registry rebuild would read back one"
            )
        return structural
    recorded = _valid_width(configuration["cohort_width"], "recorded search")
    if recorded != structural:
        raise ValueError(
            "search cohort_width disagrees with its recorded configuration: "
            f"declared {structural}, recorded {recorded}"
        )
    return recorded


def refuse_wide_cohort(width: int, *, resumed: bool = False) -> None:
    """Refuse a generational cohort on the synchronous path.

    A cohort needs the dispatcher that admits and commits its members as one
    batch, which arrives with M11.2. Narrowing silently to one instead would be
    worse than refusing: the width reaches run identity, so the run would record
    a wide declaration over a trajectory that was stepped one decision at a
    time. Resume re-reads the declaration rather than trusting the earlier
    admission -- a run admitted narrow can be resumed against a wide one.
    """

    if width <= 1:
        return
    where = "resumed" if resumed else "started"
    raise CapabilityError(
        f"a search declaring cohort_width={width} cannot be {where} on the "
        "synchronous path; concurrent execution is not shipped"
    )


def _bound(
    program: SearchProgram, proposer: ComponentRef, budget: Budget
) -> SearchProgram:
    """A program offering ``bind`` must declare the whole preset contract."""

    bind = getattr(program, "bind", None)
    if bind is None:
        return program
    if not callable(bind) or not all(
        hasattr(program, name) for name in ("configuration", "identity_key")
    ):
        raise TypeError(
            "a bindable search preset must declare bind(proposer, budget), "
            "configuration, and identity_key"
        )
    return bind(proposer, budget)


def prepare_search(
    program: SearchProgram,
    *,
    proposer: ComponentRef,
    budget: Budget,
) -> PreparedSearch:
    """Bind a capable preset and retain its executable and durable forms."""

    # Read the width the CALLER declared, before binding can change it.
    # `declared_cohort_width` below compares the bound program's structural
    # attribute against its own recorded configuration, so a `bind` that drops
    # the width from both agrees with itself at one -- and the run is prepared
    # narrow, with a narrow identity, from a wide declaration. That is the exact
    # capability downgrade this module refuses everywhere else.
    requested = _valid_width(getattr(program, "cohort_width", 1), "search")

    program = _bound(program, proposer, budget)
    if not callable(getattr(program, "next", None)):
        raise TypeError("search must implement next(state)")

    configuration = getattr(program, "configuration", FrozenMap())
    if not isinstance(configuration, Mapping):
        raise TypeError("search configuration must be a mapping")
    spec = SearchSpec(
        policy=_policy(program),
        configuration=configuration,
        proposer=proposer,
    )
    identity_key = getattr(program, "identity_key", None)
    if identity_key is None:
        identity_key = serialization.identity_content(spec)
    if not isinstance(identity_key, str) or not identity_key:
        raise TypeError("search identity key must be non-empty text")
    width = declared_cohort_width(program, configuration)
    if width != requested:
        raise ValueError(
            "search bind changed the declared cohort_width: "
            f"declared {requested}, bound {width}"
        )
    return PreparedSearch(
        program=program,
        spec=spec,
        identity_key=identity_key,
        cohort_width=width,
    )


__all__ = [
    "PreparedSearch",
    "declared_cohort_width",
    "prepare_search",
    "refuse_wide_cohort",
]
