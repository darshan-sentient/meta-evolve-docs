"""Captured, storage-independent run facts and safe display hooks."""

from __future__ import annotations

from dataclasses import dataclass, field
from math import isfinite
from typing import Literal

from meta_evolve.domain import (
    ContentDigest, ContextSpec, ExperienceSpec, Maximize, Minimize,
    PolicyRef, RunCapabilities, RunId, Usage,
)

from .experience_usage import RunExperienceUsage


@dataclass(frozen=True, slots=True)
class RunSummary:
    """A frozen, storage-independent report, including runs with no winner.

    Lifecycle records whether the run stopped; rankability records whether a
    successful measurement exists. Neither promises improvement over the seed.
    Counts and usage include committed failures, but not pending work.

    Capture with ``run.summary()`` while storage is open. Text and notebook
    display use only the captured facts, including after storage closes. Decoded
    artifacts remain available programmatically but are never displayed here.
    Optional metadata defaults to unknown for manually constructed summaries.
    Persistence describes the capture handle; capabilities describe the recorded
    execution, without verifying current permission or compatibility to resume.
    """

    run_id: RunId
    policy: PolicyRef
    primary_score: int | float | None
    evaluation_count: int
    usage: Usage
    random_seed: int
    initial_artifact: object
    initial_artifact_digest: ContentDigest
    winning_lineage: tuple[object, ...]
    context_spec: ContextSpec | None
    experience_spec: ExperienceSpec | None
    experience_usage: RunExperienceUsage
    # The sorted roles whose recorded reference identifies its component by
    # name alone: named, not configured. This certifies nothing about the roles
    # it omits -- any local component may self-declare arbitrary version text,
    # and only a ComponentManifest represents a verified identity.
    name_only_components: tuple[str, ...] = ()
    lifecycle: Literal["complete", "incomplete"] = field(kw_only=True)
    rankability: Literal["rankable", "unrankable"] = field(kw_only=True)
    stop_reason: str | None = field(kw_only=True)
    primary_objective: Maximize | Minimize | None = field(default=None, kw_only=True)
    baseline_score: int | float | None = field(default=None, kw_only=True)
    failure_count: int | None = field(default=None, kw_only=True)
    storage_is_durable: bool | None = field(default=None, kw_only=True)
    storage_location: str | None = field(default=None, kw_only=True)
    capabilities: RunCapabilities | None = field(default=None, kw_only=True)

    def __post_init__(self) -> None:
        if self.lifecycle not in ("complete", "incomplete"):
            raise ValueError("lifecycle must be complete or incomplete")
        if self.rankability not in ("rankable", "unrankable"):
            raise ValueError("rankability must be rankable or unrankable")
        if self.stop_reason is not None and not isinstance(self.stop_reason, str):
            raise TypeError("stop_reason must be a string or None")
        if self.lifecycle == "complete":
            if not self.stop_reason or not self.stop_reason.strip():
                raise ValueError("complete summary requires a non-empty stop_reason")
        elif self.stop_reason is not None:
            raise ValueError("incomplete summary requires stop_reason=None")
        if not isinstance(self.winning_lineage, tuple):
            raise TypeError("winning_lineage must be a tuple")
        if isinstance(self.evaluation_count, bool) or not isinstance(self.evaluation_count, int):
            raise TypeError("evaluation_count must be an integer")
        if self.evaluation_count < 0:
            raise ValueError("evaluation_count must be non-negative")
        if self.rankability == "rankable":
            score = self.primary_score
            if isinstance(score, bool) or not isinstance(score, (int, float)):
                raise TypeError("rankable summary requires a numeric primary_score")
            if isinstance(score, float) and not isfinite(score):
                raise ValueError("primary_score must be finite")
            if not self.winning_lineage or not self.evaluation_count:
                raise ValueError("rankable summary requires lineage and an evaluation")
        elif self.primary_score is not None or self.winning_lineage:
            raise ValueError("unrankable summary requires no score or winning lineage")
        if self.primary_objective is not None and not isinstance(
            self.primary_objective, (Maximize, Minimize)
        ):
            raise TypeError("primary_objective must be Maximize, Minimize, or None")
        if self.baseline_score is not None:
            score = self.baseline_score
            if isinstance(score, bool) or not isinstance(score, (int, float)):
                raise TypeError("baseline_score must be numeric or None")
            if isinstance(score, float) and not isfinite(score):
                raise ValueError("baseline_score must be finite")
            if self.rankability == "unrankable":
                raise ValueError("unrankable summary requires no baseline_score")
        if self.failure_count is not None:
            if isinstance(self.failure_count, bool) or not isinstance(self.failure_count, int):
                raise TypeError("failure_count must be an integer or None")
            if self.failure_count < 0:
                raise ValueError("failure_count must be non-negative")
        if self.storage_is_durable is not None and not isinstance(self.storage_is_durable, bool):
            raise TypeError("storage_is_durable must be a bool or None")
        if self.storage_location is not None and not isinstance(self.storage_location, str):
            raise TypeError("storage_location must be a string or None")
        if self.capabilities is not None and not isinstance(self.capabilities, RunCapabilities):
            raise TypeError("capabilities must be RunCapabilities or None")

    def __repr__(self) -> str:
        from meta_evolve._run_display import summary_repr

        return summary_repr(self)

    def __str__(self) -> str:
        from meta_evolve._run_display import summary_text

        return summary_text(self)

    def _repr_html_(self) -> str:
        from meta_evolve._run_display import summary_html

        return summary_html(self)
