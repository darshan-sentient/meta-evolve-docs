"""Declare, select, commit, and reload policy-pushed proposer context."""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain import (
    ContextBundle,
    ContextPolicyDeclared,
    ContextSelected,
    ContextSpec,
    CorrelationId,
    ExperienceRef,
    RunId,
    Task,
    Trial,
)
from meta_evolve.domain.context import bundle_violation
from meta_evolve.ports import EventStore
from meta_evolve.errors import InvalidDecision

from .experience_replay import replay_experience_graph
from .experience import ExperienceGraph
from .identities import correlation_for_run, correlation_for_trial
from .run_projection import RunProjection


class ContextSelector(Protocol):
    def select(
        self,
        task: Task,
        candidate: ExperienceRef,
        graph: ExperienceGraph,
        spec: ContextSpec,
    ) -> ContextBundle: ...


class ContextHost(Protocol):
    run_id: RunId
    task: Task
    events: EventStore

    @property
    def projection(self) -> RunProjection: ...

    def append_fact(self, body: object, *, correlation: CorrelationId): ...


def declare_context(host: ContextHost, spec: ContextSpec | None) -> None:
    if spec is None:
        return
    correlation = correlation_for_run(host.run_id)
    host.append_fact(ContextPolicyDeclared(spec=spec), correlation=correlation)


def select_or_load_context(
    host: ContextHost,
    trial: Trial,
    selector: ContextSelector | None,
) -> ContextBundle:
    if trial.spec.context_policy is None:
        return ContextBundle.empty()
    projection = host.projection
    committed = projection.context_for(trial.id)
    if committed is not None:
        return committed
    declaration = projection.context_declaration
    if declaration is None or selector is None:
        raise RuntimeError("declared context selector is unavailable")
    graph = replay_experience_graph(host.run_id, host.events.read(host.run_id))
    candidate = ExperienceRef(
        run_id=host.run_id,
        kind="trial",
        occurrence_id=trial.id.value,
    )
    bundle = selector.select(host.task, candidate, graph, declaration.spec)
    if not isinstance(bundle, ContextBundle):
        raise TypeError("context policy select must return a ContextBundle")
    violation = bundle_violation(
        bundle,
        declaration.spec,
        projection.experience_records,
        before_step=trial.logical_step,
    )
    if violation is not None:
        raise InvalidDecision(violation)
    correlation = correlation_for_trial(trial.id)
    host.append_fact(
        ContextSelected(
            trial_id=trial.id,
            policy=declaration.spec.policy,
            observed_version=projection.version,
            bundle=bundle,
        ),
        correlation=correlation,
    )
    committed = host.projection.context_for(trial.id)
    assert committed is not None
    return committed


__all__ = ["ContextSelector", "declare_context", "select_or_load_context"]
