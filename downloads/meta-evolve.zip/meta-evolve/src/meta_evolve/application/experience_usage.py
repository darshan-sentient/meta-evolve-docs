"""Aggregate push and pull experience usage for one replayed run."""

from __future__ import annotations

from dataclasses import dataclass, field

from meta_evolve.domain import ContextUsage, ExperienceUsage
from meta_evolve.domain.experience_access import EXPERIENCE_OPERATIONS
from meta_evolve.views import ExperienceOperationUsage

from .run_projection import RunProjection


@dataclass(frozen=True, slots=True)
class RunExperienceUsage:
    context: ContextUsage
    pull: ExperienceUsage
    by_operation: tuple[ExperienceOperationUsage, ...] = field(
        default=(),
        repr=False,
    )

    def __post_init__(self) -> None:
        if not isinstance(self.context, ContextUsage):
            raise TypeError("run context usage must be ContextUsage")
        if not isinstance(self.pull, ExperienceUsage):
            raise TypeError("run pull usage must be ExperienceUsage")
        if not isinstance(self.by_operation, tuple) or any(
            not isinstance(item, ExperienceOperationUsage)
            for item in self.by_operation
        ):
            raise TypeError(
                "run experience usage by_operation must contain operation views"
            )
        expected_order = tuple(
            operation
            for operation in EXPERIENCE_OPERATIONS
            if any(item.operation == operation for item in self.by_operation)
        )
        if tuple(item.operation for item in self.by_operation) != expected_order:
            raise ValueError(
                "run operation usage must be unique and canonically ordered"
            )
        if self.by_operation and _sum_usage(
            tuple(item.usage for item in self.by_operation)
        ) != self.pull:
            raise ValueError("run operation usage must reconcile with pull usage")


def aggregate_experience_usage(state: RunProjection) -> RunExperienceUsage:
    context = ContextUsage(
        records=sum(item.bundle.usage.records for item in state.context_selections),
        chars=sum(item.bundle.usage.chars for item in state.context_selections),
    )
    grant_usage = tuple(
        state.experience_usage_for(item.grant.trial_id)
        for item in state.experience_grants
    )
    pull = ExperienceUsage(
        operations=sum(item.operations for item in grant_usage),
        results=sum(item.results for item in grant_usage),
        records=sum(item.records for item in grant_usage),
        chars=sum(item.chars for item in grant_usage),
    )
    totals = {operation: ExperienceUsage() for operation in EXPERIENCE_OPERATIONS}
    for attempt in state.experience_attempts:
        resolution = state.resolution_for(attempt.operation_id)
        result = getattr(resolution, "result", None)
        delta = ExperienceUsage(
            operations=1,
            results=(result.usage.results - attempt.usage.results if result else 0),
            records=(result.usage.records - attempt.usage.records if result else 0),
            chars=(result.usage.chars - attempt.usage.chars if result else 0),
        )
        totals[attempt.request.operation] = _sum_usage(
            (totals[attempt.request.operation], delta)
        )
    by_operation = tuple(
        ExperienceOperationUsage(operation=operation, usage=totals[operation])
        for operation in EXPERIENCE_OPERATIONS
        if totals[operation] != ExperienceUsage()
    )
    return RunExperienceUsage(
        context=context,
        pull=pull,
        by_operation=by_operation,
    )


def _sum_usage(values: tuple[ExperienceUsage, ...]) -> ExperienceUsage:
    return ExperienceUsage(
        operations=sum(item.operations for item in values),
        results=sum(item.results for item in values),
        records=sum(item.records for item in values),
        chars=sum(item.chars for item in values),
    )


__all__ = ["RunExperienceUsage", "aggregate_experience_usage"]
