"""Synchronous coordinator for bootstrap, policy decisions, and event writes."""

from __future__ import annotations

from collections.abc import Sequence

from meta_evolve.ports.work_store import WorkBroker, WorkIntent
from meta_evolve.domain import (
    Artifact,
    Budget,
    ComponentRef,
    ContextSpec,
    CorrelationId,
    EventEnvelope,
    ExperienceSpec,
    LEGACY_LOCAL_CAPABILITIES,
    RunCapabilities,
    RunId,
    SearchDecision,
    SearchProgram,
    SearchSpec,
    Task,
    TaskId,
    Trial,
    TrialOutcome,
)
from meta_evolve.ports.callables import Evaluator
from meta_evolve.ports.runners import ProposerRunner

from meta_evolve.errors import DurableCorruption, RunError
from .batch_grammar import recognized_batch_shape
from .bootstrap import start_run
from .codecs import CodecIndex
from .decisions import CommittedDecision, commit_decision
from .context_selection import (
    ContextSelector,
    declare_context,
    select_or_load_context,
)
from .execution import _resume_completed_trial, execute_trial
from .experience_reader import declare_experience, issue_or_load_reader
from .batch_envelopes import batch_envelopes
from .identities import correlation_for_trial
from .projections import RunProjection
from .recovery import scan_batch_grammar
from .storage import Storage
from .committed_fold import fold_committed

class SequentialCoordinator:
    def __init__(
        self,
        *,
        run_id: RunId,
        task_id: TaskId,
        task: Task,
        run_budget: Budget,
        random_seed: int,
        search: SearchSpec,
        proposer_runner: ProposerRunner,
        proposer_ref: ComponentRef,
        evaluator: Evaluator,
        storage: Storage,
        codecs: CodecIndex,
        capabilities: RunCapabilities = LEGACY_LOCAL_CAPABILITIES,
        projection: RunProjection | None = None,
        committed_bodies: Sequence[object] | None = None,
        context_selector: ContextSelector | None = None,
        experience_spec: ExperienceSpec | None = None,
    ) -> None:
        self.run_id = run_id
        self.task_id = task_id
        self.task = task
        self.run_budget = run_budget
        self.random_seed = random_seed
        self.search = search
        self.proposer_runner = proposer_runner
        self.proposer_ref = proposer_ref
        self.evaluator = evaluator
        self._storage = storage
        # Wiring only, like ``storage``: the coordinator never translates a
        # payload itself. Holding the index lets the evaluation boundary
        # resolve a codec without the coordinator branching on artifact types.
        self.codecs = codecs
        self.artifacts = storage.artifacts
        self.events = storage.events
        self.capabilities = capabilities
        self.context_selector = context_selector
        self.experience_spec = experience_spec
        if projection is not None and projection.run_id != run_id:
            # apply_event does not re-check envelope.run_id against the
            # projection's run_id (that guard lives only in
            # replay_run_projection), so a foreign-run seed would silently
            # fold this run's envelopes onto the wrong state.
            raise RunError("seeded projection belongs to another run")
        self._projection = (
            projection if projection is not None else RunProjection.empty(run_id)
        )
        # Seed the ordered grammar source from the resumed prefix
        # (resume passes
        # ``committed_bodies``; a coordinator reconstructed mid-run over a seeded
        # non-empty projection falls back to a SINGLE storage read here), and to
        # ``()`` for a fresh run. This is the only place storage may be read to
        # seed it — commit_batch never reads storage (it appends in memory).
        if committed_bodies is not None:
            self._committed_bodies: list[object] = list(committed_bodies)
        elif self._projection.version > 0:
            self._committed_bodies = [
                event.body for event in storage.events.read(run_id)
            ]
        else:
            self._committed_bodies = []

    @property
    def projection(self) -> RunProjection:
        return self._projection

    def _batch_envelopes(
        self,
        bodies: Sequence[object],
        correlation: CorrelationId,
        pre: RunProjection,
    ) -> list[EventEnvelope]:
        """The host-Protocol name for `batch_envelopes`, which owns the rule."""

        return batch_envelopes(self.run_id, bodies, correlation, pre)

    def work_broker(self) -> WorkBroker:
        """This run's work broker, from the storage it was built with.

        Here rather than at the caller so nothing reaches through
        `coordinator._storage` -- a walk across two objects and one private
        field to ask a question the coordinator can answer itself. `Storage`
        decides whether it HAS a broker; this only says which storage to ask.
        """

        return self._storage.work_broker()

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        occurrences: Sequence[Artifact] = (),
        correlation: CorrelationId,
        work: Sequence[WorkIntent] = (),
    ) -> RunProjection:
        """Atomically commit ``bodies`` as one contiguous event batch.

        The whole batch is preflight-folded on a local copy *before* any
        write, sharing the ``fold_committed`` step with
        ``replay_run_projection`` so the projection-equals-replay invariant
        cannot drift. It does not re-run replay's structural pre-checks
        (envelope type, run scope, sequence contiguity): the envelopes are
        constructed here and satisfy those by construction. A structurally
        invalid *batch* (e.g. a body ``apply_event`` rejects) raises
        ``InvalidSearchHistory`` and nothing is written. Only after the store
        commit succeeds is the incremental in-memory projection advanced; an
        ``EventStreamConflict`` (or any other commit failure) propagates with
        ``self._projection`` untouched.
        """

        if not bodies:
            raise ValueError("commit_batch requires at least one event body")

        pre = self._projection
        # The stream is contiguous, so ``version == len(stream)`` and
        # ``pre_version`` is exactly the ``expected_version`` the store wants.
        pre_version = pre.version

        envelopes = self._batch_envelopes(bodies, correlation, pre)

        # Preflight fold — share the fold step with replay_run_projection, on a
        # local copy, before any write, so an invalid batch leaves storage
        # untouched.
        folded = pre
        for envelope in envelopes:
            folded = fold_committed(folded, envelope)

        # Grammar preflight — the fold validates per-event semantics but NOT the
        # batch SHAPE, so a lone PolicyDecisionMade(Stop) (no explanation) would
        # fold cleanly yet be declared DurableCorruption by resume's recovery
        # grammar, violating "committed ⟹ recoverable". Reject any batch that is
        # not exactly one recognized coordinator batch (or a single M3 fact)
        # here, BEFORE persisting, using the SAME shape matchers recovery uses.
        new_bodies = [envelope.body for envelope in envelopes]
        if recognized_batch_shape(new_bodies) is None:
            raise ValueError(
                "commit_batch rejects a batch the recovery grammar would "
                "reject: bodies must form exactly one recognized coordinator "
                "batch (genesis / decision / result / evaluation) or a single "
                "M3 fact"
            )

        # Whole-stream grammar preflight — recognized_batch_shape only validates
        # the batch in ISOLATION, so a valid-shaped batch committed in the wrong
        # CONTEXT (e.g. an evaluation batch after a newer trial decision) would
        # persist yet be rejected by recovery's whole-stream scan, re-opening a
        # "committed but not recoverable" hole. Run the SAME recovery structural
        # scan over the WHOLE ordered stream (committed bodies + this batch)
        # BEFORE persisting; commit_batch and recovery thus consume the identical
        # grammar over the identical stream and cannot diverge. This uses the
        # in-memory ``_committed_bodies`` only — no per-commit storage read.
        scan_batch_grammar([*self._committed_bodies, *new_bodies])

        # A store failure (EventStreamConflict or otherwise) propagates here,
        # leaving self._projection untouched; mode-specific handling lives at
        # the call sites (CP-3), not in this method.
        # `work` rides the SAME transaction as the events that authorise it,
        # which is the seam PR-B1 built and nothing has called since. The record
        # requires enqueue to insert work rows "in the same transaction as the
        # decision cohort or genesis", and this is the only place both are in
        # scope. Empty by default, so every existing caller is byte-for-byte the
        # call it was.
        new_version = self._storage.commit(
            self.run_id,
            pre_version,
            events=tuple(envelopes),
            occurrences=tuple(occurrences),
            work=tuple(work),
        )
        # Contiguity invariant: the committed stream length must equal the
        # projected version. A mismatch is a real store/projection divergence,
        # not an assertion (which -O would strip).
        if new_version != folded.version:
            raise DurableCorruption(
                f"committed stream length {new_version} does not match "
                f"projected version {folded.version}"
            )
        self._projection = folded
        # Advance the in-memory grammar source only after the store commit.
        self._committed_bodies.extend(new_bodies)
        return folded

    def append_fact(self, body: object, *, correlation: CorrelationId) -> RunProjection:
        """Commit a single fact as its own atomic one-event batch.

        A thin M3-compatibility shim: the context/experience write-path
        (``context_selection``/``experience_reader``) commits one event at a
        time. Routing each through ``commit_batch`` gives those writes the same
        atomic, preflight-folded path as every other kernel fact, so no M3
        call site needs to change and the durable stream is a sequence of
        1-event batches at the M3 event positions.
        """

        return self.commit_batch([body], correlation=correlation)

    def read_events(self) -> tuple[EventEnvelope, ...]:
        return self.events.read(self.run_id)

    def start(
        self,
        seed: object,
        *,
        context_spec: ContextSpec | None = None,
        experience_spec: ExperienceSpec | None = None,
    ) -> None:
        start_run(
            self,
            seed,
            context_spec=context_spec,
            experience_spec=experience_spec,
        )

    def record_decision(
        self, program: SearchProgram, decision: SearchDecision
    ) -> CommittedDecision:
        return commit_decision(self, program, decision)

    def declare_context(self, spec: ContextSpec | None) -> None:
        declare_context(self, spec)

    def declare_experience(self, spec: ExperienceSpec | None) -> None:
        declare_experience(self, spec)

    def execute(self, trial: Trial) -> TrialOutcome:
        bundle = select_or_load_context(self, trial, self.context_selector)
        reader = issue_or_load_reader(self, trial, self.experience_spec)
        return execute_trial(self, trial, bundle, reader)

    def resume_completed_trial(self, trial: Trial) -> TrialOutcome:
        """Finish the pending evaluation of an already-committed trial.

        Routes ``resume``'s EVALUATION_PENDING recovery through the SAME
        failure / already-evaluated / evaluation-authorized guards
        ``execute_trial`` uses for a re-driven trial, so the "should this
        pending trial be evaluated?" decision lives in exactly one place
        (``_resume_completed_trial``) rather than being re-encoded at the call
        site. The proposer is never re-run and the proposal/result are never
        re-committed; only the evaluation batch (if still authorized) is
        committed, with the same per-trial correlation the original run used.
        """

        existing = self._projection.completed_trial(trial.id)
        if existing is None:
            raise DurableCorruption(
                f"cannot resume evaluation of uncommitted trial {trial.id}"
            )
        correlation = correlation_for_trial(trial.id)
        return _resume_completed_trial(self, trial, existing, correlation)


__all__ = ["SequentialCoordinator"]
