"""Incremental exact experience snapshots used by context replay validation."""

from __future__ import annotations

from meta_evolve.domain import (
    ArtifactCreated,
    BootstrapPrepared,
    ContextPolicyDeclared,
    ContextRecord,
    ContextSelected,
    EvaluationCompleted,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    EvidenceRecorded,
    ExperienceRef,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    ProposalSubmitted,
    TrialCompleted,
    TrialSpec,
)
from meta_evolve.domain.events import EventEnvelope

from .run_projection import RunProjection


def _record(
    state: RunProjection,
    event: EventEnvelope,
    kind: str,
    occurrence: object,
    logical_step: int,
    value: object,
) -> ContextRecord:
    identity = getattr(occurrence, "value", occurrence)
    return ContextRecord(
        ref=ExperienceRef(
            run_id=state.run_id,
            kind=kind,
            occurrence_id=identity,
        ),
        logical_step=logical_step,
        event_sequence=event.sequence,
        value=value,
    )


def _pending_step(state: RunProjection) -> int:
    for decision in reversed(state.decisions):
        if (
            isinstance(decision.decision, TrialSpec)
            and decision.trial_id is not None
            and state.completed_trial(decision.trial_id) is None
        ):
            return decision.logical_step
    if state.completed_trials:
        return state.completed_trials[-1].trial.logical_step
    return 0


def records_for_event(
    state: RunProjection, event: EventEnvelope
) -> tuple[ContextRecord, ...]:
    body = event.body
    if isinstance(body, BootstrapPrepared):
        trial = body.trial
        return (
            _record(state, event, "trial", trial.id, 0, trial),
            _record(state, event, "proposal", body.proposal.id, 0, body.proposal),
        )
    if isinstance(body, PolicyDecisionMade):
        return (
            _record(
                state,
                event,
                "decision",
                body.decision_id,
                body.logical_step,
                body,
            ),
        )
    if isinstance(body, PolicyDecisionExplained):
        decision = next(
            item for item in state.decisions if item.decision_id == body.decision_id
        )
        return (
            _record(
                state,
                event,
                "decision_explanation",
                body.decision_id,
                decision.logical_step,
                body,
            ),
        )
    if isinstance(body, ContextPolicyDeclared):
        occurrence = (
            f"{body.spec.policy.origin}:{body.spec.policy.name}:"
            f"{body.spec.policy.version}"
        )
        return (_record(state, event, "context_policy", occurrence, 0, body),)
    if isinstance(body, ContextSelected):
        decision = next(
            item for item in state.decisions if item.trial_id == body.trial_id
        )
        return (
            _record(
                state,
                event,
                "context_selection",
                body.trial_id,
                decision.logical_step,
                body,
            ),
        )
    if isinstance(body, ExperienceAccessDeclared):
        return (
            _record(
                state,
                event,
                "experience_access",
                "pull-access",
                0,
                body,
            ),
        )
    if isinstance(body, ExperienceGrantIssued):
        return (
            _record(
                state,
                event,
                "experience_grant",
                body.grant.trial_id,
                body.grant.as_of + 1,
                body,
            ),
        )
    operation_kinds = (
        (ExperienceOperationAttempted, "experience_attempt"),
        (ExperienceOperationSucceeded, "experience_success"),
        (ExperienceOperationDenied, "experience_denial"),
        (ExperienceOperationBudgetExhausted, "experience_exhaustion"),
    )
    for fact_type, kind in operation_kinds:
        if isinstance(body, fact_type):
            decision = next(
                item for item in state.decisions if item.trial_id == body.trial_id
            )
            return (
                _record(
                    state,
                    event,
                    kind,
                    body.operation_id,
                    decision.logical_step,
                    body,
                ),
            )
    if isinstance(body, ProposalSubmitted):
        decision = next(
            item for item in state.decisions if item.trial_id == body.proposal.trial_id
        )
        return (
            _record(
                state,
                event,
                "proposal",
                body.proposal.id,
                decision.logical_step,
                body.proposal,
            ),
        )
    if isinstance(body, ArtifactCreated):
        return (
            _record(
                state,
                event,
                "artifact",
                body.artifact_id,
                _pending_step(state),
                body,
            ),
        )
    if isinstance(body, EvidenceRecorded):
        return (
            _record(
                state,
                event,
                "evidence",
                body.evidence.id,
                _pending_step(state),
                body.evidence,
            ),
        )
    if isinstance(body, TrialCompleted):
        trial = body.trial
        outcome = _record(
            state, event, "outcome", trial.id, trial.logical_step, body.outcome
        )
        if state.bootstrap is not None and state.bootstrap.trial.id == trial.id:
            return (outcome,)
        return (
            _record(state, event, "trial", trial.id, trial.logical_step, trial),
            outcome,
        )
    if isinstance(body, EvaluationCompleted):
        evaluation = body.evaluation
        completed = state.completed_trial(evaluation.trial_id)
        assert completed is not None
        return (
            _record(
                state,
                event,
                "evaluation",
                evaluation.id,
                completed.trial.logical_step,
                evaluation,
            ),
        )
    return ()


__all__ = ["records_for_event"]
