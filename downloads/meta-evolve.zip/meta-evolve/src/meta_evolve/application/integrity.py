"""The storage-level half of the resume-time artifact-reference integrity
check (design §58).

Design §58 enumerates the exhaustive artifact-reference set —
``RunStarted.seed_artifact_id``, every ``ArtifactCreated.artifact_id``, and
each occurrence's ``parent_ids`` — from a run's event stream, and requires
every one of those references to resolve to an occurrence row *and* a blob
whose bytes hash to the recorded digest, else ``DurableCorruption``.
Enumerating that set needs event replay, which is M4.4's ``resume`` (out of
this storage-only slice's scope); what belongs here is the reusable,
storage-level piece: given any ``ArtifactStore`` and a set of artifact ids to
check, verify each one resolves cleanly, transitively through its own
``parent_ids`` (a corrupt store can claim a parent that was never itself
stored). M4.4 calls this with the ids it enumerates from replay.
"""

from __future__ import annotations

from collections.abc import Iterable

from meta_evolve.domain import ArtifactId
from meta_evolve.errors import DurableCorruption, DurableStoreError
from meta_evolve.ports import ArtifactNotFound, ArtifactStore


def check_artifact_references(
    artifacts: ArtifactStore, artifact_ids: Iterable[ArtifactId]
) -> None:
    """Verify every id in ``artifact_ids`` resolves to a stored artifact
    whose payload bytes hash to its recorded digest, and recursively verify
    each resolved artifact's own ``parent_ids`` the same way.

    ``ArtifactStore.get`` already re-validates the digest against the
    decoded payload (``Artifact.__post_init__``) and, for the durable
    adapter, the blob store's own digest check — this helper's job is just
    walking the reference graph and turning a missing or corrupt reference
    into a typed ``DurableCorruption``, never a raw ``ArtifactNotFound`` or a
    silently accepted gap.
    """

    visited: set[ArtifactId] = set()
    pending = list(artifact_ids)
    while pending:
        artifact_id = pending.pop()
        if not isinstance(artifact_id, ArtifactId):
            raise TypeError("artifact reference must be an ArtifactId")
        if artifact_id in visited:
            continue
        visited.add(artifact_id)
        try:
            artifact = artifacts.get(artifact_id)
        except ArtifactNotFound as error:
            raise DurableCorruption(
                f"artifact reference does not resolve: {artifact_id}"
            ) from error
        except DurableStoreError:
            # Incompatible/corrupt durable data and infrastructure access
            # failures already have their precise public type. Preserve it.
            raise
        except Exception as error:
            # ANY other failure resolving or decoding the artifact — a corrupt
            # occurrence row, malformed/undecodable payload bytes, a digest
            # mismatch surfaced as ValueError/TypeError, truncated JSON — is
            # durable corruption, not a raw adapter error leaking out.
            raise DurableCorruption(
                f"artifact reference could not be resolved or decoded: "
                f"{artifact_id}: {error}"
            ) from error
        pending.extend(artifact.parent_ids)


__all__ = ["check_artifact_references"]
