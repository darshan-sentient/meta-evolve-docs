"""Storage-level integrity checks over a run's recorded artifacts.

Design §58 enumerates the exhaustive artifact-reference set --
``RunStarted.seed_artifact_id``, every ``ArtifactCreated.artifact_id``, and
each occurrence's ``parent_ids`` -- from a run's event stream, and requires
every one of those references to resolve to an occurrence row *and* a blob
whose bytes hash to the recorded digest, else ``DurableCorruption``.
Enumerating that set needs event replay, so the caller supplies the ids and
this module supplies the reusable, storage-level piece.

Three checks live here, each asking a different question of the same bytes, and
all three run from ``load_validated_run`` on every reader's path rather than on
resume alone: does each reference RESOLVE (``check_artifact_references``); does
each resolved artifact AGREE with the run's declaration
(``check_artifact_declaration``); and was that declaration LEGAL to record at
all (``check_declared_codec``). They are separate because they fail on different
bytes, not because they defend each other: one coherent rewrite defeats all
three.

That is expected, and it is the point of ``docs/durable-trust.md``. Nothing in
this store is authenticated -- every id, digest and chain link is recomputable
by whoever can write the file -- so these detect ACCIDENTAL corruption and never
tampering. Read them as answering "was this written correctly", never "was this
written by someone entitled to". A check that reads its own inputs out of the
record it is judging cannot do more than that, and every check here does.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable

from meta_evolve.domain import Artifact, ArtifactId
from meta_evolve.errors import DurableCorruption, DurableStoreError
from meta_evolve.ports import ArtifactNotFound, ArtifactStore

from .codecs import BUILTIN_CODECS


def walk_artifacts(
    artifacts: ArtifactStore,
    artifact_ids: Iterable[ArtifactId],
    visit: Callable[[Artifact], None],
) -> None:
    """Walk the reachable artifact graph, resolving each id exactly once.

    ONE home for the traversal and, more importantly, one home for the error
    conversion. The two checks below each carried their own copy of this loop,
    and the copies had already diverged: the reference walk converted a
    ``DurableStoreError`` and any other resolution failure into
    ``DurableCorruption``, while the declaration walk caught only
    ``ArtifactNotFound`` -- so on the reader's path a corrupt occurrence row, a
    digest mismatch surfaced as ``ValueError`` or truncated payload bytes
    escaped one of the two as a raw adapter error. A rule with two homes is a
    rule with two answers.
    """

    visited: set[ArtifactId] = set()
    pending = list(artifact_ids)
    while pending:
        artifact_id = pending.pop()
        if not isinstance(artifact_id, ArtifactId):
            raise TypeError("artifact reference must be an ArtifactId")
        if artifact_id in visited:
            continue
        visited.add(artifact_id)
        try:
            artifact = artifacts.get(artifact_id)
        except ArtifactNotFound as error:
            raise DurableCorruption(
                f"artifact reference does not resolve: {artifact_id}"
            ) from error
        except DurableStoreError:
            # Incompatible/corrupt durable data and infrastructure access
            # failures already have their precise public type. Preserve it.
            raise
        except Exception as error:
            # ANY other failure resolving or decoding the artifact -- a corrupt
            # occurrence row, malformed/undecodable payload bytes, a digest
            # mismatch surfaced as ValueError/TypeError, truncated JSON -- is
            # durable corruption, not a raw adapter error leaking out.
            raise DurableCorruption(
                f"artifact reference could not be resolved or decoded: "
                f"{artifact_id}: {error}"
            ) from error
        visit(artifact)
        pending.extend(artifact.parent_ids)


def load_committed_artifact(
    artifacts: ArtifactStore, artifact_id: ArtifactId
) -> Artifact:
    """Read one artifact the committed stream references, during execution.

    The id is already validated as committed, so "not found" or a row or payload
    that cannot decode (``ValueError``/``TypeError``) is damage: that is
    ``DurableCorruption``, which escapes normalization. Other failures -- an
    ``OSError`` blip, a store's ``KeyError`` -- stay retryable delivery faults.
    """

    try:
        return artifacts.get(artifact_id)
    except ArtifactNotFound as error:
        raise DurableCorruption(
            f"committed artifact {getattr(artifact_id, 'value', artifact_id)} "
            "is missing from artifact storage"
        ) from error
    except (ValueError, TypeError) as error:
        raise DurableCorruption(
            f"committed artifact {getattr(artifact_id, 'value', artifact_id)} "
            f"could not be decoded: {error}"
        ) from error


def check_artifact_references(
    artifacts: ArtifactStore, artifact_ids: Iterable[ArtifactId]
) -> None:
    """Verify every id in ``artifact_ids`` resolves to a stored artifact
    whose payload bytes hash to its recorded digest, and recursively verify
    each resolved artifact's own ``parent_ids`` the same way.

    ``ArtifactStore.get`` already re-validates the digest against the
    decoded payload (``Artifact.__post_init__``) and, for the durable
    adapter, the blob store's own digest check — this helper's job is just
    walking the reference graph and turning a missing or corrupt reference
    into a typed ``DurableCorruption``, never a raw ``ArtifactNotFound`` or a
    silently accepted gap.
    """

    # Resolution IS the check here: `walk_artifacts` already turns a missing
    # or undecodable reference into `DurableCorruption`, so nothing more is
    # asked of each artifact.
    walk_artifacts(artifacts, artifact_ids, lambda _artifact: None)


def check_artifact_declaration(
    artifacts: ArtifactStore,
    artifact_ids: Iterable[ArtifactId],
    *,
    kind: str,
    representation: str,
) -> None:
    """Verify every artifact reachable from ``artifact_ids`` carries the run's
    declared artifact type, walking ``parent_ids`` the way
    ``check_artifact_references`` does and turning a missing reference into the
    same typed ``DurableCorruption`` rather than a raw ``ArtifactNotFound``.

    The two sites that build an artifact -- ``bootstrap.py`` and
    ``proposal_completion.py`` -- both take ``kind`` from
    ``host.task.artifact_kind``, so within one run the pair is the task's by
    construction. A stored artifact that disagrees is a store contradicting its
    own declaration.

    It needs its own check because nothing else covers it. The occurrence's
    ``kind`` and ``representation`` are metadata beside the payload, not inside
    it: the digest is over the payload alone, and the event chain never mentions
    them. Yet decoding dispatches on exactly that pair -- ``CodecIndex.decode``
    resolves ``(artifact.kind, artifact.representation)`` -- so an edited
    occurrence steers every later decode at a codec the declaration never named,
    while the declaration itself still reads as built-in.

    The parent walk is not decoration: a decode reaches a parent through
    ``Run.lineage`` and through the view builder, so an unwalked parent is a
    reachable artifact whose codec nobody checked.
    """

    def refuse_a_foreign_declaration(artifact: Artifact) -> None:
        if (artifact.kind, artifact.representation) != (kind, representation):
            raise DurableCorruption(
                f"artifact {artifact.id.value} declares "
                f"({artifact.kind!r}, {artifact.representation!r}), which is "
                f"not the run's declared ({kind!r}, {representation!r})"
            )

    # The shared walk. This check previously carried its own copy which handled
    # only `ArtifactNotFound`, so a corrupt occurrence, a digest mismatch or
    # truncated payload bytes leaked a raw adapter error out of a durable
    # integrity check -- out of the walk whose entire job is to notice damage.
    walk_artifacts(artifacts, artifact_ids, refuse_a_foreign_declaration)


def check_declared_codec(*, mode: str, kind: str, representation: str) -> None:
    """Verify a durable-local run's recorded declaration names a built-in codec.

    ``check_artifact_declaration`` above checks AGREEMENT -- that the stored
    artifacts carry the pair the run declared. This checks the RULE, which is a
    different forge: rewrite ``RunStarted.task`` and move the occurrences with
    it, and the store agrees with itself perfectly while naming a codec
    ``prepare_start`` would never have admitted. A registered custom codec then
    resolves, so nothing downstream notices that it is rebuilding a payload no
    manifest covers.

    Corruption rather than a capability question, and for the same reason the
    occurrence check is: ``prepare_start`` refuses this pair unconditionally for
    durable-local, so no version of this library can have written such a
    durable-local stream. A store holding one was written by something else.

    True of the PAIR, and silent about the MODE. ``mode`` comes from the same
    ``RunStarted`` the pair does, so a rewrite that also declares the run
    ``local`` passes. Under the trust boundary in ``docs/durable-trust.md``
    that is the boundary itself: a further record-internal check would buy
    nothing and would wrongly declare legitimately interrupted runs corrupt.
    """

    # Every mode that records a declaration to verify, which since M11.2 is
    # two: `distributed` adopts durable-local's component discipline wholesale
    # and refuses a custom codec at START for the same reason. Naming only
    # durable-local meant the refusal was not made AT ALL on a distributed
    # resume, on any reader's path.
    if mode == "local":
        return
    if (kind, representation) not in BUILTIN_CODECS:
        raise DurableCorruption(
            f"{mode} run declares ({kind!r}, {representation!r}), which "
            f"is not a built-in artifact: a registered artifact codec carries "
            f"no manifest, so the recorded declaration cannot be verified"
        )


__all__ = [
    "check_artifact_declaration",
    "check_artifact_references",
    "check_declared_codec",
    "walk_artifacts",
]
