"""Self-contained run summaries and fair pairwise comparisons."""

from __future__ import annotations

from dataclasses import dataclass, field
from math import isfinite
from typing import TYPE_CHECKING, Literal

from meta_evolve.domain import (
    Artifact,
    ContentDigest,
    ContextSpec,
    ExperienceSpec,
    Maximize,
    PolicyRef,
    RunId,
    RunStarted,
    Usage,
)
from meta_evolve.domain.search import _recorded_usage
from meta_evolve.errors import NoSuccessfulEvaluation, RunsNotComparable

from .durable_loading import load_validated_run
from .experience_usage import RunExperienceUsage, aggregate_experience_usage

if TYPE_CHECKING:
    from .results import Run


@dataclass(frozen=True, slots=True)
class RunSummary:
    """A frozen, storage-independent report, including runs with no winner.

    Lifecycle records whether the run stopped; rankability records whether a
    successful measurement exists. Neither promises improvement over the seed.
    Counts and usage include committed failures, but not pending work.
    """

    run_id: RunId
    policy: PolicyRef
    primary_score: int | float | None
    evaluation_count: int
    usage: Usage
    random_seed: int
    initial_artifact: object
    initial_artifact_digest: ContentDigest
    winning_lineage: tuple[object, ...]
    context_spec: ContextSpec | None
    experience_spec: ExperienceSpec | None
    experience_usage: RunExperienceUsage
    # The sorted roles whose recorded reference identifies its component by
    # name alone: named, not configured. This certifies nothing about the roles
    # it omits -- any local component may self-declare arbitrary version text,
    # and only a ComponentManifest represents a verified identity.
    name_only_components: tuple[str, ...] = ()
    lifecycle: Literal["complete", "incomplete"] = field(kw_only=True)
    rankability: Literal["rankable", "unrankable"] = field(kw_only=True)
    stop_reason: str | None = field(kw_only=True)

    def __post_init__(self) -> None:
        if self.lifecycle not in ("complete", "incomplete"):
            raise ValueError("lifecycle must be complete or incomplete")
        if self.rankability not in ("rankable", "unrankable"):
            raise ValueError("rankability must be rankable or unrankable")
        if self.stop_reason is not None and not isinstance(self.stop_reason, str):
            raise TypeError("stop_reason must be a string or None")
        if self.lifecycle == "complete":
            if not self.stop_reason or not self.stop_reason.strip():
                raise ValueError("complete summary requires a non-empty stop_reason")
        elif self.stop_reason is not None:
            raise ValueError("incomplete summary requires stop_reason=None")
        if not isinstance(self.winning_lineage, tuple):
            raise TypeError("winning_lineage must be a tuple")
        if isinstance(self.evaluation_count, bool) or not isinstance(self.evaluation_count, int):
            raise TypeError("evaluation_count must be an integer")
        if self.evaluation_count < 0:
            raise ValueError("evaluation_count must be non-negative")
        if self.rankability == "rankable":
            score = self.primary_score
            if isinstance(score, bool) or not isinstance(score, (int, float)):
                raise TypeError("rankable summary requires a numeric primary_score")
            if isinstance(score, float) and not isfinite(score):
                raise ValueError("primary_score must be finite")
            if not self.winning_lineage or not self.evaluation_count:
                raise ValueError("rankable summary requires lineage and an evaluation")
        elif self.primary_score is not None or self.winning_lineage:
            raise ValueError("unrankable summary requires no score or winning lineage")


@dataclass(frozen=True, slots=True)
class RunComparison:
    """The exact-score result for two compatible run summaries."""

    left: RunSummary
    right: RunSummary
    winner: RunSummary | None
    same_random_seed: bool
    same_context_declaration: bool
    same_experience_declaration: bool

    def __post_init__(self) -> None:
        if (
            self.winner is not None
            and self.winner is not self.left
            and self.winner is not self.right
        ):
            raise ValueError("comparison winner must be its left or right summary")
        if self.left.rankability != "rankable" or self.right.rankability != "rankable":
            raise ValueError("comparison requires two rankable summaries")
        if (self.winner is None) != (self.left.primary_score == self.right.primary_score):
            raise ValueError("comparison ties require equal successful scores")
        if not isinstance(self.same_random_seed, bool):
            raise TypeError("same_random_seed must be a bool")
        if self.same_random_seed != (
            self.left.random_seed == self.right.random_seed
        ):
            raise ValueError("same_random_seed must match the compared summaries")
        if not isinstance(self.same_context_declaration, bool):
            raise TypeError("same_context_declaration must be a bool")
        if self.same_context_declaration != (
            self.left.context_spec == self.right.context_spec
        ):
            raise ValueError(
                "same_context_declaration must match the compared summaries"
            )
        if not isinstance(self.same_experience_declaration, bool):
            raise TypeError("same_experience_declaration must be a bool")
        if self.same_experience_declaration != (
            self.left.experience_spec == self.right.experience_spec
        ):
            raise ValueError(
                "same_experience_declaration must match the compared summaries"
            )

    @property
    def tied(self) -> bool:
        return self.winner is None


def summarize_run(run: Run) -> RunSummary:
    return _summary_inputs(run)[0]


def _summary_inputs(run: Run) -> tuple[RunSummary, RunStarted, Artifact]:
    projection = load_validated_run(
        run._storage, run.id, require_existing=True
    ).projection
    start = projection.start
    assert start is not None  # validated nonempty history includes its declaration
    views = run._views(projection)
    try:
        best = views.best_evaluation(None)
    except NoSuccessfulEvaluation:
        best = None
    objective = start.task.objectives[0]
    initial = run._storage.artifacts.get(start.seed_artifact_id)
    assert initial.digest is not None
    lineage = () if best is None else views.lineage(best.artifact_id)
    stop = projection.stop
    return RunSummary(
        run_id=run.id,
        policy=start.search.policy,
        primary_score=None if best is None else best.metrics[objective.metric],
        evaluation_count=len(projection.completed_evaluations),
        usage=_recorded_usage(projection.completed_trials, projection.completed_evaluations),
        random_seed=start.random_seed,
        # Decoded, like every other artifact value a caller sees: this field
        # and winning_lineage describe the same artifacts, so they must not
        # disagree about their type.
        initial_artifact=views.artifact(start.seed_artifact_id).value,
        initial_artifact_digest=initial.digest,
        winning_lineage=tuple(item.artifact.value for item in lineage),
        lifecycle="incomplete" if stop is None else "complete",
        rankability="unrankable" if best is None else "rankable",
        stop_reason=None if stop is None else stop.reason,
        context_spec=(
            projection.context_declaration.spec
            if projection.context_declaration is not None
            else None
        ),
        experience_spec=(
            projection.experience_declaration.spec
            if projection.experience_declaration is not None
            else None
        ),
        experience_usage=aggregate_experience_usage(projection),
        # Both roles ``compare`` gates on, because both have the same hole: it
        # requires exact equality of each, and a name-only reference makes that
        # equality prove nothing about the live callable behind it.
        name_only_components=tuple(
            sorted(
                component.role
                for component in (start.task.evaluator, start.search.proposer)
                if component.name_only
            )
        ),
    ), start, initial


def compare_runs(left_run: Run, other: object) -> RunComparison:
    from .results import Run

    if not isinstance(other, Run):
        raise TypeError("other must be a Run")

    # Construct both summaries first so a failed evaluation is never treated as
    # a score, an incompatibility, or an automatic loss.
    left, left_start, left_initial = _summary_inputs(left_run)
    left_score = _require_score(left)
    right, right_start, right_initial = _summary_inputs(other)
    right_score = _require_score(right)

    _require_equal(
        left_start.task.evaluator,
        right_start.task.evaluator,
        "evaluator component",
    )
    _require_equal(
        left_start.task.artifact_kind,
        right_start.task.artifact_kind,
        "task artifact kind",
    )
    left_objective = left_start.task.objectives[0]
    right_objective = right_start.task.objectives[0]
    _require_equal(left_objective.metric, right_objective.metric, "objective metric")
    _require_equal(type(left_objective), type(right_objective), "objective direction")
    _require_equal(
        left_objective.satisfy,
        right_objective.satisfy,
        "objective satisfaction threshold",
    )
    _require_equal(
        left_start.task.budget,
        right_start.task.budget,
        "task-level budget",
    )
    _require_equal(left_start.run_budget, right_start.run_budget, "effective run budget")

    _require_equal(left_initial.kind, right_initial.kind, "initial artifact kind")
    _require_equal(
        left_initial.representation,
        right_initial.representation,
        "initial artifact representation",
    )
    _require_equal(
        left_initial.schema_version,
        right_initial.schema_version,
        "initial artifact schema",
    )
    _require_equal(
        left_initial.digest,
        right_initial.digest,
        "initial artifact content digest",
    )
    _require_equal(
        left_start.search.proposer,
        right_start.search.proposer,
        "authorized proposer component",
    )

    if left_score == right_score:
        winner = None
    elif isinstance(left_objective, Maximize):
        winner = left if left_score > right_score else right
    else:
        winner = left if left_score < right_score else right
    return RunComparison(
        left=left,
        right=right,
        winner=winner,
        same_random_seed=left.random_seed == right.random_seed,
        same_context_declaration=left.context_spec == right.context_spec,
        same_experience_declaration=(
            left.experience_spec == right.experience_spec
        ),
    )


def _require_score(summary: RunSummary) -> int | float:
    if summary.primary_score is None:
        raise NoSuccessfulEvaluation(
            "run has no successful evaluations; inspect trials() or inspect() for typed failures"
        )
    return summary.primary_score


def _require_equal(left: object, right: object, declaration: str) -> None:
    if left != right:
        raise RunsNotComparable(declaration)


__all__ = ["RunComparison", "RunSummary"]
