"""Self-contained run summaries and fair pairwise comparisons."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from meta_evolve.domain import (
    ContentDigest,
    ContextSpec,
    ExperienceSpec,
    Maximize,
    PolicyRef,
    RunId,
    Usage,
)
from meta_evolve.errors import RunError, RunsNotComparable

from .experience_usage import RunExperienceUsage, aggregate_experience_usage

if TYPE_CHECKING:
    from .results import Run


@dataclass(frozen=True, slots=True)
class RunSummary:
    """An immutable, storage-independent view of one successful run."""

    run_id: RunId
    policy: PolicyRef
    primary_score: int | float
    evaluation_count: int
    usage: Usage
    random_seed: int
    initial_artifact: object
    initial_artifact_digest: ContentDigest
    winning_lineage: tuple[object, ...]
    context_spec: ContextSpec | None
    experience_spec: ExperienceSpec | None
    experience_usage: RunExperienceUsage
    # The sorted roles whose recorded reference identifies its component by
    # name alone: named, not configured. This certifies nothing about the roles
    # it omits -- any local component may self-declare arbitrary version text,
    # and only a ComponentManifest represents a verified identity.
    name_only_components: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class RunComparison:
    """The exact-score result for two compatible run summaries."""

    left: RunSummary
    right: RunSummary
    winner: RunSummary | None
    same_random_seed: bool
    same_context_declaration: bool
    same_experience_declaration: bool

    def __post_init__(self) -> None:
        if (
            self.winner is not None
            and self.winner is not self.left
            and self.winner is not self.right
        ):
            raise ValueError("comparison winner must be its left or right summary")
        if not isinstance(self.same_random_seed, bool):
            raise TypeError("same_random_seed must be a bool")
        if self.same_random_seed != (
            self.left.random_seed == self.right.random_seed
        ):
            raise ValueError("same_random_seed must match the compared summaries")
        if not isinstance(self.same_context_declaration, bool):
            raise TypeError("same_context_declaration must be a bool")
        if self.same_context_declaration != (
            self.left.context_spec == self.right.context_spec
        ):
            raise ValueError(
                "same_context_declaration must match the compared summaries"
            )
        if not isinstance(self.same_experience_declaration, bool):
            raise TypeError("same_experience_declaration must be a bool")
        if self.same_experience_declaration != (
            self.left.experience_spec == self.right.experience_spec
        ):
            raise ValueError(
                "same_experience_declaration must match the compared summaries"
            )

    @property
    def tied(self) -> bool:
        return self.winner is None


def summarize_run(run: Run) -> RunSummary:
    projection = run._projection()
    start = projection.start
    if start is None:
        raise RunError("run has not started")
    best = run._best_evaluation(None)
    objective = start.task.objectives[0]
    initial = run._storage.artifacts.get(start.seed_artifact_id)
    assert initial.digest is not None
    lineage = run.lineage()
    return RunSummary(
        run_id=run.id,
        policy=start.search.policy,
        primary_score=best.metrics[objective.metric],
        evaluation_count=len(projection.completed_evaluations),
        usage=projection.search_state.usage,
        random_seed=start.random_seed,
        # Decoded, like every other artifact value a caller sees: this field
        # and winning_lineage describe the same artifacts, so they must not
        # disagree about their type.
        initial_artifact=run._codecs.decode(initial),
        initial_artifact_digest=initial.digest,
        winning_lineage=tuple(item.artifact.value for item in lineage),
        context_spec=(
            projection.context_declaration.spec
            if projection.context_declaration is not None
            else None
        ),
        experience_spec=(
            projection.experience_declaration.spec
            if projection.experience_declaration is not None
            else None
        ),
        experience_usage=aggregate_experience_usage(projection),
        # Both roles ``compare`` gates on, because both have the same hole: it
        # requires exact equality of each, and a name-only reference makes that
        # equality prove nothing about the live callable behind it.
        name_only_components=tuple(
            sorted(
                component.role
                for component in (start.task.evaluator, start.search.proposer)
                if component.name_only
            )
        ),
    )


def compare_runs(left_run: Run, other: object) -> RunComparison:
    from .results import Run

    if not isinstance(other, Run):
        raise TypeError("other must be a Run")

    # Construct both summaries first so a failed evaluation is never treated as
    # a score, an incompatibility, or an automatic loss.
    left = summarize_run(left_run)
    right = summarize_run(other)
    left_projection = left_run._projection()
    right_projection = other._projection()
    left_start = left_projection.start
    right_start = right_projection.start
    assert left_start is not None and right_start is not None

    _require_equal(
        left_start.task.evaluator,
        right_start.task.evaluator,
        "evaluator component",
    )
    _require_equal(
        left_start.task.artifact_kind,
        right_start.task.artifact_kind,
        "task artifact kind",
    )
    left_objective = left_start.task.objectives[0]
    right_objective = right_start.task.objectives[0]
    _require_equal(left_objective.metric, right_objective.metric, "objective metric")
    _require_equal(type(left_objective), type(right_objective), "objective direction")
    _require_equal(
        left_objective.satisfy,
        right_objective.satisfy,
        "objective satisfaction threshold",
    )
    _require_equal(
        left_start.task.budget,
        right_start.task.budget,
        "task-level budget",
    )
    _require_equal(left_start.run_budget, right_start.run_budget, "effective run budget")

    left_initial = left_run._storage.artifacts.get(left_start.seed_artifact_id)
    right_initial = other._storage.artifacts.get(right_start.seed_artifact_id)
    _require_equal(left_initial.kind, right_initial.kind, "initial artifact kind")
    _require_equal(
        left_initial.representation,
        right_initial.representation,
        "initial artifact representation",
    )
    _require_equal(
        left_initial.schema_version,
        right_initial.schema_version,
        "initial artifact schema",
    )
    _require_equal(
        left_initial.digest,
        right_initial.digest,
        "initial artifact content digest",
    )
    _require_equal(
        left_start.search.proposer,
        right_start.search.proposer,
        "authorized proposer component",
    )

    if left.primary_score == right.primary_score:
        winner = None
    elif isinstance(left_objective, Maximize):
        winner = left if left.primary_score > right.primary_score else right
    else:
        winner = left if left.primary_score < right.primary_score else right
    return RunComparison(
        left=left,
        right=right,
        winner=winner,
        same_random_seed=left.random_seed == right.random_seed,
        same_context_declaration=left.context_spec == right.context_spec,
        same_experience_declaration=(
            left.experience_spec == right.experience_spec
        ),
    )


def _require_equal(left: object, right: object, declaration: str) -> None:
    if left != right:
        raise RunsNotComparable(declaration)


__all__ = ["RunComparison", "RunSummary"]
