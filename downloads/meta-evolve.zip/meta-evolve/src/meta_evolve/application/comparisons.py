"""Self-contained run summaries and fair pairwise comparisons."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from meta_evolve.domain import (
    Artifact,
    Maximize,
    RunStarted,
)
from meta_evolve.domain.search import _recorded_usage
from meta_evolve.errors import NoSuccessfulEvaluation, RunsNotComparable

from .durable_loading import load_validated_run
from .experience_usage import aggregate_experience_usage
from .run_summary import RunSummary

if TYPE_CHECKING:
    from .results import Run


@dataclass(frozen=True, slots=True)
class RunComparison:
    """The exact-score result for two compatible run summaries."""

    left: RunSummary
    right: RunSummary
    winner: RunSummary | None
    same_random_seed: bool
    same_context_declaration: bool
    same_experience_declaration: bool

    def __post_init__(self) -> None:
        if (
            self.winner is not None
            and self.winner is not self.left
            and self.winner is not self.right
        ):
            raise ValueError("comparison winner must be its left or right summary")
        if self.left.rankability != "rankable" or self.right.rankability != "rankable":
            raise ValueError("comparison requires two rankable summaries")
        if (self.winner is None) != (self.left.primary_score == self.right.primary_score):
            raise ValueError("comparison ties require equal successful scores")
        if not isinstance(self.same_random_seed, bool):
            raise TypeError("same_random_seed must be a bool")
        if self.same_random_seed != (
            self.left.random_seed == self.right.random_seed
        ):
            raise ValueError("same_random_seed must match the compared summaries")
        if not isinstance(self.same_context_declaration, bool):
            raise TypeError("same_context_declaration must be a bool")
        if self.same_context_declaration != (
            self.left.context_spec == self.right.context_spec
        ):
            raise ValueError(
                "same_context_declaration must match the compared summaries"
            )
        if not isinstance(self.same_experience_declaration, bool):
            raise TypeError("same_experience_declaration must be a bool")
        if self.same_experience_declaration != (
            self.left.experience_spec == self.right.experience_spec
        ):
            raise ValueError(
                "same_experience_declaration must match the compared summaries"
            )

    @property
    def tied(self) -> bool:
        return self.winner is None


def summarize_run(run: Run) -> RunSummary:
    return _summary_inputs(run)[0]


def _summary_inputs(run: Run) -> tuple[RunSummary, RunStarted, Artifact]:
    projection = load_validated_run(
        run._storage, run.id, require_existing=True
    ).projection
    start = projection.start
    assert start is not None  # validated nonempty history includes its declaration
    views = run._views(projection)
    try:
        best = views.best_evaluation(None)
    except NoSuccessfulEvaluation:
        best = None
    objective = start.task.objectives[0]
    initial = run._storage.artifacts.get(start.seed_artifact_id)
    assert initial.digest is not None
    lineage = () if best is None else views.lineage(best.artifact_id)
    stop = projection.stop
    baseline = (
        projection.evaluation_for(projection.bootstrap.trial.id)
        if projection.bootstrap is not None else None
    )
    failed_attempts = {
        item.trial.id for item in projection.completed_trials
        if item.outcome.failure is not None
    } | {
        item.evaluation.trial_id for item in projection.completed_evaluations
        if item.evaluation.failure is not None
    }
    return RunSummary(
        run_id=run.id,
        policy=start.search.policy,
        primary_score=None if best is None else best.metrics[objective.metric],
        evaluation_count=len(projection.completed_evaluations),
        usage=_recorded_usage(projection.completed_trials, projection.completed_evaluations),
        random_seed=start.random_seed,
        # Decoded, like every other artifact value a caller sees: this field
        # and winning_lineage describe the same artifacts, so they must not
        # disagree about their type.
        initial_artifact=views.artifact(start.seed_artifact_id).value,
        initial_artifact_digest=initial.digest,
        winning_lineage=tuple(item.artifact.value for item in lineage),
        lifecycle="incomplete" if stop is None else "complete",
        rankability="unrankable" if best is None else "rankable",
        stop_reason=None if stop is None else stop.reason,
        primary_objective=objective,
        baseline_score=(
            baseline.evaluation.metrics[objective.metric]
            if baseline is not None and baseline.evaluation.failure is None else None
        ),
        failure_count=len(failed_attempts),
        storage_is_durable=run._storage.is_durable,
        storage_location=run._storage._display_path,
        capabilities=start.capabilities,
        context_spec=(
            projection.context_declaration.spec
            if projection.context_declaration is not None
            else None
        ),
        experience_spec=(
            projection.experience_declaration.spec
            if projection.experience_declaration is not None
            else None
        ),
        experience_usage=aggregate_experience_usage(projection),
        # Both roles ``compare`` gates on, because both have the same hole: it
        # requires exact equality of each, and a name-only reference makes that
        # equality prove nothing about the live callable behind it.
        name_only_components=tuple(
            sorted(
                component.role
                for component in (start.task.evaluator, start.search.proposer)
                if component.name_only
            )
        ),
    ), start, initial


def compare_runs(left_run: Run, other: object) -> RunComparison:
    from .results import Run

    if not isinstance(other, Run):
        raise TypeError("other must be a Run")

    # Construct both summaries first so a failed evaluation is never treated as
    # a score, an incompatibility, or an automatic loss.
    left, left_start, left_initial = _summary_inputs(left_run)
    left_score = _require_score(left)
    right, right_start, right_initial = _summary_inputs(other)
    right_score = _require_score(right)

    _require_equal(
        left_start.task.evaluator,
        right_start.task.evaluator,
        "evaluator component",
    )
    _require_equal(
        left_start.task.artifact_kind,
        right_start.task.artifact_kind,
        "task artifact kind",
    )
    left_objective = left_start.task.objectives[0]
    right_objective = right_start.task.objectives[0]
    _require_equal(left_objective.metric, right_objective.metric, "objective metric")
    _require_equal(type(left_objective), type(right_objective), "objective direction")
    _require_equal(
        left_objective.satisfy,
        right_objective.satisfy,
        "objective satisfaction threshold",
    )
    _require_equal(
        left_start.task.budget,
        right_start.task.budget,
        "task-level budget",
    )
    _require_equal(left_start.run_budget, right_start.run_budget, "effective run budget")

    _require_equal(left_initial.kind, right_initial.kind, "initial artifact kind")
    _require_equal(
        left_initial.representation,
        right_initial.representation,
        "initial artifact representation",
    )
    _require_equal(
        left_initial.schema_version,
        right_initial.schema_version,
        "initial artifact schema",
    )
    _require_equal(
        left_initial.digest,
        right_initial.digest,
        "initial artifact content digest",
    )
    _require_equal(
        left_start.search.proposer,
        right_start.search.proposer,
        "authorized proposer component",
    )

    if left_score == right_score:
        winner = None
    elif isinstance(left_objective, Maximize):
        winner = left if left_score > right_score else right
    else:
        winner = left if left_score < right_score else right
    return RunComparison(
        left=left,
        right=right,
        winner=winner,
        same_random_seed=left.random_seed == right.random_seed,
        same_context_declaration=left.context_spec == right.context_spec,
        same_experience_declaration=(
            left.experience_spec == right.experience_spec
        ),
    )


def _require_score(summary: RunSummary) -> int | float:
    if summary.primary_score is None:
        raise NoSuccessfulEvaluation(
            "run has no successful evaluations; inspect trials() or inspect() for typed failures"
        )
    return summary.primary_score


def _require_equal(left: object, right: object, declaration: str) -> None:
    if left != right:
        raise RunsNotComparable(declaration)


__all__ = ["RunComparison", "RunSummary"]
