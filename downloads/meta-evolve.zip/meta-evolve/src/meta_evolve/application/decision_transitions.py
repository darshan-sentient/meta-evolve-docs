"""Admit one policy decision into the committed history.

Split out of ``transitions.py`` -- which owns the whole fold -- because a
decision carries the rules concurrency changes most: the barrier deciding
whether a decision may be committed at all, and the cohort provenance telling
replay what the policy actually observed. Same shape as
``proposal_transitions`` and ``archive_transitions``: one branch of the fold,
independently testable.
"""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain.events import PolicyDecisionMade
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.domain.trial import ArchiveUpdate, TrialSpec

from .archive_transitions import archive_transition_error
from .disposition import outstanding_trial_ids
from .run_projection import RunProjection


def _invalid(sequence: int, reason: str) -> InvalidSearchHistory:
    # Local, like `proposal_transitions._invalid`: importing it from
    # `transitions` would close a cycle, since that module calls `decide`.
    return InvalidSearchHistory(
        f"invalid search history at sequence {sequence}: {reason}"
    )


def cohort_members(
    state: RunProjection, body: PolicyDecisionMade
) -> tuple[PolicyDecisionMade, ...]:
    """The decisions already committed that share this one's observed base.

    One definition, two consumers: the barrier asks whether an outstanding trial
    belongs to the cohort this decision is joining, and the cohort-base rules ask
    where that cohort began. Deriving it once is what stops the two acquiring
    subtly different notions of base, adjacency and width.

    Only a trial decision can join a cohort, and only a contiguous trailing run
    counts -- a decision on the same base with something else committed between
    is not a sibling, it is a forgery.
    """

    if not isinstance(body.decision, TrialSpec):
        return ()
    base = body.policy_base
    members: list[PolicyDecisionMade] = []
    for recorded in reversed(state.decisions):
        if not isinstance(recorded.decision, TrialSpec):
            break
        if recorded.policy_base != base:
            break
        members.append(recorded)
    return tuple(reversed(members))


def _admit(state: RunProjection, body: PolicyDecisionMade, sequence: int) -> None:
    """The decision barrier.

    A decision may be committed when nothing is outstanding, or when it joins
    the cohort every outstanding trial already belongs to. Outstanding means the
    record's definition: a decided trial with no completion, or one whose
    completion succeeded and still owes an authorized evaluation.
    """

    # The declared width is read back out of the RECORDED configuration, which a
    # forged, foreign or migrated store controls -- so it is validated on every
    # decision, before anything can return early, or an impossible declaration
    # would replay cleanly on every run whose decisions have no siblings.
    width = state.start.search.configuration.get("cohort_width", 1)
    if not isinstance(width, int) or isinstance(width, bool) or width < 1:
        raise _invalid(sequence, "declared cohort width is invalid")

    outstanding = set(outstanding_trial_ids(state))
    members = cohort_members(state, body)
    if outstanding:
        if not members:
            raise _invalid(
                sequence, "cannot decide with work outstanding"
            )
        joined = {item.trial_id for item in members}
        # An unreachable backstop. Reaching it needs an outstanding trial X that
        # is NOT a member of the trailing run this decision joins. Let D be that
        # run's opener. X's decision precedes D, and a trial's membership of
        # `outstanding` only ever ENDS -- it is added at its decision and
        # removed for good once it fails, is terminally skipped, or is
        # evaluated, and the fold refuses a second completion or a second
        # evaluation, so it cannot re-enter. So X was outstanding when D was
        # committed too. D opens its own base, hence had no members of its own,
        # hence hit the refusal above and was never committed. The stream that
        # would reach here therefore cannot exist.
        if not outstanding <= joined:
            raise _invalid(
                sequence,
                "cannot decide with work outstanding from an earlier cohort",
            )
    if not members:
        if body.cohort_base is not None:
            raise _invalid(sequence, "a cohort base needs an earlier member")
        return
    # The run of decisions on this base must begin where the base says it does,
    # or `policy_base` would name a state the first member never observed.
    #
    # An unreachable backstop: `cohort_members` only returns decisions whose
    # `policy_base` equals this one's, and a member that records no base has
    # `observed_version == policy_base`, so the opener satisfies this by
    # construction. Reaching it needs a member that DOES record a base to lead
    # the run, which means the true opener was excluded from the walk -- and
    # excluding it means forging it into something an earlier rule rejects first.
    if members[0].observed_version != body.policy_base:
        raise _invalid(sequence, "cohort base does not begin its own cohort")
    # ... and the members must be genuinely ADJACENT in the stream, not merely
    # consecutive in the decision tuple, which drops every non-decision event.
    # A batch is two events per member, so a member that truly followed its
    # siblings sits exactly `2 * len(members)` past the base; anything committed
    # between them -- a result, an evaluation, a standalone fact -- moves the
    # head and fails here. Without this a decision could claim a base it never
    # observed and replay would reconstruct the wrong policy input.
    if body.observed_version != body.policy_base + 2 * len(members):
        raise _invalid(sequence, "cohort members are not adjacent in the stream")
    # That the first member records no base and a later one does both follow
    # from the two checks above, because every decision in `state.decisions`
    # has itself passed this function -- even on a spliced stream:
    #   * a `members[0]` carrying a base was admitted as a later member, so its
    #     own adjacency check put it at `policy_base + 2k` for some k >= 1, hence
    #     above the base it shares with this decision -- and the check above
    #     fires first.
    #   * `cohort_base is None` forces `policy_base == observed_version`, so the
    #     adjacency check demands `2 * len(members) == 0`, which is false here
    #     because `members` is non-empty -- and it fires first.
    if len(members) + 1 > width:
        raise _invalid(
            sequence, f"cohort exceeds the declared width of {width}"
        )


def decide(
    state: RunProjection, body: PolicyDecisionMade, sequence: int
) -> RunProjection:
    """Validate and record one policy decision."""

    if not state.ready:
        raise _invalid(sequence, "bootstrap evaluation must precede policy decisions")
    _admit(state, body, sequence)
    search = state.search_state
    if body.policy != state.start.search.policy:
        raise _invalid(sequence, "decision policy does not match the run policy")
    if body.logical_step != search.next_logical_step:
        raise _invalid(sequence, "policy decision logical step is not contiguous")
    if body.decision_id != search.next_decision_id:
        raise _invalid(sequence, "policy decision id is not reproducible")
    if body.observed_version != state.version:
        raise _invalid(sequence, "decision observed the wrong stream version")
    for name, recorded_seed in body.random_seeds.items():
        if recorded_seed != search.randomness.seed(name):
            raise _invalid(sequence, f"recorded random seed {name!r} is invalid")
    if isinstance(body.decision, TrialSpec):
        if body.decision.task_id != state.start.task_id:
            raise _invalid(sequence, "trial decision belongs to another task")
        if body.decision.proposer != state.start.search.proposer:
            raise _invalid(sequence, "trial decision selected an unauthorized proposer")
        if any(parent not in state.artifact_ids for parent in body.decision.parent_ids):
            raise _invalid(sequence, "trial decision references an unknown parent")
        if any(item.trial_id == body.trial_id for item in state.decisions):
            raise _invalid(sequence, "trial identity was already committed")
        if body.random_seeds.get("trial") != body.decision.random_seed:
            raise _invalid(sequence, "trial decision seed does not match its record")
        declaration = state.context_declaration
        declared_policy = (
            declaration.spec.policy if declaration is not None else None
        )
        if body.decision.context_policy != declared_policy:
            raise _invalid(
                sequence,
                "trial context policy does not match the run declaration",
            )
    elif isinstance(body.decision, ArchiveUpdate):
        error = archive_transition_error(state, body.decision)
        if error is not None:
            raise _invalid(sequence, error)
    return replace(state, version=sequence, decisions=state.decisions + (body,))


__all__ = ["decide"]
