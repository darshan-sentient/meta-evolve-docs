"""Deterministic live filtering, traversal, comparison, and rendering."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import (
    ContextRecord,
    ExperienceComparison,
    ExperienceFilter,
    ExperienceObservation,
    ExperienceRequest,
    ExperienceUsage,
)
from meta_evolve.domain.evaluation import Failure
from meta_evolve.domain.experience import NON_CANDIDATE_EXPERIENCE_KINDS
from meta_evolve.errors import ExperienceAccessDenied

from .experience import ExperienceGraph, ExperienceQuery, ExperienceRecord
from .experience_contract import interleave_records, metric_deltas, render_records
from .source_operations import execute_source_request


@dataclass(frozen=True, slots=True)
class _Capacity:
    results: int
    records: int
    chars: int


def execute_request(
    graph: ExperienceGraph,
    request: ExperienceRequest,
    before: ExperienceUsage,
    *,
    max_results: int,
    max_records: int,
    max_chars: int,
    resolve_source=None,
):
    if request.operation in {
        "list_source_paths", "read_source", "diff_source"
    }:
        return execute_source_request(
            graph,
            request,
            before,
            max_results=max_results,
            max_records=max_records,
            max_chars=max_chars,
            resolve=resolve_source,
        )
    query = ExperienceQuery(
        task_id=graph.task_id,
        run_id=graph.run_id,
        as_of=request.as_of,
    )
    remaining = _Capacity(
        results=max(0, max_results - before.results),
        records=max(0, max_records - before.records),
        chars=max(0, max_chars - before.chars),
    )
    if request.operation == "search":
        return _search(graph, query, request, before, remaining)
    if request.operation == "open":
        return _open(graph, query, request, before, remaining)
    if request.operation in {"ancestors", "siblings"}:
        return _traverse(graph, query, request, before, remaining)
    return _compare(graph, query, request, before, remaining)


def _snapshot(record: ExperienceRecord) -> ContextRecord:
    return ContextRecord(
        ref=record.ref,
        logical_step=record.logical_step,
        event_sequence=record.event_sequence,
        value=record.value,
    )


def _failure_kind(value: object) -> str | None:
    failure = getattr(value, "failure", None)
    return failure.kind if isinstance(failure, Failure) else None


def _matches(record: ExperienceRecord, filters: ExperienceFilter) -> bool:
    return (
        (not filters.record_kinds or record.kind in filters.record_kinds)
        and (
            not filters.failure_kinds
            or _failure_kind(record.value) in filters.failure_kinds
        )
    )


def _render(
    records: tuple[ContextRecord, ...], available_chars: int
) -> tuple[str, bool]:
    complete = render_records(records)
    rendered = complete[:available_chars]
    return rendered, len(rendered) < len(complete)


def _usage(
    before: ExperienceUsage,
    references: tuple,
    records: tuple,
    rendered: str,
) -> ExperienceUsage:
    return ExperienceUsage(
        operations=before.operations,
        results=before.results + len(references),
        records=before.records + len(records),
        chars=before.chars + len(rendered),
    )


def _bounded_count(total: int, limit: int | None, capacity: int) -> int:
    caller = total if limit is None else min(total, limit)
    return min(caller, capacity)


def _candidate_records(records) -> tuple:
    return tuple(
        record
        for record in records
        if record.kind not in NON_CANDIDATE_EXPERIENCE_KINDS
    )


def _search(graph, query, request, before, remaining):
    candidates = tuple(
        record
        for record in _candidate_records(graph.state_at(query).records)
        if _matches(record, request.filters)
    )
    count = _bounded_count(
        len(candidates), request.limit, min(remaining.results, remaining.records)
    )
    records = tuple(_snapshot(item) for item in candidates[:count])
    references = tuple(item.ref for item in records)
    rendered, chars_cut = _render(records, remaining.chars)
    return ExperienceObservation(
        references=references,
        records=records,
        rendered=rendered,
        truncated=count < len(candidates) or chars_cut,
        usage=_usage(before, references, records, rendered),
    )


def _open(graph, query, request, before, remaining):
    state = graph.state_at(query)
    source = next((item for item in state.records if item.ref == request.ref), None)
    if source is None:
        raise ExperienceAccessDenied()
    allowed = min(remaining.results, remaining.records) >= 1
    records = (_snapshot(source),) if allowed else ()
    references = (source.ref,) if allowed else ()
    rendered, chars_cut = _render(records, remaining.chars)
    return ExperienceObservation(
        references=references,
        records=records,
        rendered=rendered,
        truncated=not allowed or chars_cut,
        usage=_usage(before, references, records, rendered),
    )


def _traverse(graph, query, request, before, remaining):
    operation = getattr(graph, request.operation)
    nodes = operation(request.ref, query)
    node_count = _bounded_count(len(nodes), request.limit, remaining.results)
    selected_nodes = nodes[:node_count]
    candidates = tuple(
        record
        for node in selected_nodes
        for record in _candidate_records(node.records)
    )
    records = tuple(_snapshot(item) for item in candidates[: remaining.records])
    references = tuple(node.ref for node in selected_nodes)
    rendered, chars_cut = _render(records, remaining.chars)
    return ExperienceObservation(
        references=references,
        records=records,
        rendered=rendered,
        truncated=(
            node_count < len(nodes)
            or len(records) < len(candidates)
            or chars_cut
        ),
        usage=_usage(before, references, records, rendered),
    )


def _compare(graph, query, request, before, remaining):
    left = graph.node(request.ref, query)
    right = graph.node(request.other_ref, query)
    nodes = (left, right)[: remaining.results]
    references = tuple(node.ref for node in nodes)
    left_source = (
        _candidate_records(left.records) if remaining.results >= 1 else ()
    )
    right_source = (
        _candidate_records(right.records) if remaining.results >= 2 else ()
    )
    paired = interleave_records(left_source, right_source)
    selected = paired[: remaining.records]
    records = tuple(_snapshot(record) for _, record in selected)
    left_records = tuple(
        _snapshot(record) for side, record in selected if side == "left"
    )
    right_records = tuple(
        _snapshot(record) for side, record in selected if side == "right"
    )
    rendered, chars_cut = _render(records, remaining.chars)
    return ExperienceComparison(
        left=request.ref,
        right=request.other_ref,
        references=references,
        left_records=left_records,
        right_records=right_records,
        deltas=metric_deltas(left_records, right_records),
        rendered=rendered,
        truncated=(
            len(references) < 2 or len(selected) < len(paired) or chars_cut
        ),
        usage=_usage(before, references, records, rendered),
    )


__all__ = ["execute_request"]
