"""The inline backend: one component call at a time, on a helper thread.

D9's inline half, now an event source in the dispatch loop (D2). A call used
to run on the dispatcher's own thread, so nothing could renew its lease until it
returned, and any component slower than the lease expired its own lease with the
call still on the stack. The component runs on a helper thread and the
dispatcher thread renews, because renewal is a write on the store's one
connection, while a component holds no storage, clock or broker by
construction (`executors.py`), so it is the half that can move.

The helper hands its outcome back as a dispatch message -- the same objects a
wire endpoint decodes -- and wakes the loop with one byte on a socketpair, so
the loop selects on this endpoint exactly as it selects on a socket (design
SD2: objects in process, frames only on the wire).

Three properties of the helper thread, each one a failure without it:

* `contextvars.copy_context().run`, taken on the dispatcher thread when the
  call starts -- a fresh thread sees none of the caller's context variables,
  so tracing or budget scopes set around a drain would vanish inside the very
  call they were set around;
* every `BaseException` handed back and re-raised on the dispatcher thread --
  a thread that let `KeyboardInterrupt` end it would turn an operator's
  interrupt into a call that silently never produced a result;
* a daemon -- a refused renewal aborts at once rather than waiting for a result
  that can no longer be committed, and a component that never returns must not
  hold the process open.

Python cannot cancel a thread, so after an abort the call may still be
running. Execution is therefore AT LEAST ONCE (design SD4), exactly as it is
for a worker process that lost its lease: nothing in this process refuses a
later drive or resume while that call runs. Acceptance stays at most once --
the abandoned call's lease is stale, its epoch superseded after the resume's
rollover, and the in-transaction `AcceptCompletion` decides regardless. What
this module guarantees is that the abandoned call can never be SETTLED:
every call carries a generation, an abort retires it, and a retired
generation's outcome is dropped when it arrives, never committed or raised.
"""

from __future__ import annotations

import contextvars
import socket
import threading
from dataclasses import dataclass

from collections.abc import Callable

from meta_evolve.domain.work import Lease
from meta_evolve.domain.workers import WorkerRegistration

from .dispatch_messages import Escaped, Message, Submission, Work
from .dispatch_outcomes import call_for, outcome_of
from .executors import EvaluationExecutor, ProposalExecutor


@dataclass(slots=True)
class _Call:
    generation: int
    lease: Lease
    thread: threading.Thread


class InlineEndpoint:
    """This process's executors, one call at a time, behind a socketpair."""

    #: Inline, a stale submission RAISES; only a wire endpoint is answered.
    answers_submissions = False

    def __init__(
        self,
        *,
        registrations: tuple[WorkerRegistration, ...],
        evaluation: EvaluationExecutor,
        proposal: ProposalExecutor,
    ) -> None:
        #: The identities its claims are made under, first that admits wins.
        self.registrations = registrations
        self._evaluation = evaluation
        self._proposal = proposal
        self._lock = threading.Lock()
        self._outbox: list[tuple[int, Submission]] = []
        self._generation = 0
        self._current: _Call | None = None
        self._reader: socket.socket | None = None
        self._writer: socket.socket | None = None

    # -- the loop's view ------------------------------------------------------

    def fileno(self) -> int:
        self._open()
        assert self._reader is not None
        return self._reader.fileno()

    def wants_work(self, bound: int) -> bool:
        """Whether a call may start: none is in flight here. Its implicit pull."""

        return self._current is None

    def alive(self, clock, window: int) -> bool:
        """Whether the current call's helper is still executing.

        The inline heartbeat: a live helper is the fact a heartbeat frame
        reports, so its lease is renewed exactly while this holds. The clock
        is not read -- a helper's liveness is not a time.
        """

        call = self._current
        return call is not None and call.thread.is_alive()

    def silent_for(self, clock) -> None:
        """Never silent: liveness here is the thread, not a heartbeat's age."""

        return None

    def departed(self) -> None:
        """Never leaves: there is no process here to interrupt separately.

        An interrupt raised by an inline component is that call's outcome and
        aborts the drive (`Escaped`), which is the divergence the record
        already states.
        """

        return None

    def send(self, message: Message) -> None:
        raise TypeError("an inline endpoint is never answered: it raises instead")

    def wants_write(self) -> bool:
        return False

    def flush(self) -> None:
        return None

    def start(self, work: Work) -> None:
        """Run `work` on a new helper thread, in a copy of THIS thread's context."""

        if self._current is not None:
            raise RuntimeError("an inline endpoint runs one call at a time")
        self._open()
        self._generation += 1
        generation = self._generation
        context = contextvars.copy_context()
        call = call_for(work, self._evaluation, self._proposal)
        lease = work.lease
        writer = self._writer

        def run() -> None:
            try:
                message = outcome_of(lease, lambda: context.run(call))
            except BaseException as error:
                # Reporting the failure itself raised -- an exception whose
                # `__str__` raises an interrupt, say. Handed back as it is: a
                # helper that ended here would leave its call bound, unsettled,
                # with the drive spinning on it.
                message = Escaped(lease=lease, error=error)
            with self._lock:
                self._outbox.append((generation, message))
            try:
                writer.send(b"\0")  # type: ignore[union-attr]
            except OSError:
                # The endpoint closed after this call was retired: nobody is
                # waiting, and a traceback from a daemon thread would be noise
                # about a result that was never going to be settled.
                pass

        thread = threading.Thread(target=run, name="meta-evolve-inline-call", daemon=True)
        self._current = _Call(generation, lease, thread)
        thread.start()

    def receive(self, clock: Callable[[], int] | None = None) -> tuple[Submission, ...]:
        """The current call's outcome, if it has arrived; retired ones dropped."""

        self._drain_wakeups()
        with self._lock:
            arrived, self._outbox = self._outbox, []
        current = self._current
        delivered = tuple(
            message
            for generation, message in arrived
            if current is not None and generation == current.generation
        )
        if delivered:
            self._current = None
        return delivered

    def retire(self) -> None:
        """Forget the current call: its outcome will be dropped when it arrives.

        Called when an exception leaves the drive. The call may still be
        running (at least once, SD4), but it no longer occupies this endpoint,
        so the next drive on the same dispatcher can start a new one.
        """

        self._current = None

    def close(self) -> None:
        for end in (self._reader, self._writer):
            if end is not None:
                end.close()
        self._reader = self._writer = None

    # -- internals ------------------------------------------------------------

    def _open(self) -> None:
        if self._reader is None:
            self._reader, self._writer = socket.socketpair()
            self._reader.setblocking(False)

    def _drain_wakeups(self) -> None:
        if self._reader is None:
            return
        try:
            while self._reader.recv(4096):
                pass
        except (BlockingIOError, InterruptedError):
            pass



__all__ = ["InlineEndpoint"]
