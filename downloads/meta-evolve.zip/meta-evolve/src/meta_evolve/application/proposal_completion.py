"""Commit normalized proposals, successors, and pending evaluations."""

from __future__ import annotations


from typing import TYPE_CHECKING

from meta_evolve.domain import (
    ArtifactCreated,
    CorrelationId,
    InfrastructureFailure,
    Trial,
    TrialCompleted,
    TrialOutcome,
)
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports import EventStreamConflict
from meta_evolve.ports.callables import ProposalResult

from .executors import encode_candidate
from .integrity import load_committed_artifact
from .evaluation_execution import (
    evaluate_artifact,
)
from .proposal_building import (
    build_proposal_completion,
    check_completion_key,
)
from .work import ProposalWork

if TYPE_CHECKING:
    from .execution import ExecutionHost


def complete_work(
    host: ExecutionHost,
    work: ProposalWork,
    result: ProposalResult,
    correlation: CorrelationId,
) -> TrialOutcome:
    """Build, commit, and drive the dependent evaluation. The shipped path."""

    trial = work.trial
    # BEFORE the already-completed short-circuit. This is an authority check on
    # the work item, not a step in building its facts, so it must refuse a
    # forged key whether or not the trial has completed. The split moved it into
    # the build half, which runs after this branch -- and a forged key on a
    # completed trial silently became a replay.
    check_completion_key(work)
    existing = host.projection.completed_trial(trial.id)
    if existing is not None:
        return resume_completed_trial(host, trial, existing, correlation)

    built = build_proposal_completion(
        host, work, encode_candidate(host.codecs, host.task, result)
    )
    outcome = built.outcome
    if outcome.failure is not None or host.capabilities.resumable:
        # A logical failure is a valid commit, and durable-local is atomic and
        # deterministic, so a crash is recovered by resume re-driving it. Every
        # exception propagates in both cases.
        host.commit_batch(
            list(built.bodies),
            occurrences=built.occurrences,
            correlation=correlation,
        )
        if outcome.failure is not None:
            return outcome
    else:
        try:
            host.commit_batch(
                list(built.bodies),
                occurrences=built.occurrences,
                correlation=correlation,
            )
        except EventStreamConflict:
            raise
        except (InvalidSearchHistory, DurableCorruption):
            raise
        except Exception as error:
            failed_outcome = TrialOutcome.failed(
                trial_id=trial.id,
                proposal_id=outcome.proposal_id,
                evidence_ids=outcome.evidence_ids,
                usage=outcome.usage,
                failure=InfrastructureFailure(
                    message=str(error) or type(error).__name__,
                    details={"exception_type": type(error).__name__},
                ),
            )
            host.commit_batch(
                [
                    body
                    for body in built.bodies
                    if not isinstance(body, (ArtifactCreated, TrialCompleted))
                ]
                + [TrialCompleted(trial=trial, outcome=failed_outcome)],
                correlation=correlation,
            )
            return failed_outcome
    # The disposition was pinned when the success batch committed; reading it
    # back is what makes this path and recovery agree without re-deriving.
    # Three-valued, and only *evaluate* (`True`) authorizes this. `is True` is
    # equivalent to truthiness over those values; it names the value it means.
    if host.projection.disposition_for(trial.id) is True:
        evaluate_artifact(host, trial, built.occurrences[0], correlation)
    return outcome


def resume_completed_trial(
    host: ExecutionHost,
    trial: Trial,
    existing: TrialCompleted,
    correlation: CorrelationId,
) -> TrialOutcome:
    """Finish only the missing evaluation of a committed successful trial."""

    outcome = existing.outcome
    if outcome.failure is not None:
        return outcome
    if host.projection.evaluation_for(trial.id) is not None:
        return outcome
    # Three-valued, and only *evaluate* (`True`) authorizes this.
    if host.projection.disposition_for(trial.id) is True:
        artifact = load_committed_artifact(host.artifacts, outcome.artifact_ids[0])
        evaluate_artifact(host, trial, artifact, correlation)
    return outcome


__all__ = ["complete_work", "resume_completed_trial"]
