"""Commit normalized proposals, successors, and pending evaluations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from meta_evolve.domain import (
    Artifact,
    ArtifactCreated,
    ArtifactId,
    CorrelationId,
    DecisionId,
    InfrastructureFailure,
    InvalidOutput,
    PolicyViolation,
    Proposal,
    ProposalId,
    ProposalSubmitted,
    ResourceExhausted,
    Trial,
    TrialCompleted,
    TrialOutcome,
)
from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.errors import DurableCorruption, InvalidDecision
from meta_evolve.ports import EventStreamConflict
from meta_evolve.ports.callables import ProposalResult

from .derivation import derivation_violation
from .evaluation_execution import (
    evaluate_artifact,
    evidence_bodies as build_evidence_bodies,
)
from .identities import stable_id
from .work import (
    WorkItem,
    action_usage,
    evaluation_authorized,
    would_exceed,
)

if TYPE_CHECKING:
    from .execution import ExecutionHost


def complete_work(
    host: ExecutionHost,
    work: WorkItem,
    result: ProposalResult,
    correlation: CorrelationId,
) -> TrialOutcome:
    expected_key = stable_id(DecisionId, "completion", work.trial.id.value).value
    if work.completion_key != expected_key:
        raise InvalidDecision("work item has an invalid completion key")
    trial = work.trial
    existing = host.projection.completed_trial(trial.id)
    if existing is not None:
        return resume_completed_trial(host, trial, existing, correlation)
    usage = action_usage(trials=1, usage=result.usage)
    reported_failure = result.failure
    failure = reported_failure
    derived_from = result.derived_from
    if would_exceed(
        usage,
        trial.spec.budget,
        host.projection,
        run_budget=host.run_budget,
        task=host.task,
    ):
        failure = ResourceExhausted(
            message="proposer usage exceeded its effective budget",
            details={
                "reported_failure": (
                    reported_failure.kind if reported_failure else None
                )
            },
        )
        derived_from = ()
    else:
        violation = derivation_violation(
            host.projection, trial.id, result.derived_from
        )
        if violation is not None:
            details = (
                {"reported_failure": reported_failure.kind}
                if reported_failure is not None
                else {}
            )
            failure = PolicyViolation(
                message="proposal derivation violates observation authority",
                details=details,
            )
            derived_from = ()
    payload: object = None
    if failure is None:
        # The one place a proposed value becomes a durable payload. It runs
        # here because this is where the task's kind and representation meet
        # the run's codec index. A value the codec *rejects* — ``TypeError``
        # or ``ValueError``, the ``ArtifactCodec`` contract's "not mine"
        # signal — is a recoverable proposer failure, exactly like any other
        # invalid output. Any other exception is a bug in the codec, not a
        # rejection, and propagates unhandled rather than being disguised as
        # bad proposer output.
        try:
            payload = host.codecs.encode(
                host.task.artifact_kind,
                host.task.artifact_representation,
                result.candidate,
            )
        except (TypeError, ValueError) as error:
            failure = InvalidOutput(
                message="proposer returned invalid output",
                details={
                    "error": str(error),
                    "output_type": type(result.candidate).__name__,
                },
            )
            derived_from = ()
        if failure is None and host.codecs.has_successor_validator(
            host.task.artifact_kind,
            host.task.artifact_representation,
        ):
            parents = tuple(
                host.artifacts.get(parent_id).payload
                for parent_id in trial.spec.parent_ids
            )
            failure = host.codecs.validate_successor(
                host.task.artifact_kind,
                host.task.artifact_representation,
                parents,
                payload,
            )
    proposal = Proposal(
        id=stable_id(ProposalId, "proposal", trial.id.value),
        trial_id=trial.id,
        parent_ids=trial.spec.parent_ids,
        operator=trial.spec.operator,
        hypothesis=result.hypothesis,
        predicted_outcomes=result.predicted_outcomes,
        metadata=result.metadata,
        derived_from=derived_from,
    )
    evidence_bodies, evidence_ids = build_evidence_bodies(
        result.evidence, owner=trial.id.value
    )
    if failure is not None:
        outcome = TrialOutcome.failed(
            trial_id=trial.id,
            proposal_id=proposal.id,
            evidence_ids=evidence_ids,
            usage=usage,
            failure=failure,
        )
        # A logical failure is a valid commit; any exception propagates in
        # both modes.
        host.commit_batch(
            [
                ProposalSubmitted(proposal=proposal),
                *evidence_bodies,
                TrialCompleted(trial=trial, outcome=outcome),
            ],
            correlation=correlation,
        )
        return outcome

    artifact = Artifact(
        id=stable_id(ArtifactId, "artifact", trial.id.value),
        payload=payload,
        kind=host.task.artifact_kind,
        representation=host.task.artifact_representation,
        parent_ids=trial.spec.parent_ids,
        provenance={
            "proposal_id": proposal.id.value,
            "run_id": host.run_id.value,
            "trial_id": trial.id.value,
        },
    )
    outcome = TrialOutcome.succeeded(
        trial_id=trial.id,
        proposal_id=proposal.id,
        artifact_ids=(artifact.id,),
        evidence_ids=evidence_ids,
        usage=usage,
    )
    success_bodies = [
        ProposalSubmitted(proposal=proposal),
        *evidence_bodies,
        ArtifactCreated(artifact_id=artifact.id),
        TrialCompleted(trial=trial, outcome=outcome),
    ]
    if host.capabilities.resumable:
        # durable-local: the result batch is atomic and the trial is
        # deterministic, so a crash here is recovered by resume re-driving it.
        # Every exception propagates; there is no InfrastructureFailure
        # fallback in this mode.
        host.commit_batch(
            success_bodies, occurrences=(artifact,), correlation=correlation
        )
    else:
        try:
            host.commit_batch(
                success_bodies, occurrences=(artifact,), correlation=correlation
            )
        except EventStreamConflict:
            raise
        except (InvalidSearchHistory, DurableCorruption):
            raise
        except Exception as error:
            failed_outcome = TrialOutcome.failed(
                trial_id=trial.id,
                proposal_id=proposal.id,
                evidence_ids=evidence_ids,
                usage=usage,
                failure=InfrastructureFailure(
                    message=str(error) or type(error).__name__,
                    details={"exception_type": type(error).__name__},
                ),
            )
            host.commit_batch(
                [
                    ProposalSubmitted(proposal=proposal),
                    *evidence_bodies,
                    TrialCompleted(trial=trial, outcome=failed_outcome),
                ],
                correlation=correlation,
            )
            return failed_outcome
    remaining = host.projection.search_state.remaining_budget
    if evaluation_authorized(remaining, trial.spec.budget, usage):
        evaluate_artifact(host, trial, artifact, correlation)
    return outcome


def resume_completed_trial(
    host: ExecutionHost,
    trial: Trial,
    existing: TrialCompleted,
    correlation: CorrelationId,
) -> TrialOutcome:
    """Finish only the missing evaluation of a committed successful trial."""

    outcome = existing.outcome
    if outcome.failure is not None:
        return outcome
    if host.projection.evaluation_for(trial.id) is not None:
        return outcome
    remaining = host.projection.search_state.remaining_budget
    if evaluation_authorized(remaining, trial.spec.budget, outcome.usage):
        artifact = host.artifacts.get(outcome.artifact_ids[0])
        evaluate_artifact(host, trial, artifact, correlation)
    return outcome


__all__ = ["complete_work", "resume_completed_trial"]
