"""Settling a claimed item's outcome through the shared completion path.

Whatever ran the component -- the inline helper thread or a worker across a
socket -- its outcome arrives here as a dispatch message, and one of four
things happens.

* `AttemptFailed` -- an attempt failure: the lease is released with its cause
  and the retry bound decides.
* `CompletionFailed` -- the proposer answered but encoding its candidate
  failed: a completion failure. The cause is recorded against the lease and
  the error propagates; the component is not run again.
* `Escaped` -- a raise the normalization boundary lets escape: the drive
  aborts with no release and no cause.
* `Completed` -- the build, the provisional fold, the keepalive and the commit
  with `AcceptCompletion`. Any fault there is a completion failure, as above.

The row stays LEASED after a completion failure until expiry or rollover
returns it to READY, and the cause just recorded decides whether a later drain
runs it again (`domain/work_aborts.py`).

On the wire, every outcome is classified first, by `submission_status`:
for a lease no longer live, a result is answered Duplicate (with the stored
acknowledgment) or Stale (with its reason), and so is a failure report -- which
then releases, records and raises nothing. A live result must also be the kind
its row asked for, of the task's declared artifact kind, or it is a protocol
violation. An inline outcome skips that read -- its lease is the one this
dispatcher holds, and the keepalive already classifies it in one write
transaction. The in-transaction acceptance still decides for both: a stale or
duplicate refusal raised there is answered the same way on the wire, and
raised inline.
"""

from __future__ import annotations

from collections.abc import Callable
from contextlib import AbstractContextManager
from typing import TYPE_CHECKING

from meta_evolve.domain.work import Lease, StaleReason, WorkKind
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.callables import EvaluationResult
from meta_evolve.ports.work_store import InvalidWorkAppend, WorkBroker
from meta_evolve.ports.work_submission import (
    SubmissionStatus,
    Duplicate,
    DuplicateCompletion,
    Live,
    Stale,
    StaleCompletion,
)

from .dispatch_binding import Binding, EvaluationInputs
from .dispatch_endpoint import Endpoint
from .dispatch_evaluation import finish_evaluation
from .dispatch_messages import (
    Submission,
    Accepted,
    Answer,
    AttemptFailed,
    Completed,
    CompletionFailed,
    Escaped,
    TransportFailure,
)
from .dispatch_outcomes import reportable_cause
from .dispatch_proposal import finish_proposal
from .executors import EncodedProposal

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .coordinator import SequentialCoordinator


class Settler:
    """The dispatcher's writes for an outcome, against one coordinator and broker."""

    def __init__(
        self,
        coordinator: SequentialCoordinator,
        broker: WorkBroker,
        clock: Callable[[], int],
        epoch: Callable[[], int | None],
    ):
        self._coordinator = coordinator
        self._broker = broker
        self._clock = clock
        self._epoch = epoch

    def fail_attempt(self, lease: Lease, cause: tuple[str, str]) -> None:
        """Release the lease with its cause; the retry bound decides.

        The answer is not read: a lease already gone has nothing left to
        return, and the cause travels with the release so reclaim can build the
        terminal fact from the row in a later pass, possibly in another process.
        """

        self._broker.release(
            self._coordinator.run_id,
            lease,
            now=self._clock(),
            failure=cause,
            epoch=self._epoch(),
        )

    def record_completion_failure(
        self, lease: Lease, error: BaseException, cause: tuple[str, str] | None = None
    ) -> None:
        """Write the cause without ever replacing the error being propagated.

        `cause` when the pair was computed where the error was raised (a
        worker); otherwise it is computed here from `error`.
        """

        try:
            self._broker.record_failure(
                self._coordinator.run_id,
                lease,
                now=self._clock(),
                cause=cause or reportable_cause(error),
                epoch=self._epoch(),
            )
        except Exception as secondary:
            error.add_note(
                f"recording this failure's cause also failed: "
                f"{type(secondary).__name__}: {secondary}"
            )

    def settle(
        self,
        binding: Binding,
        message: Submission,
        blocking: Callable[[str], AbstractContextManager[None]],
        protect: Callable[[Binding], Lease | StaleReason],
    ) -> None:
        """Apply `message`, the outcome of `binding`'s call. May raise to abort."""

        lease = binding.lease
        endpoint = binding.endpoint
        if endpoint.answers_submissions:
            # EVERY outcome kind is classified first on the wire, not only a
            # result: a lease that expired while still bound here gets its
            # failure answered Stale with nothing written, exactly as its
            # result would be -- never a release, a cause or an abort.
            try:
                status = self._status(lease)
            except Exception as secondary:
                if isinstance(message, (CompletionFailed, Escaped)):
                    secondary.add_note(
                        f"while settling a worker's {type(message.error).__name__}: "
                        f"{message.error}"
                    )
                raise
            if not isinstance(status, Live):
                self._answer(endpoint, lease, status)
                return
        if isinstance(message, AttemptFailed):
            self.fail_attempt(lease, message.cause)
            return
        if isinstance(message, (CompletionFailed, Escaped)):
            if endpoint.answers_submissions:
                message.error.add_note(
                    # The lease's own worker id, not the endpoint's: the
                    # protocol declares `registrations`, and `registration` is
                    # one backend's extra. Byte-for-byte the same string.
                    f"raised in worker {lease.worker_id}"
                )
                if isinstance(message, CompletionFailed) and message.cause is not None:
                    # The rebuilt error has no `__cause__`; the operator reads
                    # the real fault here, not only on the durable row.
                    message.error.add_note(f"cause: {message.cause[0]}: {message.cause[1]}")
            if isinstance(message, CompletionFailed):
                self.record_completion_failure(lease, message.error, message.cause)
            raise message.error
        with blocking("commit"):
            # Drain buffered heartbeats before judging this connection fresh.
            # The settling binding is already unbound, so the blocking guard's
            # renewal pass cannot protect it before its own result build.
            try:
                protect(binding)
            except StaleCompletion as stale:
                # No build, fold or recorded failure for a refused renewal.
                if not endpoint.answers_submissions:
                    raise
                self.answer_stale(endpoint, lease, stale.reason)
                return
            try:
                self._finish(binding, message.result)
            except StaleCompletion as stale:
                if not endpoint.answers_submissions:
                    self.record_completion_failure(lease, stale)
                    raise
                self.answer_stale(endpoint, lease, stale.reason)
                return
            except DuplicateCompletion as duplicate:
                if not endpoint.answers_submissions:
                    self.record_completion_failure(lease, duplicate)
                    raise
                # A duplicate the store has no acknowledgment for is a row
                # that recorded an acceptance without what it answered with:
                # durable state disagreeing with itself, not a replay.
                if duplicate.acknowledgment is None:
                    raise DurableCorruption(
                        f"work item {lease.item.value} is recorded as accepted "
                        "with no acknowledgment to replay"
                    ) from duplicate
                self._answer(endpoint, lease, Duplicate(duplicate.acknowledgment))
                return
            except DurableCorruption as error:
                # The keepalive's "already accepted": on the wire, a resend
                # that raced its own acceptance, so the stored answer decides.
                # The re-read must never REPLACE the corruption it is checking.
                if endpoint.answers_submissions:
                    try:
                        status = self._status(lease)
                    except Exception as secondary:
                        error.add_note(
                            f"classifying it also failed: "
                            f"{type(secondary).__name__}: {secondary}"
                        )
                        status = Stale(StaleReason.NOT_LEASED)
                    if isinstance(status, Duplicate):
                        self._answer(endpoint, lease, status)
                        return
                self.record_completion_failure(lease, error)
                raise
            except Exception as error:
                self.record_completion_failure(lease, error)
                raise
        if endpoint.answers_submissions:
            accepted = self._status(lease)
            if not isinstance(accepted, Duplicate):
                raise DurableCorruption(
                    f"work item {lease.item.value} was committed but its row "
                    "does not record the acceptance"
                )
            self._answer(endpoint, lease, Accepted(accepted.acknowledgment))

    def refuse_foreign_result(self, binding: Binding, message: Submission) -> None:
        """A worker's result must be the kind its row asked for, of the task's
        declared artifact kind: a worker encodes with the run's own task (D14,
        same build), so anything else is a protocol violation, refused before
        it can reach the fold -- never a candidate. Inline results are the
        dispatcher's own, and failure reports carry no result: both pass."""

        if not (binding.endpoint.answers_submissions and isinstance(message, Completed)):
            return
        result = message.result
        wanted = (
            EvaluationResult if binding.row.kind is WorkKind.EVALUATION else EncodedProposal
        )
        if not isinstance(result, wanted):
            raise TransportFailure(f"a {type(result).__name__} for {binding.row.kind.value} work")
        if isinstance(result, EncodedProposal):
            task = self._coordinator.task
            if (result.kind, result.representation) != (
                task.artifact_kind,
                task.artifact_representation,
            ):
                raise TransportFailure("a result of a kind the run's task does not declare")

    def settle_unbound(self, endpoint: Endpoint, message: Submission) -> None:
        """A submission for a lease this endpoint does not hold here.

        A resend of an already-settled result, or the outcome of a call whose
        renewal was refused -- the worker was answered `Stale` and the lease
        unbound while its component still ran, so its result, or its failure,
        arrives afterwards. Every such outcome is classified and answered from
        the store alone, whatever kind it is: a slow component that then fails
        is not a protocol violation. Only a LIVE lease this connection was
        never given, or an item the run does not hold, breaks the protocol.
        """

        if not endpoint.answers_submissions:
            return  # inline: a retired call, dropped at the endpoint already
        status = self._status(message.lease)
        if isinstance(status, Live):
            raise TransportFailure("an outcome for a live lease this connection was not given")
        self._answer(endpoint, message.lease, status)

    def answer_stale(
        self, endpoint: Endpoint, lease: Lease, reason: StaleReason
    ) -> None:
        self._answer(endpoint, lease, Stale(reason))

    def _status(self, lease: Lease) -> SubmissionStatus:
        try:
            return self._broker.submission_status(
                self._coordinator.run_id, lease, now=self._clock()
            )
        except InvalidWorkAppend:
            # A `Lease` names no run: this is how another run's lease arrives.
            raise TransportFailure("a lease for an item this run does not hold") from None

    def _answer(
        self, endpoint: Endpoint, lease: Lease, outcome: Accepted | Duplicate | Stale
    ) -> None:
        endpoint.send(Answer(item=lease.item, outcome=outcome))

    def _finish(self, binding: Binding, result: object) -> None:
        host = self._coordinator
        resolved = binding.resolved
        if isinstance(resolved, EvaluationInputs):
            assert isinstance(result, EvaluationResult)
            finish_evaluation(
                host, binding.lease, resolved.trial, resolved.artifact.id, result,
                correlation=binding.correlation, keepalive=binding.keepalive,
            )
        else:
            assert isinstance(result, EncodedProposal)
            finish_proposal(
                host, binding.lease, resolved.trial, result, resolved.parents,
                correlation=binding.correlation, keepalive=binding.keepalive,
            )


__all__ = ["Settler"]
