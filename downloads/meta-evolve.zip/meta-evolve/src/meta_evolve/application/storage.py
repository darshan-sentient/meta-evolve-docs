"""Paired artifact and event storage with an all-or-none ``commit``.

On length: well past the ~300 guideline, and deliberately not split. This
module is one public facade -- ``Storage`` -- whose constructors, capability
declarations and ``commit`` are a single surface a user reads top to bottom; the
declarations exist to constrain the commit, and separating them would put the
rule in one file and the thing it governs in another. The per-backend behaviour
that COULD be a second responsibility already lives in ``unit_of_work.py``, and
that is where growth belongs.
"""

from __future__ import annotations

import inspect
import os
import stat
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path

from meta_evolve.adapters.filesystem import (
    DurableArtifactStore,
    ReadOnlyDurableArtifactStore,
)
from meta_evolve.adapters.memory import InMemoryArtifactStore, InMemoryEventStore
from meta_evolve.adapters.sqlite import (
    ReadOnlySqliteEventStore,
    SqliteEventStore,
    open_read_only_store,
    open_store,
)
from meta_evolve.domain import Artifact, EventEnvelope, RunId
from meta_evolve.domain.work import DEFAULT_LEASE_SECONDS
from meta_evolve.ports.work_store import WorkBroker, WorkIntent, WorkTransactor
from meta_evolve.errors import CapabilityError, DurableStoreError
from meta_evolve.ports import ArtifactStore, EventStore, RunIndex, RunVersionReader

from .unit_of_work import (
    CommitStrategy,
    DurableUnitOfWork,
    InMemoryUnitOfWork,
    LocalOnlyUnitOfWork,
    ReadOnlyUnitOfWork,
)


def _accepts_event_store(commit) -> bool:
    """Whether ``commit`` declares an ``event_store`` parameter BY NAME.

    Stricter than `_accepts_work`: `work` is a request a strategy may absorb in
    `**kwargs`, while `bind_event_store` is a guarantee that writes reach the
    composed store. A `**kwargs` strategy may never read the key, so it is not
    an acceptance here; a strategy that forwards the store declares it.
    """

    try:
        parameters = inspect.signature(commit).parameters
    except (TypeError, ValueError):  # pragma: no cover - exotic callables
        # Fail closed, unlike `_accepts_work`: an unverifiable promise is not made.
        return False
    declared = parameters.get("event_store")
    # By name and by kind: `Storage.commit` passes the store as a keyword, so a
    # positional-only parameter of the right name would raise at the first commit.
    return declared is not None and declared.kind in (
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
        inspect.Parameter.KEYWORD_ONLY,
    )


def _accepts_work(commit) -> bool:
    """Whether ``work=`` will BIND on ``commit``, by keyword.

    It cannot tell whether the strategy then writes the rows: a successful
    :meth:`Storage.commit` means they were handed over, and durability is the
    strategy's own guarantee. Its purpose is a :class:`CapabilityError` naming
    the strategy instead of a bare ``TypeError`` from inside a commit.
    ``**kwargs`` counts, since forwarding wrappers are the ordinary shape at
    ``Storage.compose``; a positional-only or ``*work`` parameter does not.
    """

    try:
        parameters = inspect.signature(commit).parameters
    except (TypeError, ValueError):  # pragma: no cover - exotic callables
        # An unreadable signature gets the benefit of the doubt: a genuine
        # TypeError from the call beats an unsupported capability refusal.
        return True
    named = parameters.get("work")
    if named is not None and named.kind in (
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
        inspect.Parameter.KEYWORD_ONLY,
    ):
        return True
    return any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD
        for parameter in parameters.values()
    )


@dataclass(frozen=True, slots=True)
class Storage:
    """Paired artifact and event storage, plus one all-or-none ``commit``.

    ``is_durable`` and ``is_read_only`` are independent capabilities.
    Durability says committed facts live on durable media; read-only says this
    handle has no commit authority. A writable durable handle therefore reports
    ``True, False`` while :meth:`read_only` reports ``True, True``.
    """

    artifacts: ArtifactStore
    events: EventStore
    is_durable: bool = False
    is_read_only: bool = False
    _commit_strategy: CommitStrategy | None = field(
        default=None, repr=False, compare=False
    )
    _close: Callable[[], None] | None = field(
        default=None, repr=False, compare=False
    )
    #: Whether `commit` hands the strategy the composed event store. Set only by
    #: `compose(bind_event_store=True)`, which refuses a strategy that cannot
    #: accept it, so this is never True for a strategy that would ignore it.
    _bind_event_store: bool = field(default=False, repr=False, compare=False)
    # Capture provenance only; never a storage address or a resume capability.
    _display_path: str | None = field(default=None, kw_only=True, repr=False, compare=False)

    def __post_init__(self) -> None:
        for value, methods, name in (
            (self.artifacts, ("put", "get"), "artifact store"),
            (self.events, ("append", "read"), "event store"),
        ):
            if not all(callable(getattr(value, method, None)) for method in methods):
                raise TypeError(f"{name} does not satisfy its storage contract")
        if self._commit_strategy is None:
            object.__setattr__(
                self,
                "_commit_strategy",
                LocalOnlyUnitOfWork(self.artifacts, self.events),
            )
        # Durability is an explicit strategy capability, not a concrete-type
        # check. This keeps third-party atomic stores composable while preventing
        # a hand-built non-atomic pair from forging the public flag.
        strategy_is_durable = getattr(self._commit_strategy, "is_durable", None)
        if not isinstance(strategy_is_durable, bool):
            raise TypeError("commit strategy must declare a boolean is_durable")
        if self.is_durable != strategy_is_durable:
            if self.is_durable:
                raise ValueError(
                    "is_durable=True requires a durable commit strategy; "
                    "use Storage.durable(...) or Storage.compose(...)"
                )
            raise ValueError(
                "a durable commit strategy requires is_durable=True; "
                "use Storage.durable(...) or Storage.compose(...)"
            )
        # Existing third-party strategies predate this second axis. Absence is
        # deliberately writable: compose() explicitly supplies commit authority.
        strategy_is_read_only = getattr(
            self._commit_strategy, "is_read_only", False
        )
        if not isinstance(strategy_is_read_only, bool):
            raise TypeError("commit strategy is_read_only must be a boolean")
        if self.is_read_only != strategy_is_read_only:
            if self.is_read_only:
                raise ValueError(
                    "is_read_only=True requires a strategy that explicitly "
                    "declares read-only behavior; use Storage.read_only(...)"
                )
            raise ValueError(
                "a read-only commit strategy requires is_read_only=True; "
                "use Storage.read_only(...)"
            )

    @classmethod
    def in_memory(cls) -> Storage:
        artifacts = InMemoryArtifactStore()
        events = InMemoryEventStore()
        return cls(
            artifacts,
            events,
            is_durable=False,
            is_read_only=False,
            _commit_strategy=InMemoryUnitOfWork(artifacts, events),
        )

    @classmethod
    def durable(cls, path: Path | str) -> Storage:
        """Wire durable storage into ``path`` (created if missing): one
        SQLite connection (events + artifact occurrence rows) shared with a
        content-addressed filesystem blob store under ``path/artifacts``.
        """

        root = Path(path)
        root.mkdir(parents=True, exist_ok=True)
        connection = open_store(root / "meta-evolve.sqlite")
        artifacts = DurableArtifactStore(connection, root / "artifacts")
        events = SqliteEventStore(connection)
        return cls(
            artifacts,
            events,
            is_durable=True,
            is_read_only=False,
            _commit_strategy=DurableUnitOfWork(connection, artifacts, events),
            _close=connection.close,
            _display_path=str(root.absolute()),
        )

    @classmethod
    def read_only(cls, path: Path | str) -> Storage:
        """Open an existing durable directory with inspection authority only.

        The directory and current schema must already exist. This path never
        creates, stamps, migrates, or otherwise repairs durable state.
        """

        root = Path(path)
        try:
            root_mode = root.stat().st_mode
            if not stat.S_ISDIR(root_mode):
                raise NotADirectoryError(
                    f"durable store path is not a directory: {root}"
                )
            artifacts_root = root / "artifacts"
            artifacts_mode = artifacts_root.stat().st_mode
            if not stat.S_ISDIR(artifacts_mode):
                raise NotADirectoryError(
                    f"durable artifact path is not a directory: {artifacts_root}"
                )
            # Opening the directories proves traversal/listing access now, so
            # permission failures surface at Storage.read_only(), not halfway
            # through an inspection. scandir itself performs no mutation.
            with os.scandir(root), os.scandir(artifacts_root):
                pass
        except OSError as error:
            raise DurableStoreError(
                f"cannot access durable store read-only at {root}: {error}"
            ) from error

        connection = open_read_only_store(root / "meta-evolve.sqlite")
        artifacts = ReadOnlyDurableArtifactStore(connection, artifacts_root)
        events = ReadOnlySqliteEventStore(connection)
        return cls(
            artifacts,
            events,
            is_durable=True,
            is_read_only=True,
            _commit_strategy=ReadOnlyUnitOfWork(),
            _close=connection.close,
            _display_path=str(root.absolute()),
        )

    @classmethod
    def compose(
        cls,
        artifacts: ArtifactStore,
        events: EventStore,
        *,
        commit_strategy: CommitStrategy,
        close: Callable[[], None] | None = None,
        bind_event_store: bool = False,
    ) -> Storage:
        """Compose independently implemented stores behind one atomic commit.

        The strategy declares whether its commit survives process restart;
        callers cannot separately forge ``is_durable``. Composed storage is
        always writable: ``Storage`` cannot verify that third-party stores
        genuinely refuse writes, so read-only inspection handles come only
        from :meth:`read_only`, which pairs the declaration with stores built
        to fail closed.

        **``events`` reaches the read path only, unless the strategy binds it.**
        A commit strategy carries its own event-store reference, so by default a
        wrapped event store sees reads and not writes.

        ``bind_event_store=True`` hands the strategy ``event_store=`` on every
        commit. A strategy whose ``commit`` does not declare that parameter --
        including a ``**kwargs`` one -- is refused by name, and one that answers
        ``can_bind`` may refuse the store for its own reason: the durable
        strategy needs ``_append_in_txn`` on its own connection, the in-memory
        one the ``_snapshot``/``_validate``/``_install`` triple, the local one
        only the port, and read-only storage binds nothing.

        A bound store is part of the commit. The in-memory strategy installs
        artifacts, then the stream, and on a stream failure restores the stream
        through the bound store's ``_install``, re-reads it, and only then rolls
        artifacts back. If the re-read stream is not the snapshot, whether or
        not the restore raised, the commit raises a ``BaseExceptionGroup``,
        keeps the artifacts so no event references a missing one, and the
        storage refuses every later commit.

        For example:

            storage = Storage.compose(
                base.artifacts, AuditedEvents(base.events),
                commit_strategy=base._commit_strategy, bind_event_store=True,
            )
        """

        durable = getattr(commit_strategy, "is_durable", None)
        if not isinstance(durable, bool):
            raise TypeError("commit strategy must declare a boolean is_durable")
        if bind_event_store and not _accepts_event_store(commit_strategy.commit):
            raise CapabilityError(
                f"{type(commit_strategy).__name__} cannot bind the composed "
                "event store: its commit does not declare an `event_store` "
                "parameter (or its signature could not be read), so its writes "
                "would go to the store it captured rather than the one "
                "composed here. A `**kwargs` strategy is not accepted: it "
                "satisfies the signature without promising to forward the store"
            )
        if bind_event_store:
            # ... and then asked of the strategy, which alone knows what it
            # writes through. A strategy that does not answer keeps the weaker
            # guarantee its declaration made.
            answer = getattr(commit_strategy, "can_bind", None)
            refusal = answer(events) if callable(answer) else None
            if refusal is not None:
                raise CapabilityError(
                    "the composed event store cannot receive "
                    f"{type(commit_strategy).__name__}'s writes: {refusal}. "
                    "Binding it would send every read to the wrapper and every "
                    "write past it -- silently. Fix the store, or compose "
                    "without `bind_event_store`"
                )
        return cls(
            artifacts,
            events,
            is_durable=durable,
            is_read_only=False,
            _commit_strategy=commit_strategy,
            _close=close,
            _bind_event_store=bind_event_store,
        )

    def work_broker(
        self, *, lease_seconds: int = DEFAULT_LEASE_SECONDS
    ) -> WorkBroker:
        """The broker over this store's work table.

        Only a store whose commit strategy DECLARES the capability has one.
        Work rows live in transactional tables beside the event stream, and a
        transition has to be atomic with the logical batch that authorizes it
        -- which needs a real transaction, not a copy-on-write swap.

        Checked with `isinstance` against a declared Protocol, as `runs()` and
        `run_version()` check theirs. `is_durable` is not the question: `ReadOnlyUnitOfWork` declares itself
        durable and has no work table, so the two capabilities are independent.
        """

        strategy = self._commit_strategy
        if not isinstance(strategy, WorkTransactor):
            raise CapabilityError(
                f"{type(strategy).__name__} has no work table: distributed "
                "runs require storage whose commit strategy declares the "
                "WorkTransactor capability, such as Storage.durable(...)"
            )
        return strategy.work_broker(lease_seconds=lease_seconds)

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
        work: Iterable[WorkIntent] = (),
    ) -> int:
        """Commit ``events``, ``occurrences`` and ``work`` as one all-or-none unit.

        ``EventStreamConflict`` on a stale ``expected_version`` propagates
        unchanged, and nothing is written. See ``unit_of_work.py`` for the
        per-backend guarantee (durable: one SQLite transaction; in-memory:
        a locked copy-on-write swap; hand-built pair: local-only fallback).

        ``work`` defaults to empty, and an empty ``work`` is the call this
        method has always made -- same arguments, same strategy method -- so a
        strategy supplied through :meth:`compose` before work rows existed keeps
        working untouched. Passing a non-empty ``work`` to a strategy that does
        not declare the parameter is a ``CapabilityError`` naming the strategy,
        decided from its signature and never from a raised exception.

        Declaring the parameter and committing the rows are separate: only
        ``DurableUnitOfWork`` writes them, and the other shipped strategies
        declare it to refuse with their own ``CapabilityError``.
        """

        rows = tuple(work)
        if not rows:
            # The original call, so a strategy predating work rows keeps working.
            if self._bind_event_store:
                return self._commit_strategy.commit(
                    run_id,
                    expected_version,
                    events=events,
                    occurrences=occurrences,
                    event_store=self.events,
                )
            return self._commit_strategy.commit(
                run_id, expected_version, events=events, occurrences=occurrences
            )
        if not _accepts_work(self._commit_strategy.commit):
            # A strategy predating the parameter, handed real work: a missing
            # capability, decided from the signature rather than a caught
            # TypeError that could come from inside a commit.
            raise CapabilityError(
                f"{type(self._commit_strategy).__name__} cannot commit work "
                "rows: it does not accept them; distributed runs require "
                "Storage.durable(...)"
            )
        extra = {"event_store": self.events} if self._bind_event_store else {}
        return self._commit_strategy.commit(
            run_id,
            expected_version,
            events=events,
            occurrences=occurrences,
            work=rows,
            **extra,
        )

    def runs(self) -> tuple[RunId, ...]:
        """Every run this storage holds events for, sorted by id.

        Identities, not ``Run`` objects: opening a run validates and replays
        its whole stream, and detail is already ``Run.summary()``'s job. A
        listing exists so those queries stay reachable once the ids have
        scrolled out of a terminal, so it returns exactly what reopening one
        needs. The order is lexicographic by id and identical across
        backends; run ids are content-derived, so it is not chronological.

        Enumeration is an optional store capability (``ports.RunIndex``),
        declared by implementing it. A paired event store that does not is
        refused explicitly here — never reported as an empty store, which
        would be a silent capability downgrade.
        """

        if not isinstance(self.events, RunIndex):
            raise CapabilityError(
                f"{type(self.events).__name__} cannot enumerate runs: it does "
                "not implement the optional RunIndex capability"
            )
        return self.events.runs()

    def run_version(self, run_id: RunId) -> int:
        """Maximum committed sequence, or ``0`` for an unseen run id.

        This optional high-water-mark query is intended for polling. Opening a
        required run remains authoritative and raises ``RunNotFound`` when no
        events exist.
        """

        if not isinstance(run_id, RunId):
            raise TypeError("run version id must be a RunId")
        if not isinstance(self.events, RunVersionReader):
            raise CapabilityError(
                f"{type(self.events).__name__} cannot read run versions: it "
                "does not implement the optional RunVersionReader capability"
            )
        return self.events.run_version(run_id)

    def close(self) -> None:
        if self._close is not None:
            self._close()

    def __enter__(self) -> Storage:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


__all__ = ["Storage"]
