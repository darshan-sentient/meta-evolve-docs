"""Paired artifact and event storage with an all-or-none ``commit``."""

from __future__ import annotations

import os
import stat
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path

from meta_evolve.adapters.filesystem import (
    DurableArtifactStore,
    ReadOnlyDurableArtifactStore,
)
from meta_evolve.adapters.memory import InMemoryArtifactStore, InMemoryEventStore
from meta_evolve.adapters.sqlite import (
    ReadOnlySqliteEventStore,
    SqliteEventStore,
    open_read_only_store,
    open_store,
)
from meta_evolve.domain import Artifact, EventEnvelope, RunId
from meta_evolve.errors import CapabilityError, DurableStoreError
from meta_evolve.ports import ArtifactStore, EventStore, RunIndex, RunVersionReader

from .unit_of_work import (
    CommitStrategy,
    DurableUnitOfWork,
    InMemoryUnitOfWork,
    LocalOnlyUnitOfWork,
    ReadOnlyUnitOfWork,
)


@dataclass(frozen=True, slots=True)
class Storage:
    """Paired artifact and event storage, plus one all-or-none ``commit``.

    ``is_durable`` and ``is_read_only`` are independent capabilities.
    Durability says committed facts live on durable media; read-only says this
    handle has no commit authority. A writable durable handle therefore reports
    ``True, False`` while :meth:`read_only` reports ``True, True``.
    """

    artifacts: ArtifactStore
    events: EventStore
    is_durable: bool = False
    is_read_only: bool = False
    _commit_strategy: CommitStrategy | None = field(
        default=None, repr=False, compare=False
    )
    _close: Callable[[], None] | None = field(
        default=None, repr=False, compare=False
    )

    def __post_init__(self) -> None:
        for value, methods, name in (
            (self.artifacts, ("put", "get"), "artifact store"),
            (self.events, ("append", "read"), "event store"),
        ):
            if not all(callable(getattr(value, method, None)) for method in methods):
                raise TypeError(f"{name} does not satisfy its storage contract")
        if self._commit_strategy is None:
            object.__setattr__(
                self,
                "_commit_strategy",
                LocalOnlyUnitOfWork(self.artifacts, self.events),
            )
        # Durability is an explicit strategy capability, not a concrete-type
        # check. This keeps third-party atomic stores composable while preventing
        # a hand-built non-atomic pair from forging the public flag.
        strategy_is_durable = getattr(self._commit_strategy, "is_durable", None)
        if not isinstance(strategy_is_durable, bool):
            raise TypeError("commit strategy must declare a boolean is_durable")
        if self.is_durable != strategy_is_durable:
            if self.is_durable:
                raise ValueError(
                    "is_durable=True requires a durable commit strategy; "
                    "use Storage.durable(...) or Storage.compose(...)"
                )
            raise ValueError(
                "a durable commit strategy requires is_durable=True; "
                "use Storage.durable(...) or Storage.compose(...)"
            )
        # Existing third-party strategies predate this second axis. Absence is
        # deliberately writable: compose() explicitly supplies commit authority.
        strategy_is_read_only = getattr(
            self._commit_strategy, "is_read_only", False
        )
        if not isinstance(strategy_is_read_only, bool):
            raise TypeError("commit strategy is_read_only must be a boolean")
        if self.is_read_only != strategy_is_read_only:
            if self.is_read_only:
                raise ValueError(
                    "is_read_only=True requires a strategy that explicitly "
                    "declares read-only behavior; use Storage.read_only(...)"
                )
            raise ValueError(
                "a read-only commit strategy requires is_read_only=True; "
                "use Storage.read_only(...)"
            )

    @classmethod
    def in_memory(cls) -> Storage:
        artifacts = InMemoryArtifactStore()
        events = InMemoryEventStore()
        return cls(
            artifacts,
            events,
            is_durable=False,
            is_read_only=False,
            _commit_strategy=InMemoryUnitOfWork(artifacts, events),
        )

    @classmethod
    def durable(cls, path: Path | str) -> Storage:
        """Wire durable storage into ``path`` (created if missing): one
        SQLite connection (events + artifact occurrence rows) shared with a
        content-addressed filesystem blob store under ``path/artifacts``.
        """

        root = Path(path)
        root.mkdir(parents=True, exist_ok=True)
        connection = open_store(root / "meta-evolve.sqlite")
        artifacts = DurableArtifactStore(connection, root / "artifacts")
        events = SqliteEventStore(connection)
        return cls(
            artifacts,
            events,
            is_durable=True,
            is_read_only=False,
            _commit_strategy=DurableUnitOfWork(connection, artifacts, events),
            _close=connection.close,
        )

    @classmethod
    def read_only(cls, path: Path | str) -> Storage:
        """Open an existing durable directory with inspection authority only.

        The directory and current schema must already exist. This path never
        creates, stamps, migrates, or otherwise repairs durable state.
        """

        root = Path(path)
        try:
            root_mode = root.stat().st_mode
            if not stat.S_ISDIR(root_mode):
                raise NotADirectoryError(
                    f"durable store path is not a directory: {root}"
                )
            artifacts_root = root / "artifacts"
            artifacts_mode = artifacts_root.stat().st_mode
            if not stat.S_ISDIR(artifacts_mode):
                raise NotADirectoryError(
                    f"durable artifact path is not a directory: {artifacts_root}"
                )
            # Opening the directories proves traversal/listing access now, so
            # permission failures surface at Storage.read_only(), not halfway
            # through an inspection. scandir itself performs no mutation.
            with os.scandir(root), os.scandir(artifacts_root):
                pass
        except OSError as error:
            raise DurableStoreError(
                f"cannot access durable store read-only at {root}: {error}"
            ) from error

        connection = open_read_only_store(root / "meta-evolve.sqlite")
        artifacts = ReadOnlyDurableArtifactStore(connection, artifacts_root)
        events = ReadOnlySqliteEventStore(connection)
        return cls(
            artifacts,
            events,
            is_durable=True,
            is_read_only=True,
            _commit_strategy=ReadOnlyUnitOfWork(),
            _close=connection.close,
        )

    @classmethod
    def compose(
        cls,
        artifacts: ArtifactStore,
        events: EventStore,
        *,
        commit_strategy: CommitStrategy,
        close: Callable[[], None] | None = None,
    ) -> Storage:
        """Compose independently implemented stores behind one atomic commit.

        The strategy declares whether its commit survives process restart;
        callers cannot separately forge ``is_durable``. Composed storage is
        always writable: ``Storage`` cannot verify that third-party stores
        genuinely refuse writes, so read-only inspection handles come only
        from :meth:`read_only`, which pairs the declaration with stores built
        to fail closed.
        """

        durable = getattr(commit_strategy, "is_durable", None)
        if not isinstance(durable, bool):
            raise TypeError("commit strategy must declare a boolean is_durable")
        return cls(
            artifacts,
            events,
            is_durable=durable,
            is_read_only=False,
            _commit_strategy=commit_strategy,
            _close=close,
        )

    def commit(
        self,
        run_id: RunId,
        expected_version: int,
        *,
        events: Iterable[EventEnvelope],
        occurrences: Iterable[Artifact],
    ) -> int:
        """Commit ``events`` and ``occurrences`` as one all-or-none unit.

        ``EventStreamConflict`` on a stale ``expected_version`` propagates
        unchanged, and nothing is written. See ``unit_of_work.py`` for the
        per-backend guarantee (durable: one SQLite transaction; in-memory:
        a locked copy-on-write swap; hand-built pair: local-only fallback).
        """

        return self._commit_strategy.commit(
            run_id, expected_version, events=events, occurrences=occurrences
        )

    def runs(self) -> tuple[RunId, ...]:
        """Every run this storage holds events for, sorted by id.

        Identities, not ``Run`` objects: opening a run validates and replays
        its whole stream, and detail is already ``Run.summary()``'s job. A
        listing exists so those queries stay reachable once the ids have
        scrolled out of a terminal, so it returns exactly what reopening one
        needs. The order is lexicographic by id and identical across
        backends; run ids are content-derived, so it is not chronological.

        Enumeration is an optional store capability (``ports.RunIndex``),
        declared by implementing it. A paired event store that does not is
        refused explicitly here — never reported as an empty store, which
        would be a silent capability downgrade.
        """

        if not isinstance(self.events, RunIndex):
            raise CapabilityError(
                f"{type(self.events).__name__} cannot enumerate runs: it does "
                "not implement the optional RunIndex capability"
            )
        return self.events.runs()

    def run_version(self, run_id: RunId) -> int:
        """Maximum committed sequence, or ``0`` for an unseen run id.

        This optional high-water-mark query is intended for polling. Opening a
        required run remains authoritative and raises ``RunNotFound`` when no
        events exist.
        """

        if not isinstance(run_id, RunId):
            raise TypeError("run version id must be a RunId")
        if not isinstance(self.events, RunVersionReader):
            raise CapabilityError(
                f"{type(self.events).__name__} cannot read run versions: it "
                "does not implement the optional RunVersionReader capability"
            )
        return self.events.run_version(run_id)

    def close(self) -> None:
        if self._close is not None:
            self._close()

    def __enter__(self) -> Storage:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


__all__ = ["Storage"]
