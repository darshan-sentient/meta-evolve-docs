"""Pure proposal-derivation authority shared by execution and replay."""

from __future__ import annotations

from meta_evolve.domain import (
    ExperienceComparison,
    ExperienceObservation,
    ExperienceOperationSucceeded,
    ExperienceRef,
    SourceDiff,
    SourcePathListing,
    SourceRead,
    TrialId,
    TrialSpec,
)

from .experience_contract import interleave_records
from .run_projection import RunProjection


def result_references(result: object) -> tuple[ExperienceRef, ...]:
    """Return one result's references in canonical first-observed order."""

    if isinstance(result, ExperienceObservation):
        records = result.records
    elif isinstance(result, ExperienceComparison):
        # Comparison records enter in their committed interleaved rendering
        # order, so the ledger matches the order the proposer observed.
        records = tuple(
            record
            for _, record in interleave_records(
                result.left_records, result.right_records
            )
        )
    elif isinstance(result, SourceDiff):
        return (result.older_artifact_ref, result.newer_artifact_ref)
    elif isinstance(result, (SourcePathListing, SourceRead)):
        return (result.artifact_ref,)
    else:
        return ()
    return result.references + tuple(record.ref for record in records)


def observation_ledger(
    state: RunProjection, trial_id: TrialId
) -> tuple[ExperienceRef, ...]:
    """Return observations in their canonical first-committed order."""

    observed: list[ExperienceRef] = []
    seen: set[ExperienceRef] = set()

    def add(references: tuple[ExperienceRef, ...]) -> None:
        for reference in references:
            if reference not in seen:
                seen.add(reference)
                observed.append(reference)

    selected = state.selection_for(trial_id)
    if selected is not None:
        add(selected.bundle.references)
    for _, resolution in state.operations_for(trial_id):
        if isinstance(resolution, ExperienceOperationSucceeded):
            add(result_references(resolution.result))
    return tuple(observed)


def derivation_violation(
    state: RunProjection,
    trial_id: TrialId,
    derived_from: tuple[ExperienceRef, ...],
) -> str | None:
    """Validate an ordered unique subsequence of strictly prior observations."""

    if state.bootstrap is not None and state.bootstrap.trial.id == trial_id:
        return (
            "bootstrap proposal cannot declare derivation"
            if derived_from
            else None
        )
    decision = next(
        (
            item
            for item in state.decisions
            if item.trial_id == trial_id and isinstance(item.decision, TrialSpec)
        ),
        None,
    )
    if decision is None:
        return "proposal derivation has no trial authority"

    sources = {record.ref: record for record in state.experience_records}
    for reference in derived_from:
        source = sources.get(reference)
        if (
            reference.run_id != state.run_id
            or source is None
            or source.logical_step >= decision.logical_step
        ):
            return "proposal derivation contains inaccessible experience"

    ledger = observation_ledger(state, trial_id)
    cursor = 0
    for reference in derived_from:
        try:
            cursor = ledger.index(reference, cursor) + 1
        except ValueError:
            return "proposal derivation is not an ordered observation subsequence"
    return None


__all__ = [
    "derivation_violation",
    "observation_ledger",
    "result_references",
]
