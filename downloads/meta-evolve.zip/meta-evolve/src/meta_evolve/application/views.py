"""Shared construction of immutable public views over one replayed run."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from meta_evolve.domain import (
    ArtifactId,
    EvidenceId,
    ExperienceRef,
    Failure,
    FrozenMap,
    TrialId,
    Usage,
    rank_evaluations,
)
from meta_evolve.errors import NoSuccessfulEvaluation, RunError
from meta_evolve.views import ArtifactView

from .codecs import CodecIndex
from .projections import RunProjection
from .storage import Storage


@dataclass(frozen=True, slots=True)
class EvidenceView:
    """One committed evidence item, with its declared kind, data, and optional URI."""

    kind: str
    data: FrozenMap
    uri: str | None
    _run_token: object = field(repr=False, compare=False)


_TRIAL_STATES = ("evaluated", "evaluation_failed", "trial_failed", "unevaluated")


@dataclass(frozen=True, slots=True)
class TrialView:
    """One committed attempt, including the seed and unsuccessful attempts.

    ``state`` distinguishes evaluated, evaluation_failed, trial_failed, and
    unevaluated attempts. ``artifact`` may be absent after a proposal failure;
    ``metrics`` stays empty when measurement did not succeed. Evidence and
    usage remain readable independently of rankability.
    """

    id: TrialId
    logical_step: int
    state: Literal["evaluated", "evaluation_failed", "trial_failed", "unevaluated"]
    artifact: ArtifactView | None
    parent_ids: tuple[ArtifactId, ...]
    hypothesis: str | None
    predicted_outcomes: FrozenMap
    metadata: FrozenMap
    metrics: FrozenMap
    uncertainty: FrozenMap
    evidence: tuple[EvidenceView, ...]
    usage: Usage
    failure: Failure | None
    derived_from: tuple[ExperienceRef, ...]
    _run_token: object = field(repr=False, compare=False)

    def __post_init__(self) -> None:
        if self.state not in _TRIAL_STATES:
            choices = ", ".join(repr(state) for state in _TRIAL_STATES)
            raise ValueError(f"trial state must be one of {choices}")


class ViewBuilder:
    """Build and memoize public views from one authoritative projection."""

    __slots__ = (
        "projection",
        "_storage",
        "_codecs",
        "_run_token",
        "_artifacts",
        "_evidence",
        "_trials",
    )

    def __init__(
        self,
        projection: RunProjection,
        storage: Storage,
        codecs: CodecIndex,
        run_token: object,
    ) -> None:
        self.projection = projection
        self._storage = storage
        self._codecs = codecs
        self._run_token = run_token
        self._artifacts: dict[ArtifactId, ArtifactView] = {}
        self._evidence: dict[EvidenceId, EvidenceView] = {}
        self._trials: dict[TrialId, TrialView] = {}

    def artifact(self, artifact_id: ArtifactId) -> ArtifactView:
        cached = self._artifacts.get(artifact_id)
        if cached is not None:
            return cached
        durable = self._storage.artifacts.get(artifact_id)
        assert durable.digest is not None
        view = ArtifactView(
            id=durable.id,
            value=self._codecs.decode(durable),
            kind=durable.kind,
            representation=durable.representation,
            digest=durable.digest.value,
            parent_ids=durable.parent_ids,
            _payload=durable.payload,
            _run_token=self._run_token,
        )
        self._artifacts[artifact_id] = view
        return view

    def evidence(self, evidence_id: EvidenceId) -> EvidenceView:
        cached = self._evidence.get(evidence_id)
        if cached is not None:
            return cached
        durable = self.projection.evidence_by_id(evidence_id)
        if durable is None:
            raise RunError("trial references missing committed evidence")
        view = EvidenceView(
            kind=durable.kind,
            data=durable.data,
            uri=durable.uri,
            _run_token=self._run_token,
        )
        self._evidence[evidence_id] = view
        return view

    def trial(self, trial_id: TrialId) -> TrialView:
        cached = self._trials.get(trial_id)
        if cached is not None:
            return cached
        completed = self.projection.completed_trial(trial_id)
        proposal = self.projection.proposal_for(trial_id)
        if completed is None or proposal is None:
            raise RunError("trial is missing committed records")
        recorded = self.projection.evaluation_for(trial_id)
        evaluation = recorded.evaluation if recorded is not None else None
        evidence_ids = completed.outcome.evidence_ids + (
            evaluation.evidence_ids if evaluation is not None else ()
        )
        if completed.outcome.failure is not None:
            state = "trial_failed"
        elif evaluation is None:
            state = "unevaluated"
        elif evaluation.failure is not None:
            state = "evaluation_failed"
        else:
            state = "evaluated"
        view = TrialView(
            id=trial_id,
            logical_step=completed.trial.logical_step,
            state=state,
            artifact=(
                self.artifact(completed.outcome.artifact_ids[0])
                if completed.outcome.artifact_ids
                else None
            ),
            parent_ids=proposal.parent_ids,
            hypothesis=proposal.hypothesis,
            predicted_outcomes=proposal.predicted_outcomes,
            metadata=proposal.metadata,
            metrics=evaluation.metrics if evaluation is not None else FrozenMap(),
            uncertainty=(
                evaluation.uncertainty if evaluation is not None else FrozenMap()
            ),
            evidence=tuple(self.evidence(item) for item in evidence_ids),
            usage=completed.outcome.usage
            + (evaluation.usage if evaluation is not None else Usage()),
            failure=completed.outcome.failure
            or (evaluation.failure if evaluation is not None else None),
            derived_from=proposal.derived_from,
            _run_token=self._run_token,
        )
        self._trials[trial_id] = view
        return view

    def best_evaluation(self, objective_name: str | None = None):
        start = self.projection.start
        if start is None:
            raise RunError("run has not started")
        objective = start.task.objectives[0]
        if objective_name is not None:
            objective = next(
                (item for item in start.task.objectives if item.metric == objective_name),
                None,
            )
            if objective is None:
                raise ValueError(f"unknown objective: {objective_name!r}")
        ranked = rank_evaluations(
            objective,
            (item.evaluation for item in self.projection.completed_evaluations),
        )
        if not ranked:
            raise NoSuccessfulEvaluation(
                "run has no successful evaluations; inspect trials() or "
                "inspect() for typed failures"
            )
        return ranked[0]

    def trials(self) -> tuple[TrialView, ...]:
        return tuple(self.trial(item.trial.id) for item in self.projection.completed_trials)

    def artifacts(self) -> tuple[ArtifactView, ...]:
        return tuple(self.artifact(item) for item in self.projection.artifact_ids)

    def all_evidence(self) -> tuple[EvidenceView, ...]:
        return tuple(self.evidence(item.evidence.id) for item in self.projection.evidence)

    def lineage(self, artifact_id: ArtifactId) -> tuple[TrialView, ...]:
        ordered: list[TrialId] = []
        visited: set[ArtifactId] = set()

        def visit(current: ArtifactId) -> None:
            if current in visited:
                return
            durable = self._storage.artifacts.get(current)
            for parent_id in durable.parent_ids:
                visit(parent_id)
            visited.add(current)
            completed = next(
                (
                    item
                    for item in self.projection.completed_trials
                    if current in item.outcome.artifact_ids
                ),
                None,
            )
            if completed is None:
                raise RunError("artifact has no committed producing trial")
            ordered.append(completed.trial.id)

        visit(artifact_id)
        return tuple(self.trial(item) for item in ordered)


__all__ = ["ArtifactView", "EvidenceView", "TrialView", "ViewBuilder"]
