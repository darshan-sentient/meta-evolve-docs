"""Compatibility completion wrapper over resumable Session execution."""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.registry import Registry

from .results import Run
from .session import Session
from .storage import Storage


def resume(run_id: RunId, *, storage: Storage, registry: Registry) -> Run:
    """Complete unfinished work in a validated durable-local session.

    Recorded component identities and the recovery frontier are checked before
    execution. An already stopped run performs no more work. Replay reads
    committed facts; resume may execute components for unfinished work.

    :param run_id: The retained run to continue.
    :param storage: Writable durable storage containing that run.
    :param registry: Components needed to reconstruct its declarations.
    :returns: The stable Run associated with the completed session.
    """

    with Session.resume(run_id, storage=storage, registry=registry) as session:
        for _decision in session:
            pass
    return session.run


__all__ = ["resume"]
