"""Batched incumbent sampling: ``k`` children, then the global incumbent again."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    ArtifactId,
    Budget,
    ComponentRef,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    TrialSpec,
    rank_evaluations,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import SearchState

from ._incumbent import lower_incumbent_decision


def _incumbent_after_successor_trials(
    state: SearchState, successor_count: int
) -> ArtifactId | None:
    """Return the incumbent after ``successor_count`` successor trials.

    A successor is identified by ``outcome.usage.trials > 0`` rather than by
    ``trial.logical_step > 0`` on purpose. The cohort boundary in
    ``_cohort_parent`` is measured against ``state.usage.trials``, which is
    the sum of exactly that field, so counting successors the same way makes
    the prefix length and the cohort origin the same unit by construction and
    cohorts cannot drift apart. The two discriminators agree today — the
    bootstrap outcome carries no trial usage and every successor is completed
    with ``action_usage(trials=1, ...)``, failures included — but only the
    usage-based one stays aligned with the counter it is compared against.

    Args:
        state: Projected search state at the current decision.
        successor_count: Number of successor trials whose outcomes may
            influence the incumbent. Failed trials count; later trials do
            not.

    Returns:
        The best successful artifact id in that prefix, or ``None`` when no
        successful evaluation exists.
    """

    evaluations = []
    seen_successors = 0
    by_trial = {
        item.evaluation.trial_id: item.evaluation
        for item in state.completed_evaluations
    }
    for completed in state.completed_trials:
        is_successor = completed.outcome.usage.trials > 0
        if is_successor and seen_successors >= successor_count:
            break
        if is_successor:
            seen_successors += 1
        evaluation = by_trial.get(completed.trial.id)
        if evaluation is not None:
            evaluations.append(evaluation)
    ranked = rank_evaluations(state.task.objectives[0], evaluations)
    return ranked[0].artifact_id if ranked else None


def _cohort_parent(state: SearchState, k: int) -> ArtifactId:
    """Freeze the incumbent that started the current cohort of ``k`` trials."""

    seed_id = state.require_start().seed_artifact_id
    origin = (state.usage.trials // k) * k
    return _incumbent_after_successor_trials(state, origin) or seed_id


@dataclass(frozen=True, slots=True, init=False)
class BestOfK:
    """Sample ``k`` successors from the incumbent, then reselect it.

    Any positive ``k`` is accepted. A ``k`` at or above ``max_trials`` simply
    means the run never completes a cohort, so the parent stays the seed for
    every trial — the same star ``BestOfN`` produces.
    """

    k: int
    max_trials: int
    policy: PolicyRef = PolicyRef("best-of-k", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(self, k: int = 3, max_trials: int = 20) -> None:
        if isinstance(k, bool) or not isinstance(k, int):
            raise TypeError("best-of-k k must be an integer")
        if k < 1:
            raise ValueError("best-of-k k must be positive")
        if isinstance(max_trials, bool) or not isinstance(max_trials, int):
            raise TypeError("best-of-k max_trials must be an integer")
        if max_trials < 0:
            raise ValueError("best-of-k max_trials must be non-negative")
        object.__setattr__(self, "k", k)
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "policy", PolicyRef("best-of-k", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {"k": self.k, "max_trials": self.max_trials}

    @property
    def identity_key(self) -> str:
        return f"best-of-k:k={self.k}:max_trials={self.max_trials}"

    def bind(self, proposer: ComponentRef, budget: Budget) -> BestOfK:
        """Authorize one proposer and derive the unit trial allocation."""

        if self.bound:
            raise ValueError("best-of-k search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError("best-of-k proposer must be a proposer component reference")
        if not isinstance(budget, Budget):
            raise TypeError("best-of-k budget must be a Budget")
        result = BestOfK(self.k, self.max_trials)
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        return lower_incumbent_decision(
            state,
            policy=self.policy,
            max_trials=self.max_trials,
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget,
            unbound_message=(
                "BestOfK must be passed to meta_evolve.run before next() is called"
            ),
            decide_parent=lambda current: _cohort_parent(current, self.k),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            seed_id = state.require_start().seed_artifact_id
            role = "seed" if decision.parent_ids[0] == seed_id else "incumbent"
            slot = state.usage.trials % self.k + 1
            return DecisionDescription(
                f"expand {role} (cohort {slot}/{self.k})",
                ("trial",),
            )
        return DecisionDescription(
            f"stop best-of-k search: {humanize_reason(decision.reason)}"
        )


__all__ = ["BestOfK"]
