"""The steady-state population preset with explicit archive membership."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    ArchiveUpdate,
    ArtifactId,
    Budget,
    ComponentRef,
    Evaluation,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
    rank_evaluations,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import PolicyMismatch, SearchState
from meta_evolve.errors import UnboundSearchProgram

from ._trial_budget import declared_trial_limit, resolve_trial_limit


def _sample_distinct(seed: int, population: int, count: int) -> tuple[int, ...]:
    """Draw ``count`` distinct indices from the seed integer alone.

    The draw depends only on integer arithmetic so recorded decisions
    reproduce on any Python version, unlike ``random.Random.sample``.
    """

    remaining = list(range(population))
    chosen: list[int] = []
    for _ in range(count):
        seed, position = divmod(seed, len(remaining))
        chosen.append(remaining.pop(position))
    return tuple(chosen)


@dataclass(frozen=True, slots=True, init=False)
class Population:
    """Retain the top ``size`` candidates and expand tournament winners.

    ``max_trials=None`` opts into inheriting the limit from the effective
    finite ``Budget.trials``. Resolution happens once during binding, and the
    resolved integer is what reaches ``SearchSpec``, the run identity, and the
    durable record, so replay and reconstruction never re-inherit. Binding with
    ``None`` against an unbounded trial budget raises
    :class:`~meta_evolve.errors.BudgetUnavailable`. An explicit integer may stop
    the search early but never widens the run budget.
    """

    size: int
    tournament_size: int
    max_trials: int | None
    policy: PolicyRef = PolicyRef("population", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(
        self, size: int = 3, tournament_size: int = 2, max_trials: int | None = 20
    ) -> None:
        for name, value in (("size", size), ("tournament_size", tournament_size)):
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(f"population {name} must be an integer")
            if value < 1:
                raise ValueError(f"population {name} must be positive")
        if tournament_size > size:
            raise ValueError("population tournament_size cannot exceed size")
        max_trials = declared_trial_limit(max_trials, "population")
        object.__setattr__(self, "size", size)
        object.__setattr__(self, "tournament_size", tournament_size)
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "policy", PolicyRef("population", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {
            "max_trials": self.max_trials,
            "size": self.size,
            "tournament_size": self.tournament_size,
        }

    @property
    def identity_key(self) -> str:
        return (
            f"population:size={self.size}"
            f":tournament_size={self.tournament_size}"
            f":max_trials={self.max_trials}"
        )

    def bind(self, proposer: ComponentRef, budget: Budget) -> Population:
        """Authorize one proposer and derive the unit trial allocation."""

        if self.bound:
            raise ValueError("population search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError(
                "population proposer must be a proposer component reference"
            )
        if not isinstance(budget, Budget):
            raise TypeError("population budget must be a Budget")
        result = Population(
            self.size,
            self.tournament_size,
            resolve_trial_limit(self.max_trials, budget, "population"),
        )
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        if not self.bound:
            raise UnboundSearchProgram(
                "Population must be passed to meta_evolve.run before next() is called"
            )
        start = state.require_start()
        if start.search.policy != self.policy:
            raise PolicyMismatch(self.policy, start.search.policy)
        if state.stop is not None:
            return state.stop
        pending = self._pending_evaluation(state)
        if pending is not None:
            return self._archive_update(state, pending)
        if state.objective_satisfied:
            return Stop(reason="objective_satisfied")
        if state.usage.trials >= self.max_trials:
            return Stop(reason="trial_limit_reached")
        members = state.archive_members
        if not members:
            return Stop(reason="population_empty")
        if state.budget_exhausted:
            return Stop(reason=state.budget_stop_reason)
        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(self._tournament_parent(state, members),),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.randomness.seed("trial"),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            members = state.archive_members
            sampled = self._tournament_indices(state, members)
            rank = members.index(decision.parent_ids[0]) + 1
            return DecisionDescription(
                f"expand tournament winner at population rank {rank} "
                f"from {len(sampled)} sampled members",
                ("selection", "trial"),
            )
        if isinstance(decision, ArchiveUpdate):
            return DecisionDescription(self._archive_rationale(state, decision))
        return DecisionDescription(
            f"stop population search: {humanize_reason(decision.reason)}"
        )

    def _pending_evaluation(self, state: SearchState) -> Evaluation | None:
        processed = {update.evaluation_id for update in state.archive_updates}
        for completed in state.completed_evaluations:
            if completed.evaluation.id not in processed:
                return completed.evaluation
        return None

    def _archive_update(
        self, state: SearchState, evaluation: Evaluation
    ) -> ArchiveUpdate:
        members = state.archive_members
        if evaluation.failure is not None:
            return ArchiveUpdate(
                evaluation_id=evaluation.id,
                candidate_id=evaluation.artifact_id,
                admitted=False,
                member_ids=members,
            )
        retained = self._ranked(state, members + (evaluation.artifact_id,))
        retained = retained[: self.size]
        if evaluation.artifact_id not in retained:
            return ArchiveUpdate(
                evaluation_id=evaluation.id,
                candidate_id=evaluation.artifact_id,
                admitted=False,
                member_ids=members,
            )
        evicted = next(
            (member for member in members if member not in retained), None
        )
        return ArchiveUpdate(
            evaluation_id=evaluation.id,
            candidate_id=evaluation.artifact_id,
            admitted=True,
            evicted_artifact_id=evicted,
            member_ids=retained,
        )

    def _ranked(
        self, state: SearchState, artifact_ids: tuple[ArtifactId, ...]
    ) -> tuple[ArtifactId, ...]:
        wanted = set(artifact_ids)
        ranked = rank_evaluations(
            state.task.objectives[0],
            (
                item.evaluation
                for item in state.completed_evaluations
                if item.evaluation.artifact_id in wanted
            ),
        )
        return tuple(item.artifact_id for item in ranked)

    def _tournament_indices(
        self, state: SearchState, members: tuple[ArtifactId, ...]
    ) -> tuple[int, ...]:
        return _sample_distinct(
            state.randomness.seed("selection"),
            len(members),
            min(self.tournament_size, len(members)),
        )

    def _tournament_parent(
        self, state: SearchState, members: tuple[ArtifactId, ...]
    ) -> ArtifactId:
        return members[min(self._tournament_indices(state, members))]

    def _archive_rationale(
        self, state: SearchState, decision: ArchiveUpdate
    ) -> str:
        if decision.admitted:
            rank = decision.member_ids.index(decision.candidate_id) + 1
            rationale = (
                f"admit candidate at population rank {rank}"
                f" of {len(decision.member_ids)}"
            )
            if decision.evicted_artifact_id is not None:
                rationale += ", evicting the lowest-ranked member"
            return rationale
        evaluation = next(
            item.evaluation
            for item in state.completed_evaluations
            if item.evaluation.id == decision.evaluation_id
        )
        cause = (
            "failed evaluation"
            if evaluation.failure is not None
            else "below population cutoff"
        )
        return f"reject candidate: {cause}"


__all__ = ["Population"]
