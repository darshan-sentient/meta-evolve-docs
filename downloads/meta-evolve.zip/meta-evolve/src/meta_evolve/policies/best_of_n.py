"""The independent best-of-N preset and bound search program."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    Budget,
    ComponentRef,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import PolicyMismatch, SearchState
from meta_evolve.errors import UnboundSearchProgram


@dataclass(frozen=True, slots=True, init=False)
class BestOfN:
    """Expand the seed independently for at most ``max_trials`` successor attempts.

    Every proposal starts from the same seed. Explicitly enabled experience
    can still communicate prior observations between attempts. The seed can
    remain the winner; a successor need not improve it.
    """

    max_trials: int
    policy: PolicyRef = PolicyRef("best-of-n", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(self, max_trials: int = 20) -> None:
        if isinstance(max_trials, bool) or not isinstance(max_trials, int):
            raise TypeError("best-of-n max_trials must be an integer")
        if max_trials < 0:
            raise ValueError("best-of-n max_trials must be non-negative")
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "policy", PolicyRef("best-of-n", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {"max_trials": self.max_trials}

    @property
    def identity_key(self) -> str:
        return f"best-of-n:max_trials={self.max_trials}"

    def bind(self, proposer: ComponentRef, budget: Budget) -> BestOfN:
        """Authorize one proposer and derive the unit trial allocation."""

        if self.bound:
            raise ValueError("best-of-n search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError(
                "best-of-n proposer must be a proposer component reference"
            )
        if not isinstance(budget, Budget):
            raise TypeError("best-of-n budget must be a Budget")
        result = BestOfN(self.max_trials)
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        if not self.bound:
            raise UnboundSearchProgram(
                "BestOfN must be passed to meta_evolve.run before next() is called"
            )
        start = state.require_start()
        if start.search.policy != self.policy:
            raise PolicyMismatch(self.policy, start.search.policy)
        if state.stop is not None:
            return state.stop
        if state.objective_satisfied:
            return Stop(reason="objective_satisfied")
        if state.usage.trials >= self.max_trials:
            return Stop(reason="trial_limit_reached")
        if state.budget_exhausted:
            return Stop(reason=state.budget_stop_reason)
        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(start.seed_artifact_id,),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.randomness.seed("trial"),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            return DecisionDescription("expand seed", ("trial",))
        return DecisionDescription(
            f"stop best-of-n search: {humanize_reason(decision.reason)}"
        )


__all__ = ["BestOfN"]
