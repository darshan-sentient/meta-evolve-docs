"""The independent best-of-N preset and bound search program."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    Budget,
    ComponentRef,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import PolicyMismatch, SearchState
from meta_evolve.errors import UnboundSearchProgram

from ._trial_budget import declared_trial_limit, resolve_trial_limit


@dataclass(frozen=True, slots=True, init=False)
class BestOfN:
    """Expand the seed independently for at most ``max_trials`` successor attempts.

    Every proposal starts from the same seed. Explicitly enabled experience
    can still communicate prior observations between attempts. The seed can
    remain the winner; a successor need not improve it.

    Exact ties retain the earlier successful evaluation. Default ranking and
    satisfaction use the first task objective. A target or budget can stop the
    run before all attempts are used.

    The resolved limit is recorded for replay. An explicit limit never widens
    the effective budget. Pass this as ``Experiment(search=BestOfN(3), ...)``;
    execution binds it for you. The methods below support search extensions.

    :param max_trials: Optional non-negative successor attempt limit. Omitted
        or ``None`` inherits finite ``Budget.trials`` at start, falling back to
        20 when unbounded. Zero allows only seed evaluation.
    :param cohort_width: Positive number of attempts planned from one committed
        history, default ``1``. Widths above one require ``mode="distributed"``
        and its admission requirements. Current execution is serial; a cohort
        is not a promise of concurrent model calls.
    :raises TypeError: If limits have unsupported types; booleans are rejected.
    :raises ValueError: If ``max_trials`` is negative or ``cohort_width`` is below one.
    """

    max_trials: int | None
    cohort_width: int = 1
    policy: PolicyRef = PolicyRef("best-of-n", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(self, max_trials: int | None = None, cohort_width: int = 1) -> None:
        max_trials = declared_trial_limit(max_trials, "best-of-n")
        if isinstance(cohort_width, bool) or not isinstance(cohort_width, int):
            raise TypeError("best-of-n cohort_width must be an integer")
        if cohort_width < 1:
            raise ValueError("best-of-n cohort_width must be at least one")
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "cohort_width", cohort_width)
        object.__setattr__(self, "policy", PolicyRef("best-of-n", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        # Omitted at the default so every recorded `SearchSpec` -- and so every
        # run identity derived from one -- is byte-identical to before.
        if self.cohort_width == 1:
            return {"max_trials": self.max_trials}
        return {"max_trials": self.max_trials, "cohort_width": self.cohort_width}

    @property
    def identity_key(self) -> str:
        if self.cohort_width == 1:
            return f"best-of-n:max_trials={self.max_trials}"
        return (
            f"best-of-n:max_trials={self.max_trials}"
            f",cohort_width={self.cohort_width}"
        )

    def bind(self, proposer: ComponentRef, budget: Budget) -> BestOfN:
        """Authorize one proposer and derive the unit trial allocation."""

        if self.bound:
            raise ValueError("best-of-n search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError(
                "best-of-n proposer must be a proposer component reference"
            )
        if not isinstance(budget, Budget):
            raise TypeError("best-of-n budget must be a Budget")
        # Every field must be named here. `prepare_search` reads both the
        # structural width and the recorded configuration off the *bound*
        # program, so a width this reconstruction drops disappears from both:
        # no disagreement is detected, the wide-cohort refusal never fires, and
        # a search the caller declared wide runs sequentially under a narrow
        # identity with no error at all. No fixture can see that.
        result = BestOfN(
            resolve_trial_limit(self.max_trials, budget),
            cohort_width=self.cohort_width,
        )
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        if not self.bound:
            raise UnboundSearchProgram(
                "BestOfN must be passed to meta_evolve.run before next() is called"
            )
        start = state.require_start()
        if start.search.policy != self.policy:
            raise PolicyMismatch(self.policy, start.search.policy)
        if state.stop is not None:
            return state.stop
        if state.objective_satisfied:
            return Stop(reason="objective_satisfied")
        if state.usage.trials >= self.max_trials:
            return Stop(reason="trial_limit_reached")
        if state.budget_exhausted:
            return Stop(reason=state.budget_stop_reason)
        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(start.seed_artifact_id,),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.randomness.seed("trial"),
        )

    def next_cohort(self, state: SearchState) -> tuple[SearchDecision, ...]:
        """A generation produced from one committed history.

        Composition is either a tuple of trial decisions or a singleton stop,
        never mixed: a stop is the whole answer, so the sequential decision
        answering `Stop` IS the cohort. That also gives the coherence law for
        free -- at width one this returns exactly `next(state)`, because it is
        `next(state)`, rather than a second implementation that has to be kept
        agreeing with it.

        Sizing is this policy's job. The record is explicit that the coordinator
        commits the whole cohort or refuses it entirely, as trial validation
        refuses rather than trims, so producing more than fits would be
        producing a batch designed to be rejected. The state to size it is
        right here: the trial ceiling this program declares, and the run's
        remaining allowance.

        Members differ only in their randomness, which is the whole point --
        best-of-n expands the SAME parent independently, so identical seeds
        would make a generation one trial done N times. No member can reference
        another's artifact because none of them looks anywhere but the seed;
        that is why this policy can declare a width and `Greedy`, which chains,
        cannot.
        """

        lead = self.next(state)
        if isinstance(lead, Stop):
            return (lead,)
        return (lead,) + tuple(
            self._member(state, ordinal)
            for ordinal in range(1, self._cohort_size(state))
        )

    def _cohort_size(self, state: SearchState) -> int:
        """How many members fit, never more than one declaration allows.

        No floor, because it cannot be reached and a floor that cannot fire
        hides whichever assumption stops being true. `next` has already
        returned `Stop` for every way `remaining` could arrive at zero: at
        `usage.trials >= max_trials` for the ceiling, and at `budget_exhausted`
        -- which is true when ANY dimension is zero -- for both allowances. A
        `max(1, ...)` here passed every law with it removed, which is how it was
        found.
        """

        remaining = self.max_trials - state.usage.trials
        allowance = state.remaining_budget
        for ceiling in (allowance.trials, allowance.evaluations):
            if ceiling is not None:
                remaining = min(remaining, ceiling)
        return min(self.cohort_width, remaining)

    def _member(self, state: SearchState, ordinal: int) -> TrialSpec:
        """The lead decision again, drawing this member's own randomness."""

        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        start = state.require_start()
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(start.seed_artifact_id,),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.member_randomness(ordinal).seed("trial"),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            return DecisionDescription("expand seed", ("trial",))
        return DecisionDescription(
            f"stop best-of-n search: {humanize_reason(decision.reason)}"
        )


__all__ = ["BestOfN"]
