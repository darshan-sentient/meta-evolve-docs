"""Functional incumbent-refinement search for the ordinary callable path."""

from __future__ import annotations

import inspect
from collections.abc import Callable
from dataclasses import dataclass, field, replace

from meta_evolve import serialization
from meta_evolve.domain import (
    ArtifactId,
    Budget,
    ComponentRef,
    FrozenMap,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.components import RUN_LOCAL_VERSION
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import SearchState
from meta_evolve.errors import InvalidDecision

from ._incumbent import lower_incumbent_decision


_SUPPORTED_RETURN = (
    "functional search callback must return the current view's "
    "search.expand() or search.stop() action"
)


@dataclass(frozen=True, slots=True, repr=False)
class _ArtifactHandle:
    _artifact_id: ArtifactId
    _role: str

    def __repr__(self) -> str:
        return "<search artifact handle>"


@dataclass(frozen=True, slots=True)
class _Expand:
    owner: object
    parent: _ArtifactHandle


@dataclass(frozen=True, slots=True)
class _Stop:
    owner: object
    decision: Stop


class _SearchView:
    __slots__ = ("_owner", "configuration", "incumbent", "seed")

    def __init__(
        self,
        *,
        seed_id: ArtifactId,
        incumbent_id: ArtifactId | None,
        configuration: FrozenMap,
    ) -> None:
        self._owner = object()
        self.configuration = configuration
        self.seed = _ArtifactHandle(seed_id, "seed")
        self.incumbent = (
            _ArtifactHandle(incumbent_id, "incumbent")
            if incumbent_id is not None
            else None
        )

    def expand(self, parent: object) -> _Expand:
        if parent is not self.seed and parent is not self.incumbent:
            raise InvalidDecision(
                "search.expand() accepts only search.seed or search.incumbent "
                "from the current decision view"
            )
        assert isinstance(parent, _ArtifactHandle)
        return _Expand(self._owner, parent)

    def stop(self, reason: str) -> _Stop:
        return _Stop(self._owner, Stop(reason=reason))


def _callback_metadata(callback: Callable[[object], object]) -> FrozenMap:
    docstring = inspect.cleandoc(callback.__doc__ or "")
    return FrozenMap(
        {
            "module": callback.__module__,
            "qualname": callback.__qualname__,
            "name": callback.__name__,
            "docstring": docstring,
        }
    )


def _validate_callback(callback: object) -> Callable[[object], object]:
    if not inspect.isfunction(callback):
        raise TypeError("functional search callback must be a Python function")
    if callback.__name__ == "<lambda>":
        raise TypeError(
            "functional search callback cannot be a lambda; define a named "
            "function whose name and docstring narrate its decisions"
        )
    parameters = tuple(inspect.signature(callback).parameters.values())
    if len(parameters) != 1 or parameters[0].kind not in (
        inspect.Parameter.POSITIONAL_ONLY,
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
    ):
        raise TypeError(
            "functional search callback must accept exactly one positional "
            "argument and no additional or variadic parameters"
        )
    if callback.__closure__:
        raise ValueError(
            "functional search callback cannot capture closure values; declare "
            "configuration on @meta.search(...) and move helpers to module scope"
        )
    return callback


@dataclass(frozen=True, slots=True)
class _FunctionalSearch:
    _callback: Callable[[object], object] = field(repr=False, compare=False)
    _metadata: FrozenMap
    _configuration: FrozenMap
    policy: PolicyRef = field(init=False)
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "policy",
            PolicyRef(
                f"{self.module}:{self.qualname}",
                RUN_LOCAL_VERSION,
                origin="local",
            ),
        )

    @property
    def module(self) -> str:
        return self._metadata["module"]  # type: ignore[return-value]

    @property
    def qualname(self) -> str:
        return self._metadata["qualname"]  # type: ignore[return-value]

    @property
    def name(self) -> str:
        return self._metadata["name"]  # type: ignore[return-value]

    @property
    def docstring(self) -> str:
        return self._metadata["docstring"]  # type: ignore[return-value]

    @property
    def metadata(self) -> FrozenMap:
        return self._metadata

    @property
    def max_trials(self) -> int:
        return self._configuration["max_trials"]  # type: ignore[return-value]

    @property
    def configuration(self) -> FrozenMap:
        return self._configuration

    @property
    def identity_key(self) -> str:
        declaration = FrozenMap(
            {"callback": self.policy.name, "configuration": self._configuration}
        )
        return f"functional:{serialization.identity_content(declaration)}"

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    def bind(self, proposer: ComponentRef, budget: Budget) -> _FunctionalSearch:
        if self.bound:
            raise ValueError("functional search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError(
                "functional search proposer must be a proposer component reference"
            )
        if not isinstance(budget, Budget):
            raise TypeError("functional search budget must be a Budget")
        return replace(
            self,
            _proposer=proposer,
            _operator=OperatorSpec(kind="mutate"),
            _budget=Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )

    def _invoke_callback(self, state: SearchState) -> tuple[ArtifactId | Stop, str]:
        start = state.require_start()
        view = _SearchView(
            seed_id=start.seed_artifact_id,
            incumbent_id=state.incumbent_id,
            configuration=self._configuration,
        )
        result = self._callback(view)
        if isinstance(result, _Expand) and result.owner is view._owner:
            return result.parent._artifact_id, result.parent._role
        if isinstance(result, _Stop) and result.owner is view._owner:
            return result.decision, "stop"
        raise InvalidDecision(_SUPPORTED_RETURN)

    def next(self, state: SearchState) -> SearchDecision:
        def decide_parent(current: SearchState) -> ArtifactId | Stop:
            decision, _ = self._invoke_callback(current)
            return decision

        return lower_incumbent_decision(
            state,
            policy=self.policy,
            max_trials=self.max_trials,
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget,
            unbound_message=(
                "functional search must be passed to meta_evolve.run before "
                "next() is called"
            ),
            decide_parent=decide_parent,
        )

    def _narrative_prefix(self) -> str:
        return self.name.replace("_", " ")

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        prefix = self._narrative_prefix()
        if isinstance(decision, TrialSpec):
            selected, role = self._invoke_callback(state)
            if selected != decision.parent_ids[0]:
                raise InvalidDecision(
                    "functional search callback did not reproduce its parent decision"
                )
            return DecisionDescription(
                f"{prefix}; expand {role}",
                ("trial",),
            )
        return DecisionDescription(
            f"{prefix}; stop: {humanize_reason(decision.reason)}"
        )


def search(
    *, max_trials: int, **configuration: object
) -> Callable[[Callable[[object], object]], _FunctionalSearch]:
    """Decorate one bounded incumbent-refinement decision function.

    The callback receives opaque ``seed`` and optional ``incumbent`` handles,
    immutable ``configuration``, and only ``expand(parent)`` / ``stop(reason)``
    actions. Declare every behavior-affecting value on this decorator; closure
    capture is rejected so the complete configuration remains identity-visible.
    """

    if isinstance(max_trials, bool) or not isinstance(max_trials, int):
        raise TypeError("functional search max_trials must be an integer")
    if max_trials < 0:
        raise ValueError("functional search max_trials must be non-negative")
    frozen = FrozenMap({"max_trials": max_trials, **configuration})

    def decorate(callback: object) -> _FunctionalSearch:
        validated = _validate_callback(callback)
        return _FunctionalSearch(validated, _callback_metadata(validated), frozen)

    return decorate


__all__ = ["search"]
