"""Replayable per-metric specialist retention."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve import serialization
from meta_evolve.domain import (
    ArchiveUpdate,
    ArtifactId,
    Budget,
    ComponentRef,
    Evaluation,
    FrozenMap,
    Maximize,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import (
    InvalidSearchHistory,
    PolicyMismatch,
    SearchState,
)
from meta_evolve.domain.values import _require_text
from meta_evolve.errors import UnboundSearchProgram


@dataclass(frozen=True, slots=True, init=False)
class Specialists:
    """Retain and expand the best artifact occurrence for each metric."""

    metrics: tuple[str, ...]
    max_trials: int
    policy: PolicyRef = PolicyRef("specialists", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(
        self, metrics: tuple[str, ...], max_trials: int = 20
    ) -> None:
        if not isinstance(metrics, tuple):
            raise TypeError("specialists metrics must be a tuple")
        if not metrics:
            raise ValueError("specialists metrics must not be empty")
        for metric in metrics:
            _require_text(metric, "specialist metric")
        if len(set(metrics)) != len(metrics):
            raise ValueError("specialists metrics must be unique")
        if isinstance(max_trials, bool) or not isinstance(max_trials, int):
            raise TypeError("specialists max_trials must be an integer")
        if max_trials < 0:
            raise ValueError("specialists max_trials must be non-negative")
        object.__setattr__(self, "metrics", metrics)
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "policy", PolicyRef("specialists", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {"max_trials": self.max_trials, "metrics": self.metrics}

    @property
    def identity_key(self) -> str:
        declaration = FrozenMap(self.configuration)
        return f"specialists:{serialization.identity_content(declaration)}"

    def bind(self, proposer: ComponentRef, budget: Budget) -> Specialists:
        """Authorize one proposer and derive the unit trial allocation."""

        if self.bound:
            raise ValueError("specialists search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError(
                "specialists proposer must be a proposer component reference"
            )
        if not isinstance(budget, Budget):
            raise TypeError("specialists budget must be a Budget")
        result = Specialists(self.metrics, self.max_trials)
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        if not self.bound:
            raise UnboundSearchProgram(
                "Specialists must be passed to meta_evolve.run before next() "
                "is called"
            )
        start = state.require_start()
        if start.search.policy != self.policy:
            raise PolicyMismatch(self.policy, start.search.policy)
        if state.stop is not None:
            return state.stop
        pending = self._pending_evaluation(state)
        if pending is not None:
            return self._archive_update(state, pending)
        if state.objective_satisfied:
            return Stop(reason="objective_satisfied")
        if state.usage.trials >= self.max_trials:
            return Stop(reason="trial_limit_reached")
        winners = self._winners(state, state.completed_evaluations)
        if not winners:
            return Stop(reason="specialist_frontier_empty")
        if state.budget_exhausted:
            return Stop(reason=state.budget_stop_reason)
        metric = self._sampled_metric(state)
        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(winners[metric].artifact_id,),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.randomness.seed("trial"),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            metric = self._sampled_metric(state)
            return DecisionDescription(
                f"expand specialist for metric {metric!r} from artifact "
                f"occurrence {decision.parent_ids[0].value}",
                ("selection", "trial"),
            )
        if isinstance(decision, ArchiveUpdate):
            return DecisionDescription(self._archive_rationale(state, decision))
        return DecisionDescription(
            f"stop specialists search: {humanize_reason(decision.reason)}"
        )

    def _pending_evaluation(self, state: SearchState) -> Evaluation | None:
        processed = {update.evaluation_id for update in state.archive_updates}
        for completed in state.completed_evaluations:
            if completed.evaluation.id not in processed:
                return completed.evaluation
        return None

    def _archive_update(
        self, state: SearchState, evaluation: Evaluation
    ) -> ArchiveUpdate:
        members = state.archive_members
        if evaluation.failure is not None:
            return ArchiveUpdate(
                evaluation_id=evaluation.id,
                candidate_id=evaluation.artifact_id,
                admitted=False,
                member_ids=members,
            )
        current = self._winners(state, state.completed_evaluations)
        owned = self._owned_metrics(current, evaluation.artifact_id)
        if not owned:
            return ArchiveUpdate(
                evaluation_id=evaluation.id,
                candidate_id=evaluation.artifact_id,
                admitted=False,
                member_ids=members,
            )
        member_ids = self._membership(current)
        removed = tuple(member for member in members if member not in member_ids)
        return ArchiveUpdate(
            evaluation_id=evaluation.id,
            candidate_id=evaluation.artifact_id,
            admitted=True,
            evicted_artifact_id=removed[0] if len(removed) == 1 else None,
            member_ids=member_ids,
        )

    def _winners(self, state: SearchState, completed) -> dict[str, Evaluation]:
        winners: dict[str, Evaluation] = {}
        maximize = isinstance(state.task.objectives[0], Maximize)
        for item in completed:
            evaluation = item.evaluation
            if evaluation.failure is not None:
                continue
            missing = tuple(
                metric for metric in self.metrics if metric not in evaluation.metrics
            )
            if missing:
                raise InvalidSearchHistory(
                    f"successful evaluation {evaluation.id.value} is missing "
                    f"specialist metrics {missing!r}"
                )
            for metric in self.metrics:
                winner = winners.get(metric)
                if winner is None or self._improves(
                    evaluation.metrics[metric], winner.metrics[metric], maximize
                ):
                    winners[metric] = evaluation
        return winners

    @staticmethod
    def _improves(candidate: object, incumbent: object, maximize: bool) -> bool:
        return candidate > incumbent if maximize else candidate < incumbent

    def _membership(self, winners: Mapping[str, Evaluation]) -> tuple[ArtifactId, ...]:
        members: list[ArtifactId] = []
        for metric in self.metrics:
            artifact_id = winners[metric].artifact_id
            if artifact_id not in members:
                members.append(artifact_id)
        return tuple(members)

    def _owned_metrics(
        self, winners: Mapping[str, Evaluation], artifact_id: ArtifactId
    ) -> tuple[str, ...]:
        return tuple(
            metric
            for metric in self.metrics
            if winners[metric].artifact_id == artifact_id
        )

    def _sampled_metric(self, state: SearchState) -> str:
        index = state.randomness.seed("selection") % len(self.metrics)
        return self.metrics[index]

    def _archive_rationale(
        self, state: SearchState, decision: ArchiveUpdate
    ) -> str:
        evaluation = next(
            item.evaluation
            for item in state.completed_evaluations
            if item.evaluation.id == decision.evaluation_id
        )
        if not decision.admitted:
            cause = (
                "failed evaluation cannot own specialist metrics"
                if evaluation.failure is not None
                else "improves no specialist metric"
            )
            return f"reject candidate: {cause}"
        winners = self._winners(state, state.completed_evaluations)
        owned = self._owned_metrics(winners, decision.candidate_id)
        labels = ", ".join(repr(metric) for metric in owned)
        noun = "metric" if len(owned) == 1 else "metrics"
        previous = state.archive_members
        removed = tuple(
            member for member in previous if member not in decision.member_ids
        )
        if not removed:
            removal = "no archive members removed"
        elif len(removed) == 1:
            removal = "removing one obsolete member"
        else:
            removal = f"removing {len(removed)} obsolete members"
        return f"admit candidate as specialist for {noun} {labels}; {removal}"


__all__ = ["Specialists"]
