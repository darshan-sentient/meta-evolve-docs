"""The minimal greedy preset and bound search program."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    Budget,
    ComponentRef,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    TrialSpec,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import SearchState
from meta_evolve.errors import UnboundSearchProgram

from ._incumbent import lower_incumbent_decision
from ._trial_budget import declared_trial_limit, resolve_trial_limit


@dataclass(frozen=True, slots=True, init=False)
class Greedy:
    """Expand the best evaluated artifact for at most ``max_trials`` attempts.

    The seed is evaluated separately. A strictly better successor becomes the
    next parent; unsuccessful attempts remain in the record. Satisfaction or
    exhaustion can stop search before the attempt limit.

    ``max_trials=None`` opts into inheriting the limit from the effective
    finite ``Budget.trials``. Resolution happens once during binding, and the
    resolved integer is what reaches ``SearchSpec``, the run identity, and the
    durable record, so replay and reconstruction never re-inherit. Binding with
    ``None`` against an unbounded trial budget raises
    :class:`~meta_evolve.errors.BudgetUnavailable`. An explicit integer may stop
    the search early but never widens the run budget.
    """

    max_trials: int | None
    policy: PolicyRef = PolicyRef("greedy", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(self, max_trials: int | None = 20) -> None:
        max_trials = declared_trial_limit(max_trials, "greedy")
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "policy", PolicyRef("greedy", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {"max_trials": self.max_trials}

    @property
    def identity_key(self) -> str:
        return f"greedy:max_trials={self.max_trials}"

    def bind(self, proposer: ComponentRef, budget: Budget) -> Greedy:
        """Authorize one proposer and derive the unit trial allocation from the run budget."""

        if self.bound:
            raise ValueError("greedy search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError("greedy proposer must be a proposer component reference")
        if not isinstance(budget, Budget):
            raise TypeError("greedy budget must be a Budget")
        result = Greedy(resolve_trial_limit(self.max_trials, budget, "greedy"))
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        return lower_incumbent_decision(
            state,
            policy=self.policy,
            max_trials=self.max_trials,
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget,
            unbound_message=(
                "Greedy must be passed to meta_evolve.run before next() is called"
            ),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            seed_id = state.require_start().seed_artifact_id
            role = "seed" if decision.parent_ids[0] == seed_id else "incumbent"
            return DecisionDescription(
                f"expand {role}",
                ("trial",),
            )
        return DecisionDescription(
            f"stop greedy search: {humanize_reason(decision.reason)}"
        )


__all__ = ["Greedy", "UnboundSearchProgram"]
