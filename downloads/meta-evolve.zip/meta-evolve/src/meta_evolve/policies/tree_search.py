"""Replayable value-directed tree-search preset."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
import math
from numbers import Real

from meta_evolve import serialization
from meta_evolve.domain import (
    Budget,
    ComponentRef,
    FrozenMap,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.decision_description import DecisionDescription, humanize_reason
from meta_evolve.domain.search import PolicyMismatch, SearchState
from meta_evolve.errors import UnboundSearchProgram

from ._tree_search import TreeEdge, TreeSelection, fold_tree


@dataclass(frozen=True, slots=True, init=False)
class TreeSearch:
    """Allocate trials with progressive widening and UCT descent."""

    max_trials: int
    exploration: float
    policy: PolicyRef = PolicyRef("tree-search", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(
        self, max_trials: int = 100, exploration: Real = 2**0.5
    ) -> None:
        if isinstance(max_trials, bool) or not isinstance(max_trials, int):
            raise TypeError("tree-search max_trials must be an integer")
        if max_trials < 0:
            raise ValueError("tree-search max_trials must be non-negative")
        if isinstance(exploration, bool) or not isinstance(exploration, Real):
            raise TypeError("tree-search exploration must be a real number")
        normalized = float(exploration)
        if not math.isfinite(normalized) or normalized < 0:
            raise ValueError(
                "tree-search exploration must be finite and non-negative"
            )
        object.__setattr__(self, "max_trials", max_trials)
        object.__setattr__(self, "exploration", normalized)
        object.__setattr__(self, "policy", PolicyRef("tree-search", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return (
            self._proposer is not None
            and self._operator is not None
            and self._budget is not None
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {
            "exploration": self.exploration,
            "max_trials": self.max_trials,
        }

    @property
    def identity_key(self) -> str:
        declaration = FrozenMap(self.configuration)
        return f"tree-search:{serialization.identity_content(declaration)}"

    def bind(self, proposer: ComponentRef, budget: Budget) -> TreeSearch:
        """Authorize one proposer and derive the unit trial allocation."""

        if self.bound:
            raise ValueError("tree-search search is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError(
                "tree-search proposer must be a proposer component reference"
            )
        if not isinstance(budget, Budget):
            raise TypeError("tree-search budget must be a Budget")
        result = TreeSearch(self.max_trials, self.exploration)
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        if not self.bound:
            raise UnboundSearchProgram(
                "TreeSearch must be passed to meta_evolve.run before next() is called"
            )
        start = state.require_start()
        if start.search.policy != self.policy:
            raise PolicyMismatch(self.policy, start.search.policy)
        if state.stop is not None:
            return state.stop
        tree = fold_tree(state)
        if state.objective_satisfied:
            return Stop(reason="objective_satisfied")
        if state.usage.trials >= self.max_trials:
            return Stop(reason="trial_limit_reached")
        if state.budget_exhausted:
            return Stop(reason=state.budget_stop_reason)
        selected = tree.select(self.exploration)
        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(selected.node.artifact_id,),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.randomness.seed("trial"),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            selection = fold_tree(state).select(self.exploration)
            return DecisionDescription(self._selection_rationale(selection), ("trial",))
        return DecisionDescription(
            f"stop tree search: {humanize_reason(decision.reason)}"
        )

    @classmethod
    def _selection_rationale(cls, selection: TreeSelection) -> str:
        parts = [cls._edge_rationale(edge) for edge in selection.path]
        node = selection.node
        parts.append(
            f"expand artifact occurrence {node.artifact_id.value}; widening "
            f"{len(node.child_ids)}/{node.widening_limit} at {node.visits} visits"
        )
        return "; ".join(parts)

    @staticmethod
    def _edge_rationale(edge: TreeEdge) -> str:
        q = "none" if edge.q is None else format(edge.q, ".12g")
        return (
            f"descend {edge.parent_id.value}->{edge.child_id.value} "
            f"(Q={q}, exploitation={edge.exploitation:.12g}, "
            f"exploration={edge.exploration_bonus:.12g}, visits="
            f"{edge.parent_visits}/{edge.child_visits})"
        )


__all__ = ["TreeSearch"]
