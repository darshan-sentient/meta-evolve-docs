"""The shipped run-level declaration for audited pull experience."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain.experience_access import ExperienceSpec


@dataclass(frozen=True, slots=True)
class PullAccess:
    """Authorize bounded, audited pull access through ``Experiment.experience``.

    Successor proposers receive the reader as ``context.experience``. Access
    is off by default. Operation, result, record, and character bounds apply
    per attempt; the reader observes only authorized, strictly prior records.

    Bounds are non-negative integers. This supplies a capability, not automatic
    feedback: the proposer chooses reader calls. Denied or exhausted access
    raises [ExperienceAccessDenied][meta_evolve.ExperienceAccessDenied] or
    [ExperienceBudgetExhausted][meta_evolve.ExperienceBudgetExhausted]. Pushed
    feedback is separately configured with ``Experiment.context``.

    :param max_operations: Maximum reader operations per attempt, default ``20``.
    :param max_results: Maximum results consumed per attempt, default ``20``.
    :param max_records: Maximum records consumed per attempt, default ``100``.
    :param max_chars: Maximum characters consumed per attempt, default ``32000``.
    """

    max_operations: int = 20
    max_results: int = 20
    max_records: int = 100
    max_chars: int = 32_000

    def __post_init__(self) -> None:
        self.experience_spec()

    def experience_spec(self) -> ExperienceSpec:
        return ExperienceSpec(
            max_operations=self.max_operations,
            max_results=self.max_results,
            max_records=self.max_records,
            max_chars=self.max_chars,
        )


__all__ = ["PullAccess"]
