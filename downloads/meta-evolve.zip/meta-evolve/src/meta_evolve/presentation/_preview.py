"""Bounded previews over frozen artifact payloads."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.views import ArtifactView

from ._format import mapping, readable, text
from .models import (
    ArtifactPresentation,
    PresentationDocument,
    PresentationField,
    PresentationSection,
)


ENTRY_LIMIT = 100
DOCUMENT_BYTES = 64 * 1024
AGGREGATE_BYTES = 256 * 1024


def _truncate(value: str, limit: int) -> tuple[str, bool, int]:
    encoded = value.encode("utf-8")
    if len(encoded) <= limit:
        return value, False, len(encoded)
    retained = encoded[:limit].decode("utf-8", errors="ignore")
    return retained, True, len(retained.encode("utf-8"))


def _bounded(sections: tuple[PresentationSection, ...]) -> tuple[
    tuple[PresentationSection, ...], int, int
]:
    indexed = [
        (document.path or "", section_index, document_index, document)
        for section_index, section in enumerate(sections)
        for document_index, document in enumerate(section.documents)
    ]
    indexed.sort(key=lambda item: (item[0], item[1], item[2]))
    omitted = max(0, len(indexed) - ENTRY_LIMIT)
    retained = indexed[:ENTRY_LIMIT]
    accepted: dict[tuple[int, int], PresentationDocument] = {}
    aggregate = 0
    aggregate_omitted = 0
    for position, (_path, section_index, document_index, document) in enumerate(retained):
        preview, truncated, size = _truncate(document.text, DOCUMENT_BYTES)
        remaining = AGGREGATE_BYTES - aggregate
        if remaining <= 0:
            aggregate_omitted = len(retained) - position
            break
        if size > remaining:
            preview, aggregate_cut, size = _truncate(preview, remaining)
            accepted[(section_index, document_index)] = replace(
                document, text=preview, truncated=truncated or aggregate_cut
            )
            aggregate += size
            aggregate_omitted = len(retained) - position - 1
            break
        accepted[(section_index, document_index)] = replace(
            document, text=preview, truncated=truncated
        )
        aggregate += size
    bounded = tuple(
        replace(
            section,
            documents=tuple(
                accepted[(section_index, document_index)]
                for document_index, _document in enumerate(section.documents)
                if (section_index, document_index) in accepted
            ),
        )
        for section_index, section in enumerate(sections)
    )
    return bounded, omitted, aggregate_omitted


def _component(item: object) -> str:
    component = mapping(item, "component declaration")
    return ":".join(
        text(component[name], f"component {name}")
        for name in ("role", "name", "version", "origin")
    )


def _harness(payload: object) -> tuple[PresentationSection, ...]:
    manifest = mapping(payload, "harness payload")
    planner = mapping(manifest["planner"], "planner declaration")
    policy = mapping(manifest["context_policy"], "context policy declaration")
    return (
        PresentationSection(
            "Planner",
            fields=(
                PresentationField("Name", text(planner["name"], "planner name")),
                PresentationField("Component", _component(planner["component"])),
                PresentationField("Interface", text(planner["interface"], "planner interface")),
            ),
            documents=(PresentationDocument("planner.txt", text(planner["value"], "planner value")),),
        ),
        PresentationSection(
            "Context policy",
            fields=(
                PresentationField("Name", text(policy["name"], "context policy name")),
                PresentationField("Component", _component(policy["component"])),
                PresentationField("Interface", text(policy["interface"], "context policy interface")),
            ),
            documents=(PresentationDocument("context-policy.json", readable(policy["configuration"])),),
        ),
    )


def _policy(payload: object) -> tuple[PresentationSection, ...]:
    manifest = mapping(payload, "policy payload")
    parent = mapping(manifest["parent_selection"], "parent selection")
    limit = mapping(manifest["trial_limit"], "trial limit")
    return (
        PresentationSection(
            "Parent selection",
            fields=(
                PresentationField("Name", text(parent["name"], "parent selection name")),
                PresentationField("Component", _component(parent["component"])),
                PresentationField("Interface", text(parent["interface"], "parent selection interface")),
                PresentationField("Allowed", readable(parent["allowed"])),
                PresentationField("Value", text(parent["mode"], "parent selection mode")),
            ),
        ),
        PresentationSection(
            "Trial limit",
            fields=(
                PresentationField("Name", text(limit["name"], "trial limit name")),
                PresentationField("Component", _component(limit["component"])),
                PresentationField("Interface", text(limit["interface"], "trial limit interface")),
                PresentationField("Minimum", readable(limit["minimum"])),
                PresentationField("Value", readable(limit["max_trials"])),
            ),
        ),
    )


def present(artifact: ArtifactView) -> ArtifactPresentation:
    payload = artifact._payload
    key = (artifact.kind, artifact.representation)
    notice = None
    if key == ("text", "utf8-text-v1"):
        sections = (PresentationSection("Text", documents=(PresentationDocument(None, text(payload, "text payload")),)),)
    elif key in {("source-tree", "utf8-tree-v1"), ("skill-set", "utf8-tree-v1")}:
        tree = mapping(payload, "tree payload")
        label = "Source files" if key[0] == "source-tree" else "Skill documents"
        sections = (PresentationSection(label, documents=tuple(PresentationDocument(path, text(body, "document text")) for path, body in tree.items())),)
    elif key == ("python-value", "canonical-json"):
        sections = (PresentationSection("Canonical Python value", documents=(PresentationDocument(None, readable(payload)),)),)
    elif key == ("agent-harness", "harness-manifest-v1"):
        sections = _harness(payload)
    elif key == ("search-policy", "policy-manifest-v1"):
        sections = _policy(payload)
    else:
        notice = "No specialized view is available; showing the canonical payload."
        sections = (PresentationSection("Canonical payload", documents=(PresentationDocument(None, canonical_payload_bytes(payload).decode("utf-8")),)),)
    bounded, omitted, aggregate_omitted = _bounded(sections)
    return ArtifactPresentation(
        artifact_id=str(artifact.id), digest=artifact.digest, kind=artifact.kind,
        representation=artifact.representation, sections=bounded, notice=notice,
        omitted_documents=omitted,
        aggregate_omitted_documents=aggregate_omitted,
    )


__all__ = ["AGGREGATE_BYTES", "DOCUMENT_BYTES", "ENTRY_LIMIT", "present"]
