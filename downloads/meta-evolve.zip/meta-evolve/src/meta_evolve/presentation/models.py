"""Immutable, inert records returned by artifact presentation functions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True, slots=True)
class PresentationField:
    label: str
    text: str


@dataclass(frozen=True, slots=True)
class PresentationDocument:
    path: str | None
    text: str
    truncated: bool = False


@dataclass(frozen=True, slots=True)
class PresentationSection:
    label: str
    fields: tuple[PresentationField, ...] = ()
    documents: tuple[PresentationDocument, ...] = ()


@dataclass(frozen=True, slots=True)
class ArtifactPresentation:
    artifact_id: str
    digest: str
    kind: str
    representation: str
    sections: tuple[PresentationSection, ...]
    notice: str | None = None
    omitted_documents: int = 0
    aggregate_omitted_documents: int = 0

    @property
    def documents(self) -> tuple[PresentationDocument, ...]:
        """All retained documents in presentation order."""

        return tuple(document for section in self.sections for document in section.documents)


@dataclass(frozen=True, slots=True)
class DiffLine:
    kind: Literal["unchanged", "added", "removed"]
    old_line: int | None
    new_line: int | None
    text: str


@dataclass(frozen=True, slots=True)
class FileDiff:
    path: str | None
    status: Literal["added", "removed", "modified", "unchanged"]
    lines: tuple[DiffLine, ...] = ()
    notice: str | None = None


@dataclass(frozen=True, slots=True)
class ArtifactDiff:
    parent_id: str
    child_id: str
    parent_digest: str
    child_digest: str
    kind: str
    representation: str
    files: tuple[FileDiff, ...]
    omitted_files: int = 0
    output_truncated: bool = False


__all__ = [
    "ArtifactDiff",
    "ArtifactPresentation",
    "DiffLine",
    "FileDiff",
    "PresentationDocument",
    "PresentationField",
    "PresentationSection",
]
