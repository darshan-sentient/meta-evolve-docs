"""Durable physical-format version contract (no I/O).

M4.1 defines the store-schema version and a pure open-time check. M4.2 wires
this into the SQLite store and supplies any DDL migrations. Record/serialization
versioning lives in ``serialization.py``; these are independent ladders.
"""

from __future__ import annotations

from .errors import DurableCorruption, SchemaVersionRejected

STORE_SCHEMA_VERSION = 2


def check_store_schema_version(found: int | None, *, populated: bool) -> None:
    """Validate a store's recorded schema version against this build.

    ``found`` is the version recorded in the store (``None`` if absent).
    ``populated`` says whether the store already holds data. A populated store
    with no version row is corrupt; an empty store without one is fine (it is
    about to be stamped). A future version is rejected rather than guessed at.
    Past versions return normally so the caller (M4.2) can run DDL migrations.
    """

    if found is None:
        if populated:
            raise DurableCorruption(
                "missing store schema version in a populated store"
            )
        return None
    if isinstance(found, bool) or not isinstance(found, int) or found < 1:
        raise SchemaVersionRejected(f"invalid store schema version: {found!r}")
    if found > STORE_SCHEMA_VERSION:
        raise SchemaVersionRejected(
            f"future store schema version {found} > {STORE_SCHEMA_VERSION}"
        )
    return None
