"""Versioned canonical serialization for Meta-Evolve domain values."""

from __future__ import annotations

import json
import math
from collections.abc import Callable
from dataclasses import MISSING, Field, fields, is_dataclass
from typing import Any, TypeVar

from . import domain
from .domain.events import LEGACY_LOCAL_CAPABILITIES
from .domain.identity import CURRENT_SCHEMA_VERSION, SchemaVersion
from .domain.values import FrozenMap
from .errors import SchemaVersionRejected


T = TypeVar("T")

_TYPE_REGISTRY = {cls.__name__: cls for cls in domain.DURABLE_TYPES}


def _field_default(item: Field[Any]) -> object:
    if item.default is not MISSING:
        return item.default
    if item.default_factory is not MISSING:
        return item.default_factory()
    return MISSING


def payload_fields(value: object) -> dict[str, object]:
    """The serializable fields of one durable record, honouring omit_if_default.

    Raw field values, not encoded ones, in declaration order. Also used by the
    policy codecs, which store bare field maps with no ``$type`` tag: omit-at-
    declared-default is *one* rule, derived from the metadata here rather than
    restated per caller. ``Usage.spend_micros`` omitting at ``0`` and
    ``Budget.spend_micros`` at ``None`` are that rule reading two defaults.
    """

    result: dict[str, object] = {}
    for item in fields(value):
        if not item.metadata.get("serialize", True):
            continue
        field_value = getattr(value, item.name)
        if item.metadata.get("omit_if_default", False):
            default = _field_default(item)
            if default is not MISSING and field_value == default:
                continue
        result[item.name] = field_value
    return result


def _encode(value: object) -> object:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("canonical JSON cannot contain NaN or infinity")
        return value
    if isinstance(value, FrozenMap):
        return {"$map": {key: _encode(item) for key, item in value.items()}}
    if isinstance(value, tuple):
        return {"$tuple": [_encode(item) for item in value]}
    if is_dataclass(value):
        type_name = type(value).__name__
        if (
            type_name not in _TYPE_REGISTRY
            or _TYPE_REGISTRY[type_name] is not type(value)
        ):
            raise TypeError(f"unregistered durable type: {type(value).__name__}")
        result: dict[str, object] = {"$type": type_name}
        for name, field_value in payload_fields(value).items():
            result[name] = _encode(field_value)
        return result
    raise TypeError(f"unsupported durable value: {type(value).__name__}")


def _decode(value: object) -> object:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("canonical JSON cannot contain NaN or infinity")
        return value
    if isinstance(value, list):
        raise ValueError("untyped JSON arrays are not valid durable values")
    if not isinstance(value, dict):
        raise TypeError(f"unsupported encoded value: {type(value).__name__}")
    if set(value) == {"$tuple"}:
        items = value["$tuple"]
        if not isinstance(items, list):
            raise ValueError("$tuple must contain an array")
        return tuple(_decode(item) for item in items)
    if set(value) == {"$map"}:
        items = value["$map"]
        if not isinstance(items, dict):
            raise ValueError("$map must contain an object")
        return FrozenMap((key, _decode(item)) for key, item in items.items())
    type_name = value.get("$type")
    if not isinstance(type_name, str):
        raise ValueError("encoded durable object is missing $type")
    cls = _TYPE_REGISTRY.get(type_name)
    if cls is None:
        raise ValueError(f"unknown durable type: {type_name!r}")
    serialized_fields = tuple(
        item for item in fields(cls) if item.metadata.get("serialize", True)
    )
    expected = {item.name for item in serialized_fields}
    optional = {
        item.name
        for item in serialized_fields
        if item.metadata.get("omit_if_default", False)
        and _field_default(item) is not MISSING
    }
    required = expected - optional
    supplied = set(value) - {"$type"}
    if not required <= supplied or not supplied <= expected:
        missing = sorted(required - supplied)
        extra = sorted(supplied - expected)
        raise ValueError(
            f"invalid fields for {type_name}: missing={missing!r}, extra={extra!r}"
        )
    decoded = {
        item.name: _decode(value[item.name])
        for item in serialized_fields
        if item.name in supplied
    }
    by_name = {item.name: item for item in serialized_fields}
    for name in supplied & optional:
        if decoded[name] == _field_default(by_name[name]):
            raise ValueError(
                f"non-canonical explicit default for {type_name}.{name}"
            )
    return cls(**decoded)


def _map_encoded_objects(
    value: object, transform: Callable[[dict[str, object]], dict[str, object]]
) -> object:
    """Return a copy of an encoded tree with ``transform`` applied to every
    ``$type`` object (children first)."""

    if isinstance(value, dict):
        if set(value) == {"$tuple"}:
            return {"$tuple": [_map_encoded_objects(item, transform)
                               for item in value["$tuple"]]}
        if set(value) == {"$map"}:
            return {"$map": {key: _map_encoded_objects(item, transform)
                             for key, item in value["$map"].items()}}
        mapped = {key: _map_encoded_objects(item, transform)
                  for key, item in value.items()}
        if "$type" in mapped:
            return transform(mapped)
        return mapped
    return value


def _migrate_v1_to_v2(payload: object) -> object:
    """Add the RunStarted.capabilities field introduced in schema version 2."""

    encoded_default = _encode(LEGACY_LOCAL_CAPABILITIES)

    def add_capabilities(obj: dict[str, object]) -> dict[str, object]:
        if obj.get("$type") == "RunStarted" and "capabilities" not in obj:
            return {**obj, "capabilities": encoded_default}
        return obj

    return _map_encoded_objects(payload, add_capabilities)


def _migrate_v2_to_v3(payload: object) -> object:
    """Add RunCapabilities.component_manifests introduced in schema version 3."""

    def add_component_manifests(obj: dict[str, object]) -> dict[str, object]:
        if obj.get("$type") == "RunCapabilities" and "component_manifests" not in obj:
            return {**obj, "component_manifests": {"$tuple": []}}
        return obj

    return _map_encoded_objects(payload, add_component_manifests)


_RECORD_MIGRATIONS: dict[int, Callable[[object], object]] = {
    1: _migrate_v1_to_v2,
    2: _migrate_v2_to_v3,
}


def _reject_future_inner_versions(value: object) -> None:
    """Fail if any decoded record carries a schema version newer than this build."""

    if isinstance(value, SchemaVersion):
        if value.value > CURRENT_SCHEMA_VERSION.value:
            raise SchemaVersionRejected(
                f"inner record schema version {value.value} exceeds "
                f"{CURRENT_SCHEMA_VERSION.value}"
            )
        return
    if isinstance(value, FrozenMap):
        for item in value.values():
            _reject_future_inner_versions(item)
    elif isinstance(value, tuple):
        for item in value:
            _reject_future_inner_versions(item)
    elif is_dataclass(value):
        for item in fields(value):
            _reject_future_inner_versions(getattr(value, item.name))


def to_data(value: object) -> dict[str, object]:
    """Return a JSON-compatible, schema-versioned serialization envelope."""

    return {
        "payload": _encode(value),
        "schema_version": CURRENT_SCHEMA_VERSION.value,
    }


def from_data(data: object, expected_type: type[T] | None = None) -> T | object:
    """Decode a serialization envelope, optionally enforcing its root type."""

    if not isinstance(data, dict) or set(data) != {"payload", "schema_version"}:
        raise ValueError(
            "serialization envelope must contain payload and schema_version"
        )
    version = data["schema_version"]
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise SchemaVersionRejected(f"invalid schema version: {version!r}")
    if version > CURRENT_SCHEMA_VERSION.value:
        raise SchemaVersionRejected(
            f"future schema version {version} > {CURRENT_SCHEMA_VERSION.value}"
        )
    payload = data["payload"]
    while version < CURRENT_SCHEMA_VERSION.value:
        migrate = _RECORD_MIGRATIONS.get(version)
        if migrate is None:
            raise SchemaVersionRejected(f"no migration from schema version {version}")
        payload = migrate(payload)
        version += 1
    result = _decode(payload)
    _reject_future_inner_versions(result)
    if expected_type is not None and not isinstance(result, expected_type):
        raise TypeError(
            f"expected {expected_type.__name__}, decoded {type(result).__name__}"
        )
    return result


def _canonical_json(obj: object) -> str:
    """Stable canonical JSON shared by the identity and storage encoders."""

    return json.dumps(
        obj,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def canonical_content(value: object) -> str:
    """Version-independent canonical encoding for identity derivation.

    Unlike ``dumps``, this excludes the schema-version envelope, so an object's
    logical identity is stable across serialization schema migrations.
    """

    return _canonical_json(_encode(value))


def identity_content(value: object) -> str:
    """Return the frozen v1 encoding used by established logical identities.

    Milestones 1–3 derived task, run, and search identities from ``dumps`` while
    the durable schema version was 1. Durable schema migrations must not change
    those identities—or the random substreams derived from them—so identity has
    its own frozen envelope rather than following the storage schema version.
    """

    return _canonical_json({"payload": _encode(value), "schema_version": 1})


def dumps(value: object) -> str:
    """Serialize a durable value to stable canonical JSON text."""

    return _canonical_json(to_data(value))


def dump_bytes(value: object) -> bytes:
    return dumps(value).encode("utf-8")


def loads(payload: str | bytes, expected_type: type[T] | None = None) -> T | object:
    """Deserialize canonical JSON text or UTF-8 bytes."""

    if isinstance(payload, bytes):
        payload = payload.decode("utf-8")
    if not isinstance(payload, str):
        raise TypeError("serialized payload must be str or bytes")
    return from_data(json.loads(payload), expected_type)
