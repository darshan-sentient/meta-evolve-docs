"""One rendering of usage and budgets, shared by the CLI and the browser.

Both surfaces printed these field lists independently, so adding a dimension
meant editing five places and nothing caught a divergence. They differ only in
separator and in whether wall time is shown -- the CLI omits it so two
byte-identical runs produce byte-identical reports -- so those are parameters
rather than second copies.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meta_evolve.domain import Budget, Usage

_MICROS_PER_DOLLAR = 1_000_000


def dollars(micros: int) -> str:
    """Render integer micro-USD as exact dollars.

    Integer division, never float: money must stay exact at every magnitude.
    Negative input is refused rather than rendered: Python floor semantics
    would print ``dollars(-1)`` as ``$-1.999999``.
    """

    if micros < 0:
        raise ValueError(f"micros must not be negative, got {micros}")
    return f"${micros // _MICROS_PER_DOLLAR}.{micros % _MICROS_PER_DOLLAR:06d}"


def optional_dollars(micros: int | None) -> str:
    """Render an optional ceiling, where ``None`` means unbounded."""

    return "None" if micros is None else dollars(micros)


def render_usage(value: Usage, *, separator: str = " ", wall: bool = False) -> str:
    fields = [
        f"trials={value.trials}",
        f"evaluations={value.evaluations}",
        f"tokens={value.tokens}",
        f"spend={dollars(value.spend_micros) if value.spend_micros is not None else 'unknown'}",
    ]
    if wall:
        fields.append(f"wall seconds={value.wall_seconds}")
    return separator.join(fields)


def render_budget(value: Budget | None, *, separator: str = " ") -> str:
    if value is None:
        return "None"
    return separator.join(
        (
            f"evaluations={value.evaluations}",
            f"trials={value.trials}",
            f"tokens={value.tokens}",
            f"spend={optional_dollars(value.spend_micros)}",
            f"wall_seconds={value.wall_seconds}",
        )
    )
