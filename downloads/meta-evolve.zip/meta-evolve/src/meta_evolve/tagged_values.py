"""The tagged value encoding, stated once and bound to a type registry.

`$type` for a registered dataclass, `$map` for a `FrozenMap`, `$tuple` for a
tuple, finite floats only. The durable format (`serialization.py`) binds
`DURABLE_TYPES`; the wire (`distributed/messages.py`) binds a wider registry
of its own. Moved out of `serialization.py` unchanged so that the wire could
exist without a second copy of the rule -- two copies are two encodings that
drift, and the one thing the wire must be is lossless for what the stream
stores.

A registry says which types a format admits and nothing else. What a format
does around the encoding -- schema envelopes and migrations for the durable
one, frames for the wire -- stays with that format.

Two further forms exist for a format that declares them, and the durable one
declares neither, so it still refuses both:

* `$enum` -- a member of a registered `Enum`, by value;
* `$as` -- a value carried as another value: `project` turns it into
  something encodable, `rebuild` turns that back. For a type whose own fields
  are not the thing to send (an `Acknowledgment` is its payload; its bytes are
  derived) or that is not a dataclass at all (an exception).
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from dataclasses import MISSING, Field, dataclass, fields, is_dataclass
from enum import Enum
from typing import Any

from .domain.values import FrozenMap


def field_default(item: Field[Any]) -> object:
    if item.default is not MISSING:
        return item.default
    if item.default_factory is not MISSING:
        return item.default_factory()
    return MISSING


def payload_fields(value: object) -> dict[str, object]:
    """The serializable fields of one record, honouring omit_if_default.

    Raw field values, not encoded ones, in declaration order. Also used by the
    policy codecs, which store bare field maps with no ``$type`` tag: omit-at-
    declared-default is *one* rule, derived from the metadata here rather than
    restated per caller. ``Usage.spend_micros`` omitting at ``0`` and
    ``Budget.spend_micros`` at ``None`` are that rule reading two defaults.
    """

    result: dict[str, object] = {}
    for item in fields(value):
        if not item.metadata.get("serialize", True):
            continue
        field_value = getattr(value, item.name)
        if item.metadata.get("omit_if_default", False):
            default = field_default(item)
            if default is not MISSING and field_value == default:
                continue
        result[item.name] = field_value
    return result


@dataclass(frozen=True, slots=True)
class Projection:
    """How a value of `kind` travels as another value (the `$as` form)."""

    kind: type
    project: Callable[[Any], object]
    rebuild: Callable[[Any], object]


class TaggedCodec:
    """Encode and decode tagged values for the types one registry names.

    `noun` names the format in refusals ("unregistered durable type: X"), so a
    refusal says which format refused rather than only that one did.
    Projections are matched by `isinstance`, in the order given.
    """

    def __init__(
        self,
        registry: Mapping[str, type],
        *,
        noun: str,
        enums: Mapping[str, type[Enum]] | None = None,
        projections: Mapping[str, Projection] | None = None,
    ) -> None:
        self._registry = dict(registry)
        self._noun = noun
        self._enums = dict(enums or {})
        self._projections = dict(projections or {})

    def encode(self, value: object) -> object:
        for name, projection in self._projections.items():
            if isinstance(value, projection.kind):
                return {"$as": name, "value": self.encode(projection.project(value))}
        if value is None or isinstance(value, (bool, int, str)):
            # Before the enum branch: a `str`/`int` enum member already
            # encodes as its plain value in the durable format, and must keep
            # doing so byte for byte.
            return value
        if isinstance(value, Enum):
            if self._enums.get(type(value).__name__) is not type(value):
                raise TypeError(f"unsupported {self._noun} value: {type(value).__name__}")
            return {"$enum": type(value).__name__, "value": value.value}
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("canonical JSON cannot contain NaN or infinity")
            return value
        if isinstance(value, FrozenMap):
            return {"$map": {key: self.encode(item) for key, item in value.items()}}
        if isinstance(value, tuple):
            return {"$tuple": [self.encode(item) for item in value]}
        if is_dataclass(value):
            type_name = type(value).__name__
            if self._registry.get(type_name) is not type(value):
                raise TypeError(
                    f"unregistered {self._noun} type: {type(value).__name__}"
                )
            result: dict[str, object] = {"$type": type_name}
            for name, field_value in payload_fields(value).items():
                result[name] = self.encode(field_value)
            return result
        raise TypeError(f"unsupported {self._noun} value: {type(value).__name__}")

    def decode(self, value: object) -> object:
        if value is None or isinstance(value, (bool, int, str)):
            return value
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("canonical JSON cannot contain NaN or infinity")
            return value
        if isinstance(value, list):
            raise ValueError(f"untyped JSON arrays are not valid {self._noun} values")
        if not isinstance(value, dict):
            raise TypeError(f"unsupported encoded value: {type(value).__name__}")
        if set(value) == {"$tuple"}:
            items = value["$tuple"]
            if not isinstance(items, list):
                raise ValueError("$tuple must contain an array")
            return tuple(self.decode(item) for item in items)
        if set(value) == {"$map"}:
            items = value["$map"]
            if not isinstance(items, dict):
                raise ValueError("$map must contain an object")
            return FrozenMap((key, self.decode(item)) for key, item in items.items())
        if set(value) == {"$enum", "value"} and value["$enum"] in self._enums:
            return self._enums[value["$enum"]](value["value"])
        if set(value) == {"$as", "value"} and value["$as"] in self._projections:
            return self._projections[value["$as"]].rebuild(self.decode(value["value"]))
        type_name = value.get("$type")
        if not isinstance(type_name, str):
            raise ValueError(f"encoded {self._noun} object is missing $type")
        cls = self._registry.get(type_name)
        if cls is None:
            raise ValueError(f"unknown {self._noun} type: {type_name!r}")
        return self._decode_record(cls, type_name, value)

    def _decode_record(self, cls: type, type_name: str, value: dict) -> object:
        serialized_fields = tuple(
            item for item in fields(cls) if item.metadata.get("serialize", True)
        )
        expected = {item.name for item in serialized_fields}
        optional = {
            item.name
            for item in serialized_fields
            if item.metadata.get("omit_if_default", False)
            and field_default(item) is not MISSING
        }
        required = expected - optional
        supplied = set(value) - {"$type"}
        if not required <= supplied or not supplied <= expected:
            missing = sorted(required - supplied)
            extra = sorted(supplied - expected)
            raise ValueError(
                f"invalid fields for {type_name}: missing={missing!r}, extra={extra!r}"
            )
        decoded = {
            item.name: self.decode(value[item.name])
            for item in serialized_fields
            if item.name in supplied
        }
        by_name = {item.name: item for item in serialized_fields}
        for name in supplied & optional:
            if decoded[name] == field_default(by_name[name]):
                raise ValueError(
                    f"non-canonical explicit default for {type_name}.{name}"
                )
        return cls(**decoded)


__all__ = ["Projection", "TaggedCodec", "field_default", "payload_fields"]
