"""Captured outcomes for isolated policy-evaluation episodes."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.tagged_values import payload_fields
from meta_evolve.domain import EvaluatorFailure, Failure, FrozenMap, RunId, Usage
from meta_evolve.domain.values import _require_text
from meta_evolve.errors import NoSuccessfulEvaluation

from .episodes import PolicySuite
from .model import PolicyArtifact


@dataclass(frozen=True, slots=True, kw_only=True)
class EpisodeOutcome:
    """One isolated inner run and its evaluator-owned cache disposition."""

    suite_digest: str
    split: str
    episode_name: str
    episode_digest: str
    run_id: RunId
    storage_location: str
    policy_digest: str
    quality: float | None
    uncertainty: Mapping[str, object] = field(default_factory=FrozenMap)
    usage: Usage = field(default_factory=Usage)
    failure: Failure | None = None
    incomplete: bool = False
    reused: bool = False

    def __post_init__(self) -> None:
        for value, name in (
            (self.suite_digest, "suite digest"),
            (self.episode_name, "episode name"),
            (self.episode_digest, "episode digest"),
            (self.storage_location, "episode storage location"),
            (self.policy_digest, "policy digest"),
        ):
            _require_text(value, name)
        if self.split not in {"development", "held_out"}:
            raise ValueError("episode split must be development or held_out")
        if not isinstance(self.run_id, RunId):
            raise TypeError("episode run_id must be a RunId")
        if self.quality is not None:
            if isinstance(self.quality, bool) or not isinstance(
                self.quality, (int, float)
            ):
                raise TypeError("episode quality must be numeric or None")
            if not math.isfinite(float(self.quality)):
                raise ValueError("episode quality must be finite")
            object.__setattr__(self, "quality", float(self.quality))
        object.__setattr__(self, "uncertainty", FrozenMap(self.uncertainty))
        if not isinstance(self.usage, Usage):
            raise TypeError("episode usage must be Usage")
        if self.failure is not None and not isinstance(self.failure, Failure):
            raise TypeError("episode failure must be Failure or None")
        if not isinstance(self.incomplete, bool) or not isinstance(self.reused, bool):
            raise TypeError("episode incomplete and reused flags must be bool")
        if self.reused and self.incomplete:
            raise ValueError("an incomplete episode is never a cache hit")

    @property
    def rankable(self) -> bool:
        return self.quality is not None and self.failure is None and not self.incomplete

    @property
    def outer_usage(self) -> Usage:
        """What this episode costs its *outer* run: money and tokens, no counts.

        The inner run's trial and evaluation counts are its own.
        """

        return self.usage.without_counts

    @classmethod
    def from_run(
        cls,
        *,
        suite: PolicySuite,
        split: str,
        episode_name: str,
        run,
        storage_location: str,
        artifact: PolicyArtifact,
        reused: bool = False,
    ) -> EpisodeOutcome:
        episode = next(
            (item for item in suite.episodes(split) if item.name == episode_name), None
        )
        if episode is None:
            raise ValueError("episode does not belong to the declared suite split")
        state = run._projection().search_state
        incomplete = state.stop is None
        failure = None
        quality = None
        uncertainty: Mapping[str, object] = FrozenMap()
        if not incomplete:
            try:
                best = run.best_trial(episode.effective_task.objectives[0].metric)
                quality = best.metrics.get(episode.effective_task.objectives[0].metric)
                uncertainty = best.uncertainty
            except NoSuccessfulEvaluation:
                failure = next(
                    (item.failure for item in run.trials() if item.failure is not None),
                    EvaluatorFailure(message="episode has no rankable evaluation"),
                )
        return cls(
            suite_digest=suite.digest,
            split=split,
            episode_name=episode.name,
            episode_digest=episode.digest,
            run_id=run.id,
            storage_location=storage_location,
            policy_digest=artifact.digest,
            quality=quality,
            uncertainty=uncertainty,
            usage=state.usage,
            failure=failure,
            incomplete=incomplete,
            reused=reused,
        )

    def to_payload(self) -> FrozenMap:
        return FrozenMap(
            {
                "suite_digest": self.suite_digest,
                "split": self.split,
                "episode_name": self.episode_name,
                "episode_digest": self.episode_digest,
                "run_id": self.run_id.value,
                "storage_location": self.storage_location,
                "policy_digest": self.policy_digest,
                "quality": self.quality,
                "uncertainty": self.uncertainty,
                "usage": _usage_payload(self.usage),
                "failure": _failure_payload(self.failure),
                "incomplete": self.incomplete,
                "reused": self.reused,
            }
        )

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> EpisodeOutcome:
        fields = {
            "suite_digest", "split", "episode_name", "episode_digest", "run_id",
            "storage_location", "policy_digest", "quality", "uncertainty", "usage",
            "failure", "incomplete", "reused",
        }
        if set(payload) != fields:
            raise ValueError("episode outcome payload has invalid fields")
        return cls(
            suite_digest=payload["suite_digest"],
            split=payload["split"],
            episode_name=payload["episode_name"],
            episode_digest=payload["episode_digest"],
            run_id=RunId(payload["run_id"]),
            storage_location=payload["storage_location"],
            policy_digest=payload["policy_digest"],
            quality=payload["quality"],
            uncertainty=payload["uncertainty"],
            usage=_usage(payload["usage"]),
            failure=_failure(payload["failure"]),
            incomplete=payload["incomplete"],
            reused=payload["reused"],
        )


def _usage_payload(value: Usage) -> FrozenMap:
    # A bare field map -- no `$type` -- derived from the field metadata instead
    # of hand-listed, so a new dimension needs no edit here. `spend_micros` is
    # omitted at its declared default, which is what keeps stored policy
    # experience byte-comparable with runs recorded before spend existed.
    return FrozenMap(payload_fields(value))


def _usage(value: object) -> Usage:
    if not isinstance(value, Mapping):
        raise ValueError("usage payload must be a mapping")
    return Usage(**dict(value))


def _failure_payload(value: Failure | None):
    if value is None:
        return None
    return FrozenMap(
        {"kind": value.kind, "message": value.message, "details": value.details}
    )


def _failure(value: object) -> Failure | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError("failure payload must be a mapping")
    from meta_evolve.domain import (
        InfrastructureFailure,
        InvalidOutput,
        PolicyViolation,
        ProposerFailure,
        ResourceExhausted,
        TimeoutFailure,
    )

    types = (
        InvalidOutput,
        ProposerFailure,
        EvaluatorFailure,
        TimeoutFailure,
        ResourceExhausted,
        PolicyViolation,
        InfrastructureFailure,
    )
    failure_type = {item.kind: item for item in types}.get(value.get("kind"))
    if failure_type is None:
        raise ValueError("unknown typed episode failure")
    return failure_type(message=value["message"], details=value["details"])


__all__ = ["EpisodeOutcome"]
