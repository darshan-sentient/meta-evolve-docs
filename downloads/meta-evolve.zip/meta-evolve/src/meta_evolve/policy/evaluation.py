"""All-or-nothing aggregation over captured policy episode outcomes."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from statistics import pstdev
from typing import Literal

from meta_evolve import serialization
from meta_evolve.tagged_values import payload_fields
from meta_evolve.domain import (
    Budget,
    ComponentRef,
    ContentDigest,
    FrozenMap,
    PolicyRef,
    Usage,
)
from meta_evolve.domain.values import _require_text

from .codec import PolicyArtifactCodec
from .episodes import PolicySuite
from .model import PolicyArtifact
from .outcomes import EpisodeOutcome


Split = Literal["development", "held_out"]


@dataclass(frozen=True, slots=True, kw_only=True)
class PolicyEvaluation:
    """Every episode outcome plus deterministic aggregate evidence."""

    suite: PolicySuite | FrozenMap
    split: Split
    artifact: PolicyArtifact
    outcomes: tuple[EpisodeOutcome, ...]
    evaluator: ComponentRef | str
    aggregation_version: str
    scoring_version: str
    metric: str = "score"
    direction: Literal["maximize", "minimize"] = "maximize"
    outer_budget: Budget = field(default_factory=Budget)
    declarations: Mapping[str, object] = field(default_factory=FrozenMap)
    candidate_policy: PolicyRef = PolicyRef("candidate-policy", "1")

    def __post_init__(self) -> None:
        if not isinstance(self.suite, (PolicySuite, FrozenMap)):
            raise TypeError("policy evaluation suite must be PolicySuite or payload")
        if self.split not in {"development", "held_out"}:
            raise ValueError("policy evaluation split must be development or held_out")
        if not isinstance(self.artifact, PolicyArtifact):
            raise TypeError("policy evaluation artifact must be PolicyArtifact")
        PolicyArtifactCodec().decode(PolicyArtifactCodec().encode(self.artifact))
        if not isinstance(self.outcomes, tuple) or not all(
            isinstance(item, EpisodeOutcome) for item in self.outcomes
        ):
            raise TypeError("policy evaluation outcomes must be EpisodeOutcome values")
        if not isinstance(self.evaluator, (ComponentRef, str)):
            raise TypeError(
                "policy evaluation evaluator must be a component or identity"
            )
        for value, name in (
            (self.aggregation_version, "aggregation version"),
            (self.scoring_version, "scoring version"),
            (self.metric, "evaluation metric"),
        ):
            _require_text(value, name)
        if self.direction not in {"maximize", "minimize"}:
            raise ValueError("policy evaluation direction must be maximize or minimize")
        if not isinstance(self.outer_budget, Budget):
            raise TypeError("policy evaluation outer_budget must be Budget")
        object.__setattr__(self, "declarations", FrozenMap(self.declarations))
        if self.candidate_policy != PolicyRef("candidate-policy", "1"):
            raise ValueError("policy evaluation requires candidate-policy@1")
        names = tuple(item.episode_name for item in self.outcomes)
        if len(names) != len(set(names)):
            raise ValueError("policy evaluation outcomes must name unique episodes")
        expected = {
            item["name"]: ContentDigest.for_payload(item).value
            for item in self.suite_payload[self.split]
        }
        if not set(names) <= set(expected):
            raise ValueError("policy evaluation outcome is not in the suite split")
        for item in self.outcomes:
            if item.suite_digest != self.suite_digest or item.split != self.split:
                raise ValueError(
                    "episode outcome belongs to a different suite or split"
                )
            if item.policy_digest != self.artifact.digest:
                raise ValueError(
                    "episode outcome belongs to a different policy artifact"
                )
            if item.episode_digest != expected[item.episode_name]:
                raise ValueError("episode outcome digest does not match the suite")

    @property
    def suite_payload(self) -> FrozenMap:
        if isinstance(self.suite, PolicySuite):
            return self.suite.to_payload()
        return self.suite

    @property
    def suite_digest(self) -> str:
        return ContentDigest.for_payload(self.suite_payload).value

    @property
    def expected_names(self) -> tuple[str, ...]:
        return tuple(item["name"] for item in self.suite_payload[self.split])

    @property
    def rankable(self) -> bool:
        by_name = {item.episode_name: item for item in self.outcomes}
        return set(by_name) == set(self.expected_names) and all(
            by_name[name].rankable for name in self.expected_names
        )

    @property
    def quality(self) -> float | None:
        if not self.rankable:
            return None
        return sum(float(item.quality) for item in self.outcomes) / len(self.outcomes)

    @property
    def robustness(self) -> float | None:
        if not self.rankable:
            return None
        values = tuple(float(item.quality) for item in self.outcomes)
        return min(values) if self.direction == "maximize" else max(values)

    @property
    def uncertainty(self) -> float | None:
        if not self.rankable:
            return None
        return pstdev(float(item.quality) for item in self.outcomes)

    @property
    def success_count(self) -> int:
        return sum(item.rankable for item in self.outcomes)

    @property
    def failure_count(self) -> int:
        return len(self.expected_names) - self.success_count

    @property
    def total_usage(self) -> Usage:
        return sum((item.usage for item in self.outcomes), Usage())

    @property
    def actual_cost(self) -> Usage:
        return self.total_usage

    @property
    def outer_usage(self) -> Usage:
        return sum((item.outer_usage for item in self.outcomes), Usage())

    @property
    def evaluator_identity(self) -> str:
        if isinstance(self.evaluator, str):
            return self.evaluator
        return serialization.identity_content(self.evaluator)

    @property
    def comparison_controls(self) -> FrozenMap:
        return FrozenMap({
            "suite": self.suite_payload,
            "split": self.split,
            "evaluator": self.evaluator_identity,
            "aggregation": self.aggregation_version,
            "scoring": self.scoring_version,
            "metric": self.metric,
            "direction": self.direction,
            "outer_budget": _budget_payload(self.outer_budget),
            "candidate_policy": {"name": "candidate-policy", "version": "1"},
            "declarations": self.declarations,
        })

    def to_payload(self) -> FrozenMap:
        return FrozenMap({
            "schema": "policy-evaluation/v1",
            "suite": self.suite_payload,
            "split": self.split,
            "artifact": PolicyArtifactCodec().encode(self.artifact),
            "outcomes": tuple(item.to_payload() for item in self.outcomes),
            "evaluator": self.evaluator_identity,
            "aggregation_version": self.aggregation_version,
            "scoring_version": self.scoring_version,
            "metric": self.metric,
            "direction": self.direction,
            "outer_budget": _budget_payload(self.outer_budget),
            "declarations": self.declarations,
        })

    @classmethod
    def from_payload(cls, payload: Mapping[str, object]) -> PolicyEvaluation:
        fields = {
            "schema", "suite", "split", "artifact", "outcomes", "evaluator",
            "aggregation_version", "scoring_version", "metric", "direction",
            "outer_budget", "declarations",
        }
        if set(payload) != fields or payload["schema"] != "policy-evaluation/v1":
            raise ValueError("policy evaluation payload has invalid schema or fields")
        return cls(
            suite=FrozenMap(payload["suite"]),
            split=payload["split"],
            artifact=PolicyArtifactCodec().decode(payload["artifact"]),
            outcomes=tuple(
                EpisodeOutcome.from_payload(item) for item in payload["outcomes"]
            ),
            evaluator=payload["evaluator"],
            aggregation_version=payload["aggregation_version"],
            scoring_version=payload["scoring_version"],
            metric=payload["metric"],
            direction=payload["direction"],
            outer_budget=_budget(payload["outer_budget"]),
            declarations=payload["declarations"],
        )


def _budget_payload(value: Budget) -> FrozenMap:
    # Same helper as the Usage codec, because it is the same rule: omit at the
    # field's declared default. That reads as `is not None` here and as `!= 0`
    # for Usage only because the two defaults differ -- and a $0 ceiling, which
    # means free-work-only, is therefore recorded rather than omitted. Omitting
    # it would decode back as None, i.e. unbounded.
    return FrozenMap(payload_fields(value))


def _budget(value: object) -> Budget:
    if not isinstance(value, Mapping):
        raise ValueError("budget payload must be a mapping")
    return Budget(**dict(value))


__all__ = ["EpisodeOutcome", "PolicyEvaluation", "Split"]
