"""Canonical policy-manifest codec and trusted successor validation."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from meta_evolve.domain import Failure, FrozenMap, InvalidOutput, PolicyViolation
from meta_evolve.domain.values import FrozenValue

from .model import ParentSelection, PolicyArtifact, TrialLimit


def _component(value) -> FrozenMap:
    return FrozenMap(
        {
            "role": value.role,
            "name": value.name,
            "version": value.version,
            "origin": value.origin,
        }
    )


def _parent_payload(value: ParentSelection) -> FrozenMap:
    return FrozenMap(
        {
            "type": "enum",
            "name": value.name,
            "component": _component(value.component),
            "interface": value.interface,
            "allowed": ("seed", "incumbent"),
            "mode": value.mode,
        }
    )


def _limit_payload(value: TrialLimit) -> FrozenMap:
    return FrozenMap(
        {
            "type": "integer",
            "name": value.name,
            "component": _component(value.component),
            "interface": value.interface,
            "minimum": 0,
            "max_trials": value.max_trials,
        }
    )


@dataclass(frozen=True, slots=True)
class PolicyArtifactCodec:
    """Translate policy manifests and reject authority-changing successors."""

    kind: str = PolicyArtifact.KIND
    representation: str = PolicyArtifact.REPRESENTATION
    interfaces: tuple[str, ...] = ("candidate-policy/v1",)

    def encode(self, value: object) -> FrozenValue:
        if not isinstance(value, PolicyArtifact):
            raise TypeError("search-policy tasks require a PolicyArtifact value")
        return FrozenMap(
            {
                "schema": "search-policy/v1",
                "parent_selection": _parent_payload(value.parent_selection),
                "trial_limit": _limit_payload(value.trial_limit),
            }
        )

    def decode(self, payload: FrozenValue) -> PolicyArtifact:
        manifest = _fields(
            payload,
            {"schema", "parent_selection", "trial_limit"},
            "policy manifest",
        )
        if manifest["schema"] != "search-policy/v1":
            raise ValueError("unsupported policy manifest schema")
        parent = _fields(
            manifest["parent_selection"],
            {"type", "name", "component", "interface", "allowed", "mode"},
            "parent selection",
        )
        limit = _fields(
            manifest["trial_limit"],
            {"type", "name", "component", "interface", "minimum", "max_trials"},
            "trial limit",
        )
        expected_parent = _parent_payload(ParentSelection("seed"))
        expected_limit = _limit_payload(TrialLimit(0))
        _fixed(parent, expected_parent, mutable={"mode"}, name="parent selection")
        _fixed(limit, expected_limit, mutable={"max_trials"}, name="trial limit")
        return PolicyArtifact(
            parent_selection=ParentSelection(parent["mode"]),
            trial_limit=TrialLimit(limit["max_trials"]),
        )

    def validate_successor(
        self, parents: tuple[FrozenValue, ...], candidate: FrozenValue
    ) -> Failure | None:
        if len(parents) != 1:
            return InvalidOutput(
                message="policy mutation requires exactly one parent",
                details={"parent_count": len(parents)},
            )
        changed = _changed_declarations(candidate)
        if changed:
            return PolicyViolation(
                message="policy successor expands mutation authority",
                details={"changed_declarations": changed},
            )
        try:
            parent = self.decode(parents[0])
            successor = self.decode(candidate)
        except (TypeError, ValueError) as error:
            return InvalidOutput(
                message="policy successor is malformed", details={"error": str(error)}
            )
        if parent == successor:
            return InvalidOutput(message="policy successor is a no-op")
        changed_values = sum(
            (
                parent.parent_selection != successor.parent_selection,
                parent.trial_limit != successor.trial_limit,
            )
        )
        if changed_values != 1:
            return InvalidOutput(
                message="policy mutation must change exactly one declared surface"
            )
        return None


def immutable_declaration_changes(
    parent: PolicyArtifact, successor: PolicyArtifact
) -> tuple[str, ...]:
    changed: list[str] = []
    for name in ("parent_selection", "trial_limit"):
        before = getattr(parent, name)
        after = getattr(successor, name)
        if type(before) is not type(after):
            changed.append(f"{name}.type")
            continue
        for attribute in ("name", "component", "interface"):
            if getattr(before, attribute) != getattr(after, attribute):
                changed.append(f"{name}.{attribute}")
    return tuple(changed)


def _fields(value: object, fields: set[str], name: str) -> Mapping:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise ValueError(f"{name} has invalid fields")
    return value


def _fixed(value: Mapping, expected: Mapping, *, mutable: set[str], name: str) -> None:
    if any(value[key] != expected[key] for key in set(expected) - mutable):
        raise ValueError(f"{name} declaration does not match schema v1")


def _changed_declarations(payload: object) -> tuple[str, ...]:
    if not isinstance(payload, Mapping):
        return ()
    manifest_fields = {"schema", "parent_selection", "trial_limit"}
    if set(payload) != manifest_fields:
        if set(payload) & {"parent_selection", "trial_limit"}:
            return ("manifest.structure",)
        return ()
    expected = {
        "parent_selection": _parent_payload(ParentSelection("seed")),
        "trial_limit": _limit_payload(TrialLimit(0)),
    }
    mutable = {"parent_selection": {"mode"}, "trial_limit": {"max_trials"}}
    changed: list[str] = []
    for surface, declaration in expected.items():
        actual = payload.get(surface)
        if isinstance(actual, Mapping) and set(actual) != set(declaration):
            changed.append(f"{surface}.structure")
            continue
        if not isinstance(actual, Mapping):
            continue
        for key in set(declaration) - mutable[surface]:
            if actual[key] != declaration[key]:
                changed.append(f"{surface}.{key}")
    return tuple(sorted(changed))


__all__ = ["PolicyArtifactCodec", "immutable_declaration_changes"]
