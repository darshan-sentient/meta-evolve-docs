"""Trusted interpreter for declarative policy artifacts."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    Budget,
    ComponentRef,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.decision_description import (
    DecisionDescription,
    humanize_reason,
)
from meta_evolve.domain.search import PolicyMismatch, SearchState
from meta_evolve.errors import UnboundSearchProgram

from .codec import PolicyArtifactCodec
from .model import PolicyArtifact


@dataclass(frozen=True, slots=True, init=False)
class CandidatePolicy:
    """Built-in search preset configured by a trusted policy manifest."""

    artifact: PolicyArtifact
    policy: PolicyRef = PolicyRef("candidate-policy", "1")
    _proposer: ComponentRef | None = field(default=None, repr=False)
    _operator: OperatorSpec | None = field(default=None, repr=False)
    _budget: Budget | None = field(default=None, repr=False)

    def __init__(self, artifact: PolicyArtifact) -> None:
        if not isinstance(artifact, PolicyArtifact):
            raise TypeError("CandidatePolicy artifact must be a PolicyArtifact")
        object.__setattr__(self, "artifact", artifact)
        object.__setattr__(self, "policy", PolicyRef("candidate-policy", "1"))
        object.__setattr__(self, "_proposer", None)
        object.__setattr__(self, "_operator", None)
        object.__setattr__(self, "_budget", None)

    @property
    def bound(self) -> bool:
        return all(
            value is not None
            for value in (self._proposer, self._operator, self._budget)
        )

    @property
    def configuration(self) -> Mapping[str, object]:
        return {"artifact": PolicyArtifactCodec().encode(self.artifact)}

    @property
    def identity_key(self) -> str:
        return f"candidate-policy:artifact={self.artifact.digest}"

    def bind(self, proposer: ComponentRef, budget: Budget) -> CandidatePolicy:
        if self.bound:
            raise ValueError("candidate policy is already bound")
        if not isinstance(proposer, ComponentRef) or proposer.role != "proposer":
            raise TypeError("candidate policy proposer must be a proposer reference")
        if not isinstance(budget, Budget):
            raise TypeError("candidate policy budget must be a Budget")
        result = CandidatePolicy(self.artifact)
        object.__setattr__(result, "_proposer", proposer)
        object.__setattr__(result, "_operator", OperatorSpec(kind="mutate"))
        object.__setattr__(
            result,
            "_budget",
            Budget(
                trials=1,
                evaluations=1,
                tokens=budget.tokens,
                wall_seconds=budget.wall_seconds,
            ),
        )
        return result

    def next(self, state: SearchState) -> SearchDecision:
        if not self.bound:
            raise UnboundSearchProgram(
                "CandidatePolicy must be passed to meta_evolve.run before next()"
            )
        start = state.require_start()
        if start.search.policy != self.policy:
            raise PolicyMismatch(self.policy, start.search.policy)
        if state.stop is not None:
            return state.stop
        if state.objective_satisfied:
            return Stop(reason="objective_satisfied")
        if state.usage.trials >= self.artifact.trial_limit.max_trials:
            return Stop(reason="trial_limit_reached")
        if state.budget_exhausted:
            return Stop(reason=state.budget_stop_reason)
        parent_id = start.seed_artifact_id
        if self.artifact.parent_selection.mode == "incumbent":
            parent_id = state.incumbent_id or parent_id
        assert self._proposer is not None
        assert self._operator is not None
        assert self._budget is not None
        return TrialSpec(
            task_id=start.task_id,
            parent_ids=(parent_id,),
            proposer=self._proposer,
            operator=self._operator,
            budget=self._budget.narrow(state.remaining_budget),
            random_seed=state.randomness.seed("trial"),
        )

    def describe_decision(
        self, state: SearchState, decision: SearchDecision
    ) -> DecisionDescription:
        if isinstance(decision, TrialSpec):
            seed_id = state.require_start().seed_artifact_id
            role = "seed" if decision.parent_ids[0] == seed_id else "incumbent"
            return DecisionDescription(
                f"candidate policy; expand {role}",
                ("trial",),
            )
        return DecisionDescription(
            f"stop candidate policy: {humanize_reason(decision.reason)}"
        )


def candidate_policy_factory(configuration: Mapping[str, object]) -> CandidatePolicy:
    """Rebuild ``candidate-policy@1`` from its exact recorded payload."""

    if set(configuration) != {"artifact"}:
        raise ValueError("candidate-policy@1 configuration must contain artifact")
    artifact = PolicyArtifactCodec().decode(configuration["artifact"])
    return CandidatePolicy(artifact)


__all__ = ["CandidatePolicy", "candidate_policy_factory"]
