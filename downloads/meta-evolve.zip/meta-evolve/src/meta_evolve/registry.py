"""Explicit, non-ambient component registry.

Above the ~300-line guideline by design: every method registers or resolves
one of the five (role, name, version)-keyed tables this class owns, sharing
one collision shape. State-free codec validation lives in
``registry_support``; what remains is registry policy and reads as one piece.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping

from .application.codecs import BUILTIN_CODECS
from .application.search_preparation import PreparedSearch, prepare_search
from .domain import Budget, ComponentManifest, ComponentRef, ContextSpec, SearchSpec
from .errors import CapabilityError
from .manifests import require_source_function, SourceDependency
from .policies import ContextPolicy
from .policies import _tree_search as tree_search_support
from .ports.codecs import ArtifactCodec
from .registry_support import (
    ancestors_context_factory,
    best_of_k_factory,
    best_of_n_factory,
    best_sibling_context_factory,
    candidate_policy_factory,
    ComponentEntry,
    context_policy_manifest,
    ContextPolicyFactory,
    greedy_factory,
    PolicyEntry,
    policy_manifest,
    PolicyFactory,
    population_factory,
    resolve_component,
    specialists_factory,
    tree_search_factory,
    validate_artifact_codec,
)


class Registry:
    """(role, name, version)-keyed components and policy factories."""

    def __init__(self) -> None:
        self._proposers: dict[tuple[str, str], ComponentEntry] = {}
        self._evaluators: dict[tuple[str, str], ComponentEntry] = {}
        self._policies: dict[tuple[str, str], PolicyEntry] = {}
        self._context_policies: dict[tuple[str, str], ComponentEntry] = {}
        self._artifact_types: dict[tuple[str, str], ArtifactCodec] = {}
        self._register_builtin_policies()
        self._register_builtin_context_policies()

    def _register_builtin_policies(self) -> None:
        self.register_policy(
            "greedy", "1", greedy_factory, deterministic=True, retry_safe=True
        )
        self.register_policy(
            "best-of-n", "1", best_of_n_factory, deterministic=True, retry_safe=True
        )
        self.register_policy(
            "best-of-k", "1", best_of_k_factory, deterministic=True, retry_safe=True
        )
        self.register_policy(
            "population", "1", population_factory, deterministic=True, retry_safe=True
        )
        self.register_policy(
            "specialists", "1", specialists_factory, deterministic=True, retry_safe=True
        )
        self.register_policy(
            "tree-search",
            "1",
            tree_search_factory,
            deterministic=True,
            retry_safe=True,
            dependencies=(tree_search_support,),
        )
        self.register_policy(
            "candidate-policy",
            "1",
            candidate_policy_factory,
            deterministic=True,
            retry_safe=True,
        )

    def _register_builtin_context_policies(self) -> None:
        self.register_context_policy(
            "ancestors-only",
            "1",
            ancestors_context_factory,
            deterministic=True,
            retry_safe=True,
        )
        self.register_context_policy(
            "best-sibling",
            "1",
            best_sibling_context_factory,
            deterministic=True,
            retry_safe=True,
        )

    def register_proposer(
        self,
        name: str,
        version: str,
        fn: Callable[..., object],
        *,
        deterministic: bool,
        retry_safe: bool,
        dependencies: Iterable[SourceDependency] = (),
        configuration: Mapping[str, object] | None = None,
    ) -> ComponentRef:
        return self._register_component(
            self._proposers,
            "proposer",
            name,
            version,
            fn,
            deterministic,
            retry_safe,
            dependencies,
            configuration,
        )

    def register_evaluator(
        self,
        name: str,
        version: str,
        fn: Callable[..., object],
        *,
        deterministic: bool,
        retry_safe: bool,
        dependencies: Iterable[SourceDependency] = (),
        configuration: Mapping[str, object] | None = None,
    ) -> ComponentRef:
        return self._register_component(
            self._evaluators,
            "evaluator",
            name,
            version,
            fn,
            deterministic,
            retry_safe,
            dependencies,
            configuration,
        )

    def register_policy(
        self,
        name: str,
        version: str,
        factory: PolicyFactory,
        *,
        deterministic: bool,
        retry_safe: bool,
        dependencies: Iterable[SourceDependency] = (),
    ) -> None:
        if not callable(factory):
            raise TypeError("policy factory must be callable")
        dependencies = tuple(dependencies)
        require_source_function(
            factory,
            f"policy {name}@{version} factory",
            dependencies=dependencies,
        )
        key = (name, version)
        existing = self._policies.get(key)
        if existing is not None and existing.factory is not factory:
            raise ValueError(
                f"policy {name}@{version} is already registered with different code"
            )
        self._policies[key] = PolicyEntry(
            factory=factory,
            deterministic=bool(deterministic),
            retry_safe=bool(retry_safe),
            dependencies=dependencies,
        )

    def register_context_policy(
        self,
        name: str,
        version: str,
        factory: ContextPolicyFactory,
        *,
        deterministic: bool,
        retry_safe: bool,
        dependencies: Iterable[SourceDependency] = (),
    ) -> None:
        """Register a module-level factory that rebuilds a context policy."""

        if not callable(factory):
            raise TypeError("context policy factory must be callable")
        dependencies = tuple(dependencies)
        require_source_function(
            factory,
            f"context policy {name}@{version} factory",
            dependencies=dependencies,
        )
        key = (name, version)
        existing = self._context_policies.get(key)
        if existing is not None and existing.fn is not factory:
            raise ValueError(
                f"context policy {name}@{version} is already registered with "
                "different code"
            )
        self._context_policies[key] = ComponentEntry(
            fn=factory,
            deterministic=bool(deterministic),
            retry_safe=bool(retry_safe),
            dependencies=dependencies,
        )

    def resolve_context_policy(self, spec: ContextSpec) -> ContextPolicy:
        """Rebuild a context policy and confirm its declaration round-trips."""

        entry = self._context_policies.get((spec.policy.name, spec.policy.version))
        if entry is None:
            raise CapabilityError(
                f"unregistered context policy {spec.policy.name}@{spec.policy.version}"
            )
        rebuilt = entry.fn(spec)
        if (
            rebuilt.policy != spec.policy
            or rebuilt.max_records != spec.max_records
            or rebuilt.max_chars != spec.max_chars
        ):
            raise CapabilityError(
                "rebuilt context policy does not match the recorded spec"
            )
        return rebuilt

    def register_artifact_type(self, codec: ArtifactCodec) -> None:
        """Register one artifact codec keyed by (kind, representation).

        Built-in keys are non-overridable — every codec offered for one is
        rejected, the built-in object included: a new decode under an old key
        would change the meaning of every artifact already committed under it,
        so different behavior needs a new key.
        """

        validate_artifact_codec(codec)
        key = (codec.kind, codec.representation)
        if key in BUILTIN_CODECS:
            raise ValueError(f"artifact type {key!r} is built-in and not overridable")
        existing = self._artifact_types.get(key)
        if existing is not None and existing is not codec:
            raise ValueError(f"artifact type {key!r} is already registered")
        self._artifact_types[key] = codec

    def artifact_types(self) -> dict[tuple[str, str], ArtifactCodec]:
        return dict(self._artifact_types)

    def artifact_interfaces(self, kind: str, representation: str) -> tuple[str, ...]:
        codec = self._artifact_types.get((kind, representation))
        if codec is None:
            codec = BUILTIN_CODECS.get((kind, representation))
        if codec is None:
            raise KeyError((kind, representation))
        return codec.interfaces

    def _register_component(
        self,
        table: dict[tuple[str, str], ComponentEntry],
        role: str,
        name: str,
        version: str,
        fn: Callable[..., object],
        deterministic: bool,
        retry_safe: bool,
        dependencies: Iterable[SourceDependency],
        configuration: Mapping[str, object] | None,
    ) -> ComponentRef:
        if not callable(fn):
            raise TypeError(f"{role} implementation must be callable")
        dependencies = tuple(dependencies)
        require_source_function(
            fn, f"{role} {name}@{version}", dependencies=dependencies
        )
        key = (name, version)
        existing = table.get(key)
        if existing is not None and existing.fn is not fn:
            raise ValueError(
                f"{role} {name}@{version} is already registered with different code"
            )
        table[key] = ComponentEntry(
            fn=fn,
            deterministic=bool(deterministic),
            retry_safe=bool(retry_safe),
            dependencies=dependencies,
            configuration=configuration,
        )
        return ComponentRef(role=role, name=name, version=version)

    def resolve_proposer(
        self, ref: ComponentRef
    ) -> tuple[Callable[..., object], ComponentManifest]:
        return resolve_component(self._proposers, "proposer", ref)

    def resolve_evaluator(
        self, ref: ComponentRef
    ) -> tuple[Callable[..., object], ComponentManifest]:
        return resolve_component(self._evaluators, "evaluator", ref)

    def resolve_policy(self, spec: SearchSpec, *, budget: Budget) -> PreparedSearch:
        """Rebuild a bound program from ``spec`` and confirm it round-trips.

        Constructs the unbound preset from the registered factory and
        ``spec.configuration``, binds it against ``proposer``/``budget``,
        and asserts the rebuilt ``SearchSpec`` equals ``spec`` exactly —
        the same check M4.4's ``resume`` relies on (there, ``budget`` is
        the recorded ``RunStarted.run_budget``).
        """

        entry = self._policies.get((spec.policy.name, spec.policy.version))
        if entry is None:
            raise CapabilityError(
                f"unregistered policy {spec.policy.name}@{spec.policy.version}"
            )
        program = entry.factory(dict(spec.configuration))
        prepared = prepare_search(program, proposer=spec.proposer, budget=budget)
        if prepared.spec != spec:
            raise CapabilityError("rebuilt SearchSpec does not match the recorded one")
        return prepared

    def _policy_manifest(self, spec: SearchSpec) -> ComponentManifest:
        entry = self._policies.get((spec.policy.name, spec.policy.version))
        if entry is None:
            raise CapabilityError(
                f"unregistered policy {spec.policy.name}@{spec.policy.version}"
            )
        return policy_manifest(entry, spec)

    def _context_policy_manifest(self, spec: ContextSpec) -> ComponentManifest:
        rebuilt = self.resolve_context_policy(spec)
        entry = self._context_policies[(spec.policy.name, spec.policy.version)]
        return context_policy_manifest(entry, spec, rebuilt)

    def manifests_for(
        self,
        *,
        proposer: ComponentRef,
        evaluator: ComponentRef,
        search: SearchSpec,
        context: ContextSpec | None = None,
    ) -> tuple[ComponentManifest, ...]:
        _, proposer_manifest = self.resolve_proposer(proposer)
        _, evaluator_manifest = self.resolve_evaluator(evaluator)
        policy_manifest = self._policy_manifest(search)
        manifests = (proposer_manifest, evaluator_manifest, policy_manifest)
        if context is not None:
            manifests += (self._context_policy_manifest(context),)
        return manifests


__all__ = ["ContextPolicyFactory", "PolicyFactory", "Registry"]
