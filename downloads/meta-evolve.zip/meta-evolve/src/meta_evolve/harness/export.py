"""Crash-safe filesystem egress for explicitly selected harness artifacts."""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

from meta_evolve.application.results import ArtifactView
from meta_evolve.domain import ComponentRef, ContentDigest

from .codec import HarnessArtifactCodec
from .model import HarnessArtifact, PolicyParam, TextParam


_MANIFEST = "harness-manifest.json"
_FILES = frozenset({_MANIFEST, "planner.md", "context-policy.json"})


@dataclass(frozen=True, slots=True)
class HarnessExport:
    destination: Path
    artifact_id: str
    digest: str


def export_harness(
    artifact: ArtifactView,
    destination: str | os.PathLike[str],
    overwrite: bool = False,
) -> HarnessExport:
    """Export one selected harness view with validation and atomic placement."""

    if not isinstance(artifact, ArtifactView):
        raise TypeError("artifact must be an ArtifactView returned by a run")
    if not isinstance(artifact.value, HarnessArtifact):
        raise TypeError("artifact view must contain a HarnessArtifact")
    if (
        artifact.kind != HarnessArtifact.KIND
        or artifact.representation != HarnessArtifact.REPRESENTATION
    ):
        raise ValueError("artifact view does not declare the harness schema")
    if not isinstance(overwrite, bool):
        raise TypeError("overwrite must be a bool")
    target = Path(destination)
    if not target.name:
        raise ValueError("destination must name a harness export directory")
    _reject_symlinks(target.parent)
    if not target.parent.is_dir():
        raise ValueError("destination parent must be an existing directory")
    if target.exists() or target.is_symlink():
        if target.is_symlink():
            raise ValueError("harness export destination must not be a symlink")
        if not overwrite:
            raise FileExistsError(f"harness export destination exists: {target}")
        load_harness(target)

    stage = Path(tempfile.mkdtemp(prefix=f".{target.name}.stage-", dir=target.parent))
    backup: Path | None = None
    try:
        _write_export(stage, artifact)
        reconstructed = load_harness(stage)
        digest = ContentDigest.for_payload(
            HarnessArtifactCodec().encode(reconstructed)
        ).value
        if digest != artifact.digest:
            raise ValueError("reconstructed harness digest does not match artifact")
        if target.exists():
            backup = Path(
                tempfile.mkdtemp(
                    prefix=f".{target.name}.backup-", dir=target.parent
                )
            )
            backup.rmdir()
            os.replace(target, backup)
        try:
            os.replace(stage, target)
        except Exception:
            if backup is not None and not target.exists():
                os.replace(backup, target)
                backup = None
            raise
        if backup is not None:
            shutil.rmtree(backup)
            backup = None
        return HarnessExport(target, artifact.id.value, artifact.digest)
    finally:
        if stage.exists() and not stage.is_symlink():
            shutil.rmtree(stage)
        if backup is not None and backup.exists() and not target.exists():
            os.replace(backup, target)


def load_harness(destination: str | os.PathLike[str]) -> HarnessArtifact:
    """Load and strictly validate a prior Meta-Evolve harness export."""

    root = Path(destination)
    _reject_symlinks(root)
    if not root.is_dir():
        raise ValueError("harness export must be a directory")
    entries = {item.name for item in root.iterdir()}
    if entries != _FILES:
        raise ValueError("directory is not a valid Meta-Evolve harness export")
    for name in _FILES:
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError("harness exports contain only regular files")
    try:
        manifest = json.loads((root / _MANIFEST).read_text(encoding="utf-8"))
        configuration = json.loads(
            (root / "context-policy.json").read_text(encoding="utf-8")
        )
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("harness export contains invalid UTF-8 JSON") from error
    expected = {
        "schema",
        "artifact_id",
        "digest",
        "kind",
        "representation",
        "planner",
        "context_policy",
    }
    if not isinstance(manifest, dict) or set(manifest) != expected:
        raise ValueError("harness export manifest has invalid fields")
    if (
        manifest["schema"] != "meta-evolve-harness-export/v1"
        or manifest["kind"] != HarnessArtifact.KIND
        or manifest["representation"] != HarnessArtifact.REPRESENTATION
    ):
        raise ValueError("harness export manifest has unsupported schema")
    if not isinstance(manifest["artifact_id"], str) or not manifest["artifact_id"]:
        raise ValueError("harness export artifact_id must be non-empty text")
    if not isinstance(manifest["digest"], str) or not manifest["digest"]:
        raise ValueError("harness export digest must be non-empty text")
    planner = _parameter_manifest(manifest["planner"], "planner")
    policy = _parameter_manifest(manifest["context_policy"], "context_policy")
    result = HarnessArtifact(
        planner=TextParam(
            planner["name"],
            _component(planner["component"]),
            planner["interface"],
            (root / "planner.md").read_text(encoding="utf-8"),
        ),
        context_policy=PolicyParam(
            policy["name"],
            _component(policy["component"]),
            policy["interface"],
            configuration,
        ),
    )
    digest = ContentDigest.for_payload(HarnessArtifactCodec().encode(result)).value
    if digest != manifest["digest"]:
        raise ValueError("harness export content does not match its digest")
    return result


def _write_export(root: Path, artifact: ArtifactView) -> None:
    value = artifact.value
    assert isinstance(value, HarnessArtifact)
    (root / "planner.md").write_text(value.planner.value, encoding="utf-8")
    (root / "context-policy.json").write_text(
        json.dumps(
            _plain(value.context_policy.configuration),
            sort_keys=True,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    manifest = {
        "schema": "meta-evolve-harness-export/v1",
        "artifact_id": artifact.id.value,
        "digest": artifact.digest,
        "kind": artifact.kind,
        "representation": artifact.representation,
        "planner": _surface_manifest(value.planner),
        "context_policy": _surface_manifest(value.context_policy),
    }
    (root / _MANIFEST).write_text(
        json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )


def _surface_manifest(value: TextParam | PolicyParam) -> dict[str, object]:
    return {
        "name": value.name,
        "component": {
            "role": value.component.role,
            "name": value.component.name,
            "version": value.component.version,
            "origin": value.component.origin,
        },
        "interface": value.interface,
    }


def _parameter_manifest(value: object, name: str) -> dict:
    if not isinstance(value, dict) or set(value) != {
        "name",
        "component",
        "interface",
    }:
        raise ValueError(f"harness export {name} declaration is invalid")
    return value


def _component(value: object) -> ComponentRef:
    if not isinstance(value, dict) or set(value) != {
        "role",
        "name",
        "version",
        "origin",
    }:
        raise ValueError("harness export component declaration is invalid")
    return ComponentRef(**value)


def _reject_symlinks(path: Path) -> None:
    if path.is_symlink():
        raise ValueError(f"harness export paths must not use symlinks: {path}")


def _plain(value: object) -> object:
    if isinstance(value, dict) or hasattr(value, "items"):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_plain(item) for item in value]
    return value


__all__ = ["HarnessExport", "export_harness", "load_harness"]
