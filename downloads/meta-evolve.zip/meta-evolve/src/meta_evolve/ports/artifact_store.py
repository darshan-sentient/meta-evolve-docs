"""Artifact storage contract and typed failures."""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain import Artifact, ArtifactId


class ArtifactNotFound(LookupError):
    def __init__(self, artifact_id: ArtifactId) -> None:
        self.artifact_id = artifact_id
        super().__init__(f"artifact not found: {artifact_id}")


class ArtifactConflict(ValueError):
    def __init__(self, artifact_id: ArtifactId) -> None:
        self.artifact_id = artifact_id
        super().__init__(f"artifact id already stores different content: {artifact_id}")


class ArtifactStore(Protocol):
    def put(self, artifact: Artifact) -> None: ...

    def get(self, artifact_id: ArtifactId) -> Artifact: ...


__all__ = ["ArtifactConflict", "ArtifactNotFound", "ArtifactStore"]
