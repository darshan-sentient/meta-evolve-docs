"""Exact-file patch commands and rich patcher results."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain.evaluation import Failure
from meta_evolve.domain.experience import ExperienceRef
from meta_evolve.domain.task import Usage
from meta_evolve.domain.values import FrozenMap, _freeze_map_field, _require_text

from .callables import EvidenceDraft, _validate_evidence, _validate_failure


_MISSING = object()


@dataclass(frozen=True, slots=True, kw_only=True)
class TextPatch:
    """Replace one complete file only when its expected text still matches.

    ``path`` names a repository-relative file; ``expected`` holds the exact
    parent text and ``replacement`` the complete new text. A stale patch is
    invalid output, not a silently applied overwrite.
    """

    path: str
    expected: str
    replacement: str

    def __post_init__(self) -> None:
        _require_text(self.path, "patch path")
        if not isinstance(self.expected, str):
            raise TypeError("patch expected content must be text")
        if not isinstance(self.replacement, str):
            raise TypeError("patch replacement content must be text")


@dataclass(frozen=True, slots=True, kw_only=True)
class PatchResult:
    """A patch command or typed proposer failure with proposal observations."""

    patch: TextPatch | object = field(default=_MISSING)
    failure: Failure | None = None
    hypothesis: str | None = None
    predicted_outcomes: FrozenMap | Mapping[str, object] = field(
        default_factory=FrozenMap
    )
    metadata: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence: tuple[EvidenceDraft, ...] = ()
    usage: Usage = Usage()
    derived_from: tuple[ExperienceRef, ...] = ()

    def __post_init__(self) -> None:
        failure = _validate_failure(self.failure)
        if failure is None:
            if not isinstance(self.patch, TextPatch):
                raise ValueError("a successful patch result requires a TextPatch")
        else:
            if self.patch is not _MISSING:
                raise ValueError("a failed patch result cannot carry a patch")
            object.__setattr__(self, "patch", None)
        if self.hypothesis is not None:
            _require_text(self.hypothesis, "patch hypothesis")
        _freeze_map_field(self, "predicted_outcomes")
        _freeze_map_field(self, "metadata")
        object.__setattr__(self, "evidence", _validate_evidence(self.evidence))
        if not isinstance(self.usage, Usage):
            raise TypeError("patch result usage must be a Usage")
        if not isinstance(self.derived_from, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.derived_from
        ):
            raise TypeError("patch result derivation must contain ExperienceRefs")
        if len(self.derived_from) != len(set(self.derived_from)):
            raise ValueError("patch result derivation references must be unique")


__all__ = ["PatchResult", "TextPatch"]
