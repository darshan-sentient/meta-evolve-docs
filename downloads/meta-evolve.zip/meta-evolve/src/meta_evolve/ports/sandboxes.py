"""Immutable contracts for bounded process execution in a workspace."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from numbers import Real
from typing import Protocol, TypeAlias, get_args

from meta_evolve.domain.evaluation import (
    InfrastructureFailure,
    PolicyViolation,
    ResourceExhausted,
    TimeoutFailure,
)
from meta_evolve.domain.task import Usage
from meta_evolve.domain.values import FrozenMap, _freeze_map_field
from meta_evolve.ports.workspaces import Workspace


ProcessFailure: TypeAlias = (
    TimeoutFailure | ResourceExhausted | PolicyViolation | InfrastructureFailure
)
_PROCESS_FAILURE_TYPES = get_args(ProcessFailure)


@dataclass(frozen=True, slots=True, kw_only=True)
class ProcessSpec:
    """A value-valid process request whose authority is decided by a provider."""

    argv: tuple[str, ...]
    cwd: str = "."
    environment: FrozenMap | Mapping[str, str] = field(default_factory=FrozenMap)
    timeout_seconds: float = 30.0
    stdout_limit: int = 1_048_576
    stderr_limit: int = 1_048_576

    def __post_init__(self) -> None:
        if not isinstance(self.argv, tuple):
            raise TypeError("process argv must be a tuple")
        if not self.argv:
            raise ValueError("process argv must be a non-empty tuple")
        if not all(isinstance(argument, str) for argument in self.argv):
            raise TypeError("process argv entries must be strings")
        if not isinstance(self.cwd, str):
            raise TypeError("process cwd must be a string")
        if not isinstance(self.environment, Mapping):
            raise TypeError("process environment must be a mapping")
        if not all(
            isinstance(key, str) and isinstance(value, str)
            for key, value in self.environment.items()
        ):
            raise TypeError("process environment entries must be strings")
        _freeze_map_field(self, "environment")
        if (
            isinstance(self.timeout_seconds, bool)
            or not isinstance(self.timeout_seconds, Real)
            or not math.isfinite(float(self.timeout_seconds))
            or float(self.timeout_seconds) <= 0
        ):
            raise ValueError("process timeout_seconds must be a positive finite number")
        object.__setattr__(self, "timeout_seconds", float(self.timeout_seconds))
        for name in ("stdout_limit", "stderr_limit"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"process {name} must be a non-negative integer")


@dataclass(frozen=True, slots=True, kw_only=True)
class ProcessResult:
    """Raw process completion or one execution-boundary failure."""

    exit_code: int | None
    stdout: str
    stderr: str
    usage: Usage
    failure: ProcessFailure | None = None

    def __post_init__(self) -> None:
        if self.exit_code is not None and (
            isinstance(self.exit_code, bool) or not isinstance(self.exit_code, int)
        ):
            raise TypeError("process exit_code must be an integer or None")
        if not isinstance(self.stdout, str) or not isinstance(self.stderr, str):
            raise TypeError("process stdout and stderr must be strings")
        if not isinstance(self.usage, Usage):
            raise TypeError("process usage must be a Usage")
        if self.failure is not None and type(self.failure) not in _PROCESS_FAILURE_TYPES:
            raise TypeError("process failure must be a declared process failure")
        if (self.exit_code is None) != (self.failure is not None):
            raise ValueError(
                "process exit_code is None exactly when a failure is present"
            )


class SandboxProvider(Protocol):
    def run(self, spec: ProcessSpec, workspace: Workspace) -> ProcessResult: ...


__all__ = ["ProcessResult", "ProcessSpec", "SandboxProvider"]
