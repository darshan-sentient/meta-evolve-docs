"""Decoded-value proposer and evaluator contracts for local execution."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Protocol

from meta_evolve.domain.evaluation import (
    Failure,
    _FAILURE_TYPES,
    _validate_evidence_fields,
    _validate_metrics,
    _validate_uncertainty,
)
from meta_evolve.domain.experience import ExperienceRef
from meta_evolve.domain.task import Usage
from meta_evolve.domain.values import (
    FrozenMap,
    _freeze_map_field,
    _require_text,
)

from .proposers import Proposer


_MISSING = object()


def _validate_failure(value: object) -> Failure | None:
    if value is not None and type(value) not in _FAILURE_TYPES:
        raise TypeError("result failure must be a typed Failure")
    return value


def _validate_evidence(values: object) -> tuple[EvidenceDraft, ...]:
    try:
        evidence = tuple(values)  # type: ignore[arg-type]
    except TypeError as error:
        raise TypeError("result evidence must contain EvidenceDraft values") from error
    if not all(isinstance(item, EvidenceDraft) for item in evidence):
        raise TypeError("result evidence must contain EvidenceDraft values")
    return evidence


@dataclass(frozen=True, slots=True, kw_only=True)
class EvidenceDraft:
    """Evidence content before the coordinator assigns durable identity."""

    kind: str
    data: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    uri: str | None = None

    def __post_init__(self) -> None:
        kind, data, uri = _validate_evidence_fields(self.kind, self.data, self.uri)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "data", data)
        object.__setattr__(self, "uri", uri)


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposalResult:
    """A normalized candidate or typed proposer failure.

    ``candidate`` is a value in the task's artifact type, not a durable
    payload: the registered codec is the one authority for that translation,
    and it runs where the task's kind and representation are known.
    """

    candidate: object = field(default=_MISSING)
    failure: Failure | None = None
    hypothesis: str | None = None
    predicted_outcomes: FrozenMap | Mapping[str, object] = field(
        default_factory=FrozenMap
    )
    metadata: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence: tuple[EvidenceDraft, ...] = ()
    usage: Usage = Usage()
    derived_from: tuple[ExperienceRef, ...] = ()

    def __post_init__(self) -> None:
        failure = _validate_failure(self.failure)
        if failure is None:
            if self.candidate is _MISSING:
                raise ValueError("a successful proposal result requires a candidate")
        else:
            if self.candidate is not _MISSING:
                raise ValueError("a failed proposal result cannot carry a candidate")
            object.__setattr__(self, "candidate", None)
        if self.hypothesis is not None:
            _require_text(self.hypothesis, "proposal hypothesis")
        _freeze_map_field(self, "predicted_outcomes")
        _freeze_map_field(self, "metadata")
        object.__setattr__(self, "evidence", _validate_evidence(self.evidence))
        if not isinstance(self.usage, Usage):
            raise TypeError("proposal result usage must be a Usage")
        if not isinstance(self.derived_from, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.derived_from
        ):
            raise TypeError("proposal result derivation must contain ExperienceRefs")
        if len(set(self.derived_from)) != len(self.derived_from):
            raise ValueError("proposal result derivation references must be unique")


@dataclass(frozen=True, slots=True, kw_only=True)
class EvaluationResult:
    """Independent measurements or a typed failure, plus evidence and usage.

    Successful metrics must cover the task objectives. A failed measurement
    has no rankable metrics. Return this explicitly to attach evidence,
    uncertainty, tokens, monetary spend, or elapsed usage; plain evaluators may
    return a scalar or metric mapping when no extra observations are needed.
    """

    metrics: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    failure: Failure | None = None
    uncertainty: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence: tuple[EvidenceDraft, ...] = ()
    usage: Usage = Usage()

    def __post_init__(self) -> None:
        metrics = _validate_metrics(self.metrics)
        failure = _validate_failure(self.failure)
        if failure is None and not metrics:
            raise ValueError("a successful evaluation result requires metrics")
        if failure is not None and metrics:
            raise ValueError("a failed evaluation result cannot carry rankable metrics")
        object.__setattr__(self, "metrics", metrics)
        object.__setattr__(self, "uncertainty", _validate_uncertainty(self.uncertainty))
        object.__setattr__(self, "evidence", _validate_evidence(self.evidence))
        if not isinstance(self.usage, Usage):
            raise TypeError("evaluation result usage must be a Usage")


class Evaluator(Protocol):
    def evaluate(self, candidate: object) -> EvaluationResult: ...


__all__ = [
    "EvaluationResult",
    "Evaluator",
    "EvidenceDraft",
    "ProposalResult",
    "Proposer",
]
