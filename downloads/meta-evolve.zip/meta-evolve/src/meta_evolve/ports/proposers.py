"""Producer-neutral context pushed to one proposer invocation."""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from meta_evolve.domain.context import ContextBundle
from meta_evolve.domain.task import Objective

from .experience import ExperienceReader
from .workspaces import WorkspaceSession

if TYPE_CHECKING:
    from .callables import ProposalResult


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposerContext:
    """The candidate-facing state authorized for one proposal.

    A callable may accept this as its optional second argument. ``rng`` supplies
    recorded per-attempt randomness; ``step`` and ``objectives`` describe the
    attempt. ``bundle`` contains pushed records, and ``experience`` is an
    optional audited reader. Repository adapters may supply ``workspace``
    with controlled execution and history information.
    """

    rng: random.Random
    step: int
    objectives: tuple[Objective, ...]
    bundle: ContextBundle
    experience: ExperienceReader | None = None
    workspace: WorkspaceSession | None = None


class Proposer(Protocol):
    def propose(
        self, parent: object, context: ProposerContext
    ) -> ProposalResult: ...


__all__ = ["Proposer", "ProposerContext"]
