"""Coordinator-facing proposer execution."""

from __future__ import annotations

import inspect
from collections.abc import Callable
from typing import Protocol

from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.experience_access import ExperienceSpec
from meta_evolve.domain.task import Budget, Objective
from meta_evolve.domain.trial import Artifact

from .callables import ProposalResult
from .proposers import ProposerContext


_MISSING = object()

VALIDATE_RUN_ARGUMENTS = (
    "artifact_kind",
    "artifact_representation",
    "objectives",
    "budget",
    "experience",
)


def validate_run_hook(value: object) -> Callable[..., None] | None:
    """Return ``value``'s optional preflight hook, proving it takes the contract.

    THE single implementation of hook discovery. A missing hook is ``None``. A
    non-callable hook, or one that cannot accept exactly
    ``VALIDATE_RUN_ARGUMENTS`` as keywords, is a declaration error reported as
    ``TypeError`` at binding time -- never sanitized into a capability
    rejection, which would report a signature typo as a provider limit.
    """

    validator = getattr(value, "validate_run", _MISSING)
    if validator is _MISSING:
        return None
    if not callable(validator):
        raise TypeError("proposer validate_run must be callable")
    try:
        signature = inspect.signature(validator)
    except (TypeError, ValueError):  # pragma: no cover - builtin/C validators
        return validator
    try:
        signature.bind(**{name: None for name in VALIDATE_RUN_ARGUMENTS})
    except TypeError as error:
        raise TypeError(
            "proposer validate_run must accept keyword-only "
            f"{', '.join(VALIDATE_RUN_ARGUMENTS)}: {error}"
        ) from error
    return validator


class ProposerRunner(Protocol):
    """Execute one proposal without exposing its artifact mechanics."""

    component: ComponentRef

    def validate_run(
        self,
        *,
        artifact_kind: str,
        artifact_representation: str,
        objectives: tuple[Objective, ...],
        budget: Budget,
        experience: ExperienceSpec | None,
    ) -> None: ...

    def execute(
        self,
        parents: tuple[Artifact, ...],
        context: ProposerContext,
    ) -> ProposalResult: ...


__all__ = ["VALIDATE_RUN_ARGUMENTS", "ProposerRunner", "validate_run_hook"]
