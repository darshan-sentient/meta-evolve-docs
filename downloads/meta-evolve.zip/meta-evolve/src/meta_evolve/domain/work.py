"""Durable work, attempt and lease values for trusted distribution.

Four identities, none collapsed. `Trial` is the logical experiment and keeps its
own identity; a `WorkItem` is one deliverable unit derived from a trial AND a
kind, because a trial has at most two -- its proposal and its evaluation -- and a
derivation that dropped the kind would merge them. A `WorkAttempt` is one
worker's bounded try at an item, derived from the item and an ordinal.

Attempt identity is **distinct, not secret**. Authority comes from an opaque
lease token, whose digest alone is ever stored, and from a monotonic fence. A
derived attempt id therefore adds no risk and needs no entropy source, and the
record explicitly rejects "a trial id serving as both work identity and lease
credential".

None of this is registered in `DURABLE_TYPES`: work rows live in their own
durable tables outside the run event stream, so none of them is ever decoded
from an event envelope, and registration would force them into `domain.__all__`
against the implementation plan's "none of them root exports".

The lease token and the work-attempt identity live here too, deferred out of
PR-B1 for having no caller and restored with one: the broker mints an attempt on
`acquire` and checks a token on `complete`. Worker identity and registration are
their own module, because the record gives worker state a different writer and
guarantee.

Past the ~300-line guideline: the work item, its lease, the attempt identity and the state machine are one invariant -- every validation here refers to at least two of them, and splitting by record would put the rules in a module none of the records import.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from hashlib import sha256

from .identity import RunId, TrialId, _OpaqueId
from .values import _require_count, _require_text, canonical_payload_bytes


class WorkKind(enum.Enum):
    """The two deliverables a trial can owe."""

    PROPOSAL = "proposal"
    EVALUATION = "evaluation"


@dataclass(frozen=True, slots=True)
class WorkItemId(_OpaqueId):
    """One deliverable unit's identity, derived from its trial and its kind."""

    @classmethod
    def for_trial(cls, trial_id: TrialId, kind: WorkKind) -> WorkItemId:
        if not isinstance(trial_id, TrialId):
            raise TypeError("work item trial id must be a TrialId")
        if not isinstance(kind, WorkKind):
            raise TypeError("work item kind must be a WorkKind")
        digest = sha256(
            canonical_payload_bytes(
                {
                    "domain": "meta-evolve/work-item/v1",
                    "parts": (trial_id.value, kind.value),
                }
            )
        ).hexdigest()
        return cls(f"work-{digest}")


@dataclass(frozen=True, slots=True, kw_only=True)
class WorkAttemptId:
    """One delivery attempt of one work item.

    A composite of the item and an ordinal rather than an opaque digest, because
    that is exactly what the ledger stores -- `(item_id, accepted_attempt)` --
    and because an attempt is meant to be DISTINCT, not secret. What is secret
    is the lease token beside it.
    """

    item: WorkItemId
    ordinal: int

    def __post_init__(self) -> None:
        if not isinstance(self.item, WorkItemId):
            raise TypeError("work attempt item must be a WorkItemId")
        if isinstance(self.ordinal, bool) or not isinstance(self.ordinal, int):
            raise TypeError("work attempt ordinal must be an integer")
        if self.ordinal < 1:
            raise ValueError("work attempt ordinals start at one")


@dataclass(frozen=True, slots=True)
class LeaseToken:
    """A lease credential: the digest that is stored, and -- only for the
    holder -- the secret that proves it.

    `issue` mints a secret, keeps it on the ISSUED token, and stores only its
    digest. `presents` hashes what a submission carries and compares that to
    what the row holds, so the stored value is a verifier and not a
    credential.

    That distinction was previously only claimed. `issue` returned the digest
    and dropped the secret, so the digest was simultaneously what the worker
    held, what `lease_json` persisted, and what the check compared -- and
    anyone able to read a work row could rebuild the exact lease the broker
    would accept. Hashing buys nothing when the hash is the thing presented.

    `secret` is `compare=False` and `repr=False`: two tokens are equal when
    they name the same lease, which is what the durable comparison means, and
    the secret must not reach a log or a repr. It is absent on every token
    reconstructed from storage, which is precisely why such a token cannot
    act.
    """

    digest: str
    secret: str | None = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        _require_text(self.digest, "lease token digest")
        if len(self.digest) != 64 or any(
            character not in "0123456789abcdef" for character in self.digest
        ):
            raise ValueError(
                "lease token digest must be 64 lowercase hex characters"
            )
        if self.secret is not None:
            _require_text(self.secret, "lease token secret")
            if sha256(self.secret.encode("utf-8")).hexdigest() != self.digest:
                raise ValueError("lease token secret does not match its digest")

    @classmethod
    def issue(cls, secret: str) -> LeaseToken:
        """The holder's token: the digest to store, and the secret to present."""

        return cls(sha256(secret.encode("utf-8")).hexdigest(), secret=secret)

    def presents(self, held: LeaseToken) -> bool:
        """Whether this submission proves the credential ``held`` records.

        A token carrying no secret was reconstructed from storage, and storage
        holds verifiers. It proves nothing, including against itself.
        """

        if self.secret is None:
            return False
        return sha256(self.secret.encode("utf-8")).hexdigest() == held.digest


class StaleReason(enum.Enum):
    """The one precondition a stale submission failed. A closed set.

    Defined beside `Lease` because `Lease.credential_mismatch` answers in it.
    Which reason is reported when several hold is `stale_reason_for`'s, in
    `work_staleness.py`; the design record's "Stale reason" term is the
    vocabulary.
    """

    NOT_LEASED = "not leased"
    ENDED = "ended"
    SUPERSEDED_ATTEMPT = "superseded attempt"
    OTHER_WORKER = "other worker"
    STALE_GENERATION = "stale generation"
    UNPROVEN_TOKEN = "unproven token"
    PRIOR_EPOCH = "prior epoch"
    EXPIRED = "expired"


@dataclass(frozen=True, slots=True, kw_only=True)
class Lease:
    """What `acquire` hands back, and what `complete` must match exactly.

    The deadline is an absolute broker timestamp. A worker never decides expiry
    from its own clock; it presents this and the broker decides.
    """

    item: WorkItemId
    attempt: WorkAttemptId
    worker_id: str
    generation: int
    # The FENCE, in the record's vocabulary: the dispatcher epoch this lease was
    # issued under. A restart bumps it, so a lease from before the restart fails
    # its precondition at the next transactional check rather than submitting
    # into a run some other dispatcher is now driving.
    epoch: int
    deadline: int
    token: LeaseToken

    def expired_at(self, now: int) -> bool:
        """Whether this lease has expired by the broker clock reading `now`.

        HALF-OPEN: a lease AT its deadline has expired, so a completion or a
        renewal arriving exactly then is already too late.

        Stated here, on the value the rule is about, because three places need
        it -- the in-memory expiry sweep, the durable one, and the acceptance
        precondition -- and the alternative was a cycle: `work_leases.py`
        already imports `lease_from` from `work_rows.py`, which is the module
        that has to ask. Both adapters import this one and neither imports
        from it, so the rule has exactly one home and no edge is added.
        """

        return now >= self.deadline

    def credential_mismatch(self, held: "Lease") -> "StaleReason | None":
        """Which part of the credential the broker holds this submission fails.

        `None` when it presents that credential. Otherwise the FIRST field that
        differs, in one order -- attempt, worker, generation, token -- because a
        different attempt always carries a different token, and a token-first
        order would report `UNPROVEN_TOKEN` for nearly every superseded attempt,
        hiding the reason that names the fix. `UNPROVEN_TOKEN` is left for the
        case the rest cannot explain: the right attempt, worker and generation
        presenting a token that does not prove -- a forged one, or one rebuilt
        from the stored digest.

        Every precondition for a LIVE lease except the deadline and the epoch:
        the attempt, the worker, the token and the worker's generation. Stated
        here, on the value, because both adapters spelled the identical
        four-tuple comparison out and a copied rule is how the two sides of one
        come to disagree -- which this pair has already done twice elsewhere.

        The deadline is deliberately NOT re-checked: both callers run their
        expiry sweep first, so an expired lease is already gone by the time this
        runs, and stating it twice made the second statement unreachable. The
        epoch is the CALLER's to check, because each adapter reads the current
        epoch differently -- one from a ledger field, one from a row inside the
        transaction -- and this value cannot see either.
        """

        # The token is PROVED, not compared. `held` came from storage, so its
        # token carries a digest and no secret; this one came from `acquire`
        # and carries the secret. Comparing the two tokens with `==` compares
        # digests, which made the stored value sufficient to act -- see
        # `LeaseToken`.
        if self.attempt != held.attempt:
            return StaleReason.SUPERSEDED_ATTEMPT
        if self.worker_id != held.worker_id:
            return StaleReason.OTHER_WORKER
        if self.generation != held.generation:
            return StaleReason.STALE_GENERATION
        if not self.token.presents(held.token):
            return StaleReason.UNPROVEN_TOKEN
        return None

    def proves_latest_attempt(
        self, attempts: int, verifier: "LeaseToken | None"
    ) -> bool:
        """Whether this is the row's latest attempt, proving the verifier it kept.

        The test for a lease a broker no longer HOLDS: expiry collected it, but
        the row keeps the attempt count and the issued token's verifier, and
        only `release` and `rollover` clear that verifier. Both brokers' post-
        expiry diagnosis rules spelled this out, and expiry recognition needs
        it too -- one statement for all three.
        """

        return (
            verifier is not None
            and self.attempt.ordinal == attempts
            and self.token.presents(verifier)
        )

    def __post_init__(self) -> None:
        if not isinstance(self.item, WorkItemId):
            raise TypeError("lease item must be a WorkItemId")
        if not isinstance(self.attempt, WorkAttemptId):
            raise TypeError("lease attempt must be a WorkAttemptId")
        if self.attempt.item != self.item:
            raise ValueError("lease attempt must belong to the leased item")
        if not isinstance(self.token, LeaseToken):
            raise TypeError("lease token must be a LeaseToken")
        _require_text(self.worker_id, "lease worker id")
        if isinstance(self.deadline, bool) or not isinstance(self.deadline, int):
            raise TypeError("lease deadline must be an integer timestamp")
        for name in ("generation", "epoch"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(f"lease {name} must be an integer")
            if value < 1:
                raise ValueError(f"lease {name} starts at one")


#: How long a lease lasts, in broker-clock seconds. Both brokers declared this
#: independently; a divergence would give the two adapters different expiry
#: behaviour under one contract suite, which is the class of defect this
#: module family keeps paying for.
DEFAULT_LEASE_SECONDS = 60

#: The shortest lease a run may configure. A lease is renewed every
#: `lease // 4` seconds while its call runs, so below this the interval is one
#: second or less on an integer clock -- a renewal that can land on the same
#: tick as the deadline it exists to move.
MIN_LEASE_SECONDS = 10


def require_lease_seconds(value: object) -> int:
    """Validate a broker's lease duration. Beside the constant, deliberately.

    Both brokers spelled these four lines out identically. Keeping the guard
    next to the default is what stops the two drifting apart -- a changed bound
    and an unchanged check is a silent hole.
    """

    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("lease seconds must be an integer")
    if value < MIN_LEASE_SECONDS:
        raise ValueError(
            f"a lease must last at least {MIN_LEASE_SECONDS} seconds, so the "
            f"renewal made every lease // 4 seconds is at least two; got {value}"
        )
    return value


def require_lease(value: object) -> "Lease":
    """Validate that a lease operation was handed a `Lease`, with its message.

    Both adapters guarded this identically at the top of their live-lease
    check. The message is matched on, so it travels with the check.
    """

    if not isinstance(value, Lease):
        raise TypeError("a lease operation needs a Lease")
    return value


def require_run_id(value: object) -> RunId:
    """Validate that a broker operation was handed a `RunId`, with its message.

    Beside `require_lease` for the same reason, and added because the two
    adapters had DRIFTED on it: the in-memory broker checked in `_ledger` on
    every operation, and the SQLite one checked nowhere -- it went straight to
    `run_id.value`. Measured worst case: `enqueue("not-a-run", ...)` reported
    `InvalidWorkAppend("belongs to another run")`, a wrong reason for a type
    error, on the only path that writes.

    The contract suite could not see it: it drives both brokers with valid
    values, so a guard present in one and absent in the other is invisible to a
    differential oracle that never passes a bad one.
    """

    if not isinstance(value, RunId):
        raise TypeError("run id must be a RunId")
    return value


def require_broker_time(value: object) -> int:
    """Validate a broker clock reading, including the message.

    The in-memory ledger and the durable clock stated this guard and its
    wording separately. The message is part of the contract -- a caller matches
    on it -- so it travels with the check rather than being retyped.
    """

    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("broker time must be an integer timestamp")
    return value


class WorkState(enum.Enum):
    """The five states of the record's work and lease machine."""

    PREPARING = "PREPARING"
    READY = "READY"
    LEASED = "LEASED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"

    @classmethod
    def terminal(cls) -> tuple["WorkState", ...]:
        """The states no transition may leave. One home, previously three.

        `TERMINAL` in the in-memory ledger, `_TERMINAL` in the SQLite broker,
        and the pair spelled out inline in `work_intents.py` -- three copies of
        one fact, in the module family that has already paid for copied rules
        twice. A fourth state joining this set had three places to be added and
        two of them were easy to miss.
        """

        return (cls.COMPLETED, cls.CANCELLED)


class FailureStage(enum.Enum):
    """Which path recorded a row's failure cause, and so what the cause can mean.

    `release` records an ATTEMPT failure: the component, or resolving its inputs,
    raised. `record_failure` records a COMPLETION failure: it returned, and its
    result could not be committed. Only the second can be a verdict on the work.
    """

    ATTEMPT = "attempt"
    COMPLETION = "completion"


@dataclass(frozen=True, slots=True, kw_only=True)
class WorkRow:
    """The part of a durable work row the domain owns.

    A boundary record between the domain and the work tables, which knows
    nothing about SQL. It is deliberately NOT the whole row: `work_items`
    declares fifteen columns and this carries ten FIELDS covering ten of them:
    `last_failure` is one field over two columns, and `last_failure_stage` rides
    in the first of those two as a prefix. The five it
    omits -- the lease, the accepted attempt, its token digest, the
    acknowledgment and the last lease's token verifier -- are the broker's to
    write and this type's to leave alone, which is why `_put_work_in_txn`
    inserts rather than upserts.

    The failure fields are the broker-written columns this type DOES carry, and
    the asymmetry is deliberate: it is read here, never written here. The
    reclaim step builds the terminal fact from a `WorkRow` handed to it by
    `broker.rows()`, in a different call from the one that caught the
    exception and possibly a different process, so without this field the
    cause has no path from the row to the fact. `enqueued` never sets it and
    `_put_work_in_txn` never writes it -- the rule the four other columns
    follow is intact; this one is simply also legible.

    `enqueued` is the only constructor a caller needs in M11.2, because the
    record's `PREPARING` state has no reachable producer here: no member may
    reference a sibling that has not been committed (the record's own rule,
    enforced at `decisions.py`), so no trial in a cohort waits on another's
    artifact and a row always arrives `READY`.
    """

    run_id: RunId
    item: WorkItemId
    trial_id: TrialId
    kind: WorkKind
    state: WorkState
    attempts: int = 0
    max_attempts: int
    # (exception type, message) from the most recent failed attempt, or None
    # when nothing has failed. NULL and "no cause" are the same state, and a
    # row migrated from schema v3 reads as None for the same reason a row that
    # simply succeeded does.
    last_failure: tuple[str, str] | None = None
    # The attempt and the stage that wrote it. A stage of None is a cause
    # recorded before the stage was (schema v4), which is read as transient.
    last_failure_attempt: int | None = None
    last_failure_stage: FailureStage | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.run_id, RunId):
            raise TypeError("work row run id must be a RunId")
        if not isinstance(self.item, WorkItemId):
            raise TypeError("work row item must be a WorkItemId")
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("work row trial id must be a TrialId")
        if not isinstance(self.kind, WorkKind):
            raise TypeError("work row kind must be a WorkKind")
        if not isinstance(self.state, WorkState):
            raise TypeError("work row state must be a WorkState")
        # The one broker-written field this type carries, and the one that had
        # no guard: it is rebuilt from two durable columns by `row_from`, so a
        # corrupt or migrated store is exactly what reaches it. Its readers
        # unpack it as a pair of strings.
        if self.last_failure is not None and not (
            isinstance(self.last_failure, tuple)
            and len(self.last_failure) == 2
            and all(isinstance(part, str) for part in self.last_failure)
        ):
            raise TypeError(
                "work row last failure must be a pair of strings, or None"
            )
        if self.last_failure_attempt is not None:
            _require_count(self.last_failure_attempt, "work row last failure attempt")
        if self.last_failure_stage is not None and not isinstance(
            self.last_failure_stage, FailureStage
        ):
            raise TypeError("work row last failure stage must be a FailureStage")
        _require_count(self.attempts, "work row attempts")
        # One cause, recorded by one attempt at one stage. A stage without its
        # attempt, or either without a cause, is a shape no writer produces.
        if self.last_failure is None and (
            self.last_failure_attempt is not None or self.last_failure_stage is not None
        ):
            raise ValueError("work row last failure attempt and stage need a cause")
        if self.last_failure_stage is not None and self.last_failure_attempt is None:
            raise ValueError("work row last failure stage needs its attempt")
        if self.last_failure_attempt is not None and not (
            1 <= self.last_failure_attempt <= self.attempts
        ):
            raise ValueError(
                "work row last failure attempt must be one the row has reached"
            )
        if isinstance(self.max_attempts, bool) or not isinstance(
            self.max_attempts, int
        ):
            raise TypeError("work row max attempts must be an integer")
        if self.max_attempts < 1:
            raise ValueError("work row max attempts must be at least one")
        # The relationships, not only the field types. Every guarantee this
        # record's readers rely on is a relationship: `enqueued` establishes all
        # three, and PR-B2 rebuilds rows from columns, where nothing else would.
        if self.attempts > self.max_attempts:
            raise ValueError(
                "work row attempts cannot exceed its max attempts"
            )
        if self.item != WorkItemId.for_trial(self.trial_id, self.kind):
            raise ValueError(
                "work row item identity must derive from its own trial and kind"
            )
        # A lease is what SPENDS an attempt, so a row that has been leased has
        # spent at least one, and so has one that reached `COMPLETED` -- the
        # only edge into it is `complete`, from `LEASED`. `attempts == 0` in
        # either state describes a row that was claimed without consuming a
        # claim, which is the shape a retry-budget bypass takes: expire it and
        # it returns to `READY` with its full budget, forever.
        #
        # The other three carry no such floor and must not acquire one:
        # `PREPARING` and a freshly enqueued `READY` are legitimately at zero,
        # a `READY` row re-readied by expiry is above it, and `cancel` reaches
        # `CANCELLED` from `READY` -- possibly before any attempt at all.
        if self.state in (WorkState.LEASED, WorkState.COMPLETED) and self.attempts < 1:
            raise ValueError(
                f"work row in {self.state.value} must have spent at least one "
                "attempt"
            )

    @property
    def is_exhausted(self) -> bool:
        """No attempts left: this row can never be claimed again.

        Half-open at the top, matching `Lease.expired_at`. The SQLite claimable
        SELECT restates this in SQL and cannot call it, so
        `tests/test_exhaustion_predicate.py` holds the two together.
        """

        return self.attempts >= self.max_attempts

    @classmethod
    def enqueued(
        cls,
        *,
        run_id: RunId,
        trial_id: TrialId,
        kind: WorkKind,
        max_attempts: int,
    ) -> WorkRow:
        return cls(
            run_id=run_id,
            item=WorkItemId.for_trial(trial_id, kind),
            trial_id=trial_id,
            kind=kind,
            state=WorkState.READY,
            max_attempts=max_attempts,
        )


__all__ = [
    "DEFAULT_LEASE_SECONDS",
    "FailureStage",
    "MIN_LEASE_SECONDS",
    "require_broker_time",
    "require_lease",
    "require_lease_seconds",
    "require_run_id",
    "Lease",
    "LeaseToken",
    "StaleReason",
    "WorkAttemptId",
    "WorkItemId",
    "WorkKind",
    "WorkRow",
    "WorkState",
]
