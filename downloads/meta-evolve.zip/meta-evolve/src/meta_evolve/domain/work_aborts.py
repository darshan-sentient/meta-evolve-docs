"""Which completion failures a second attempt cannot clear.

D7's split, and the only place it is written. A completion-stage abort happens
after the component has already returned, so the question is never "did it
fail" but "would running it again produce anything different". Two causes say
no: a result the provisional fold cannot reconcile with the committed history
(`InvalidSearchHistory`), and a coordinator refusing the completion as invalid
(`InvalidDecision`). Neither is about the environment, so neither improves by
being retried, and a run that retried them would spend its whole bound arriving
at the same place with two more misleading attempts on the record.

Everything else is transient and re-runs: a conflicted append, a store that was
not mounted, a lost lease, a superseded dispatcher.

DECLARED as types, READ by name, and the asymmetry is the point. The process
that meets the exception is never the process that acts on it: a completion
failure is recorded by `record_failure` and the decision is taken by whichever
run resumes afterwards, which has only the `(type name, message)` pair the row
stored. So the check has to be a name. Writing the set AS names would make it a
list of strings nothing verifies -- rename or delete `InvalidSearchHistory` and
a string list goes quietly stale, while the tuple below stops importing. The
names are derived from it rather than typed out a second time.

There is deliberately NO live `isinstance` half. One was written first, on the
assumption the dispatcher would classify the exception as it caught it, and it
had no caller: the dispatcher records the cause and re-raises, and every
decision about that cause is taken after a restart, from the row. A second
reading with no reader is a second thing to keep in step for nothing.

Its own module rather than a pair of lines in `work.py`, for the reason the
record gives elsewhere: `work.py` is already over the length guideline and
argues that what it holds is one invariant about the row, the lease and the
attempt. This is a different question -- about a cause, not about a row -- and
it has to be legible from the adapter that validates the transition as well as
from the application that chooses it.

POSITIVE, not an exclusion. "Deterministic unless listed as transient" fails in
the direction that loses work -- an unclassified cause would end its item
permanently the first time it occurred -- while "transient unless listed as
deterministic" fails towards a wasted retry, which the bound already ends.
"""

from __future__ import annotations

from meta_evolve.errors import InvalidDecision

from .search import InvalidSearchHistory
from .work import FailureStage, WorkRow

#: The closed set. A cause belongs here when re-running the component cannot
#: change the answer, and nothing else does.
DETERMINISTIC_ABORTS: tuple[type[BaseException], ...] = (
    InvalidSearchHistory,
    InvalidDecision,
)

#: The same set as a resumed run sees it. DERIVED, never retyped -- see the
#: module docstring.
DETERMINISTIC_ABORT_NAMES = frozenset(
    cause.__name__ for cause in DETERMINISTIC_ABORTS
)


def diagnosed_deterministic(last_failure: tuple[str, str] | None) -> bool:
    """Whether a recorded cause is one a re-run cannot clear.

    Takes the stored pair rather than the row holding it, because its callers
    hold it in two different shapes -- a `WorkRow` field in the application,
    two SQLite columns inside the writing transaction -- and the column reader
    would otherwise have to fake a row to ask a question about two values it
    already has in hand.

    `None` is not an abort: expiry and rollover both return a row to READY
    without passing through the path that writes a cause, and reading "no
    cause" as deterministic would end an item nothing had diagnosed.
    """

    if last_failure is None:
        return False
    return last_failure[0] in DETERMINISTIC_ABORT_NAMES


def aborted(row: WorkRow) -> bool:
    """Whether the row's CURRENT attempt came back with a verdict on the work.

    A deterministic name is not enough. `release` records an attempt failure
    under the same name a completion failure has -- a component may raise
    `InvalidDecision` itself -- and an earlier attempt's verdict says nothing
    once a later attempt has claimed the row. So three things must hold: the
    cause was recorded at the completion stage, by the attempt the row is on,
    and its name is in the set. A cause with no recorded stage (schema v4)
    fails the first, which is the direction this module fails in: a retry.
    """

    return (
        row.last_failure_stage is FailureStage.COMPLETION
        and row.last_failure_attempt == row.attempts
        and diagnosed_deterministic(row.last_failure)
    )


__all__ = [
    "DETERMINISTIC_ABORTS",
    "DETERMINISTIC_ABORT_NAMES",
    "aborted",
    "diagnosed_deterministic",
]
