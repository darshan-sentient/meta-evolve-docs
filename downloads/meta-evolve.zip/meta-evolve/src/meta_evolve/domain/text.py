"""Prompt or document text with a declared durable kind.

This type adds no content rules of its own — empty strings, NUL characters,
and large documents are all valid. The type owns shape; evaluators own
quality; budgets own size. ``SourceTree``'s NUL prohibition is deliberately
not imported: that rule exists because trees materialize to files, and text
never touches a filesystem here.

The one limit is not this type's and is not specific to it: canonical
payloads serialize as UTF-8, so a lone surrogate raises ``UnicodeEncodeError``
there. A plain ``str`` seed on a ``python-value`` task fails identically.
"""

from __future__ import annotations

from typing import ClassVar


class Text(str):
    """An immutable UTF-8 text artifact, usable as a Python string.

    Use ``Task(artifact=Text, ...)`` for prompt or document candidates. The
    proposer can return a plain string; the codec decodes retained values as
    ``Text``. Ordinary string seeds also work with the default task codec, so
    this wrapper is optional when a distinct text artifact kind is unnecessary.
    Empty strings are valid. The codec validates text; the evaluator defines
    quality, and constructing ``Text`` does not run an evaluation.
    """

    KIND: ClassVar[str] = "text"
    REPRESENTATION: ClassVar[str] = "utf8-text-v1"

    __slots__ = ()

    def to_payload(self) -> str:
        return str(self)

    @classmethod
    def from_payload(cls, value: object) -> "Text":
        if not isinstance(value, str):
            raise TypeError("text payload must be a string")
        return cls(value)


__all__ = ["Text"]
