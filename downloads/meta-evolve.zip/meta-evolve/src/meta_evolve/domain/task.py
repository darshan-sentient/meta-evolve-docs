"""Objectives, resource accounting, and the task contract.

Kept as one file beyond 300 lines so these interdependent public declarations
and their parameter documentation stay together without moving durable types
while adding the author resource projection. The reviewed length is baselined.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Iterable, Mapping
from dataclasses import InitVar, dataclass, field
from numbers import Real
from typing import Any, TypeAlias

from .components import ComponentRef
from .resources import Resources
from .values import (
    FrozenMap,
    _freeze_map_field,
    _require_count,
    _require_measurement,
    _require_text,
)


_MISSING = object()


@dataclass(frozen=True, slots=True)
class _Objective:
    metric: str
    satisfy: float | None = None

    def __post_init__(self) -> None:
        _require_text(self.metric, "objective metric")
        if self.satisfy is not None:
            if (
                isinstance(self.satisfy, bool)
                or not isinstance(self.satisfy, Real)
                or not math.isfinite(float(self.satisfy))
            ):
                raise ValueError("objective satisfaction threshold must be finite")
            object.__setattr__(self, "satisfy", float(self.satisfy))


@dataclass(frozen=True, slots=True)
class Maximize(_Objective):
    """Prefer larger values of one named evaluation metric.

    Use ``Maximize("quality", satisfy=0.9)`` in [Task.objectives][meta_evolve.Task].
    Built-in search uses the first objective for ranking and satisfaction;
    additional objectives do not automatically become joint stopping conditions.

    :param metric: Non-empty metric name returned by the evaluator.
    :param satisfy: Optional finite target; a value greater than or equal to it
        satisfies this objective. ``None`` supplies no target.
    """

    pass


@dataclass(frozen=True, slots=True)
class Minimize(_Objective):
    """Prefer smaller values of one named evaluation metric.

    For example, ``Minimize("errors", satisfy=0)`` targets zero errors.
    Objective values are measurements; a typed failure is never a low score.
    See [Task][meta_evolve.Task] for ordering and evaluator return forms.

    :param metric: Non-empty metric name returned by the evaluator.
    :param satisfy: Optional finite target; a value less than or equal to it
        satisfies this objective. ``None`` supplies no target.
    """

    pass


Objective: TypeAlias = Maximize | Minimize


def _validate_objectives(
    values: Iterable[Objective], label: str
) -> tuple[Objective, ...]:
    objectives = tuple(values)
    if not objectives or not all(
        isinstance(objective, (Maximize, Minimize)) for objective in objectives
    ):
        raise TypeError(f"{label} objectives must contain Maximize or Minimize values")
    names = tuple(objective.metric for objective in objectives)
    if len(names) != len(set(names)):
        raise ValueError(f"{label} objective metric names must be unique")
    return objectives


@dataclass(frozen=True, slots=True, kw_only=True)
class Usage:
    """Recorded non-negative resource consumption, additive with ``+``.

    Returned by [Run.usage()][meta_evolve.Run.usage] and retained in durable
    domain records. Rich component results report [Resources][meta_evolve.Resources];
    the execution engine owns the trial and evaluation counts here.

    ``spend_micros=None`` explicitly means unknown billed spend. Adding any
    unknown spend produces an unknown total; individual known charges remain
    in history. Estimates belong in evidence. Use ``resources`` to forward
    nested-run resources without charging its trials and evaluations again.

    :param evaluations: Evaluator invocations, including the seed and failures.
    :param trials: Successor proposal attempts, including failures; excludes seed.
    :param tokens: Reported token count, defaulting to zero.
    :param spend_micros: Billed micro-USD (one millionth of a US dollar), or
        ``None`` when unknown. The default ``0`` means known free work.
    :param wall_seconds: Reported non-negative finite elapsed seconds.
    """

    evaluations: int = 0
    trials: int = 0
    tokens: int = 0
    # Charged micro-USD only. Estimates belong in evidence. Omit zero to keep
    # historical experience renderings byte-identical; unknown is explicit null.
    spend_micros: int | None = field(default=0, metadata={"omit_if_default": True})
    wall_seconds: float = 0.0

    def __post_init__(self) -> None:
        _require_count(self.evaluations, "evaluations")
        _require_count(self.trials, "trials")
        _require_count(self.tokens, "tokens")
        if self.spend_micros is not None:
            _require_count(self.spend_micros, "spend_micros")
        object.__setattr__(
            self,
            "wall_seconds",
            _require_measurement(self.wall_seconds, "wall_seconds"),
        )

    def __add__(self, other: object) -> Usage:
        if not isinstance(other, Usage):
            return NotImplemented
        return Usage(
            evaluations=self.evaluations + other.evaluations,
            trials=self.trials + other.trials,
            tokens=self.tokens + other.tokens,
            spend_micros=(None if self.spend_micros is None or other.spend_micros is None
                          else self.spend_micros + other.spend_micros),
            wall_seconds=self.wall_seconds + other.wall_seconds,
        )

    @property
    def resources(self) -> Resources:
        """Project component costs losslessly, without engine-owned counts."""

        return Resources(tokens=self.tokens, spend_micros=self.spend_micros,
                         wall_seconds=self.wall_seconds)

    @property
    def without_counts(self) -> Usage:
        """Retain measured resources, including unknown spend, without counts."""

        return Usage(
            tokens=self.tokens,
            spend_micros=self.spend_micros,
            wall_seconds=self.wall_seconds,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Budget:
    """Immutable resource ceilings, checked against recorded [Usage][meta_evolve.Usage].

    Every field defaults to ``None`` (no ceiling for that resource). Counts
    must be non-negative integers; booleans are rejected. A budget bounds work
    independently of a search preset's own attempt limit.

    Resource reports are checked after actions return; an in-flight SDK call
    is not interrupted. A monetary overrun is charged and recorded as a typed
    failure. This is not a hard provider spending cap.

    In ``run(..., budget=...)``, omitted or ``None`` fields inherit task ceilings.
    Supplied limits may tighten or introduce ceilings, but exceeding a finite
    task ceiling raises ``ValueError`` before work starts. ``Budget()`` retains
    every task ceiling; zero remains a real limit. [run][meta_evolve.run]
    documents execution defaults; the limits guide supplies complete examples.

    :param evaluations: Maximum evaluator invocations, including the seed.
        Zero cannot admit the seed and raises [BudgetUnavailable][meta_evolve.BudgetUnavailable]
        at run start. Failed evaluations still consume this allowance.
    :param trials: Maximum successor proposal attempts; the seed consumes none.
        Zero permits seed evaluation only.
    :param tokens: Ceiling on component-reported tokens.
    :param spend_micros: Ceiling on billed micro-USD; zero permits known free work.
        Unknown spend makes a monetary ceiling unverifiable and stops more work.
    :param wall_seconds: Ceiling on reported non-negative finite elapsed seconds.
    """

    evaluations: int | None = None
    trials: int | None = None
    tokens: int | None = None
    # Integer micro-USD, matching Usage.spend_micros. Enforced post-hoc: a
    # reported charge can stop later work but cannot unspend money, so this is a
    # ceiling that halts, never a hard cap. Reservation/preflight semantics are
    # what a hard cap needs, and this milestone does not claim one.
    spend_micros: int | None = field(
        default=None,
        metadata={"omit_if_default": True},
    )
    wall_seconds: float | None = None

    def __post_init__(self) -> None:
        for name in ("evaluations", "trials", "tokens", "spend_micros"):
            value = getattr(self, name)
            if value is not None:
                _require_count(value, name)
        if self.wall_seconds is not None:
            object.__setattr__(
                self,
                "wall_seconds",
                _require_measurement(self.wall_seconds, "wall_seconds"),
            )

    def allows(self, usage: Usage) -> bool:
        """Whether every declared ceiling can be verified against this usage."""
        if not isinstance(usage, Usage):
            raise TypeError("usage must be a Usage")
        return all(
            limit is None or (amount is not None and amount <= limit)
            for limit, amount in (
                (self.evaluations, usage.evaluations),
                (self.trials, usage.trials),
                (self.tokens, usage.tokens),
                (self.spend_micros, usage.spend_micros),
                (self.wall_seconds, usage.wall_seconds),
            )
        )

    def remaining_after(self, usage: Usage) -> Budget:
        """Subtract allowed usage, leaving unlimited dimensions as ``None``.

        :raises ValueError: If usage exceeds a ceiling or required spend is unknown.
        """
        if not self.allows(usage):
            raise ValueError("usage exceeds budget or a required amount is unknown")

        def remaining(limit: int | float | None, amount: int | float | None) -> Any:
            return None if limit is None else limit - amount

        return Budget(
            evaluations=remaining(self.evaluations, usage.evaluations),
            trials=remaining(self.trials, usage.trials),
            tokens=remaining(self.tokens, usage.tokens),
            spend_micros=remaining(self.spend_micros, usage.spend_micros),
            wall_seconds=remaining(self.wall_seconds, usage.wall_seconds),
        )

    def narrow(self, other: Budget) -> Budget:
        """Return the tighter ceiling in each dimension without changing either input.

        ``None`` contributes no ceiling. Unlike the ``run`` override, this
        operation takes minima instead of rejecting a wider input.
        """
        if not isinstance(other, Budget):
            raise TypeError("other must be a Budget")

        def narrower(left: Any, right: Any) -> Any:
            if left is None:
                return right
            if right is None:
                return left
            return min(left, right)

        return Budget(
            evaluations=narrower(self.evaluations, other.evaluations),
            trials=narrower(self.trials, other.trials),
            tokens=narrower(self.tokens, other.tokens),
            spend_micros=narrower(self.spend_micros, other.spend_micros),
            wall_seconds=narrower(self.wall_seconds, other.wall_seconds),
        )


def spend_exhausted(*, remaining: Budget, charged: Usage) -> bool:
    """Whether remaining spend is used up or cannot be verified.

    A zero ceiling still permits known free work. Unknown spend forbids further
    work only when a monetary ceiling exists. Pass a remainder, not the original
    ceiling: the same Budget type represents both.
    """
    if charged.spend_micros is None:
        return remaining.spend_micros is not None
    return remaining.spend_micros == 0 and charged.spend_micros > 0


@dataclass(frozen=True, slots=True, kw_only=True)
class Task:
    """Define independent evaluation, objectives, artifact type, and budget.

    Construction declares the rules without evaluating a candidate. The seed
    belongs to [Experiment][meta_evolve.Experiment]. Candidate proposals cannot
    revise this contract.

    Malformed declarations raise ``TypeError`` or ``ValueError``. During a run,
    invalid returned measurements become typed outcomes, not fabricated scores.

    :param evaluator: Callable receiving the decoded candidate, or a registered
        evaluator reference. Return a finite number for exactly one objective,
        a mapping covering every objective, [EvaluationResult][meta_evolve.EvaluationResult],
        or a typed failure from ``meta_evolve.domain``. Booleans are not scores.
    :param artifact: Optional artifact type, such as [Text][meta_evolve.Text],
        with declared kind and representation; an instance is rejected.
        Omit it for ordinary immutable JSON-like values, including strings.
    :param objectives: Non-empty ordered objectives with unique metric names.
        Defaults to ``(Maximize("score"),)`` with no satisfaction target. The
        first controls default ranking and built-in satisfaction stopping.
        Extra reported metrics are retained without changing that selection.
    :param budget: Optional [Budget][meta_evolve.Budget]; ``None`` adds no task
        ceiling. Search can still impose its own finite attempt limit.
    :param environment: Evaluator-owned JSON-like metadata, frozen on construction
        and included in task identity. It does not configure an OS environment.
    :param artifact_kind: Advanced codec kind; defaults to ``"python-value"``.
    :param artifact_representation: Advanced codec representation; defaults to
        ``"canonical-json"``. Prefer ``artifact=`` for declared artifact types;
        conflicting explicit kind or representation values are rejected.
    """

    evaluator: ComponentRef | Callable[..., object]
    artifact: InitVar[type | None] = None
    objectives: tuple[Objective, ...] = (Maximize("score"),)
    budget: Budget | None = None
    environment: Mapping[str, object] = field(
        default_factory=FrozenMap,
        metadata={"omit_if_default": True},
    )
    artifact_kind: str = "python-value"
    artifact_representation: str = field(
        default="canonical-json",
        metadata={"omit_if_default": True},
    )

    def __post_init__(self, artifact: type | None) -> None:
        if artifact is not None:
            # The declaration names the artifact *type*; an instance carries
            # the same class attributes and would otherwise pass unnoticed,
            # reading as a seed the task never accepted.
            if not isinstance(artifact, type):
                raise TypeError("task artifact must be a type, not an instance")
            kind = getattr(artifact, "KIND", None)
            representation = getattr(artifact, "REPRESENTATION", None)
            if not isinstance(kind, str) or not isinstance(representation, str):
                raise TypeError(
                    "task artifact must declare string KIND and REPRESENTATION"
                )
            if self.artifact_kind not in ("python-value", kind):
                raise ValueError("task artifact conflicts with artifact_kind")
            if self.artifact_representation not in ("canonical-json", representation):
                raise ValueError(
                    "task artifact conflicts with artifact_representation"
                )
            object.__setattr__(self, "artifact_kind", kind)
            object.__setattr__(self, "artifact_representation", representation)
        evaluator = self.evaluator
        if callable(evaluator) and not isinstance(evaluator, ComponentRef):
            declared = getattr(evaluator, "component", _MISSING)
            if declared is _MISSING:
                evaluator = ComponentRef.local_evaluator(evaluator)
            else:
                if (
                    not isinstance(declared, ComponentRef)
                    or declared.role != "evaluator"
                    or declared.origin != "local"
                    or declared.adapter is not evaluator
                ):
                    raise TypeError(
                        "declared callable component must be a local evaluator "
                        "ComponentRef retaining that callable"
                    )
                evaluator = declared
            object.__setattr__(self, "evaluator", evaluator)
        if not isinstance(evaluator, ComponentRef) or evaluator.role != "evaluator":
            raise TypeError("task evaluator must be an evaluator component or callable")
        object.__setattr__(
            self, "objectives", _validate_objectives(self.objectives, "task")
        )
        if self.budget is not None and not isinstance(self.budget, Budget):
            raise TypeError("task budget must be a Budget")
        _freeze_map_field(self, "environment")
        _require_text(self.artifact_kind, "artifact kind")
        _require_text(self.artifact_representation, "artifact representation")
        adapter = evaluator.adapter
        if adapter is not None:
            validator = getattr(adapter, "validate_task", _MISSING)
            if validator is not _MISSING:
                if not callable(validator):
                    raise TypeError("evaluator validate_task must be callable")
                validator(self)
