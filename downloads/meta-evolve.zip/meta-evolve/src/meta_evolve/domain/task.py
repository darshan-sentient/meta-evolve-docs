"""Objectives, resource accounting, and the task contract."""

from __future__ import annotations

import math
from collections.abc import Callable, Iterable, Mapping
from dataclasses import InitVar, dataclass, field
from numbers import Real
from typing import Any, TypeAlias

from .components import ComponentRef
from .values import (
    FrozenMap,
    _freeze_map_field,
    _require_count,
    _require_measurement,
    _require_text,
)


_MISSING = object()


@dataclass(frozen=True, slots=True)
class _Objective:
    metric: str
    satisfy: float | None = None

    def __post_init__(self) -> None:
        _require_text(self.metric, "objective metric")
        if self.satisfy is not None:
            if (
                isinstance(self.satisfy, bool)
                or not isinstance(self.satisfy, Real)
                or not math.isfinite(float(self.satisfy))
            ):
                raise ValueError("objective satisfaction threshold must be finite")
            object.__setattr__(self, "satisfy", float(self.satisfy))


@dataclass(frozen=True, slots=True)
class Maximize(_Objective):
    pass


@dataclass(frozen=True, slots=True)
class Minimize(_Objective):
    pass


Objective: TypeAlias = Maximize | Minimize


def _validate_objectives(
    values: Iterable[Objective], label: str
) -> tuple[Objective, ...]:
    objectives = tuple(values)
    if not objectives or not all(
        isinstance(objective, (Maximize, Minimize)) for objective in objectives
    ):
        raise TypeError(f"{label} objectives must contain Maximize or Minimize values")
    names = tuple(objective.metric for objective in objectives)
    if len(names) != len(set(names)):
        raise ValueError(f"{label} objective metric names must be unique")
    return objectives


@dataclass(frozen=True, slots=True, kw_only=True)
class Usage:
    """Recorded non-negative resource consumption, additive with ``+``.

    Components report tokens, ``spend_micros``, and elapsed ``wall_seconds``.
    Trial and evaluation counts belong to the execution engine. ``without_counts``
    retains provider usage when aggregating bounded inner runs.
    ``spend_micros=None`` explicitly means unknown billed spend. Adding any
    unknown spend produces an unknown total; individual known charges remain
    in history. The zero default preserves free local work and historical bytes.
    """

    evaluations: int = 0
    trials: int = 0
    tokens: int = 0
    # Charged micro-USD only. Estimates belong in evidence. Omit zero to keep
    # historical experience renderings byte-identical; unknown is explicit null.
    spend_micros: int | None = field(default=0, metadata={"omit_if_default": True})
    wall_seconds: float = 0.0

    def __post_init__(self) -> None:
        _require_count(self.evaluations, "evaluations")
        _require_count(self.trials, "trials")
        _require_count(self.tokens, "tokens")
        if self.spend_micros is not None:
            _require_count(self.spend_micros, "spend_micros")
        object.__setattr__(
            self,
            "wall_seconds",
            _require_measurement(self.wall_seconds, "wall_seconds"),
        )

    def __add__(self, other: object) -> Usage:
        if not isinstance(other, Usage):
            return NotImplemented
        return Usage(
            evaluations=self.evaluations + other.evaluations,
            trials=self.trials + other.trials,
            tokens=self.tokens + other.tokens,
            spend_micros=(None if self.spend_micros is None or other.spend_micros is None
                          else self.spend_micros + other.spend_micros),
            wall_seconds=self.wall_seconds + other.wall_seconds,
        )

    @property
    def without_counts(self) -> Usage:
        """Retain measured resources, including unknown spend, without counts."""

        return Usage(
            tokens=self.tokens,
            spend_micros=self.spend_micros,
            wall_seconds=self.wall_seconds,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Budget:
    """Optional ceilings; ``None`` means that resource is unbounded."""

    evaluations: int | None = None
    trials: int | None = None
    tokens: int | None = None
    # Integer micro-USD, matching Usage.spend_micros. Enforced post-hoc: a
    # reported charge can stop later work but cannot unspend money, so this is a
    # ceiling that halts, never a hard cap. Reservation/preflight semantics are
    # what a hard cap needs, and this milestone does not claim one.
    spend_micros: int | None = field(
        default=None,
        metadata={"omit_if_default": True},
    )
    wall_seconds: float | None = None

    def __post_init__(self) -> None:
        for name in ("evaluations", "trials", "tokens", "spend_micros"):
            value = getattr(self, name)
            if value is not None:
                _require_count(value, name)
        if self.wall_seconds is not None:
            object.__setattr__(
                self,
                "wall_seconds",
                _require_measurement(self.wall_seconds, "wall_seconds"),
            )

    def allows(self, usage: Usage) -> bool:
        """Whether every declared ceiling can be verified against this usage."""
        if not isinstance(usage, Usage):
            raise TypeError("usage must be a Usage")
        return all(
            limit is None or (amount is not None and amount <= limit)
            for limit, amount in (
                (self.evaluations, usage.evaluations),
                (self.trials, usage.trials),
                (self.tokens, usage.tokens),
                (self.spend_micros, usage.spend_micros),
                (self.wall_seconds, usage.wall_seconds),
            )
        )

    def remaining_after(self, usage: Usage) -> Budget:
        if not self.allows(usage):
            raise ValueError("usage exceeds budget or a required amount is unknown")

        def remaining(limit: int | float | None, amount: int | float | None) -> Any:
            return None if limit is None else limit - amount

        return Budget(
            evaluations=remaining(self.evaluations, usage.evaluations),
            trials=remaining(self.trials, usage.trials),
            tokens=remaining(self.tokens, usage.tokens),
            spend_micros=remaining(self.spend_micros, usage.spend_micros),
            wall_seconds=remaining(self.wall_seconds, usage.wall_seconds),
        )

    def narrow(self, other: Budget) -> Budget:
        if not isinstance(other, Budget):
            raise TypeError("other must be a Budget")

        def narrower(left: Any, right: Any) -> Any:
            if left is None:
                return right
            if right is None:
                return left
            return min(left, right)

        return Budget(
            evaluations=narrower(self.evaluations, other.evaluations),
            trials=narrower(self.trials, other.trials),
            tokens=narrower(self.tokens, other.tokens),
            spend_micros=narrower(self.spend_micros, other.spend_micros),
            wall_seconds=narrower(self.wall_seconds, other.wall_seconds),
        )


def spend_exhausted(*, remaining: Budget, charged: Usage) -> bool:
    """Whether remaining spend is used up or cannot be verified.

    A zero ceiling still permits known free work. Unknown spend forbids further
    work only when a monetary ceiling exists. Pass a remainder, not the original
    ceiling: the same Budget type represents both.
    """
    if charged.spend_micros is None:
        return remaining.spend_micros is not None
    return remaining.spend_micros == 0 and charged.spend_micros > 0


@dataclass(frozen=True, slots=True, kw_only=True)
class Task:
    """Define independent evaluation, objectives, artifact type, and budget.

    The evaluator receives a decoded candidate. It may return a scalar for a
    single objective, a metric mapping, an EvaluationResult, or a typed failure.
    The first objective controls default ranking. ``artifact=`` accepts a type,
    not an instance; the seed belongs to Experiment. Candidate proposals cannot
    revise this evaluation contract.
    """

    evaluator: ComponentRef | Callable[..., object]
    artifact: InitVar[type | None] = None
    objectives: tuple[Objective, ...] = (Maximize("score"),)
    budget: Budget | None = None
    environment: Mapping[str, object] = field(
        default_factory=FrozenMap,
        metadata={"omit_if_default": True},
    )
    artifact_kind: str = "python-value"
    artifact_representation: str = field(
        default="canonical-json",
        metadata={"omit_if_default": True},
    )

    def __post_init__(self, artifact: type | None) -> None:
        if artifact is not None:
            # The declaration names the artifact *type*; an instance carries
            # the same class attributes and would otherwise pass unnoticed,
            # reading as a seed the task never accepted.
            if not isinstance(artifact, type):
                raise TypeError("task artifact must be a type, not an instance")
            kind = getattr(artifact, "KIND", None)
            representation = getattr(artifact, "REPRESENTATION", None)
            if not isinstance(kind, str) or not isinstance(representation, str):
                raise TypeError(
                    "task artifact must declare string KIND and REPRESENTATION"
                )
            if self.artifact_kind not in ("python-value", kind):
                raise ValueError("task artifact conflicts with artifact_kind")
            if self.artifact_representation not in ("canonical-json", representation):
                raise ValueError(
                    "task artifact conflicts with artifact_representation"
                )
            object.__setattr__(self, "artifact_kind", kind)
            object.__setattr__(self, "artifact_representation", representation)
        evaluator = self.evaluator
        if callable(evaluator) and not isinstance(evaluator, ComponentRef):
            declared = getattr(evaluator, "component", _MISSING)
            if declared is _MISSING:
                evaluator = ComponentRef.local_evaluator(evaluator)
            else:
                if (
                    not isinstance(declared, ComponentRef)
                    or declared.role != "evaluator"
                    or declared.origin != "local"
                    or declared.adapter is not evaluator
                ):
                    raise TypeError(
                        "declared callable component must be a local evaluator "
                        "ComponentRef retaining that callable"
                    )
                evaluator = declared
            object.__setattr__(self, "evaluator", evaluator)
        if not isinstance(evaluator, ComponentRef) or evaluator.role != "evaluator":
            raise TypeError("task evaluator must be an evaluator component or callable")
        object.__setattr__(
            self, "objectives", _validate_objectives(self.objectives, "task")
        )
        if self.budget is not None and not isinstance(self.budget, Budget):
            raise TypeError("task budget must be a Budget")
        _freeze_map_field(self, "environment")
        _require_text(self.artifact_kind, "artifact kind")
        _require_text(self.artifact_representation, "artifact representation")
        adapter = evaluator.adapter
        if adapter is not None:
            validator = getattr(adapter, "validate_task", _MISSING)
            if validator is not _MISSING:
                if not callable(validator):
                    raise TypeError("evaluator validate_task must be callable")
                validator(self)
