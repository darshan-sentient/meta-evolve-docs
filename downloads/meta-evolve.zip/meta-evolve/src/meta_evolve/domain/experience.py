"""Stable references to exact same-run experience occurrences."""

from __future__ import annotations

from dataclasses import dataclass

from .identity import RunId
from .values import _require_text


EXPERIENCE_KINDS = (
    "decision",
    "decision_explanation",
    "trial",
    "proposal",
    "artifact",
    "outcome",
    "evidence",
    "evaluation",
    "context_policy",
    "context_selection",
    "experience_access",
    "experience_grant",
    "experience_attempt",
    "experience_success",
    "experience_denial",
    "experience_exhaustion",
)

NON_CANDIDATE_EXPERIENCE_KINDS = frozenset(
    {
        "context_policy",
        "context_selection",
        "experience_access",
        "experience_grant",
        "experience_attempt",
        "experience_success",
        "experience_denial",
        "experience_exhaustion",
    }
)


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceRef:
    """A run-scoped reference to one causal record occurrence."""

    run_id: RunId
    kind: str
    occurrence_id: str

    def __post_init__(self) -> None:
        if not isinstance(self.run_id, RunId):
            raise TypeError("experience reference run id must be a RunId")
        if self.kind not in EXPERIENCE_KINDS:
            raise ValueError(f"unsupported experience reference kind: {self.kind!r}")
        _require_text(self.occurrence_id, "experience occurrence id")


__all__ = [
    "EXPERIENCE_KINDS",
    "NON_CANDIDATE_EXPERIENCE_KINDS",
    "ExperienceRef",
]
