"""Which one reason a stale submission is stale for, when several hold.

`Lease.credential_mismatch` and `Lease.proves_latest_attempt` each state one
rule; this states the ORDER they are asked in, alongside the row-state and
epoch checks around them, so acceptance and both brokers report the same reason
for the same row. The design record's "Stale reason" term is the vocabulary;
the order is D8's, revised after review:

1. Terminal rows first, and the epoch deliberately unchecked there -- the
   record's terminal exemption, which is what lets a duplicate be answered
   across a restart. A `COMPLETED` row checks attempt, then token; a
   `CANCELLED` row is `ENDED`.
2. `PRIOR_EPOCH`. Before the row, because a genuine cross-restart submission
   otherwise never reports it: `rollover` returns the row to `READY`, and a
   later `acquire` mints a new attempt, so an attempt-first order calls it
   `NOT_LEASED` or `SUPERSEDED_ATTEMPT`. An expired lease from before a restart
   reports the restart, which is the truer cause.
3. A `READY` row is `EXPIRED` when expiry is recognised from the verifier the
   row kept, and `NOT_LEASED` otherwise. Recognising it here is what lets a
   broker that swept expiry before classifying -- as every write does -- still
   say `EXPIRED` rather than the vaguer answer.
4. A `LEASED` row: the credential, then the held deadline, half-open.

`None` means not stale: a live lease, or the accepted lease at a completed row
(a duplicate). The caller knows which by the state it passed in.

Pure: no storage, no clock of its own. Decoding a damaged row is the adapter's
job, so a `LEASED` row without its held lease is refused rather than classified.
"""

from __future__ import annotations

from .work import Lease, LeaseToken, StaleReason, WorkState


def stale_reason_for(
    presented: Lease,
    *,
    state: WorkState,
    held: Lease | None,
    attempts: int,
    verifier: LeaseToken | None,
    accepted_attempt: int | None,
    accepted_token: LeaseToken | None,
    current_epoch: int,
    clock: int,
) -> StaleReason | None:
    """The reason `presented` is stale at this row, or `None` if it is not."""

    if state is WorkState.COMPLETED:
        if presented.attempt.ordinal != accepted_attempt:
            return StaleReason.SUPERSEDED_ATTEMPT
        if accepted_token is None or not presented.token.presents(accepted_token):
            return StaleReason.UNPROVEN_TOKEN
        return None
    if state is WorkState.CANCELLED:
        return StaleReason.ENDED
    if presented.epoch != current_epoch:
        return StaleReason.PRIOR_EPOCH
    if state in (WorkState.READY, WorkState.PREPARING):
        if presented.proves_latest_attempt(attempts, verifier):
            return StaleReason.EXPIRED
        return StaleReason.NOT_LEASED
    if held is None:
        raise ValueError(
            f"a LEASED row for {presented.item.value} must be classified with its "
            "held lease; a leased row without one is damage for the adapter to "
            "report, not a stale submission"
        )
    mismatch = presented.credential_mismatch(held)
    if mismatch is not None:
        return mismatch
    if held.expired_at(clock):
        return StaleReason.EXPIRED
    return None


__all__ = ["stale_reason_for"]
