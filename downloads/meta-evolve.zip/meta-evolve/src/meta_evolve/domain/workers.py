"""Trusted-worker identity, generation and declared capacity.

Its own module because the record gives worker state a different writer and a
different guarantee from work rows: a work row is written by the transaction
that authorises it, while a registration is held by the dispatcher that minted
it. In M11.2 that table is in memory -- nothing persists a worker -- so this
carries no durable concerns and appears in no allowlist.

Deferred out of PR-B1 for having no caller, and restored here with one: the
broker reads capacity and generation inside `acquire`.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256

from .identity import RunId, _OpaqueId
from .values import _require_count, _require_text


@dataclass(frozen=True, slots=True)
class WorkerId(_OpaqueId):
    """One worker's identity within a run.

    Derived from the run and the executor slot rather than random, so a restart
    that rebuilds the same slots mints the same ids and a reader can tell which
    slot a lease belonged to. The record contemplates an operator-supplied id
    for the cross-process case; that arrives with M11.4's registry, where an
    operator exists to supply one.
    """

    @classmethod
    def for_slot(cls, run_id: RunId, slot: int) -> WorkerId:
        if not isinstance(run_id, RunId):
            raise TypeError("worker run id must be a RunId")
        _require_count(slot, "worker slot")
        digest = sha256(
            f"meta-evolve/worker/v1|{run_id.value}|{slot}".encode("utf-8")
        ).hexdigest()
        return cls(f"worker-{digest}")


@dataclass(frozen=True, slots=True, kw_only=True)
class WorkerRegistration:
    """What the broker checks a claim against, read inside its transaction."""

    worker: WorkerId
    generation: int
    max_concurrent_leases: int
    environment_fingerprint: str

    # `generation` is a constant 1 for the whole of M11.2, because REVOCATION is
    # the only thing that moves it and the durable worker table that revocation
    # needs is M11.4's. It is carried and checked now so the field exists where
    # the record requires it, not so that anything can bump it: a `revoked()`
    # helper was written here and deleted for having no caller, which is the
    # speculation `AGENTS.md` rules out.
    #
    # The consequence, stated rather than implied: nothing in M11.2 ENFORCES
    # revocation. A broker compares a presented lease's generation against the
    # one stored with that lease, which catches a mismatched claim and would not
    # catch a worker whose generation an authority had bumped -- there being no
    # such authority yet.

    def __post_init__(self) -> None:
        if not isinstance(self.worker, WorkerId):
            raise TypeError("registration worker must be a WorkerId")
        if isinstance(self.generation, bool) or not isinstance(self.generation, int):
            raise TypeError("registration generation must be an integer")
        if self.generation < 1:
            raise ValueError("registration generation starts at one")
        if (
            isinstance(self.max_concurrent_leases, bool)
            or not isinstance(self.max_concurrent_leases, int)
        ):
            raise TypeError("registration capacity must be an integer")
        if self.max_concurrent_leases < 1:
            raise ValueError("registration capacity must admit at least one lease")
        _require_text(self.environment_fingerprint, "registration fingerprint")

    def admits_one_more(self, *, currently_held: int) -> bool:
        """Whether a worker holding ``currently_held`` leases may take another.

        Named for the claim under consideration rather than `admits(held=)`: the
        `+ 1` is the claim being weighed, and a signature that hides it invites a
        caller to pass the post-claim count and get an off-by-one.
        """

        _require_count(currently_held, "held leases")
        return currently_held + 1 <= self.max_concurrent_leases


__all__ = ["WorkerId", "WorkerRegistration"]
