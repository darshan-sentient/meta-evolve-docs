"""Monetary spend adjudication: one place that decides paid work must stop.

Split out of ``search.py`` rather than left inline. Spend adjudication is one
independently testable responsibility, and folding it back in pushed that module
55 lines past the size limit AGENTS.md sets.

Free functions over committed facts rather than ``SearchState`` methods, so the
aggregate rule and the per-trial rule read as one page instead of as two
properties separated by everything else a state can answer. ``SearchState``
keeps thin properties that delegate, so callers are unaffected.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .task import Budget, Usage, spend_exhausted

if TYPE_CHECKING:  # pragma: no cover - annotation only; search.py imports this
    from .search import SearchState


def trial_ceiling_breached(state: SearchState) -> bool:
    """Whether a completed trial's spend ceiling is exceeded or unverifiable.

    The aggregate remaining budget cannot express this: a policy may submit
    explicit per-trial ``spend_micros`` ceilings while the task and run leave
    spend unbounded, in which case ``spend_exhausted`` never arms and paid work
    continues indefinitely. Each trial's own ceiling and its own attributed
    spend are both durable, so this is a pure fold over committed facts exactly
    like ``usage`` -- live, resume, and recovery therefore agree by
    construction.

    Accumulates plain integers, not ``Usage``: this fold runs on every admission
    check and every policy step, and building a frozen record per event to read
    one field back out of it cost a 200-trial run 14% of its wall clock. It also
    folds only the trials that declared a ceiling, so a run with none pays for
    the ceiling scan alone.

    The sum covers **every** evaluation attributed to a trial, while
    ``application/views.py`` sums the one evaluation a trial view carries. They
    agree today only because ``application/transitions.py`` refuses a second
    evaluation per trial ("M1 supports one evaluation per trial"). Two reasons
    not to share one implementation, neither of them the layering: the semantics
    genuinely differ (all evaluations versus one), and this folds the whole run
    at once while a view is built one cached trial at a time, so calling it per
    view would be quadratic. The accumulating form is the one enforcement wants,
    because it cannot under-count if that restriction lifts. When
    multi-evaluation lands, the two must be reconciled deliberately rather than
    discovered.
    """

    trials = tuple(state.completed_trials)
    ceilings = [
        (item.trial.id, item.trial.spec.budget.spend_micros)
        for item in trials
        # A trial without its own ceiling is unbounded, the bootstrap trial
        # included; only the aggregate rule governs it.
        if item.trial.spec.budget.spend_micros is not None
    ]
    if not ceilings:
        # Nothing declared a ceiling, so skip folding spend per trial.
        return False
    charged = dict.fromkeys((trial_id for trial_id, _ in ceilings), 0)
    for item in trials:
        if item.trial.id in charged:
            amount = item.outcome.usage.spend_micros
            total = charged[item.trial.id]
            charged[item.trial.id] = None if amount is None or total is None else total + amount
    for item in state.completed_evaluations:
        trial_id = item.evaluation.trial_id
        if trial_id in charged:
            amount = item.evaluation.usage.spend_micros
            total = charged[trial_id]
            charged[trial_id] = None if amount is None or total is None else total + amount
    return any(charged[trial_id] is None or charged[trial_id] > ceiling
               for trial_id, ceiling in ceilings)


def unverifiable(state: SearchState) -> bool:
    """Whether a declared aggregate or trial ceiling has an unknown charge."""
    if state.remaining_budget.spend_micros is not None and state.usage.spend_micros is None:
        return True
    bounded = {item.trial.id for item in state.completed_trials
               if item.trial.spec.budget.spend_micros is not None}
    return any(item.trial.id in bounded and item.outcome.usage.spend_micros is None
               for item in state.completed_trials) or any(
        item.evaluation.trial_id in bounded and item.evaluation.usage.spend_micros is None
        for item in state.completed_evaluations
    )


def blocked(
    state: SearchState,
    *,
    remaining: Budget | None = None,
    charged: Usage | None = None,
) -> bool:
    """Whether monetary spend forbids further paid work, at either scope.

    One name for the rule so the advisory halt and the coordinator's admission
    check cannot drift apart.

    ``remaining`` and ``charged`` are what ``state.remaining_budget`` and
    ``state.usage`` would return: pure folds over the same frozen history, which
    both callers have already computed by the time they get here. Passing them
    is an optimisation and nothing else -- anything but ``state``'s own folds is
    a bug, and omitting them is always correct.
    """

    return spend_exhausted(
        remaining=state.remaining_budget if remaining is None else remaining,
        charged=state.usage if charged is None else charged,
    ) or trial_ceiling_breached(state)
