"""Immutable JSON-like values and the validation primitives built on them."""

from __future__ import annotations

import json
import math
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from numbers import Real
from typing import TypeAlias


def _require_text(value: object, name: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError(f"{name} must be a non-empty string without outer whitespace")
    return value


def _require_count(value: object, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer")
    return value


def _require_measurement(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a non-negative finite number")
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise ValueError(f"{name} must be a non-negative finite number")
    return result


def _require_ids(values: Iterable[object], id_type: type, name: str) -> tuple:
    items = tuple(values)
    if not all(isinstance(item, id_type) for item in items):
        raise TypeError(f"{name} must be {id_type.__name__} values")
    if len(items) != len(set(items)):
        raise ValueError(f"{name} must be unique")
    return items


@dataclass(frozen=True, slots=True, init=False)
class FrozenMap(Mapping[str, object]):
    """A recursively immutable mapping with stable key ordering."""

    _items: tuple[tuple[str, object], ...]

    def __init__(
        self,
        values: Mapping[str, object] | Iterable[tuple[str, object]] = (),
    ) -> None:
        source = values.items() if isinstance(values, Mapping) else values
        items: list[tuple[str, object]] = []
        seen: set[str] = set()
        for key, value in source:
            _require_text(key, "mapping key")
            if key in seen:
                raise ValueError(f"duplicate mapping key: {key!r}")
            seen.add(key)
            items.append((key, freeze(value)))
        object.__setattr__(self, "_items", tuple(sorted(items)))

    def __getitem__(self, key: str) -> object:
        for item_key, value in self._items:
            if item_key == key:
                return value
        raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        return (key for key, _ in self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __hash__(self) -> int:
        return hash(self._items)

    def __repr__(self) -> str:
        return f"FrozenMap({dict(self._items)!r})"


FrozenValue: TypeAlias = (
    None | bool | int | float | str | tuple[object, ...] | FrozenMap
)


def freeze(value: object) -> FrozenValue:
    """Convert a JSON-like value to its recursively immutable representation."""

    if isinstance(value, FrozenMap):
        return value
    if isinstance(value, Mapping):
        return FrozenMap(value)
    if isinstance(value, (tuple, list)):
        return tuple(freeze(item) for item in value)
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("durable values cannot contain NaN or infinity")
        return value
    raise TypeError(f"unsupported durable value: {type(value).__name__}")


def _freeze_map_field(instance: object, name: str) -> FrozenMap:
    frozen = FrozenMap(getattr(instance, name))
    object.__setattr__(instance, name, frozen)
    return frozen


def _encode_payload(value: FrozenValue) -> object:
    if isinstance(value, FrozenMap):
        return {"$map": {key: _encode_payload(item) for key, item in value.items()}}
    if isinstance(value, tuple):
        return {"$tuple": [_encode_payload(item) for item in value]}
    return value


def canonical_payload_bytes(value: object) -> bytes:
    """Encode an immutable JSON-like payload for content hashing."""

    return json.dumps(
        _encode_payload(freeze(value)),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _decode_payload(value: object) -> FrozenValue:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("durable values cannot contain NaN or infinity")
        return value
    if isinstance(value, list):
        raise ValueError("untyped JSON arrays are not a valid canonical payload shape")
    if not isinstance(value, dict):
        raise TypeError(f"unsupported canonical payload value: {type(value).__name__}")
    if set(value) == {"$tuple"}:
        items = value["$tuple"]
        if not isinstance(items, list):
            raise ValueError("$tuple must contain an array")
        return tuple(_decode_payload(item) for item in items)
    if set(value) == {"$map"}:
        items = value["$map"]
        if not isinstance(items, dict):
            raise ValueError("$map must contain an object")
        return FrozenMap((key, _decode_payload(item)) for key, item in items.items())
    raise ValueError(f"unrecognized canonical payload shape: {sorted(value)!r}")


def decode_payload_bytes(data: bytes) -> FrozenValue:
    """Strict inverse of ``canonical_payload_bytes``.

    Parses canonical JSON bytes back into a ``FrozenValue``, decoding the
    ``$map``/``$tuple`` wrappers ``_encode_payload`` produces. Unlike
    ``serialization._decode``, this never resolves a ``$type`` dataclass —
    ``canonical_payload_bytes`` never emits one either, so this is a genuine,
    matching inverse of exactly what it encodes.
    """

    return _decode_payload(json.loads(data.decode("utf-8")))
