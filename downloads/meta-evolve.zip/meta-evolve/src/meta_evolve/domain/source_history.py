"""Git-neutral durable facts for a future authorized source-history view."""

from __future__ import annotations

from dataclasses import dataclass

from .experience import ExperienceRef
from .identity import ContentDigest, TrialId
from .values import _require_count, _require_text


SOURCE_HISTORY_FORMAT = "source-history-manifest/v1"


def _ref(value: object, kind: str, name: str) -> ExperienceRef:
    if not isinstance(value, ExperienceRef):
        raise TypeError(f"{name} must be an ExperienceRef")
    if value.kind != kind:
        raise ValueError(f"{name} must identify a {kind} occurrence")
    return value


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceHistoryBounds:
    max_ancestors: int
    max_archive_members: int
    max_chars: int

    def __post_init__(self) -> None:
        _require_count(self.max_ancestors, "source history max ancestors")
        _require_count(
            self.max_archive_members, "source history max archive members"
        )
        _require_count(self.max_chars, "source history max chars")


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceHistoryEntry:
    artifact_ref: ExperienceRef
    digest: ContentDigest
    parent_refs: tuple[ExperienceRef, ...]
    logical_step: int
    proposal_ref: ExperienceRef
    evaluation_ref: ExperienceRef
    selection_rationale: str

    def __post_init__(self) -> None:
        artifact = _ref(self.artifact_ref, "artifact", "history artifact ref")
        if not isinstance(self.digest, ContentDigest):
            raise TypeError("history digest must be a ContentDigest")
        if not isinstance(self.parent_refs, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.parent_refs
        ):
            raise TypeError("history parent refs must be a tuple of ExperienceRefs")
        if len(self.parent_refs) != len(set(self.parent_refs)):
            raise ValueError("history parent refs must be unique")
        for parent in self.parent_refs:
            _ref(parent, "artifact", "history parent ref")
        proposal = _ref(self.proposal_ref, "proposal", "history proposal ref")
        evaluation = _ref(
            self.evaluation_ref, "evaluation", "history evaluation ref"
        )
        if any(
            item.run_id != artifact.run_id
            for item in (*self.parent_refs, proposal, evaluation)
        ):
            raise ValueError("history entry refs must belong to one run")
        _require_count(self.logical_step, "history logical step")
        _require_text(self.selection_rationale, "history selection rationale")


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceHistoryManifest:
    format_version: str
    head_ref: ExperienceRef
    entries: tuple[SourceHistoryEntry, ...]
    bounds: SourceHistoryBounds

    def __post_init__(self) -> None:
        if self.format_version != SOURCE_HISTORY_FORMAT:
            raise ValueError(
                f"source history format must be {SOURCE_HISTORY_FORMAT!r}"
            )
        head = _ref(self.head_ref, "artifact", "source history head ref")
        if not isinstance(self.entries, tuple) or any(
            not isinstance(item, SourceHistoryEntry) for item in self.entries
        ):
            raise TypeError("source history entries must be SourceHistoryEntries")
        if not self.entries:
            raise ValueError("source history entries must not be empty")
        if self.entries[0].artifact_ref != head:
            raise ValueError("source history head must be the first entry")
        artifact_refs = tuple(item.artifact_ref for item in self.entries)
        if len(artifact_refs) != len(set(artifact_refs)):
            raise ValueError("source history artifact refs must be unique")
        if any(item.run_id != head.run_id for item in artifact_refs):
            raise ValueError("source history entries must belong to one run")
        authorized = set(artifact_refs)
        if any(
            parent not in authorized
            for entry in self.entries
            for parent in entry.parent_refs
        ):
            raise ValueError("source history parents must remain inside the manifest")
        if not isinstance(self.bounds, SourceHistoryBounds):
            raise TypeError("source history bounds must be SourceHistoryBounds")


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceHistoryMounted:
    """The exact authorized source history mounted before one proposal."""

    trial_id: TrialId
    observed_version: int
    manifest: SourceHistoryManifest

    def __post_init__(self) -> None:
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("source history mount trial id must be a TrialId")
        _require_count(self.observed_version, "source history observed version")
        if not isinstance(self.manifest, SourceHistoryManifest):
            raise TypeError("source history mount manifest must be a SourceHistoryManifest")


__all__ = [
    "SourceHistoryBounds",
    "SourceHistoryEntry",
    "SourceHistoryManifest",
    "SourceHistoryMounted",
]
