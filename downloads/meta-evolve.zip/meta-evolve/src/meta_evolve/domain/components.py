"""Durable references to components and policies.

Past the ~300-line guideline, deliberately: every record here is a durable reference validated by its own `__post_init__`, and the validations are the file. Splitting them by record would put `ComponentRef`, `PolicyRef` and `RunCapabilities` in three files that each import the same shared refusals from a fourth -- more surface, same rules.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field

from .values import FrozenMap, _freeze_map_field, _require_text


#: The derivation version an environment fingerprint carries as its prefix.
#: Defined HERE, in the leaf that validates it, rather than imported from
#: ``meta_evolve.environment``: that module interrogates the running process
#: (``platform``, ``sys``, ``sysconfig``) and reads back from
#: ``domain.values``, so importing it made a domain record depend outward and
#: closed a loop. ``environment`` imports this name instead.
ENVIRONMENT_FINGERPRINT_VERSION = "meta-evolve/environment/v1"

#: A fingerprint's suffix is the sha256 hexdigest `environment.py` produces.
_FINGERPRINT_DIGEST_LENGTH = 64
_FINGERPRINT_DIGEST_ALPHABET = frozenset("0123456789abcdef")

_ORIGINS = ("registered", "local")
# The version a run-local reference carries when nothing configured it: the
# adapter's module and qualname are its whole identity.
RUN_LOCAL_VERSION = "run-local"


def _require_origin(value: object, name: str) -> str:
    if not isinstance(value, str) or value not in _ORIGINS:
        choices = " or ".join(repr(origin) for origin in _ORIGINS)
        raise ValueError(f"{name} must be {choices}")
    return value


def _is_proposer_adapter(value: object) -> bool:
    return callable(value) or callable(getattr(value, "propose", None))


@dataclass(frozen=True, slots=True)
class ComponentRef:
    """Durable component identity and its registered or local origin."""

    role: str
    name: str
    version: str
    origin: str = "registered"
    _adapter: object | None = field(
        default=None,
        repr=False,
        compare=False,
        hash=False,
        metadata={"serialize": False},
    )

    def __post_init__(self) -> None:
        _require_text(self.role, "component role")
        _require_text(self.name, "component name")
        _require_text(self.version, "component version")
        _require_origin(self.origin, "component origin")
        if self.origin != "local" and self._adapter is not None:
            raise ValueError("only local component references may retain an adapter")
        if self._adapter is not None and not callable(self._adapter):
            if self.role != "proposer" or not _is_proposer_adapter(self._adapter):
                raise TypeError("component adapter must be callable")

    @classmethod
    def proposer(cls, name: str, version: str) -> ComponentRef:
        return cls(role="proposer", name=name, version=version)

    @classmethod
    def evaluator(cls, name: str, version: str) -> ComponentRef:
        return cls(role="evaluator", name=name, version=version)

    @classmethod
    def _run_local(cls, role: str, adapter: object) -> ComponentRef:
        """Build the run-local ref whose identity is the adapter's own name."""

        module = getattr(adapter, "__module__", type(adapter).__module__)
        name = getattr(adapter, "__qualname__", type(adapter).__qualname__)
        return cls(
            role=role,
            name=f"{module}:{name}",
            version=RUN_LOCAL_VERSION,
            origin="local",
            _adapter=adapter,
        )

    @classmethod
    def local(cls, role: str, adapter: Callable[..., object]) -> ComponentRef:
        if not callable(adapter):
            raise TypeError("local component adapter must be callable")
        return cls._run_local(role, adapter)

    @classmethod
    def local_proposer(cls, adapter: object) -> ComponentRef:
        if not _is_proposer_adapter(adapter):
            raise TypeError(
                "local proposer adapter must be callable or implement "
                "propose(parent, context)"
            )
        return cls._run_local("proposer", adapter)

    @classmethod
    def local_evaluator(cls, adapter: Callable[..., object]) -> ComponentRef:
        return cls.local("evaluator", adapter)

    @classmethod
    def configured_local(
        cls,
        role: str,
        adapter: object,
        *,
        name: str,
        version: str,
    ) -> ComponentRef:
        """A local reference that identifies its component by configuration.

        The way out of the run-local sentinel for a closure or live object
        whose behaviour depends on captured state its module and qualname
        cannot show -- a model id, a threshold, a case list. Declaring it is
        what lets ``compare`` refuse two runs configured differently, since
        equality of a name-only reference proves nothing about the callable.

        ``origin`` and the retained adapter are derived rather than accepted:
        ``Task`` admits a callable's declared component only when it is a local
        reference holding that exact callable by identity, so a caller-supplied
        pair could only ever build a reference the declaration hook rejects.

        ``version`` must not be ``RUN_LOCAL_VERSION``. A reference claiming to
        be configured while still reporting as ``name_only`` is precisely the
        state the report exists to expose.
        """

        _require_text(name, "component name")
        _require_text(version, "component version")
        if version == RUN_LOCAL_VERSION:
            raise ValueError(
                "a configured local component version must not be the run-local "
                f"sentinel {RUN_LOCAL_VERSION!r}"
            )
        return cls(
            role=role,
            name=name,
            version=version,
            origin="local",
            _adapter=adapter,
        )

    @property
    def adapter(self) -> object | None:
        return self._adapter

    @property
    def name_only(self) -> bool:
        """Whether this reference identifies its component by name alone.

        True only for the run-local sentinel, where module and qualname are the
        whole identity and ``_adapter`` is excluded from equality -- so two
        closures from one factory over different captured state compare equal.

        Must never be simplified to ``origin == "local"``: a local component may
        version itself with a full configuration digest (``CommandEvaluator``
        does), and those references identify their component exactly.
        """

        return self.origin == "local" and self.version == RUN_LOCAL_VERSION


_REQUIRED_MANIFEST_ROLES = ("proposer", "evaluator", "policy")
# Optional roles a non-legacy run MAY additionally record (e.g. a run that
# declares an M3 context policy). Absent by default so the common three-role
# run is unchanged.
_OPTIONAL_MANIFEST_ROLES = ("context-policy",)
_MANIFEST_ROLES = _REQUIRED_MANIFEST_ROLES + _OPTIONAL_MANIFEST_ROLES
_ALLOWED_MODES = ("local", "durable-local", "distributed")


@dataclass(frozen=True, slots=True, kw_only=True)
class ComponentManifest:
    """A verified component identity: source and configuration digests.

    Digest construction and registry lookup live outside ``domain``
    (``manifests.py``/``registry.py``); this record only carries the
    already-computed, immutable result. ``deterministic``/``retry_safe``
    are declarations made at registration time, not runtime proofs.
    """

    role: str
    name: str
    version: str
    import_hint: str
    implementation_digest: str
    configuration_digest: str
    deterministic: bool
    retry_safe: bool
    work_requirements: FrozenMap | Mapping[str, object] = field(
        default_factory=FrozenMap, metadata={"omit_if_default": True}
    )

    def __post_init__(self) -> None:
        if self.role not in _MANIFEST_ROLES:
            choices = " or ".join(repr(role) for role in _MANIFEST_ROLES)
            raise ValueError(f"component manifest role must be {choices}")
        _require_text(self.name, "component manifest name")
        _require_text(self.version, "component manifest version")
        _require_text(self.import_hint, "component manifest import hint")
        _require_text(
            self.implementation_digest, "component manifest implementation digest"
        )
        if not isinstance(self.configuration_digest, str):
            raise TypeError("component manifest configuration digest must be a string")
        if not isinstance(self.deterministic, bool):
            raise TypeError("component manifest deterministic flag must be a bool")
        if not isinstance(self.retry_safe, bool):
            raise TypeError("component manifest retry_safe flag must be a bool")
        _freeze_map_field(self, "work_requirements")


def _validate_component_manifests(
    values: object,
) -> tuple[ComponentManifest, ...]:
    """Canonical, keyed-set validation for a run's recorded manifest tuple.

    Empty is valid (legacy-local runs record none). A non-empty tuple must
    cover exactly one proposer, one evaluator, and one policy manifest, and
    MAY additionally carry at most one of each optional role (e.g. a
    ``context-policy`` when the run declares an M3 context policy). It is
    returned in a stable role-sorted order so equality never depends on
    registration or resolution order.
    """

    if not isinstance(values, tuple) or not all(
        isinstance(item, ComponentManifest) for item in values
    ):
        raise TypeError(
            "run capability component manifests must be a tuple of ComponentManifest"
        )
    if not values:
        return values
    roles = tuple(item.role for item in values)
    present = set(roles)
    missing = set(_REQUIRED_MANIFEST_ROLES) - present
    unknown = present - set(_MANIFEST_ROLES)
    if len(roles) != len(present) or missing or unknown:
        raise ValueError(
            "run capability component manifests must cover exactly one "
            "proposer, one evaluator, and one policy, plus at most one of each "
            "optional role"
        )
    return tuple(sorted(values, key=lambda item: item.role))


@dataclass(frozen=True, slots=True, kw_only=True)
class RunCapabilities:
    """Recorded execution profile and verified component manifests."""

    mode: str
    resumable: bool
    component_manifests: tuple[ComponentManifest, ...] = ()
    environment_fingerprint: str = field(
        default="", metadata={"omit_if_default": True}
    )

    def __post_init__(self) -> None:
        if self.mode not in _ALLOWED_MODES:
            raise ValueError(f"run capability mode must be one of {_ALLOWED_MODES}")
        if not isinstance(self.resumable, bool):
            raise TypeError("run capability resumable must be a bool")
        object.__setattr__(
            self,
            "component_manifests",
            _validate_component_manifests(self.component_manifests),
        )
        if self.mode == "local" and (self.resumable or self.component_manifests):
            raise ValueError(
                "local runs are neither resumable nor carry component manifests"
            )
        if self.resumable and self.mode not in ("durable-local", "distributed"):
            raise ValueError(
                "only durable-local and distributed runs may be resumable"
            )
        if not isinstance(self.environment_fingerprint, str):
            raise TypeError("run capability environment fingerprint must be a string")
        # Recorded exactly when there will be a worker to compare it against. On
        # a local or durable-local run nothing declares an environment, so a
        # fingerprint there is a fact no reader consults; on a distributed run
        # its absence would silently retire the drift refusal PR-B2 adds. Stated
        # as forthcoming on purpose: nothing reads this field yet, and a comment
        # in the present tense would claim a mechanism that does not exist.
        if bool(self.environment_fingerprint) != (self.mode == "distributed"):
            raise ValueError(
                "a distributed run records an environment fingerprint and no "
                "other mode does"
            )
        # Well-formed, not merely non-empty. Every other string in this module
        # goes through `_require_text`, and this one additionally has a shape:
        # the digest is meaningless without the version prefix that says which
        # derivation produced it, so `'x'` must not pass for a distributed run.
        if self.environment_fingerprint:
            _require_text(
                self.environment_fingerprint, "run capability environment fingerprint"
            )
            prefix = f"{ENVIRONMENT_FINGERPRINT_VERSION}:"
            if not self.environment_fingerprint.startswith(prefix):
                raise ValueError(
                    "run capability environment fingerprint must carry its "
                    f"derivation version ({ENVIRONMENT_FINGERPRINT_VERSION})"
                )
            # ... and the digest behind it. Checking only the prefix accepted
            # `'meta-evolve/environment/v1:'` and `'...:garbage'`, which
            # serialize and replay perfectly while no legitimate worker
            # fingerprint can ever equal them -- so the run is unstartable and
            # unresumable for good, and nothing says why.
            digest = self.environment_fingerprint[len(prefix):]
            if len(digest) != _FINGERPRINT_DIGEST_LENGTH or not (
                set(digest) <= _FINGERPRINT_DIGEST_ALPHABET
            ):
                raise ValueError(
                    "run capability environment fingerprint must end in a "
                    f"{_FINGERPRINT_DIGEST_LENGTH}-character lowercase hex "
                    "digest"
                )
        if self.resumable and not self.component_manifests:
            raise ValueError(
                "a resumable run must record component manifests"
            )
        # A distributed run needs them for the same reason it needs a
        # fingerprint above, and independently of `resumable`: the manifests are
        # what a worker's identity is checked AGAINST, so a distributed run
        # recording none has nothing to refuse a mismatched worker with. Tying
        # the requirement to `resumable` alone left `mode="distributed",
        # resumable=False` validating with an empty tuple -- a run that
        # dispatches to workers it cannot identify.
        if self.mode == "distributed" and not self.component_manifests:
            raise ValueError(
                "a distributed run must record component manifests"
            )


LEGACY_LOCAL_CAPABILITIES = RunCapabilities(mode="local", resumable=False)


@dataclass(frozen=True, slots=True)
class PolicyRef:
    """Durable policy identity and its registered or local origin."""

    name: str
    version: str
    origin: str = "registered"

    def __post_init__(self) -> None:
        _require_text(self.name, "policy name")
        _require_text(self.version, "policy version")
        _require_origin(self.origin, "policy origin")
