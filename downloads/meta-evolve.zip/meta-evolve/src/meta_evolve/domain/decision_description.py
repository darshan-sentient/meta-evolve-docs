"""Non-durable metadata returned by decision-description capabilities."""

from __future__ import annotations

from dataclasses import dataclass

from .values import _require_text


@dataclass(frozen=True, slots=True)
class DecisionDescription:
    rationale: str
    random_streams: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _require_text(self.rationale, "decision rationale")
        if not isinstance(self.random_streams, tuple):
            raise TypeError("decision random streams must be a tuple")
        for name in self.random_streams:
            _require_text(name, "random stream name")
        if len(set(self.random_streams)) != len(self.random_streams):
            raise ValueError("decision random stream names must be unique")


def humanize_reason(reason: str) -> str:
    """Render a structured decision reason as prose without changing the fact."""

    return reason.replace("_", " ")


__all__ = ["DecisionDescription"]
