"""Trial outcomes, evidence, evaluations, and the typed failure taxonomy."""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from numbers import Real
from typing import ClassVar, TypeAlias

from .components import ComponentRef
from .identity import ArtifactId, EvaluationId, EvidenceId, ProposalId, TrialId
from .task import Usage
from .values import FrozenMap, _freeze_map_field, _require_ids, _require_text


def _validate_metrics(values: Mapping[str, object] | FrozenMap) -> FrozenMap:
    metrics = FrozenMap(values)
    for name, value in metrics.items():
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ValueError(f"evaluation metric {name!r} must be numeric")
        if not math.isfinite(float(value)):
            raise ValueError(f"evaluation metric {name!r} must be finite")
    return metrics


def _validate_uncertainty(values: Mapping[str, object] | FrozenMap) -> FrozenMap:
    uncertainty = FrozenMap(values)
    for name, value in uncertainty.items():
        if (
            isinstance(value, bool)
            or not isinstance(value, Real)
            or not math.isfinite(float(value))
            or float(value) < 0
        ):
            raise ValueError(
                f"evaluation uncertainty {name!r} must be non-negative"
            )
    return uncertainty


def _validate_evidence_fields(
    kind: object,
    data: Mapping[str, object] | FrozenMap,
    uri: object,
) -> tuple[str, FrozenMap, str | None]:
    validated_kind = _require_text(kind, "evidence kind")
    validated_data = FrozenMap(data)
    if uri is not None:
        validated_uri = _require_text(uri, "evidence uri")
    else:
        validated_uri = None
    return validated_kind, validated_data, validated_uri


@dataclass(frozen=True, slots=True, kw_only=True)
class Failure:
    message: str
    details: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    kind: ClassVar[str] = "failure"

    def __post_init__(self) -> None:
        _require_text(self.message, "failure message")
        _freeze_map_field(self, "details")


@dataclass(frozen=True, slots=True, kw_only=True)
class InvalidOutput(Failure):
    kind: ClassVar[str] = "invalid_output"


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposerFailure(Failure):
    kind: ClassVar[str] = "proposer_failure"


@dataclass(frozen=True, slots=True, kw_only=True)
class EvaluatorFailure(Failure):
    kind: ClassVar[str] = "evaluator_failure"


@dataclass(frozen=True, slots=True, kw_only=True)
class TimeoutFailure(Failure):
    kind: ClassVar[str] = "timeout"


@dataclass(frozen=True, slots=True, kw_only=True)
class ResourceExhausted(Failure):
    kind: ClassVar[str] = "resource_exhausted"


@dataclass(frozen=True, slots=True, kw_only=True)
class PolicyViolation(Failure):
    kind: ClassVar[str] = "policy_violation"


@dataclass(frozen=True, slots=True, kw_only=True)
class InfrastructureFailure(Failure):
    kind: ClassVar[str] = "infrastructure_failure"


_FailureType: TypeAlias = (
    InvalidOutput
    | ProposerFailure
    | EvaluatorFailure
    | TimeoutFailure
    | ResourceExhausted
    | PolicyViolation
    | InfrastructureFailure
)

_FAILURE_TYPES = (
    InvalidOutput,
    ProposerFailure,
    EvaluatorFailure,
    TimeoutFailure,
    ResourceExhausted,
    PolicyViolation,
    InfrastructureFailure,
)

FAILURE_KINDS = tuple(failure_type.kind for failure_type in _FAILURE_TYPES)


@dataclass(frozen=True, slots=True, kw_only=True)
class TrialOutcome:
    """A successful artifact commit or a typed execution failure."""

    trial_id: TrialId
    proposal_id: ProposalId | None
    artifact_ids: tuple[ArtifactId, ...]
    evidence_ids: tuple[EvidenceId, ...] = ()
    usage: Usage = Usage()
    failure: _FailureType | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("outcome trial id must be a TrialId")
        if self.proposal_id is not None and not isinstance(
            self.proposal_id, ProposalId
        ):
            raise TypeError("outcome proposal id must be a ProposalId")
        artifact_ids = _require_ids(
            self.artifact_ids, ArtifactId, "outcome artifact ids"
        )
        object.__setattr__(self, "artifact_ids", artifact_ids)
        object.__setattr__(
            self,
            "evidence_ids",
            _require_ids(self.evidence_ids, EvidenceId, "outcome evidence ids"),
        )
        if not isinstance(self.usage, Usage):
            raise TypeError("outcome usage must be a Usage")
        if self.failure is None:
            if self.proposal_id is None or not artifact_ids:
                raise ValueError(
                    "a successful outcome requires a proposal and artifact"
                )
        else:
            if type(self.failure) not in _FAILURE_TYPES:
                raise TypeError("outcome failure must be a typed Failure")
            if artifact_ids:
                raise ValueError("a failed outcome cannot commit artifacts")

    @classmethod
    def succeeded(
        cls,
        *,
        trial_id: TrialId,
        proposal_id: ProposalId,
        artifact_ids: tuple[ArtifactId, ...],
        evidence_ids: tuple[EvidenceId, ...] = (),
        usage: Usage = Usage(),
    ) -> TrialOutcome:
        return cls(
            trial_id=trial_id,
            proposal_id=proposal_id,
            artifact_ids=artifact_ids,
            evidence_ids=evidence_ids,
            usage=usage,
        )

    @classmethod
    def failed(
        cls,
        *,
        trial_id: TrialId,
        failure: _FailureType,
        proposal_id: ProposalId | None = None,
        evidence_ids: tuple[EvidenceId, ...] = (),
        usage: Usage = Usage(),
    ) -> TrialOutcome:
        return cls(
            trial_id=trial_id,
            proposal_id=proposal_id,
            artifact_ids=(),
            evidence_ids=evidence_ids,
            usage=usage,
            failure=failure,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Evidence:
    id: EvidenceId
    kind: str
    data: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    uri: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.id, EvidenceId):
            raise TypeError("evidence id must be an EvidenceId")
        kind, data, uri = _validate_evidence_fields(self.kind, self.data, self.uri)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "data", data)
        object.__setattr__(self, "uri", uri)


@dataclass(frozen=True, slots=True, kw_only=True)
class Evaluation:
    """Independent measurements or a typed evaluation failure."""

    id: EvaluationId
    trial_id: TrialId
    artifact_id: ArtifactId
    evaluator: ComponentRef
    metrics: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence_ids: tuple[EvidenceId, ...] = ()
    uncertainty: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    usage: Usage = Usage()
    failure: _FailureType | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.id, EvaluationId):
            raise TypeError("evaluation id must be an EvaluationId")
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("evaluation trial id must be a TrialId")
        if not isinstance(self.artifact_id, ArtifactId):
            raise TypeError("evaluation artifact id must be an ArtifactId")
        if (
            not isinstance(self.evaluator, ComponentRef)
            or self.evaluator.role != "evaluator"
        ):
            raise TypeError(
                "evaluation evaluator must be an evaluator component reference"
            )
        metrics = _validate_metrics(self.metrics)
        object.__setattr__(self, "metrics", metrics)
        object.__setattr__(
            self,
            "evidence_ids",
            _require_ids(
                self.evidence_ids, EvidenceId, "evaluation evidence ids"
            ),
        )
        uncertainty = _validate_uncertainty(self.uncertainty)
        object.__setattr__(self, "uncertainty", uncertainty)
        if not isinstance(self.usage, Usage):
            raise TypeError("evaluation usage must be a Usage")
        if self.failure is None:
            if not metrics:
                raise ValueError("a successful evaluation requires metrics")
        else:
            if type(self.failure) not in _FAILURE_TYPES:
                raise TypeError("evaluation failure must be a typed Failure")
            if metrics:
                raise ValueError("a failed evaluation cannot carry rankable metrics")

    @classmethod
    def succeeded(
        cls,
        *,
        id: EvaluationId,
        trial_id: TrialId,
        artifact_id: ArtifactId,
        evaluator: ComponentRef,
        metrics: Mapping[str, object] | FrozenMap,
        evidence_ids: tuple[EvidenceId, ...] = (),
        uncertainty: Mapping[str, object] | FrozenMap = FrozenMap(),
        usage: Usage = Usage(),
    ) -> Evaluation:
        return cls(
            id=id,
            trial_id=trial_id,
            artifact_id=artifact_id,
            evaluator=evaluator,
            metrics=metrics,
            evidence_ids=evidence_ids,
            uncertainty=uncertainty,
            usage=usage,
        )

    @classmethod
    def failed(
        cls,
        *,
        id: EvaluationId,
        trial_id: TrialId,
        artifact_id: ArtifactId,
        evaluator: ComponentRef,
        failure: _FailureType,
        evidence_ids: tuple[EvidenceId, ...] = (),
        usage: Usage = Usage(),
    ) -> Evaluation:
        return cls(
            id=id,
            trial_id=trial_id,
            artifact_id=artifact_id,
            evaluator=evaluator,
            evidence_ids=evidence_ids,
            usage=usage,
            failure=failure,
        )
