"""Durable declarations, grants, requests, observations, and pull usage."""

from __future__ import annotations

from dataclasses import dataclass, field
from numbers import Real

from .context import ContextRecord
from .evaluation import FAILURE_KINDS
from .experience import ExperienceRef
from .identity import RunId, TaskId, TrialId
from .values import FrozenMap, _freeze_map_field, _require_count, _require_text


EXPERIENCE_OPERATIONS = (
    "search", "open", "ancestors", "siblings", "compare",
    "list_source_paths", "read_source", "diff_source",
)


def _normalized(values: object, name: str) -> tuple[str, ...]:
    if isinstance(values, str):
        raise TypeError(f"{name} must be an iterable of strings")
    try:
        result = tuple(sorted(set(values)))  # type: ignore[arg-type]
    except TypeError as error:
        raise TypeError(f"{name} must be an iterable of strings") from error
    if not all(isinstance(item, str) for item in result):
        raise TypeError(f"{name} must contain strings")
    for item in result:
        _require_text(item, name[:-1])
    return result


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceSpec:
    max_operations: int = 20
    max_results: int = 20
    max_records: int = 100
    max_chars: int = 32_000

    def __post_init__(self) -> None:
        for value, name in (
            (self.max_operations, "experience max operations"),
            (self.max_results, "experience max results"),
            (self.max_records, "experience max records"),
            (self.max_chars, "experience max chars"),
        ):
            _require_count(value, name)


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceGrant:
    run_id: RunId
    task_id: TaskId
    trial_id: TrialId
    as_of: int
    spec: ExperienceSpec

    def __post_init__(self) -> None:
        if not isinstance(self.run_id, RunId):
            raise TypeError("experience grant run id must be a RunId")
        if not isinstance(self.task_id, TaskId):
            raise TypeError("experience grant task id must be a TaskId")
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("experience grant trial id must be a TrialId")
        _require_count(self.as_of, "experience grant as_of")
        if not isinstance(self.spec, ExperienceSpec):
            raise TypeError("experience grant spec must be an ExperienceSpec")

    @property
    def max_operations(self) -> int:
        return self.spec.max_operations

    @property
    def max_results(self) -> int:
        return self.spec.max_results

    @property
    def max_records(self) -> int:
        return self.spec.max_records

    @property
    def max_chars(self) -> int:
        return self.spec.max_chars


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceFilter:
    record_kinds: tuple[str, ...] = ()
    failure_kinds: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "record_kinds",
            _normalized(self.record_kinds, "record kinds"),
        )
        object.__setattr__(
            self,
            "failure_kinds",
            _normalized(self.failure_kinds, "failure kinds"),
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceRequest:
    operation: str
    filters: ExperienceFilter = ExperienceFilter()
    ref: ExperienceRef | None = None
    other_ref: ExperienceRef | None = None
    as_of: int | None = None
    limit: int | None = None
    paths: tuple[str, ...] = field(
        default=(), metadata={"omit_if_default": True}
    )

    def __post_init__(self) -> None:
        if self.operation not in EXPERIENCE_OPERATIONS:
            raise ValueError(f"unsupported experience operation: {self.operation!r}")
        if not isinstance(self.filters, ExperienceFilter):
            raise TypeError("experience request filters must be ExperienceFilter")
        if self.ref is not None and not isinstance(self.ref, ExperienceRef):
            raise TypeError("experience request ref must be an ExperienceRef")
        if self.other_ref is not None and not isinstance(
            self.other_ref, ExperienceRef
        ):
            raise TypeError("experience request other ref must be an ExperienceRef")
        if self.as_of is not None:
            if isinstance(self.as_of, bool) or not isinstance(self.as_of, int):
                raise TypeError("experience request as_of must be an integer")
        if self.limit is not None:
            if isinstance(self.limit, bool) or not isinstance(self.limit, int):
                raise TypeError("experience request limit must be an integer")
        if not isinstance(self.paths, tuple) or any(
            not isinstance(path, str) for path in self.paths
        ):
            raise TypeError("experience request paths must be a tuple of strings")
        if self.operation == "search":
            if self.ref is not None or self.other_ref is not None:
                raise ValueError("search request cannot contain target references")
        elif self.operation == "compare":
            if self.ref is None or self.other_ref is None:
                raise ValueError("compare request requires two references")
            if self.filters != ExperienceFilter() or self.limit is not None:
                raise ValueError("compare request cannot contain filters or a limit")
        elif self.operation == "diff_source":
            if self.ref is None or self.other_ref is None:
                raise ValueError("diff_source request requires two references")
            if self.filters != ExperienceFilter() or self.limit is not None:
                raise ValueError("diff_source request cannot contain filters or a limit")
        elif self.operation in {"list_source_paths", "read_source"}:
            if self.ref is None or self.other_ref is not None:
                raise ValueError(f"{self.operation} request requires one reference")
            if self.filters != ExperienceFilter():
                raise ValueError(f"{self.operation} request cannot contain filters")
            if self.operation == "list_source_paths" and self.paths:
                raise ValueError("list_source_paths request cannot contain paths")
            if self.operation == "read_source" and self.limit is not None:
                raise ValueError("read_source request cannot contain a limit")
        else:
            if self.ref is None or self.other_ref is not None:
                raise ValueError(f"{self.operation} request requires one reference")
            if self.filters != ExperienceFilter():
                raise ValueError(f"{self.operation} request cannot contain filters")
            if self.operation == "open" and self.limit is not None:
                raise ValueError("open request cannot contain a limit")
        if self.operation not in {"read_source", "diff_source"} and self.paths:
            raise ValueError(f"{self.operation} request cannot contain paths")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceUsage:
    operations: int = 0
    results: int = 0
    records: int = 0
    chars: int = 0

    def __post_init__(self) -> None:
        for value, name in (
            (self.operations, "experience usage operations"),
            (self.results, "experience usage results"),
            (self.records, "experience usage records"),
            (self.chars, "experience usage chars"),
        ):
            _require_count(value, name)


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceObservation:
    references: tuple[ExperienceRef, ...] = ()
    records: tuple[ContextRecord, ...] = ()
    rendered: str = ""
    truncated: bool = False
    usage: ExperienceUsage = ExperienceUsage()

    def __post_init__(self) -> None:
        if not isinstance(self.references, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.references
        ):
            raise TypeError("experience references must be ExperienceRefs")
        if len(set(self.references)) != len(self.references):
            raise ValueError("experience references must be unique")
        if not isinstance(self.records, tuple) or any(
            not isinstance(item, ContextRecord) for item in self.records
        ):
            raise TypeError("experience observation records must be ContextRecords")
        if not isinstance(self.rendered, str):
            raise TypeError("experience rendering must be text")
        if not isinstance(self.truncated, bool):
            raise TypeError("experience truncation must be a boolean")
        if not isinstance(self.usage, ExperienceUsage):
            raise TypeError("experience observation usage must be ExperienceUsage")
        if (
            self.usage.results < len(self.references)
            or self.usage.records < len(self.records)
            or self.usage.chars < len(self.rendered)
        ):
            raise ValueError("experience observation usage cannot undercount contents")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceComparison:
    left: ExperienceRef
    right: ExperienceRef
    references: tuple[ExperienceRef, ...] = ()
    left_records: tuple[ContextRecord, ...] = ()
    right_records: tuple[ContextRecord, ...] = ()
    deltas: FrozenMap | dict[str, object] = field(default_factory=FrozenMap)
    rendered: str = ""
    truncated: bool = False
    usage: ExperienceUsage = ExperienceUsage()

    def __post_init__(self) -> None:
        if not isinstance(self.left, ExperienceRef) or not isinstance(
            self.right, ExperienceRef
        ):
            raise TypeError("experience comparison targets must be ExperienceRefs")
        if not isinstance(self.references, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.references
        ):
            raise TypeError("experience comparison references must be ExperienceRefs")
        for records, name in (
            (self.left_records, "left"),
            (self.right_records, "right"),
        ):
            if not isinstance(records, tuple) or any(
                not isinstance(item, ContextRecord) for item in records
            ):
                raise TypeError(f"experience comparison {name} records are invalid")
        deltas = _freeze_map_field(self, "deltas")
        if any(
            isinstance(value, bool) or not isinstance(value, Real)
            for value in deltas.values()
        ):
            raise ValueError("experience comparison deltas must be numeric")
        if not isinstance(self.rendered, str):
            raise TypeError("experience comparison rendering must be text")
        if not isinstance(self.truncated, bool):
            raise TypeError("experience comparison truncation must be a boolean")
        if not isinstance(self.usage, ExperienceUsage):
            raise TypeError("experience comparison usage must be ExperienceUsage")
        records = len(self.left_records) + len(self.right_records)
        if (
            self.usage.results < len(self.references)
            or self.usage.records < records
            or self.usage.chars < len(self.rendered)
        ):
            raise ValueError("experience comparison usage cannot undercount contents")


ExperienceResult = ExperienceObservation | ExperienceComparison


__all__ = [
    "EXPERIENCE_OPERATIONS",
    "FAILURE_KINDS",
    "ExperienceComparison",
    "ExperienceFilter",
    "ExperienceGrant",
    "ExperienceObservation",
    "ExperienceRequest",
    "ExperienceResult",
    "ExperienceSpec",
    "ExperienceUsage",
]
