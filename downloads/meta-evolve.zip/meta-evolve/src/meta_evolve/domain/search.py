"""Policy-facing search state and deterministic decision randomness.

Slightly over AGENTS.md's 300-line guidance, deliberately: what remains after
spend adjudication moved to ``spend.py`` is a single type whose members are all
folds over one event stream (``usage``, ``remaining_budget``,
``incumbent_value``, ``budget_exhausted``). Splitting those apart would mean
passing that stream across a module boundary to compute halves of one
projection, which is harder to follow than the extra lines.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from hashlib import sha256
from typing import Protocol

from .components import PolicyRef
from .evaluation import Evaluation, TrialOutcome
from .events import (
    EvaluationCompleted,
    PolicyDecisionMade,
    RunStarted,
    TrialCompleted,
)
from .identity import ArtifactId, DecisionId, RunId
from . import spend
from .task import Budget, Maximize, Objective, Task, Usage
from .trial import ArchiveUpdate, SearchDecision, Stop
from .values import _require_count, _require_text, canonical_payload_bytes


class InvalidSearchHistory(ValueError):
    """The event facts cannot describe one coherent search history."""


class SearchNotStarted(RuntimeError):
    """A policy-facing view was requested before the run start completed."""


class PolicyMismatch(ValueError):
    def __init__(self, expected: PolicyRef, actual: PolicyRef) -> None:
        self.expected = expected
        self.actual = actual
        super().__init__(f"search policy is {actual!r}, not {expected!r}")


@dataclass(frozen=True, slots=True)
class DecisionRandomness:
    root_seed: int
    policy: PolicyRef
    decision_id: DecisionId

    def __post_init__(self) -> None:
        if isinstance(self.root_seed, bool) or not isinstance(self.root_seed, int):
            raise TypeError("randomness root seed must be an integer")
        if not isinstance(self.policy, PolicyRef):
            raise TypeError("randomness policy must be a PolicyRef")
        if not isinstance(self.decision_id, DecisionId):
            raise TypeError("randomness decision id must be a DecisionId")

    def seed(self, name: str) -> int:
        _require_text(name, "random stream name")
        payload = canonical_payload_bytes(
            {
                "decision_id": self.decision_id.value,
                "domain": "meta-evolve/random-substream/v1",
                "policy": {
                    "name": self.policy.name,
                    "origin": self.policy.origin,
                    "version": self.policy.version,
                },
                "root_seed": self.root_seed,
                "stream": name,
            }
        )
        return int.from_bytes(sha256(payload).digest(), "big")


def decision_id_for(run_id: RunId, logical_step: int) -> DecisionId:
    if not isinstance(run_id, RunId):
        raise TypeError("decision run id must be a RunId")
    if (
        isinstance(logical_step, bool)
        or not isinstance(logical_step, int)
        or logical_step < 1
    ):
        raise ValueError("decision logical step must be a positive integer")
    payload = canonical_payload_bytes(
        {
            "domain": "meta-evolve/search-decision/v1",
            "logical_step": logical_step,
            "run_id": run_id.value,
        }
    )
    return DecisionId(f"decision-{sha256(payload).hexdigest()}")


def rank_evaluations(
    objective: Objective, evaluations: Iterable[Evaluation]
) -> tuple[Evaluation, ...]:
    """Successful evaluations best-first; the input's own order breaks ties.

    Score is primary and the sort is stable, so a later better score still wins
    and only an exact tie falls back to the order the caller supplied. A caller
    passing a ``RunProjection`` collection therefore gets ties resolved by
    logical step, because those collections are canonicalized at insertion. A
    caller gathering evaluations from anywhere else inherits that source's order
    instead -- ``policies/context.py`` ranks experience-graph siblings, which
    have no relation to this run's logical steps.
    """

    successful = [item for item in evaluations if item.failure is None]
    return tuple(
        sorted(
            successful,
            key=lambda item: float(item.metrics[objective.metric]),
            reverse=isinstance(objective, Maximize),
        )
    )


def _remaining_or_zero(budget: Budget, usage: Usage) -> Budget:
    def remaining(limit: int | float | None, amount: int | float | None):
        if limit is None:
            return None
        return 0 if amount is None else max(0, limit - amount)

    return Budget(
        evaluations=remaining(budget.evaluations, usage.evaluations),
        trials=remaining(budget.trials, usage.trials),
        tokens=remaining(budget.tokens, usage.tokens),
        spend_micros=remaining(budget.spend_micros, usage.spend_micros),
        wall_seconds=remaining(budget.wall_seconds, usage.wall_seconds),
    )


def _recorded_usage(
    completed_trials: tuple[TrialCompleted, ...],
    completed_evaluations: tuple[EvaluationCompleted, ...],
) -> Usage:
    """Fold committed costs independently of policy readiness or rankability."""
    outcomes = tuple(item.outcome for item in completed_trials)
    evaluations = tuple(item.evaluation for item in completed_evaluations)
    charged = outcomes + evaluations
    spend_values = tuple(item.usage.spend_micros for item in charged)
    return Usage(
        trials=sum(item.usage.trials for item in outcomes),
        evaluations=sum(item.usage.evaluations for item in evaluations),
        tokens=sum(item.usage.tokens for item in charged),
        spend_micros=None if None in spend_values else sum(spend_values),
        wall_seconds=sum(item.usage.wall_seconds for item in charged),
    )


@dataclass(frozen=True, slots=True, kw_only=True)
class SearchState:
    """Immutable facts whose policy-facing views are derived on demand."""

    run_id: RunId
    version: int = 0
    start: RunStarted | None = None
    artifact_ids: tuple[ArtifactId, ...] = ()
    decisions: tuple[PolicyDecisionMade, ...] = ()
    completed_trials: tuple[TrialCompleted, ...] = ()
    completed_evaluations: tuple[EvaluationCompleted, ...] = ()

    @classmethod
    def empty(cls, run_id: RunId) -> SearchState:
        if not isinstance(run_id, RunId):
            raise TypeError("search state run id must be a RunId")
        return cls(run_id=run_id)

    @property
    def started(self) -> bool:
        return self.start is not None and self.seed_artifact_id in self.artifact_ids

    def require_start(self) -> RunStarted:
        if not self.started or self.start is None:
            raise SearchNotStarted(f"search run {self.run_id} has not started")
        return self.start

    @property
    def task(self) -> Task:
        return self.require_start().task

    @property
    def seed_artifact_id(self) -> ArtifactId | None:
        return self.start.seed_artifact_id if self.start is not None else None

    @property
    def usage(self) -> Usage:
        return _recorded_usage(self.completed_trials, self.completed_evaluations)

    @property
    def task_remaining_budget(self) -> Budget:
        task_budget = self.task.budget or Budget()
        return _remaining_or_zero(task_budget, self.usage)

    @property
    def run_remaining_budget(self) -> Budget:
        return _remaining_or_zero(self.require_start().run_budget, self.usage)

    @property
    def remaining_budget(self) -> Budget:
        # One usage fold for both halves: each is a pure function of the same
        # history, and the admission check, the advisory halt, and any policy
        # consulting remaining budget all land here within one decision.
        usage = self.usage
        task_budget = self.task.budget or Budget()
        return _remaining_or_zero(task_budget, usage).narrow(
            _remaining_or_zero(self.require_start().run_budget, usage)
        )

    @property
    def task_budget_exceeded(self) -> bool:
        budget = self.task.budget
        return budget is not None and not budget.allows(self.usage)

    @property
    def run_budget_exceeded(self) -> bool:
        return not self.require_start().run_budget.allows(self.usage)

    @property
    def failed_outcomes(self) -> tuple[TrialOutcome, ...]:
        return tuple(
            item.outcome
            for item in self.completed_trials
            if item.outcome.failure is not None
        )

    @property
    def failed_evaluations(self) -> tuple[Evaluation, ...]:
        return tuple(
            item.evaluation
            for item in self.completed_evaluations
            if item.evaluation.failure is not None
        )

    @property
    def stop(self) -> Stop | None:
        if self.decisions and isinstance(self.decisions[-1].decision, Stop):
            return self.decisions[-1].decision
        return None

    @property
    def archive_updates(self) -> tuple[ArchiveUpdate, ...]:
        return tuple(
            item.decision
            for item in self.decisions
            if isinstance(item.decision, ArchiveUpdate)
        )

    @property
    def archive_members(self) -> tuple[ArtifactId, ...]:
        updates = self.archive_updates
        return updates[-1].member_ids if updates else ()

    @property
    def next_logical_step(self) -> int:
        return len(self.decisions) + 1

    @property
    def next_decision_id(self) -> DecisionId:
        self.require_start()
        return decision_id_for(self.run_id, self.next_logical_step)

    def member_randomness(self, ordinal: int) -> DecisionRandomness:
        """The randomness for the ``ordinal``-th member of the next cohort.

        A policy handed one committed state gets one ``randomness``, keyed on
        the decision id for the next logical step. A cohort is produced from
        that single state, so every member would otherwise draw the same seeds.

        The distinction needs no new hash input: a member's logical step is
        already distinct, so ``decision_id_for`` separates them, and the fold's
        seed check still passes because member *i* folds when the decision count
        has already advanced by *i*. Ordinal zero is ``randomness``.
        """

        _require_count(ordinal, "cohort member ordinal")
        start = self.require_start()
        return DecisionRandomness(
            root_seed=start.random_seed,
            policy=start.search.policy,
            decision_id=decision_id_for(self.run_id, self.next_logical_step + ordinal),
        )

    @property
    def randomness(self) -> DecisionRandomness:
        start = self.require_start()
        return DecisionRandomness(
            root_seed=start.random_seed,
            policy=start.search.policy,
            decision_id=self.next_decision_id,
        )

    def _incumbent(self) -> tuple[ArtifactId | None, float | None]:
        objective = self.task.objectives[0]
        ranked = rank_evaluations(
            objective,
            (item.evaluation for item in self.completed_evaluations),
        )
        if not ranked:
            return None, None
        best = ranked[0]
        return best.artifact_id, float(best.metrics[objective.metric])

    @property
    def incumbent_id(self) -> ArtifactId | None:
        return self._incumbent()[0]

    @property
    def incumbent_value(self) -> float | None:
        return self._incumbent()[1]

    @property
    def objective_satisfied(self) -> bool:
        objective = self.task.objectives[0]
        value = self.incumbent_value
        if value is None or objective.satisfy is None:
            return False
        if isinstance(objective, Maximize):
            return value >= objective.satisfy
        return value <= objective.satisfy

    @property
    def trial_spend_ceiling_breached(self) -> bool:
        """Whether any completed trial spent past its own spend ceiling."""

        return spend.trial_ceiling_breached(self)

    @property
    def spend_blocked(self) -> bool:
        """Whether monetary spend forbids further paid work, at either scope."""

        return spend.blocked(self)

    @property
    def budget_exhausted(self) -> bool:
        budget = self.remaining_budget
        if any(
            value == 0
            for value in (
                budget.evaluations,
                budget.trials,
                budget.tokens,
                budget.wall_seconds,
            )
            if value is not None
        ):
            return True
        # Cheap dimensions first: the spend rules fold history per trial, so
        # they are worth skipping once something else has already halted.
        return spend.blocked(self, remaining=budget, charged=self.usage)

    @property
    def budget_stop_reason(self) -> str:
        """Distinguish unavailable accounting from a measured exhausted limit."""
        return "accounting_unavailable" if spend.unverifiable(self) else "budget_exhausted"


class SearchProgram(Protocol):
    def next(self, state: SearchState) -> SearchDecision: ...


__all__ = [
    "DecisionRandomness",
    "InvalidSearchHistory",
    "PolicyMismatch",
    "SearchNotStarted",
    "SearchProgram",
    "SearchState",
    "decision_id_for",
    "rank_evaluations",
]
