# Meta-Evolve

[![CI](https://github.com/salzubi401/meta-evolve/actions/workflows/ci.yml/badge.svg)](https://github.com/salzubi401/meta-evolve/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

Meta-Evolve is a declarative Python library for evaluated evolution over
versioned artifacts. Propose revisions, measure them, and keep the history
that explains the selected result.

## Start with a duration parser

A time-tracking tool accepts `90s`, but users also enter `1h30m` and `2 minutes`.
A model proposes Python source; an independent evaluator checks it against
40 development cases. Meta-Evolve records revisions and selects by measured score.

The canonical starting source is deliberately incomplete:

<!-- parser-seed:start -->
```python
SEED = '''def parse_seconds(text):
    """Parse a whole number of seconds or minutes."""
    import re
    match = re.fullmatch(r"([0-9]+)(s|m)", text)
    if not match:
        raise ValueError("expected seconds or minutes")
    quantity, unit = match.groups()
    return int(quantity) * (60 if unit == "m" else 1)
'''
```
<!-- parser-seed:end -->

### Install and try it

Use Python 3.12+ on macOS or Linux. Download the
[matching source package](https://salzubi401.github.io/meta-evolve-docs/downloads/meta-evolve.zip)
and the
[three-file parser bundle](https://salzubi401.github.io/meta-evolve-docs/downloads/parser.zip)
into a new working folder, then run:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install ./meta-evolve.zip
python -m zipfile -e parser.zip .
python parser.py --dry-run
# The real seed grader runs without an SDK or credentials.
# It prints 17/40 passing development cases and six case observations.
```

For model-proposed revisions, in that same environment:

```bash
python -m pip install openai
export OPENAI_API_KEY="your-api-key"
python parser.py --run ./runs/parser-01
python parser.py --inspect ./runs/parser-01
```

The live run allows up to three revision requests and saves its history.
Provider charges may apply; inspection makes no model calls. Model settings,
limits, independent final checks, all source files, and interpretation are in
[Start here](docs/start-here.md). Live outcomes vary; retained live evidence is
pending in [#271](https://github.com/salzubi401/meta-evolve/issues/271).

Then [improve a routing prompt](docs/learn/llm-prompt.md) with the same loop.
That evaluator calls a response model and grades labels in Python. Both lessons
are self-contained. Explore [recipes](docs/recipes.md), the
[API reference](docs/reference/api.md), and [SDK integration](docs/guides/providers.md).

## Status and authority

The local author path is **Shipped**. See [project status](docs/project/status.md)
for milestone accounting and the [roadmap](docs/milestones.md) for future scope.
Candidates cannot change their evaluator, budget, permissions, or promotion
rules. Selecting a result does not deploy it.

See [the documentation home](docs/index.md) for offline reading and
[AGENTS.md](AGENTS.md) for repository design and implementation discipline.

## License

Meta-Evolve uses the [Apache License 2.0](LICENSE), a permissive open-source
license that includes an explicit patent grant.
