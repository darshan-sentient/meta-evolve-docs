# Meta-Evolve

[![CI](https://github.com/salzubi401/meta-evolve/actions/workflows/ci.yml/badge.svg)](https://github.com/salzubi401/meta-evolve/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

Improve prompts, code, and agent configurations through measured experiments.
Meta-Evolve is a declarative Python library for evaluated evolution and
meta-evolution over versioned artifacts. You supply a starting value, a proposer,
and an independent evaluator. Search chooses what to try next; the run keeps
the attempts and results.

[Start here](docs/start-here.md) · [Explore examples](docs/examples.md)

## One improvement experiment

This API preview uses definitions from the [complete parser notebook](docs/start-here.md).
The lesson includes installation, `import meta_evolve as meta`, and the `SEED`,
`propose`, and `evaluate` definitions. Use Python 3.12 or newer.

<!-- parser-run:start -->
```python
result = meta.improve(
    seed=SEED,
    proposer=propose,
    evaluator=evaluate,
    trials=2,
)
```
<!-- parser-run:end -->

| Input | Role in the parser example |
|---|---|
| `SEED` | Starting Python source; it handles seconds but misses minutes and hours |
| `propose` | A function that returns revised source |
| `evaluate` | An independent function that runs six checks and returns a score |
| `trials=2` | At most two proposal attempts after the seed is evaluated |

The default search builds on the best measured version. `result.best().value`
returns the selected source; `result.trials()` retains the seed and every
proposal attempt, including regressions and failures.

In this tutorial, handwritten revisions produce scores of 33% → 67% → 100%
through real Python evaluation. No SDK, credentials, or model requests are
needed. These results describe the six tutorial checks.

## Adapt the experiment

- [Guides](docs/guides/index.md): change evaluation or search, supply feedback,
  set limits, inspect results, and save history. Feedback is supplied explicitly.
- [Concepts](docs/concepts/index.md): understand artifacts, evidence, and
  meta-evolution.
- [API reference](docs/reference/api.md): look up parameters and result queries.

Try [routing prompts](docs/learn/llm-prompt.md) in another simulated notebook,
or [use your model SDK](docs/guides/providers.md) for real requests. The larger
[live parser](docs/guides/live-parser.md) and [live routing](docs/guides/live-prompt.md)
examples add separate final checks. They are **Experimental/live-only**;
retained live evidence remains pending in
[#271](https://github.com/salzubi401/meta-evolve/issues/271).

## Status and authority

The local author path is **Shipped**. See [project status](docs/project/status.md)
for milestone accounting and the [roadmap](docs/milestones.md) for future scope.
Candidates cannot change their evaluator, budget, permissions, or promotion
rules. Selecting a result does not deploy it.

See [the documentation home](docs/index.md) for offline reading and
[AGENTS.md](AGENTS.md) for repository design and implementation discipline.

## License

Meta-Evolve uses the [Apache License 2.0](LICENSE), a permissive open-source
license that includes an explicit patent grant.
