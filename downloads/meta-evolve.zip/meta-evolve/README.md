# Meta-Evolve

[![CI](https://github.com/salzubi401/meta-evolve/actions/workflows/ci.yml/badge.svg)](https://github.com/salzubi401/meta-evolve/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

Meta-Evolve is a declarative Python library for evaluated evolution and
meta-evolution over versioned artifacts. Propose revisions, measure them, and
keep the history that explains the selected result.

## Start in a notebook

[Start here](docs/start-here.md) walks through a complete duration-parser example
in small, ordered cells. Use Python 3.12 or newer. Installation, source, simulated
agent responses, grading, and results are all on the page.

The starting parser reads seconds but does not convert minutes or hours:

<!-- parser-seed:start -->
```python
SEED = '''def parse_seconds(text):
    return int(text[:-1])
'''
```
<!-- parser-seed:end -->

A handwritten `agent(message)` supplies revisions. Python actually runs and
grades them: the six-case score moves from 33% to 67% to 100%. This is a
deterministic simulation with no SDK, credentials, or model requests.

Choose a [task guide](docs/guides/index.md) for evaluation, search, feedback,
limits, inspection, or saved runs. Try [routing prompts](docs/learn/llm-prompt.md)
to apply the loop to a different artifact.

For real model calls, the [live parser guide](docs/guides/live-parser.md) and
[live routing guide](docs/guides/live-prompt.md) include SDK setup, accounting,
execution limits, and separate final checks. Those examples are
**Experimental/live-only**; retained live evidence remains pending in
[#271](https://github.com/salzubi401/meta-evolve/issues/271).

Explore the [examples](docs/examples.md), [API reference](docs/reference/api.md),
and [SDK integration guide](docs/guides/providers.md).

## Status and authority

The local author path is **Shipped**. See [project status](docs/project/status.md)
for milestone accounting and the [roadmap](docs/milestones.md) for future scope.
Candidates cannot change their evaluator, budget, permissions, or promotion
rules. Selecting a result does not deploy it.

See [the documentation home](docs/index.md) for offline reading and
[AGENTS.md](AGENTS.md) for repository design and implementation discipline.

## License

Meta-Evolve uses the [Apache License 2.0](LICENSE), a permissive open-source
license that includes an explicit patent grant.
