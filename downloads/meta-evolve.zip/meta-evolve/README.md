# Meta-Evolve

[![CI](https://github.com/sentient-xyz/meta-evolve/actions/workflows/ci.yml/badge.svg)](https://github.com/sentient-xyz/meta-evolve/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

**Improve solutions. Improve the methods that produce them.**

Meta-Evolve is a Python framework for applying, composing, and evolving
improvement methods. Define what can change, propose revisions, and measure
the results. Then make a declared part of the improvement procedure the
candidate and evaluate the outcomes it produces.

[Use a method](docs/research/index.md#use-a-method) ·
[Compose a method](docs/research/decomposition.md) ·
[Evolve a method](docs/learn/autoresearch.md)

[Run the parser quickstart](#one-improvement-experiment) with no SDK or API key.

## Evolve an artifact, then the method

**Evolve an artifact**

```text
Artifact
  ↓ Propose a permitted revision
  ↓ Evaluate independently
  ↓ Record the outcome
Search chooses the next parent
or stops
```

**Evolve a method**

```text
Procedure artifact
  ↓ Propose a permitted
    procedure change
  ↓ Outer evaluation runs
    bounded inner work
  ↓ Record the outcome
Outer search chooses the next parent
or stops
```

At each level, evaluation rules and limits remain fixed outside the candidate.
Search can select an artifact or procedure when eligible measurements exist;
the seed may remain selected. An outer candidate changes only its declared
part of the procedure.

Permissions and promotion also remain outside candidate control. Selecting a
result does not deploy it. See [authority and promotion](docs/concepts/authority.md).

Retained versions and outcomes let you inspect what changed, compare results,
and trace their origins. [Runs and history](docs/concepts/history.md) explains
what a run records and how to preserve it.

## One framework, different kinds of discovery

Your artifact might be a program, a collection of skills, a research procedure,
or a custom representation of a model or hypothesis. You supply the domain
and its evaluation; compatible proposal, search, and experience components can
be reused across methods. The [artifact guide](docs/concepts/domains.md)
explains built-in kinds and custom domains.

| Explore | What the walkthrough provides |
|---|---|
| [Skills and context](docs/research/ace.md) | **Shipped**: a deterministic playbook-curation mechanism |
| [Agent harnesses](docs/research/meta-harness.md) | **Shipped**: bounded harness edits evaluated through repository repairs |
| [Research procedures](docs/learn/autoresearch.md) | **Shipped**: an outer recipe evaluated through bounded inner searches |
| [Systems optimization](docs/research/adrs.md) | **Shipped**: scheduler revisions measured in a deterministic simulator |
| [Data generation](docs/learn/research-labs/02-autodata.md) | **Experimental/live-only**: a generation recipe revised from solver behavior |
| [Scientific discovery](docs/research/index.md#scientific-discovery) | **Design—not shipped**: mappings for hypothesis search, model discovery, and experiment selection |

These are entry points into a growing [method library](docs/research/index.md).
Each page identifies the implemented mechanism and evidence; a teaching
fixture does not reproduce a paper's complete system or results.

Use the framework to [compose compatible components](docs/research/decomposition.md),
[add an artifact domain](docs/adding-an-artifact-domain.md), or
[evaluate a search policy as an artifact](docs/guides/policy-evolution.md).
Independent evaluation, explicit experience, and inspectable results carry
through those choices. See [when to use Meta-Evolve](docs/comparison.md).

[Full tutorial](docs/start-here.md) · [Use your model SDK](docs/guides/providers.md)

## One improvement experiment

Start small to learn the API used by the larger methods.
Our time tracker needs to read durations such as `30s`, `2m`, and `1h` as seconds.
Its starting parser ignores the unit. We'll propose a correction and let six
independent checks decide whether to select it. No SDK or API key is needed.

### Install in a notebook

Get `meta-evolve.zip` from your [documentation build](docs/index.md#read-offline);
the file is in its `downloads/` folder. This installs the package distributed
with those docs, without cloning the repository.

<!-- notebook-install:start -->
Open a notebook running **Python 3.12 or newer**. Put `meta-evolve.zip` in
the notebook's working folder. For a hosted notebook, upload it through the
file browser; `%pwd` in a cell shows the working folder.

Run this cell once to install the library into the notebook's environment.
Skip it if you already installed this package. Restart the kernel if asked,
then copy the remaining Python blocks into cells in order.

```python
%pip install ./meta-evolve.zip
```
<!-- notebook-install:end -->

### Define what can change

The **artifact** is Python source stored in a string; `SEED` is its starting
version. The **proposer**, `propose(source)`, receives the current source and
returns a revision. Here it always returns one handwritten correction.

```python
import meta_evolve as meta

SEED = '''def parse_seconds(text):
    return int(text[:-1])
'''


def propose(source):
    return '''def parse_seconds(text):
    quantity = int(text[:-1])
    seconds_per_unit = {"s": 1, "m": 60, "h": 3600}
    return quantity * seconds_per_unit[text[-1]]
'''
```

### Define what better means

The **evaluator**, `evaluate(source)`, runs the parser against fixed expected
answers and returns the fraction correct. A higher score is better. The seed
passes only the two seconds cases; the proposed source cannot change the checks.
`load_parser` executes the handwritten source and returns its function.

```python
CASES = (
    ("30s", 30),
    ("90s", 90),
    ("2m", 120),
    ("3m", 180),
    ("1h", 3600),
    ("2h", 7200),
)


def load_parser(source):
    namespace = {}
    exec(source, namespace)
    return namespace["parse_seconds"]


def evaluate(source):
    parse = load_parser(source)
    passed = 0
    for text, expected in CASES:
        actual = parse(text)
        if type(actual) is int and actual == expected:
            passed += 1
    return passed / len(CASES)
```

This small evaluator runs reviewed code in your notebook. The
[live source example](docs/guides/live-parser.md) uses a child-process grader
for model-generated revisions.

### Run, inspect, and use the result

`meta.improve()` evaluates the seed, tries revisions, and returns a **run** with
the results. `trials=1` allows one proposal attempt after the seed evaluation.
The default search keeps the best score; a tie or a worse revision keeps the
earlier winner. `result.trials()` includes the seed and attempts;
`result.best().value` gives us the selected source to use.

```python
result = meta.improve(
    seed=SEED,
    proposer=propose,
    evaluator=evaluate,
    trials=1,
)

print(f"Seed score: {result.trials()[0].metrics['score']:.0%}")
print(f"Selected score: {result.best_trial().metrics['score']:.0%}")
print(f"Evaluations: {result.usage().evaluations}")
print("Selected source:")
print(result.best().value, end="")

parse_seconds = load_parser(result.best().value)
print("4m:", parse_seconds("4m"), "seconds")
# Output:
# Seed score: 33%
# Selected score: 100%
# Evaluations: 2
# Selected source:
# def parse_seconds(text):
#     quantity = int(text[:-1])
#     seconds_per_unit = {"s": 1, "m": 60, "h": 3600}
#     return quantity * seconds_per_unit[text[-1]]
# 4m: 240 seconds
```

The proposal is handwritten; Python actually executes and scores both versions.
The selected revision passes all six checks, and its parser converts `4m` to
240 seconds. These scores describe this example, not a model's ability to improve
code or correctness on every possible input.

**Try it:** change `trials=1` to `trials=0` and rerun the last cell. Only the seed
will be evaluated: the selected score stays at 33%, and `4m` incorrectly returns
4 seconds. Restore `trials=1` afterward.

## Adapt the experiment

| Your question | What to change | Next step |
|---|---|---|
| What am I improving? | Replace `SEED` with your starting value | [Full parser tutorial](docs/start-here.md) |
| What counts as better? | Replace the evaluator and its checks | [Define evaluation](docs/guides/evaluation.md) |
| Where do revisions come from? | Replace the proposer | [Use your model SDK](docs/guides/providers.md) |
| How much work should run? | Set the attempt limit | [Set limits](docs/guides/limits.md) |
| How do I keep the results? | Save the run's history | [Save and reopen a run](docs/learn/06-persist-run.md) |

The [full tutorial](docs/start-here.md) walks through the same parser in two
revisions. It includes all setup again, so you can open a fresh notebook.
To decide whether this approach fits your project, read
[When to use Meta-Evolve](docs/comparison.md).

- [Guides](docs/guides/index.md): change evaluation or search, supply feedback,
  set limits, inspect results, and save history. Feedback is supplied explicitly.
- [Concepts](docs/concepts/index.md): understand artifacts, evidence, and
  meta-evolution.
- [API reference](docs/reference/api.md): look up parameters and result queries.

Try [routing prompts](docs/learn/llm-prompt.md) in another simulated notebook,
or [use your model SDK](docs/guides/providers.md) for real requests. The larger
[live parser](docs/guides/live-parser.md) and [live routing](docs/guides/live-prompt.md)
examples add separate final checks. They are **Experimental/live-only**;
no retained live result is available yet. See
[evidence and verification](docs/project/evidence.md) for what has been tested.

## Status and authority

Meta-Evolve is a declarative Python library for evaluated evolution and
meta-evolution over versioned artifacts.

See [project status](docs/project/status.md) for current capabilities and the
[Development index](docs/project/index.md) for contribution guidance, design,
and the roadmap.
Candidates cannot change their evaluator, budget, permissions, or promotion
rules. Selecting a result does not deploy it.

See [the documentation home](docs/index.md) for offline reading and
[AGENTS.md](AGENTS.md) for repository design and implementation discipline.

## License

Meta-Evolve uses the [Apache License 2.0](LICENSE), a permissive open-source
license that includes an explicit patent grant.
