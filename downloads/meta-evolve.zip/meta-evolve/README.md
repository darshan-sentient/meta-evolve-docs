# Meta-Evolve

[![CI](https://github.com/sentient-xyz/meta-evolve/actions/workflows/ci.yml/badge.svg)](https://github.com/sentient-xyz/meta-evolve/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)

**Improve solutions. Improve the methods that produce them.**

Start with a prompt, skill document, program, or agent setup. You provide a way
to propose changes and checks for what counts as better. Meta-Evolve runs the
attempts, selects the best measured version, and keeps the results for inspection.

**Start with a version → propose a change → test it → inspect what happened.**

[Run the notebook walkthrough](docs/start-here.md), or copy the five cells below.
No model or API key needed.

## See the loop in action

These standalone lessons apply the same roles to different artifacts. Read the
method summary first, then inspect the example or run its notebook.

| Example | Availability and evidence | What you will see |
|---|---|---|
| [SVG Feedback Descent](docs/build-patterns/feedback-descent.md) | **Shipped**; captured live run; Codex authentication to rerun | An image critique guides revisions; Greedy keeps the highest-scoring SVG, including when later attempts regress |
| [EvoSkill](docs/build-patterns/evoskill.md) | **Experimental/live-only**; captured Claude/OfficeQA run | An executor misses a question; separate agents plan and build a native skill, then population search evaluates skill folders |
| [Meta-Harness](docs/research/meta-harness.md) | **Experimental/live-only**; offline SDK rehearsal, live capture pending | Revise a worker's instructions or context, independently test its repairs, then select and check on fresh tasks |

Each lesson states its credentials, supported environment, and work limits.
The [parser below](#one-improvement-experiment) is the quickest way to try the
API without an account. The [method library](docs/research/index.md) separates
runnable examples from proposed research directions.

## One improvement experiment

Our time tracker thinks **four minutes means four seconds**. Let's propose a
correction and check both versions against the same six expected answers.
The correction is handwritten; Python actually executes and scores the parsers.

### 1. Install

<!-- notebook-install:start -->
Use a fresh notebook environment running **Python 3.12 or newer**.
Install directly from the published documentation:

```python
%pip install https://sentient-xyz.github.io/meta-evolve-docs/downloads/meta-evolve.zip
```

If you already imported Meta-Evolve, restart the kernel after installing.
Then run the remaining cells in order.

**Archived or offline docs:** use the ZIP included with that build. Put
`meta-evolve.zip` in the notebook's working folder (`%pwd` shows it; hosted
notebooks let you upload files), then run `%pip install ./meta-evolve.zip`
instead. Installing from source may still download build tools.
<!-- notebook-install:end -->

### 2. Try the starting parser

An [**artifact**](docs/concepts/index.md#artifact) is the thing you want to improve—a
prompt, skill document, program, or agent setup. Here it is the parser's Python
source. `SEED` holds its starting version; `load_parser` turns the source into a
function we can call.

```python
import meta_evolve as meta

SEED = '''def parse_seconds(text):
    return int(text[:-1])
'''


def load_parser(source):
    namespace = {}
    exec(source, namespace)
    return namespace["parse_seconds"]


print("4m:", load_parser(SEED)("4m"), "seconds")
# Output:
# 4m: 4 seconds
```

### 3. Define what better means

`evaluate(source)` checks the answers and returns the fraction correct.
Higher is better. The starting parser passes only the two seconds cases.
These checks stay fixed while we try a revision.

```python
CASES = (
    ("30s", 30),
    ("90s", 90),
    ("2m", 120),
    ("3m", 180),
    ("1h", 3600),
    ("2h", 7200),
)


def evaluate(source):
    parse = load_parser(source)
    passed = 0
    for text, expected in CASES:
        actual = parse(text)
        if type(actual) is int and actual == expected:
            passed += 1
    return passed / len(CASES)


print(f"Starting: {evaluate(SEED) * len(CASES):.0f}/{len(CASES)} checks")
# Output:
# Starting: 2/6 checks
```

### 4. Propose a correction

`propose(source)` receives the current parser and returns a revised source
string. This correction multiplies by the number of seconds in each unit.

```python
def propose(source):
    return '''def parse_seconds(text):
    quantity = int(text[:-1])
    seconds_per_unit = {"s": 1, "m": 60, "h": 3600}
    return quantity * seconds_per_unit[text[-1]]
'''
```

### 5. Run, inspect, and use it

`meta.improve()` checks the starting version, tries the correction, and selects
the better score. `trials=1` allows one revision attempt after the starting check;
then the run stops. You choose both the checks and the attempt limit.
`result.best().value` gives you the selected source to use.

```python
result = meta.improve(
    seed=SEED,
    # This example returns a handwritten correction.
    # Replace it with a function that asks an agent or LLM for new candidates.
    proposer=propose,
    evaluator=evaluate,
    trials=1,
)

summary = result.summary()
print(f"Starting: {evaluate(SEED) * len(CASES):.0f}/{len(CASES)} checks")
print(f"Selected: {summary.primary_score * len(CASES):.0f}/{len(CASES)} checks")
print("Selected source:")
print(result.best().value, end="")

parse_seconds = load_parser(result.best().value)
print("4m:", parse_seconds("4m"), "seconds")
# Output:
# Starting: 2/6 checks
# Selected: 6/6 checks
# Selected source:
# def parse_seconds(text):
#     quantity = int(text[:-1])
#     seconds_per_unit = {"s": 1, "m": 60, "h": 3600}
#     return quantity * seconds_per_unit[text[-1]]
# 4m: 240 seconds
```

**2/6 → 6/6 checks passed. Four minutes now gives 240 seconds.** A tie or a worse
revision keeps the earlier winner. Passing these six checks establishes the
result for those inputs; it doesn't establish correctness for every input.
Selecting this source does not deploy it.

**Try it:** change `trials=1` to `trials=0` and rerun the last cell. Predict what
happens: the starting parser stays selected, passes **2/6** checks, and returns
**4 seconds** for `"4m"`. Restore `trials=1` to try the correction again.

The returned `result` also keeps the attempted versions and their outcomes.
This history is in memory. To keep it after Python closes,
[save and reopen the run](docs/learn/06-persist-run.md).

<a id="adapt-the-experiment"></a>
<a id="use-your-model-next"></a>

## What would you like to improve?

| Your task | Try next |
|---|---|
| Improve an image | [Draw and revise an SVG using visual feedback](docs/build-patterns/feedback-descent.md) |
| Teach reusable skills | [Build native Claude skills from OfficeQA failures](docs/build-patterns/evoskill.md) |
| Improve instructions | [Revise a support-ticket routing prompt](docs/learn/llm-prompt.md) |
| Improve a program | [Repair the parser with model-proposed changes](docs/guides/live-parser.md), or [optimize a scheduler in Jupyter](docs/research/adrs.md) |
| Improve how an agent works | [Revise its code-repair instructions in Meta-Harness](docs/research/meta-harness.md) |

Each path explains its own setup. You can also [adapt the checks to your task](docs/guides/evaluation.md),
[connect your model SDK](docs/guides/providers.md), or [set a different work limit](docs/guides/limits.md).
The first notebook executes reviewed, handwritten Python directly; the live parser
uses a bounded child-process grader for model-generated source.

<a id="evolve-an-artifact-then-the-method"></a>

## Improve a program—or how an agent works

**Improve a parser**

```text
Change the parser's source
↓ Run that parser in Python
↓ Count how many fixed checks pass
Keep the best measured version
```

The [parser walkthrough](docs/start-here.md)
tries one handwritten correction: **2/6 → 6/6 checks passed**.

**Improve how an agent repairs code**

```text
Change the agent's repair instructions or context settings
↓ Run the same worker on fixed repository repair tasks
↓ Independently test the code it produces
Keep the best measured settings
```

The [Meta-Harness example](docs/research/meta-harness.md)
uses Claude SDK agents to propose settings and produce repairs. Independent
checks measure those repairs before private selection and a held-out comparison.
Its live capture is pending; the separate
[deterministic reference](docs/research/meta-harness-reference.md) runs without
model requests.


The second level measures the instructions through the repairs they produce.
At both levels, the starting version can still win. Evaluation rules and limits
stay fixed; proposed changes affect only the declared source or settings.

[Read about evaluation and work limits](docs/concepts/authority.md).

<a id="one-framework-different-kinds-of-discovery"></a>
<a id="research-and-project-status"></a>

## Explore further

The [method library](docs/research/index.md) connects more tasks to implemented examples:

| Example | What you can explore |
|---|---|
| [Skills and context](docs/research/ace.md) | **Shipped**: revise a playbook used by an agent |
| [Systems optimization](docs/research/adrs.md) | **Shipped**: measure scheduler revisions in a simulator |
| [Research procedures](docs/learn/autoresearch.md) | **Shipped**: evaluate a procedure through the searches it runs |

The [live parser](docs/guides/live-parser.md) and [live routing prompt](docs/guides/live-prompt.md)
are **Experimental/live-only**. Their pages explain model setup and evidence limits.
For more control, [compose a method](docs/research/decomposition.md) or
[add your own kind of artifact](docs/adding-an-artifact-domain.md).

[Choose a task guide](docs/guides/index.md) · [Look up a term](docs/concepts/index.md#glossary) ·
[API reference](docs/reference/api.md) · [When to use Meta-Evolve](docs/comparison.md)

## Development

See [project status](docs/project/status.md), [evidence](docs/project/evidence.md),
and the [Development index](docs/project/index.md) for capabilities, verification,
and contribution guidance. [AGENTS.md](AGENTS.md) records the repository's design discipline.

Upgrading existing code? See [Migrate to 0.2](https://sentient-xyz.github.io/meta-evolve-docs/guides/migrate-to-0.2/).
[Documentation home](docs/index.md) · [offline reading](docs/contributor-code-tour.md#build-and-serve-documentation)

## License

Meta-Evolve uses the [Apache License 2.0](LICENSE), a permissive open-source
license that includes an explicit patent grant.
