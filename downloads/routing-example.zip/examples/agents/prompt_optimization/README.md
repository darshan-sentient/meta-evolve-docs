# Prompt optimization

For the introductory direct-call path, start with the
[meeting-notes example](../../learn/meeting_notes/). This supplemental recipe
uses source-tree agent sessions and nested evaluation.

The candidate is a system prompt — a `meta.Text` — and its score is the pass
rate of a development evaluation suite. For every case, an agent instructed with the
candidate prompt reads a support ticket, writes a reply, and a plain local
function grades it. The suite reports one `EvaluationResult`, so the kernel
records exactly one evaluation per candidate, and every session's token, monetary, and
elapsed-time usage rolls up into that evaluation.

This is the loop most teams run by hand: write a prompt, run it against some
cases, look at what broke, edit the prompt. The text-rewrite example evolves text too, but
its evaluator counts keywords — it never asks a model anything. Here the score
comes from the behaviour of whatever agent the wrapper drives, and the rewrite
session receives the cases that actually failed. The shipped fixture returns
a fixed replacement; the tests also exercise a rewriter that uses the report.

Run it from the repository root:

```bash
uv run python examples/agents/prompt_optimization/main.py
```

The shipped run is deterministic, offline, and free: `main.py` binds a fixture
wrapper (see [The fixture](#the-fixture-and-what-a-real-wrapper-replaces)
below). Everything in between — the suite, the evidence, the rewriter shape,
the budgets — is the code a real SDK wrapper would drive.

## The eval suite

Four support tickets, each with the exact reply it must draw
(`ROUTE: BILLING`, `ROUTE: PLATFORM`, `ROUTE: SALES`). The check is exact after
stripping, because the reply format is part of what is being optimized.

The wrapper produces the behavior under test, and a plain Python function
grades it. The expected routing labels make an exact local check sufficient.
An LLM judge would add calls and require its own evaluation contract; it is
not needed for this particular task.

Four cases give the pass rate 0.25 steps. Each candidate requires four
wrapper sessions; a session may contain multiple SDK requests.

Two cases are ordinary triage: the annotations route a double charge to
billing and a login 500 to platform. The fixture follows these conventions
once its instructions name the teams; a live model is not guaranteed to do so.
The other two hinge on house policy that appears in no ticket:

- a refund demanded *because something broke* is routed by its root cause, not
  by the remedy asked for — so it goes to `PLATFORM`, not `BILLING`;
- a question about something the product cannot do yet is a commercial
  conversation — so it goes to `SALES`, not `PLATFORM`.

The fixture gets these cases wrong until its prompt names the relevant rule.
The report-driven test wrapper uses these failures to make two revisions;
the default fixture replaces the prompt in one step.

## The seed prompt, and why it fails

```text
You are the support triage assistant for a SaaS product.
Read the customer's ticket and decide which team should handle it.
Be brief.
```

The seed names no team or reply format, so the handwritten fixture returns
unmatched replies and every case fails: a pass rate of 0.0. A real model may
behave differently, including guessing the required format without a rewrite.
The failure report exposes the expected replies and the two house rules. A
rewriter can use that evidence to propose a prompt; only evaluation establishes
whether its revisions help these cases.

## The rewriter runs one level down, not as the kernel's proposer

Every session in this example has the same shape: the wrapper takes a
`meta.SourceTree`, edits it, and hands the tree back — that is what answering a
ticket already looks like (`ticket.md` in, `answer.txt` out), and one
`build_agent(instructions)` factory serves every session. The outer run's
artifact is a `meta.Text`, not a tree, so the wrapper is never named as the
outer proposer. The outer proposer is an ordinary Python function: it stages a
two-file tree — `prompt.md` holding the parent prompt and `failing_cases.md`
holding the eval report — runs the wrapper on it as an inner run, and lifts the
edited file back into `meta.Text`. The agent really does the
rewriting; it just does it one level down, the same way context evolution puts the
agent inside the evaluator. If the session produces no candidate, or leaves
`prompt.md` untouched, that is a typed `ProposerFailure` rather than a
candidate that scores badly.

The failing cases reach the rewriter through the kernel rather than a side
channel. The suite records per-case scores and replies as evidence, and
`meta.AncestorsOnly` pushes the parent's records into the proposer's context,
where the proposer picks out the newest copy of each. No shared dictionary, no
hidden state between the evaluator and the proposer.

## What "held-out" means here, and what it does not

These are development cases: their feedback guides prompt selection.

The cases are held out of the *prompt*: no ticket, and no expected reply, ever
appears in the seed. They are not a held-out *split* — the rewriter is shown
the cases it failed, including the reply each expected, which is exactly how
eval-driven prompt work goes and exactly where it can go wrong. A rewriter can
always overfit by naming these tickets instead of stating a rule, so the
rewriter's instructions say "state general rules, never answers for these
particular tickets". Measuring whether it complied needs a second, unseen suite
— that is a larger deliverable than this example.

## The model is inside the evaluator, so the suite declares it

Every case runs its session *inside* the evaluator, which means the model is
captured state that a plain run-local component reference cannot show: such a
reference is named by module and qualname alone. Two prompt runs over two
different models would therefore declare the **same** evaluator, and
`Run.compare` would rank them — a winner, silently, from an uncontrolled
comparison.

`ComponentRef.configured_local` closes it. `eval_suite` declares
`prompt-optimization:eval-suite`, versioned by a plain `hashlib` digest over
the case names, the session bounds, and the model it was built with. That is
why `evolve_prompt` takes the model by *name* as well as bound inside the agent
factory: what the evaluator was configured with has to reach the declaration.
(The fixture run declares `deterministic-sdk-fixture-v1` for the same reason —
a fixture is a configuration too.) Comparing two models now raises:

```text
RunsNotComparable: runs declare different evaluator components
```

The session bounds are in the digest because they decide which cases a
comparison ever saw: a prompt that needed one more turn is not a worse prompt,
and two runs under different ceilings are not one experiment.
`examples/agents/model_migration` documents the whole trap. The digest is
deliberately coarser than a registered component's: it covers the case *names*,
not the tickets or their expected replies, so a suite that changes what a case
measures without renaming it still declares the same evaluator. Bump
`EVAL_SUITE_VERSION` when that happens.

Nothing declares a closure's configuration for you. What changed is that it is
no longer invisible: `RunSummary.name_only_components` lists the roles whose
recorded reference is a name and nothing else, and this example's runs report
`('proposer',)` — the rewriting function itself, which is correct, because the
model it calls is bound one level down rather than being the kernel's proposer.

## The fixture, and what a real wrapper replaces

`main.py` ships `fixture_agent`, a deterministic stand-in for a user-owned SDK
wrapper: a plain callable factory with the same shape a real one has —
`build_agent(instructions)` returns a proposer that takes a source tree and
returns one. Answering, it routes a ticket correctly only when the instructions
it was built with name the right team, so the fixture responses fail the seed evaluation;
rewriting, it replaces `prompt.md` with a prompt that states every rule at
once.

That last part is the honest limit of the shipped demo. The fixture's rewrite
does not read the report, so the deterministic run climbs 0.0 → 1.0 in a single
step — mechanism on display, not a gradient. The run prints `session tokens: 0`
because the fixture reports no usage; a wrapper that returns
`meta.ProposalResult` with
`meta.Usage(tokens=..., spend_micros=..., wall_seconds=...)` would see
its cost rolled up into the outer evaluation, and
`tests/test_prompt_optimization_example.py` proves both the roll-up and the
full 0.0 → 0.5 → 1.0 climb with a fake that answers only from the instructions
it is handed and rewrites only from the report. The rising pass rate shows
how those prompt rules affect the fixture. No credentialed run happens in CI.

## Bring your own SDK

Pass your own `build_agent(instructions)` factory to `evolve_prompt` to drive a
real model through the same boundary. The wrapper owns authentication, session
lifecycle, turn and timeout enforcement, and telemetry — see
[SDK guide](../../../docs/guides/providers.md) and the
credential-free [`examples/agents/user_owned_sdk`](../user_owned_sdk/) for the
complete shape. Two contracts matter here:

- **Declare what affects behaviour.** Give `evolve_prompt` the model name your
  wrapper is bound to, and honour `SESSION_TURNS` and
  `SESSION_TIMEOUT_SECONDS` inside the wrapper — they are part of the declared
  evaluator identity precisely so that two runs under different ceilings fail
  closed instead of being compared.
- **Count the sessions before you spend them.** The outer budget allows three
  candidates (the seed plus two rewrites) over a four-case suite, plus one
  rewrite session per trial, so one run makes at most **14 wrapper sessions**
  — each bounded by the 120-second session budget the inner runs declare. With
  a paid SDK bound in, actual requests and costs depend on the wrapper.
  Recorded randomness and observations explain search decisions; they do not
  guarantee identical responses from later live calls.

A wrapper's ordinary exceptions become one candidate's typed `ProposerFailure`
and the search moves on; `meta.CapabilityError` states a fact about the whole
run — a missing dependency, a refused preflight — so it escapes the evaluator
unwrapped and aborts on the first candidate rather than being recorded as three
failures in a row.

**Historical note.** Before the repository moved to the user-owned SDK
boundary, this example shipped a first-party adapter, and one live run against
a frontier model reached a 1.0 pass rate after a *single* rewrite — the session
invented the strict reply format and a root-cause rule unprompted. By this
document's own test, that result condemned the cases rather than crowning the
search: one step is not a gradient, and the cases fed back to the rewriter are
the same ones scored, so even that 1.0 was training-case fit. The full
write-up, including the measured cost, is in this file's history on `main`.
Treat any live result here the same way: a working feedback loop over cases
that may be too easy, not evidence that prompt optimization is solved.

## Tests

`tests/test_prompt_optimization_example.py` imports `evolve_prompt`,
`evaluate_prompt`, and `eval_suite` and drives them through a deterministic
fake wrapper: the seed genuinely fails, the search climbs 0.0 → 0.5 → 1.0, the
rewriter sees only the cases still broken, a silent session becomes a typed
evaluator failure naming each unfinished case rather than a low score, usage
rolls up, and two models are refused a comparison. It also pins the 14-session
worst case this README quotes.
