"""Optimize a system prompt against an eval suite scored by an injected agent.

The candidate is the prompt itself -- a ``meta.Text`` -- and its score is the
pass rate of the development suite in ``prompt_suite.py``: for every case, an
agent built from a user-owned ``build_agent(instructions)`` factory and
instructed with the candidate prompt answers a support ticket, and a plain
local function grades the reply.

The rewriter is an agent from the same factory, but it is *not* the outer
proposer component. Every wrapper session in this example works on a
``meta.SourceTree`` while the outer artifact is a ``meta.Text``, so the outer
proposer is an ordinary Python function that runs the agent on a two-file
source tree, the prompt and the eval report, and lifts the edited file back
into ``meta.Text``. Nothing here pretends the agent is the kernel's proposer
component; it does its rewriting one level down, exactly as example 08 puts
the agent inside the evaluator.

The failing cases reach the rewriter through the kernel rather than a side
channel: the suite records per-case scores and replies as evidence, and
``meta.AncestorsOnly`` pushes the parent's records into the proposer's context.

Every piece is importable and injectable: ``evolve_prompt`` takes the agent
factory, so the shipped ``main`` binds the deterministic fixture below and
``tests/test_prompt_optimization_example.py`` drives this same logic through a
fake wrapper. Nothing in this file needs an SDK, a credential, or the network.
"""

from __future__ import annotations

import sys
from collections.abc import Callable, Mapping
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import ProposerFailure
from meta_evolve.ports import ProposalResult, Proposer, ProposerContext

HERE = Path(__file__).parent
if str(HERE) not in sys.path:
    # Example modules are plain siblings, not an installed package: this is
    # what lets ``python examples/agents/prompt_optimization/main.py`` just work.
    sys.path.insert(0, str(HERE))

from prompt_suite import (  # noqa: E402 -- needs the path entry above
    CASES,
    CASE_ANSWERS,
    CASE_SCORES,
    SESSION_BUDGET,
    SESSION_TIMEOUT_SECONDS,
    SESSION_TURNS,
    eval_suite,
)


# What the shipped run passes as ``model``: the evaluator declares whatever it
# was configured with, and a fixture is a configuration too. A run over this
# fixture and a run over a real model are refused a comparison, which is right.
FIXTURE_DECLARATION = "deterministic-sdk-fixture-v1"
# The outer bound that decides what a live run costs: the seed prompt plus at
# most two rewrites, each rewrite one session and each candidate a whole suite.
PROMPT_TRIALS = 2
PROMPT_BUDGET = meta.Budget(evaluations=PROMPT_TRIALS + 1, trials=PROMPT_TRIALS)
# Ancestor records accumulate at roughly nine per candidate, and the newest are
# the first casualties of truncation -- which is exactly the record the
# rewriter needs. Raised well past what PROMPT_TRIALS can produce.
CONTEXT_RECORDS = 60

PROMPT_FILE = "prompt.md"
REPORT_FILE = "failing_cases.md"

# The ordinary first draft: it says what the job is and nothing about what the
# answer must look like. It names no team and no reply format, so every case
# fails on a real model for a reason a rewrite can fix -- which is the whole
# point. A seed that already passes measures nothing, which is exactly what
# went wrong in example 11.
SEED_PROMPT = (
    "You are the support triage assistant for a SaaS product.\n"
    "Read the customer's ticket and decide which team should handle it.\n"
    "Be brief.\n"
)

REWRITER_INSTRUCTIONS = (
    "You improve system prompts. prompt.md holds the current system prompt.\n"
    "failing_cases.md holds the eval cases it got wrong, each with the reply\n"
    "the case expected and the reply the prompt actually produced.\n\n"
    "Rewrite prompt.md so a model following it answers every failing case\n"
    "correctly without breaking the cases it already passes. State general\n"
    "rules, never answers for these particular tickets. Edit prompt.md only."
)


def latest_evidence(context: ProposerContext, kind: str) -> Mapping[str, object]:
    """The parent's own copy of one evidence kind, from pushed context."""

    records = [
        record
        for record in context.bundle.records
        if record.kind == "evidence" and record.value.kind == kind
    ]
    if not records:
        return {}
    return max(records, key=lambda record: record.logical_step).value.data


def failure_report(context: ProposerContext) -> str:
    """Render the parent's failing cases as an ordinary eval report."""

    scores = latest_evidence(context, CASE_SCORES)
    answers = latest_evidence(context, CASE_ANSWERS)
    return "\n".join(
        f"## {case.name}\n\n"
        f"Ticket:\n{case.ticket}\n"
        f"Expected reply:\n{case.expected}\n\n"
        f"The prompt produced:\n{answers.get(case.name, '')}\n"
        for case in CASES
        if case.name in scores and float(scores[case.name]) < 1.0
    )


def prompt_changed(parent: meta.Text) -> Callable[[meta.SourceTree], float]:
    """The rewrite session's own objective: leave a different prompt behind."""

    def check(tree: meta.SourceTree) -> float:
        return float(tree.get(PROMPT_FILE, "") not in ("", str(parent)))

    return check


def rewrite_prompt(
    parent: meta.Text,
    context: ProposerContext,
    build_agent: Callable[[str], Proposer],
) -> ProposalResult:
    """The outer proposer: an agent rewriting the prompt from its failures."""

    report = failure_report(context)
    if not report:
        # Unreached while ``satisfy`` stops the search on a perfect parent, and
        # honest when it does not: without recorded failures there is nothing
        # for the feedback loop to act on, and rewriting anyway would measure
        # the model's imagination rather than the eval suite.
        return ProposalResult(
            failure=ProposerFailure(message="the parent has no recorded failing case")
        )
    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=prompt_changed(parent),
            artifact=meta.SourceTree,
            objectives=(meta.Maximize("rewritten"),),
            budget=SESSION_BUDGET,
        ),
        seed=meta.SourceTree({PROMPT_FILE: str(parent), REPORT_FILE: report}),
        proposer=build_agent(REWRITER_INSTRUCTIONS),
        search=meta.Greedy(max_trials=1),
    )
    rewrite = meta.run(experiment)
    # Only provider cost rolls up; the rewrite run's own counts stay its own.
    # usage() is the failure-safe accessor, though it is NOT guarding a reachable
    # loss at this site: the next statement is best_trial(), which routes to the
    # same NoSuccessfulEvaluation raiser summary() would have, and the seed
    # always evaluates locally so neither fires. The three sibling sites are
    # where the accessor genuinely matters.
    usage = rewrite.usage().without_counts
    trial = rewrite.best_trial()
    if trial.metrics["rewritten"] != 1.0:
        # The seed always evaluates, so this is reached whenever the session
        # produced no candidate or left prompt.md untouched. Either way there
        # is no new prompt, which is a typed proposer failure rather than a
        # candidate that happens to score badly.
        return ProposalResult(
            failure=ProposerFailure(message="the rewriter produced no new prompt"),
            usage=usage,
        )
    assert trial.artifact is not None
    return ProposalResult(
        candidate=meta.Text(trial.artifact.value[PROMPT_FILE]), usage=usage
    )


def evolve_prompt(
    build_agent: Callable[[str], Proposer], *, model: str, random_seed: int = 0
) -> meta.Run:
    """Evolve the system prompt; the model only ever runs underneath it.

    The model is named as well as bound, because it is what the evaluator was
    configured with: ``eval_suite`` puts it in the declared component version,
    so two runs of this over two models are refused rather than compared.
    """

    def propose(parent: meta.Text, context: ProposerContext) -> ProposalResult:
        return rewrite_prompt(parent, context, build_agent)

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=eval_suite(build_agent, model=model),
            artifact=meta.Text,
            objectives=(meta.Maximize("pass_rate", satisfy=1.0),),
            budget=PROMPT_BUDGET,
        ),
        seed=meta.Text(SEED_PROMPT),
        proposer=propose,
        search=meta.Greedy(max_trials=PROMPT_TRIALS),
        context=meta.AncestorsOnly(max_records=CONTEXT_RECORDS),
        random_seed=random_seed,
    )
    return meta.run(experiment)


def fixture_agent(instructions: str) -> Proposer:
    """A deterministic stand-in for a user-owned SDK wrapper.

    Same shape as a real wrapper: built once per candidate from the rendered
    instructions, then invoked once per session with a source tree. Answering,
    it routes a ticket correctly only when the instructions name the right
    team, so the seed prompt genuinely fails and a rewritten prompt genuinely
    passes -- the score tracks the prompt, not the fixture. Rewriting, it
    replaces ``prompt.md`` with a prompt that states every rule at once, so
    the shipped demo climbs 0.0 -> 1.0 in a single step; the test suite's fake
    rewrites from the eval report instead and shows the 0.0 -> 0.5 -> 1.0
    climb the feedback loop is built for.

    It returns bare trees and reports no usage, which is why ``main`` prints
    zero session tokens. A real wrapper returns ``ProposalResult`` carrying
    ``meta.Usage(tokens=..., spend_micros=..., wall_seconds=...)`` and sees that
    cost rolled up
    into the outer evaluation; see docs/guides/providers.md for the shape.
    """

    def propose(tree: meta.SourceTree, _context) -> meta.SourceTree:
        if PROMPT_FILE in tree:
            prompt = (
                "Route duplicate charges to BILLING. Route login failures and "
                "refunds caused by product defects to PLATFORM. Route questions "
                "about unavailable features to SALES. Reply exactly as "
                "ROUTE: TEAM.\n"
            )
            return meta.SourceTree({**tree, PROMPT_FILE: prompt})
        ticket = tree["ticket.md"].lower()
        if "charged twice" in ticket and "BILLING" in instructions:
            answer = "ROUTE: BILLING"
        elif ("login" in ticket or "dropped" in ticket) and "PLATFORM" in instructions:
            answer = "ROUTE: PLATFORM"
        elif "saml" in ticket and "SALES" in instructions:
            answer = "ROUTE: SALES"
        else:
            answer = "ROUTE: SUPPORT"
        return meta.SourceTree({**tree, "answer.txt": answer + "\n"})

    return propose


def main() -> None:
    # Deterministic and free: the fixture stands in for a user-owned SDK
    # wrapper. To drive a real model, pass your own build_agent(instructions)
    # factory and its model name here instead -- the run is then live and may
    # incur cost. Worst case is PROMPT_BUDGET.evaluations * len(CASES) suite
    # sessions plus PROMPT_BUDGET.trials rewrite sessions == 14 of them.
    result = evolve_prompt(fixture_agent, model=FIXTURE_DECLARATION)
    try:
        trial = result.best_trial()
    except meta.NoSuccessfulEvaluation:
        # Every candidate's suite failed, so there is nothing to rank -- for a
        # reason the eval suite saw: a ``meta.CapabilityError`` is a fact about
        # the whole run rather than one candidate, so it would have escaped
        # ``evolve_prompt`` above instead of landing here. The kernel recorded
        # each trial's reason, so name it rather than leave a reader guessing
        # which case broke and how.
        print("no candidate scored: every eval case failed before producing a reply")
        for attempt in result.trials():
            fault = attempt.failure
            if fault is not None:
                print(f"  {fault.kind}: {fault.message} {dict(fault.details)}")
        raise SystemExit(1)
    scores = next(item for item in trial.evidence if item.kind == CASE_SCORES)
    print(f"pass rate: {trial.metrics['pass_rate']}")
    print(f"cases: {dict(scores.data)}")
    print(f"session tokens: {trial.usage.tokens}")
    print(f"evaluations: {result.summary().evaluation_count}")
    print("--- winning prompt ---")
    print(result.best())


if __name__ == "__main__":
    main()
