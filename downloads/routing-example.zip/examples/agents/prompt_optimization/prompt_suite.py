"""The development eval suite: what a candidate system prompt is measured against.

Each case runs one ordinary inner ``meta.run`` whose proposer is an agent
instructed with the candidate prompt. The model reads the ticket, writes a
reply, and a plain local function grades it. The whole suite reports one
``EvaluationResult``, so the outer kernel records exactly one evaluation per
candidate and every session's provider cost rolls up into that evaluation.

These are development cases: their feedback guides the outer search. This
example binds ``CASES`` in a local closure and has no untouched final split.

It also owns the single session bound that ``main.py``'s rewriter imports,
because every agent session in this example has the same shape: one workspace,
one answer, one turn-bounded run.

The suite closes over the model, so it declares that: ``eval_suite`` gives its
evaluator a ``configured_local`` component versioned by the cases, the session
bounds, and the model. Without it two prompt runs over two models would record
the same evaluator and ``Run.compare`` would rank an uncontrolled comparison.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from hashlib import sha256

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, EvaluatorFailure
from meta_evolve.ports import EvaluationResult, EvidenceDraft, Proposer


# Bounds any single agent session in this example -- answering a ticket or
# rewriting a prompt. Each inner run is one session: the seed evaluation, one
# proposal, and the proposal's evaluation.
SESSION_TIMEOUT_SECONDS = 120.0
# Declared rather than defaulted, and folded into the evaluator's declared
# version below: a turn ceiling a wrapper defaults silently decides which
# cases a comparison ever saw, and a prompt that needed one more turn is not a
# worse prompt. A user-owned wrapper should enforce both of these bounds.
SESSION_TURNS = 12
SESSION_BUDGET = meta.Budget(
    evaluations=2,
    trials=1,
    wall_seconds=SESSION_TIMEOUT_SECONDS,
)

TICKET_FILE = "ticket.md"
ANSWER_FILE = "answer.txt"
CASE_SCORES = "prompt-optimization.case-scores"
CASE_ANSWERS = "prompt-optimization.case-answers"
# Enough of a reply to show a rewriter what went wrong, bounded so a runaway
# answer cannot bloat the durable evidence or the rewriter's tree.
ANSWER_EXCERPT = 240
# The suite's declared evaluator identity, in the shape the library's own local
# configured components use: a revision prefix and a
# digest. It is deliberately coarser than theirs -- it covers the model, the
# session bounds, and the case *names*, not the tickets or their expected
# replies -- so two suites that rename nothing while changing what a case
# measures still declare the same evaluator. Bump the prefix when that happens;
# a digest over the cases themselves is what a registered component is for.
EVAL_SUITE_COMPONENT = "prompt-optimization:eval-suite"
EVAL_SUITE_VERSION = "1"


@dataclass(frozen=True, slots=True)
class Case:
    """One development eval case: a ticket and the exact reply it must draw."""

    name: str
    ticket: str
    expected: str


# Four development cases give the pass rate 0.25 steps. Each case uses one
# wrapper session. The fixture's ordinary triage cases need named teams; the
# other two need the house rules for defects and unavailable features.
# The report-driven test wrapper repairs those omissions in two revisions.
# These are fixture behaviors, not guarantees about a live model.
CASES = (
    Case(
        name="double_charge",
        ticket="My card was charged twice for the June invoice. Please fix it.\n",
        expected="ROUTE: BILLING",
    ),
    Case(
        name="login_error",
        ticket="Since this morning the login page 500s for our whole team.\n",
        expected="ROUTE: PLATFORM",
    ),
    Case(
        name="refund_for_bug",
        ticket="Your CSV export dropped half our rows, so we want June refunded.\n",
        expected="ROUTE: PLATFORM",
    ),
    Case(
        name="missing_feature",
        ticket=(
            "Do you support SAML single sign-on yet?"
            " We cannot roll out without it.\n"
        ),
        expected="ROUTE: SALES",
    ),
)

# Constant across every candidate: it is the delivery mechanism, not the thing
# under test. The candidate prompt goes last and verbatim.
ANSWERING_HARNESS = (
    "The customer ticket is in ticket.md. Write your reply to answer.txt and\n"
    "change no other file.\n\n"
    "Follow this system prompt exactly:\n\n"
)


def episode_instructions(prompt: meta.Text) -> str:
    # Stripped because the adapter rejects instructions with outer whitespace.
    # Only the edges move: whatever the prompt says stays word for word.
    return (ANSWERING_HARNESS + str(prompt)).strip()


def case_check(case: Case) -> Callable[[meta.SourceTree], Mapping[str, float]]:
    """Grade one reply. Exact after stripping: the format is under test."""

    def check(tree: meta.SourceTree) -> Mapping[str, float]:
        answer = tree.get(ANSWER_FILE, "").strip()
        # ``answered`` separates a session that replied from one that left the
        # seed's blank file behind, so a silent case is never graded as a wrong
        # answer. ``passed`` is the number the suite actually reports.
        return {
            "answered": float(bool(answer)),
            "passed": float(answer == case.expected),
        }

    return check


def run_case(case: Case, agent: Proposer) -> meta.Run:
    """One case: a plain inner run over an ordinary source-tree task."""

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=case_check(case),
            artifact=meta.SourceTree,
            # No ``satisfy``: the episode must always reach its one proposal,
            # so a missing reply means the agent failed rather than that the
            # inner search stopped early.
            objectives=(meta.Maximize("answered"), meta.Maximize("passed")),
            budget=SESSION_BUDGET,
        ),
        seed=meta.SourceTree({TICKET_FILE: case.ticket, ANSWER_FILE: ""}),
        proposer=agent,
        search=meta.Greedy(max_trials=1),
    )
    return meta.run(experiment)


def evaluate_prompt(
    prompt: meta.Text, build_agent: Callable[[str], Proposer]
) -> EvaluationResult:
    """Score one prompt by running the whole eval suite end to end."""

    agent = build_agent(episode_instructions(prompt))
    usage = meta.Usage()
    scores: dict[str, float] = {}
    answers: dict[str, str] = {}
    unfinished: dict[str, str] = {}
    for case in CASES:
        episode = run_case(case, agent)
        # usage() over summary(): accumulating past an episode that scored
        # nothing must not discard the dollars already counted above.
        # Only the provider-reported measures roll up -- tokens and charged
        # spend. The episodes' own trial and evaluation counts belong to the
        # inner runs; the outer kernel mints its own.
        usage += episode.usage().without_counts
        # The episode declares one proposal, so the run is the seed and the
        # agent's attempt at it; unpacking both fails loudly rather than
        # mistaking one for the other. A trial nothing scored produced no
        # candidate at all, and a blank reply produced nothing to grade.
        # Neither is evidence about the prompt, so neither may become a low
        # score.
        trials = episode.trials()
        if len(trials) != 2:
            # The only anticipated shape error, handled by shape rather than by
            # catching: banking the total matters, because returning a failure
            # that carries `usage` keeps every dollar the earlier cases already
            # billed, while letting this escape would hand the adapter a raise
            # it converts to a failure with a default Usage().
            #
            # Deliberately NOT a broad `except`. A storage or query fault --
            # DurableCorruption, ExperienceStoreUnavailable -- is an
            # infrastructure outcome, not evidence about the prompt, and
            # reporting it as an EvaluatorFailure would score the candidate for
            # someone else's outage. Those escape.
            return EvaluationResult(
                failure=EvaluatorFailure(
                    message=f"case {case.name} produced an unreadable episode",
                    details={"reason": f"expected 2 trials, read {len(trials)}"},
                ),
                usage=usage,
            )
        _, reply = trials
        if reply.state != "evaluated" or reply.metrics.get("answered") != 1.0:
            # Name the fault the trial recorded, not just the case. "Which
            # case broke" without "how" is what a live run cannot act on: a
            # turn limit and a blank reply are different findings, and only
            # one of them is about the prompt.
            if reply.failure is not None:
                # The kind alone is too coarse to act on: a well-behaved
                # wrapper records the part that tells you what to change --
                # turn_limit, provider_capacity -- as the failure's reason.
                fault = reply.failure
                unfinished[case.name] = str(fault.details.get("reason", fault.kind))
            elif reply.state != "evaluated":
                unfinished[case.name] = reply.state
            else:
                unfinished[case.name] = "answered_nothing"
            continue
        scores[case.name] = float(reply.metrics["passed"])
        # Not an assert: under -O it vanishes, and the AttributeError that
        # follows would discard the banked total instead of reporting it.
        if reply.artifact is None:
            unfinished[case.name] = "scored_without_an_artifact"
            scores.pop(case.name)
            continue
        answers[case.name] = reply.artifact.value[ANSWER_FILE][:ANSWER_EXCERPT]

    evidence = (
        EvidenceDraft(kind=CASE_SCORES, data=scores),
        EvidenceDraft(kind=CASE_ANSWERS, data=answers),
    )
    if unfinished:
        return EvaluationResult(
            failure=EvaluatorFailure(
                message="an eval case produced no reply to grade",
                details={"unfinished_cases": unfinished},
            ),
            evidence=evidence,
            usage=usage,
        )
    return EvaluationResult(
        metrics={"pass_rate": sum(scores.values()) / len(scores)},
        evidence=evidence,
        usage=usage,
    )


def suite_version(model: str) -> str:
    """What this evaluator was configured with, as a durable version string."""

    # Plain stdlib on purpose. The library's canonical serialization is hidden
    # from the domain facade (tests/test_public_api.py pins that), so reaching
    # for it here would show a reader something they cannot do. A version is
    # free-form text; what it owes is determinism across processes, which is
    # why this hashes an explicit string rather than using Python's own hash().
    # Session bounds included: two runs under different turn ceilings or
    # timeouts must not declare the same evaluator, because the harness would
    # then be free to decide which cases a comparison ever saw.
    material = "\n".join(
        (EVAL_SUITE_VERSION, model, str(SESSION_TURNS), str(SESSION_TIMEOUT_SECONDS))
        + tuple(case.name for case in CASES)
    )
    return f"{EVAL_SUITE_VERSION}+{sha256(material.encode()).hexdigest()}"


def eval_suite(
    build_agent: Callable[[str], Proposer], *, model: str
) -> Callable[[meta.Text], EvaluationResult]:
    """Bind the development suite to one model's agent factory, and declare it.

    The model lives inside this closure, and a run-local reference is named by
    module and qualname alone -- so without this declaration two prompt runs
    over two different models would record the *same* evaluator and
    ``Run.compare`` would rank an uncontrolled comparison. Declaring the
    configuration is what earns the refusal: ``configured_local`` versions the
    closure by what it was built with, so the guard can see the models differ.
    """

    def score_prompt(prompt: meta.Text) -> EvaluationResult:
        return evaluate_prompt(prompt, build_agent)

    score_prompt.component = ComponentRef.configured_local(
        "evaluator",
        score_prompt,
        name=EVAL_SUITE_COMPONENT,
        version=suite_version(model),
    )
    return score_prompt
