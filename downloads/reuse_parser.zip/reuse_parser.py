"""Reopen a parser history and inspect exported source without executing it."""

import argparse
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import RunId
from parser import SEED, evaluate


# --8<-- [start:save]
def save_seed(directory):
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=False)
    with meta.Storage.durable(root / "history") as storage:
        result = meta.improve(seed=SEED, proposer=lambda source: source,
                              evaluator=evaluate, trials=0, storage=storage)
        (root / "run-id.txt").write_text(result.id.value + "\n")
        (root / "selected.py").write_text(result.best().value)
        print("Saved seed: 0 revisions, 1 evaluation")
# --8<-- [end:save]


# --8<-- [start:reopen]
def reopen(directory):
    root = Path(directory)
    run_id = RunId((root / "run-id.txt").read_text().strip())
    with meta.Storage.read_only(root / "history") as storage:
        result = meta.Run(run_id, storage)
        print("Saved revisions:", result.usage().trials)
        print("Stop reason:", result.inspect().overview.stop_reason)
        try:
            source = result.best().value
        except meta.NoSuccessfulEvaluation:
            print("No measured candidate to reuse")
            return
        print("Selected source:\n" + source.rstrip())
        exported = root / "selected.py"
        print("Export matches history:", exported.exists() and exported.read_text() == source)
        print("Separate final report:", "present" if (root / "final.json").exists() else "absent")
# --8<-- [end:reopen]


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("directory", type=Path, help="existing parser history directory")
    cli.add_argument("--save-seed", action="store_true", help="save a new zero-revision run for free")
    args = cli.parse_args()
    if args.save_seed:
        save_seed(args.directory)
    else:
        reopen(args.directory)
