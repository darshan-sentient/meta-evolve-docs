"""What a component declares it was configured with.

A local component reference is named by its module and qualname, so two
closures built by one factory over different captured state compare *equal*.
That is what ``ComponentRef.configured_local`` exists to escape, and it only
helps if the declared version actually moves when the captured state does.

So this module owns the one job of turning captured configuration into a
version string, and it does it by hashing an explicit manifest rather than a
hand-joined line of whichever fields came to mind. The distinction matters: a
join is a list someone maintains, and the field they forget is invisible. A
manifest is a value a test can walk, perturb field by field, and prove the
digest responds to -- which is how ``test_context_evolution_identity`` checks
these rather than by re-listing the same fields the code lists.

Both siblings use it, which is why it is not named for either.

Nothing here can score, run, or observe anything. It reads configuration and
returns text.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import fields
from hashlib import sha256

CURATOR_COMPONENT = "context-evolution:playbook-curator"
CURATOR_REVISION = "1"


def canonical(value: object) -> str:
    """Stable text for a nested plain value, across processes and platforms.

    Plain stdlib on purpose: the library's own canonical serialization is
    hidden from the domain facade, so reaching for it here would show a reader
    something they cannot do in their own example.
    """

    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(revision: str, manifest: Mapping[str, object]) -> str:
    """A declared version: a revision prefix and a digest of the manifest.

    The prefix is for changes a manifest cannot see -- a rewritten check whose
    inputs are unchanged, say. The digest is for everything it can.
    """

    return f"{revision}+{sha256(canonical(manifest).encode()).hexdigest()}"


def field_manifest(value: object) -> Mapping[str, object]:
    """Every declared dataclass field, so new budget dimensions cannot vanish."""

    return {field.name: getattr(value, field.name) for field in fields(value)}


def lesson_manifest(lessons: Sequence[object]) -> tuple[Mapping[str, str], ...]:
    """Every field of every published lesson, in published order.

    Order is part of the configuration, not incidental: the curator generates
    for the first uncovered lesson, so two runs given the same lessons in a
    different order propose different playbooks and must not declare the same
    proposer. Nothing is sorted here for that reason.
    """

    return tuple(
        {
            "id": lesson.identity,
            "section": lesson.section,
            "marker": lesson.marker,
            "content": lesson.content,
        }
        for lesson in lessons
    )


def curator_manifest(lessons: Sequence[object]) -> Mapping[str, object]:
    """Everything a curator's behaviour depends on: the lessons, and nothing else.

    That is the whole of it, and deliberately so -- the curator is a pure
    function of the published lessons and its parent. If it ever closes over
    anything more, this manifest is where the addition has to be declared.
    """

    return {"revision": CURATOR_REVISION, "lessons": lesson_manifest(lessons)}


def curator_version(lessons: Sequence[object]) -> str:
    """What a proposer built over these lessons declares itself to be."""

    return digest(CURATOR_REVISION, curator_manifest(lessons))


__all__ = [
    "CURATOR_COMPONENT",
    "CURATOR_REVISION",
    "canonical",
    "curator_manifest",
    "curator_version",
    "digest",
    "field_manifest",
    "lesson_manifest",
]
