"""A short entry into the maintained skill mechanism demonstration. No model calls."""

from skill_context import FIXTURE_AGENT, evolve_skills

result = evolve_skills(FIXTURE_AGENT)
for index, attempt in enumerate(result.trials()):
    print(f"Candidate {index}: {attempt.metrics['solved']:.0%} episodes solved")
print("Selected documents:", ", ".join(sorted(result.best().value)))
print("Outer revisions / evaluations:", result.usage().trials, result.usage().evaluations)
# Output:
# Candidate 0: 0% episodes solved
# Candidate 1: 50% episodes solved
# Candidate 2: 100% episodes solved
# Selected documents: skills/interest.md, skills/leases.md
# Outer revisions / evaluations: 2 3
