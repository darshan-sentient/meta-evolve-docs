"""The skill suite: what a skill set scores, and what the evaluator declares.

``skill_episodes`` owns the episodes and how one of them runs. This module owns
every *decision* about them -- how per-episode scores become the one metric the
outer search ranks, which outcomes refuse to be ranked at all, and what the
evaluator declares itself to have been configured with.

The same seam the ACE sibling has between ``ace_rollouts`` and ``ace_episodes``,
so neither sibling has to be read to understand the other. It was one file
until that file outgrew this repo's module budget, and the split is where the
budget was already implicitly drawn: tasks below, judgement above.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, EvaluatorFailure
from meta_evolve.errors import ExecutionAccountingUnknown
from meta_evolve.ports import EvaluationResult, EvidenceDraft

from ace_outcomes import WRAPPER_FAILED, RolloutFault, classify_fault
from declared_identity import digest, field_manifest
from inner_agent import InnerAgent
from inner_capture import capture_run
from skill_episodes import (
    AGGREGATION,
    BASE_INSTRUCTIONS,
    CHECK_REVISION,
    EPISODE_BUDGET,
    EPISODE_SUITE_COMPONENT,
    EPISODE_SUITE_VERSION,
    EPISODES,
    episode_instructions,
    run_episode,
)

def evaluate_skills(
    skills: meta.SkillSet, agent: InnerAgent
) -> EvaluationResult:
    """Score one skill set by running the episode suite end to end."""

    instructions = episode_instructions(skills)
    # What the inner runs were configured with: this agent, and this skill set
    # rendered into instructions. Both live inside the session closure, where a
    # run-local reference cannot see either.
    version = digest(
        agent.revision,
        {"agent": dict(agent.manifest), "instructions": instructions},
    )
    usage = meta.Usage()
    scores: dict[str, float] = {}
    unfinished: dict[str, RolloutFault] = {}
    captures: list[dict[str, object]] = []
    sessions = 0
    for episode in EPISODES:
        # One session per episode. A live wrapper holds conversation state, so
        # a single agent spanning the suite would let the second episode answer
        # from the first -- and both episodes ask for a house convention, so the
        # leak would read as the skill set working.
        sessions += 1
        try:
            session = agent.build(instructions)
        except ExecutionAccountingUnknown:
            raise
        except Exception as unstarted:
            # Opening the session happens outside the inner run's failure
            # boundary, so a wrapper that cannot open one raised straight out
            # of the suite -- past the typed outcome, and discarding the cost
            # earlier episodes had already reported. Catching broadly is the
            # point rather than a lapse: the factory is the caller's code and
            # this is where it becomes an outcome. ``BaseException`` is
            # deliberately not caught, so an interrupt still interrupts.
            unfinished[episode.name] = RolloutFault(
                WRAPPER_FAILED, f"session did not start: {unstarted}"
            )
            continue
        result = run_episode(episode, session, version)
        captures.append(capture_run(episode.name, result))
        # Only reported cost rolls up: tokens, charged spend, and wall seconds,
        # and only if the injected agent reports them. Episode trials and
        # evaluations belong to the inner runs; the outer kernel mints its own.
        # usage() over summary(), so that accumulating past an episode which
        # scored nothing does not discard the dollars already counted.
        usage += result.usage().without_counts
        # The episode declares exactly one proposal, so the run is the seed and
        # the agent's attempt at it; unpacking both fails loudly rather than
        # mistaking one for the other. A failed episode is no evidence about
        # the skill set, so it must not become a low score -- and the attempt's
        # own typed failure names the fault instead of inferring one.
        _, attempt = result.trials()
        if attempt.state == "evaluated":
            scores[episode.name] = float(attempt.metrics["solved"])
        else:
            # The reason when the wrapper recorded one, the kind otherwise:
            # `proposer_failure` alone hides whether the session ran out of
            # time or the wrapped SDK refused the request.
            # A declared kind wins over the raw one: the check that refused an
            # absent target says ``unverifiable``, and reporting the library's
            # ``evaluator_failure`` instead would lose which of the four
            # unrankable outcomes this was.
            fault = attempt.failure
            unfinished[episode.name] = classify_fault(attempt.state, fault)

    evidence = (
        EvidenceDraft(
            kind="skill-evolution.episode-suite",
            data={
                "scores": scores,
                "sessions": sessions,
                "runs": tuple(captures),
            },
        ),
    )
    if unfinished:
        return EvaluationResult(
            failure=EvaluatorFailure(
                message="an episode agent produced no candidate",
                details={
                    "unfinished_episodes": {
                        name: {
                            "kind": fault.kind,
                            "detail": fault.detail,
                            "reported": fault.reported,
                        }
                        for name, fault in unfinished.items()
                    }
                },
            ),
            evidence=evidence,
            usage=usage.resources,
        )
    return EvaluationResult(
        metrics={"solved": sum(scores.values()) / len(scores)},
        evidence=evidence,
        usage=usage.resources,
    )


def episode_manifest(agent: InnerAgent) -> Mapping[str, object]:
    """Everything this evaluator's behaviour depends on, as one plain value.

    A manifest rather than a joined line, for the reason
    ``ace_episodes.evaluator_manifest`` gives: a join is a list someone
    maintains, and the field they forget leaves no trace.
    ``test_context_evolution_identity`` walks this and requires the version to
    move for every leaf.
    """

    return {
        "revision": EPISODE_SUITE_VERSION,
        "agent": agent.manifest,
        "aggregation": AGGREGATION,
        "check_revision": CHECK_REVISION,
        "instructions": BASE_INSTRUCTIONS,
        "budget": field_manifest(EPISODE_BUDGET),
        "episodes": tuple(
            {
                "name": episode.name,
                "target": episode.target,
                "answer": episode.answer,
                "source": dict(episode.source.items()),
            }
            for episode in EPISODES
        ),
    }


def suite_version(agent: InnerAgent) -> str:
    """What this evaluator was configured with, as a durable version string."""

    return digest(EPISODE_SUITE_VERSION, episode_manifest(agent))


def session_count(run: meta.Run) -> int:
    """Actual wrapper sessions retained by every outer evaluation."""

    return sum(
        int(item.data.get("sessions", 0))
        for trial in run.trials()
        for item in trial.evidence
        if item.kind == "skill-evolution.episode-suite"
    )


def episode_suite(
    agent: InnerAgent,
) -> Callable[[meta.SkillSet], EvaluationResult]:
    """Bind the episode suite to one declared agent, and declare itself.

    The agent lives inside this closure and a run-local reference is named by
    module and qualname alone, so without a declaration two skill runs over
    two different agents would record the *same* evaluator and ``Run.compare``
    would rank an uncontrolled comparison. Taking an ``InnerAgent`` rather
    than a factory and a model id is what makes the declaration unforgettable
    rather than merely available.
    """

    def score_skill_set(skills: meta.SkillSet) -> EvaluationResult:
        return evaluate_skills(skills, agent)

    score_skill_set.component = ComponentRef.configured_local(
        "evaluator",
        score_skill_set,
        name=EPISODE_SUITE_COMPONENT,
        version=suite_version(agent),
    )
    return score_skill_set


__all__ = [
    "episode_manifest",
    "episode_suite",
    "evaluate_skills",
    "session_count",
    "suite_version",
]
