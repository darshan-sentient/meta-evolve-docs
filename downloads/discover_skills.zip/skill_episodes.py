"""The episode suite: what a candidate skill set is measured against.

Each episode asks for something easy to do and impossible to do *correctly*
without a house convention that appears nowhere in the repository, so what
decides the score is knowledge the model cannot infer rather than a habit it
already has. Every episode runs one ordinary inner ``meta.run`` whose proposer
is an agent instructed with the base instructions plus the candidate's rendered
skills, and a plain local function checks the result.

Not a *held-out* suite, and the word is worth not using here. These episodes
are the objective: every candidate is scored on both, and nothing is kept back
from selection. What they are held back from is the **agent**, which is a
different property with a different guarantee behind it. The ACE sibling is
where held-out means what it usually means -- a split that never enters
proposal context and never contributes to the objective.

The whole suite reports one ``EvaluationResult``, so the outer kernel records
exactly one evaluation per candidate and every episode's reported cost --
tokens and elapsed time, whatever the injected agent chooses to report --
rolls up into that evaluation.

The suite is a local closure over ``EPISODES`` and is therefore not portable;
the portable ``EpisodeSuite`` type is M8's deliverable, not this example's. It
owns the session bound too, because every episode session here has the same
shape: one workspace, one edited file, one time-bounded run.

Because it closes over the agent's configuration, it declares it:
``episode_suite`` gives its evaluator a ``configured_local`` component
versioned by ``episode_manifest``. Without that, two runs over two differently
configured agents record the same evaluator and ``Run.compare`` ranks an
uncontrolled comparison.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, EvaluatorFailure
from meta_evolve.ports import EvaluationResult, Proposer

from declared_identity import digest


EPISODE_TIMEOUT_SECONDS = 120.0
# One inner run per episode: the seed evaluation plus a single agent proposal.
EPISODE_BUDGET = meta.Budget(
    evaluations=2,
    trials=1,
    wall_seconds=EPISODE_TIMEOUT_SECONDS,
)
# The suite's declared evaluator identity, in the shape the library's own
# locally configured components use: a revision prefix and a digest over an
# explicit manifest. It used to be deliberately coarser -- the agent
# declaration, the timeout, and the episode *names* -- with a comment saying so
# and inviting whoever changed what an episode measured to bump the prefix by
# hand. Nothing enforced that, and a version nobody has to maintain correctly
# is one ``compare`` cannot rely on. ``episode_manifest`` covers the inputs;
# ``CHECK_REVISION`` covers the rule itself, for a rewritten check over
# unchanged inputs.
EPISODE_SUITE_COMPONENT = "skill-evolution:episode-suite"
# The two components an inner episode declares. Both used to be name-only, so a
# run said nothing about which skill set had been rendered into it.
EPISODE_CHECK_COMPONENT = "skill-evolution:episode-check"
EPISODE_SESSION_COMPONENT = "skill-evolution:episode-session"
EPISODE_SUITE_VERSION = "1"
# Bumped when the rule stopped scoring an absent target 0.0 and started
# refusing it, and again when the episodes became filing disclosures rather
# than a repository's version and log-level strings.
CHECK_REVISION = "3"

# The same word the shared ``ace_outcomes`` attribution table owns. Restated
# here because this module is the *task* half, which the sibling split keeps
# free of the other one's imports -- and pinned equal by
# ``test_context_evolution_outcomes`` so the vocabulary cannot drift into two
# meanings. Attribution itself is not restated: ``skill_suite`` calls the one
# ``classify_fault``, because two copies of a rule about authority is how a
# wrapper got to choose its own.
UNVERIFIABLE = "unverifiable"
# How per-episode scores become the metric the outer search ranks. A suite
# taking the worst episode rather than the mean would rank different skill sets
# and must not claim the same evaluator.
AGGREGATION = "mean"


@dataclass(frozen=True, slots=True)
class Episode:
    """One repository task whose answer is not in it, checked locally.

    ``target`` and ``answer`` are declared rather than captured. The checks used
    to hold both as literals in their own bodies, where the declared evaluator
    identity could not reach them: two suites expecting different values for the
    same file declared the same evaluator, and a comment asked whoever changed
    one to bump a revision by hand. What an episode accepts is configuration.
    """

    name: str
    target: str
    answer: str
    source: meta.SourceTree
    check: Callable[[meta.SourceTree], float]


# Each episode asks for something easy to do and impossible to do *correctly*
# without a policy that appears nowhere in the workspace -- skills earn their
# keep by carrying knowledge a model cannot infer, not habits it already has.
# These are XBRL tagging reviews: the note states the amount, and choosing the
# element is the expert judgement. The answers are the filer's own taxonomy
# *extension* elements, which exist only in its tagging manual, so the standard
# element a capable agent reaches for is defensible and wrong. Both episodes
# are one note, one file, one value, which keeps them inside an agent session's
# turn budget. README.md records, as clearly-labeled history, the two live
# measurements that forced both constraints.
UNTAGGED = "untagged\n"


def house_answer_check(
    target: str, answer: str
) -> Callable[[meta.SourceTree], EvaluationResult]:
    """The one checking rule: the target file holds exactly the house answer.

    Both episodes share it, which is the honest shape -- they differ in what
    they ask for, not in how the asking is judged. Deriving the check from the
    declared pair is what lets the declared evaluator identity cover it.

    An absent target is refused rather than scored. It used to return ``0.0``,
    which reads as "the agent wrote the wrong thing" when what happened is that
    there is nothing left to read -- and a wrapper that deleted the file
    produced three evaluated trials at ``0.0`` with no failure anywhere. That
    is the low-score-instead-of-typed-failure conflation this example's own
    authority contract forbids, and the ACE sibling had already closed it one
    layer up while this one still recorded rankable zeros underneath.
    """

    def check(tree: meta.SourceTree) -> EvaluationResult:
        if target not in tree:
            return EvaluationResult(
                failure=EvaluatorFailure(
                    message=f"{target} absent from the candidate",
                    details={
                        "kind": UNVERIFIABLE,
                        "reason": f"{target} absent from the candidate",
                        "target": target,
                    },
                )
            )
        return EvaluationResult(metrics={"solved": float(tree.get(target) == answer)})

    check.component = ComponentRef.configured_local(
        "evaluator",
        check,
        name=EPISODE_CHECK_COMPONENT,
        version=digest(
            CHECK_REVISION,
            {"revision": CHECK_REVISION, "target": target, "answer": answer},
        ),
    )
    return check


# Deliberately tiny: with a live wrapper injected, every episode is one real
# agent session with real cost. The fixture pays nothing, but the shape is
# sized for the runs that do.
def _episode(name: str, target: str, readme: str, answer: str) -> Episode:
    return Episode(
        name=name,
        target=target,
        answer=answer,
        source=meta.SourceTree({"README.md": readme, target: UNTAGGED}),
        check=house_answer_check(target, answer),
    )


EPISODES = (
    # ``nwi:InterestPaidNetOfCapitalized`` is unguessable: it is this filer's
    # extension element, and ``us-gaap:InterestPaid`` is the standard one.
    _episode(
        "interest",
        "note_05_interest.tag",
        "# Note 5 -- Interest\n\nInterest paid, net of $3 million capitalized, was\n"
        "$52 million.\n\nTag that amount: write the XBRL element name into\n"
        "note_05_interest.tag.\n",
        "nwi:InterestPaidNetOfCapitalized\n",
    ),
    # ``us-gaap:LeaseCost`` is the natural pick and includes finance leases.
    _episode(
        "leases",
        "note_12_lease_cost.tag",
        "# Note 12 -- Lease cost\n\nOperating lease cost, excluding short-term "
        "leases, was\n$40 million.\n\nTag that amount: write the XBRL element name "
        "into\nnote_12_lease_cost.tag.\n",
        "nwi:OperatingLeaseCostExcludingShortTerm\n",
    ),
)

# Deliberately minimal: it says what to do and nothing about how. Any hint of
# the conventions here would hand every candidate the skills for free and
# flatten the search.
BASE_INSTRUCTIONS = "Read README.md and do what it asks."


def render_skills(skills: meta.SkillSet) -> str:
    """Fold a skill set into one instruction block, in path order.

    ``SkillSet`` owns layout only, so what a skill *means* is the reader's
    call: this reader treats each document as prose to append. An empty skill
    set renders to nothing and the agent runs on the base instructions alone.
    """

    if not skills:
        return ""
    documents = "\n\n".join(skills[path].strip() for path in skills)
    return f"\n\nApply these skills:\n\n{documents}"


def episode_instructions(skills: meta.SkillSet) -> str:
    return BASE_INSTRUCTIONS + render_skills(skills)


def declared_session(session: Proposer, version: str) -> Proposer:
    """The caller's session, wrapped in a callable this module can declare.

    Through a local wrapper rather than by setting an attribute on whatever the
    factory returned: that object belongs to the caller and may not accept one
    -- a ``functools.partial`` does not.
    """

    def propose(tree, context):
        return session(tree, context)

    propose.component = ComponentRef.configured_local(
        "proposer", propose, name=EPISODE_SESSION_COMPONENT, version=version
    )
    return propose


def run_episode(episode: Episode, session: Proposer, version: str) -> meta.Run:
    """One episode: a plain inner run over an ordinary source-tree task.

    Both components are declared. Left name-only, the inner run recorded a
    module-and-qualname reference for a closure holding the whole rendered
    skill set -- so one episode run with and without a skill produced the *same*
    inner run id while scoring 0.0 and 1.0.
    """

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=episode.check,
            artifact=meta.SourceTree,
            # No ``satisfy`` here on purpose: the episode must always reach its
            # one proposal, so that a missing second evaluation means the agent
            # failed rather than that the search stopped early.
            objectives=(meta.Maximize("solved"),),
            budget=EPISODE_BUDGET,
        ),
        seed=episode.source,
        proposer=declared_session(session, version),
        search=meta.Greedy(max_trials=1),
    )
    return meta.run(experiment)


__all__ = [
    "AGGREGATION",
    "BASE_INSTRUCTIONS",
    "CHECK_REVISION",
    "EPISODES",
    "EPISODE_BUDGET",
    "EPISODE_CHECK_COMPONENT",
    "EPISODE_SESSION_COMPONENT",
    "EPISODE_SUITE_COMPONENT",
    "EPISODE_SUITE_VERSION",
    "Episode",
    "UNTAGGED",
    "UNVERIFIABLE",
    "declared_session",
    "episode_instructions",
    "house_answer_check",
    "render_skills",
    "run_episode",
]
