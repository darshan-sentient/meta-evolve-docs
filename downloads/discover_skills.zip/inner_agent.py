"""The agent that runs underneath, and what it declares itself to be.

Both siblings take one of these rather than a factory plus a model id, because
a model id is not an agent. Wrapper revision, SDK and CLI version, how the
system instruction gets built, which tools are permitted, the turn limit --
every one of those can change what an agent does while the model id stays
fixed. A run that declared only the model would record two materially
different experiments identically, and ``Run.compare`` requires exact
declaration equality and *nothing else*, so it would then rank an uncontrolled
comparison as a controlled one.

That is the same hidden-closure defect ``declared_identity`` exists to close
for published lessons. The factory is a closure too: it captures whatever
configured it, and none of that is visible in the string a caller passes.

So this module owns the boundary object, and the boundary is one value on
purpose -- there is no call in either sibling that accepts a wrapper without
saying what it is.

Nothing here runs the agent. It holds the callable and turns what was declared
about it into text.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import FrozenMap

from declared_identity import digest
from factory_identity import UndeclaredAgent, factory_digest

# What both committed fixture agents declare as their model. It is not a model
# id, and that is the point: a fixture-driven run and a live run therefore
# declare different evaluators, so ``Run.compare`` refuses the pair rather than
# ranking a deterministic stand-in against a paid one.
FIXTURE_MODEL = "deterministic-sdk-fixture-v1"


def _plain(value: object) -> object:
    if isinstance(value, Mapping):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_plain(item) for item in value]
    return value


@dataclass(frozen=True, slots=True)
class InnerAgent:
    """A wrapper factory, bound to the declaration that describes it.

    ``build(instructions)`` is called once per rollout and returns a proposer
    for that one session. Everything else here is what the evaluator records
    about it.

    The honest limit is worth stating, because the example is a demonstration
    of declaration and not of enforcement: a declaration is a *claim*. Nothing
    can check that ``model`` names the model the wrapper really calls, or that
    ``configuration`` lists everything it closed over. What carrying both in
    one value buys is that the claim cannot be *omitted*, and
    ``factory_digest`` makes the one part that can be verified verified.
    """

    build: Callable[[str], object]
    model: str
    revision: str
    configuration: Mapping[str, object] = field(default_factory=dict)
    _implementation: str = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        for name in ("model", "revision"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value or value != value.strip():
                raise ValueError(
                    f"agent {name} must be non-empty text without outer whitespace"
                )
        object.__setattr__(self, "configuration", FrozenMap(self.configuration))
        object.__setattr__(self, "_implementation", factory_digest(self.build))

    @property
    def manifest(self) -> Mapping[str, object]:
        """Everything declared about this agent, as one plain value.

        A manifest rather than a joined line for the reason
        ``declared_identity`` gives: a test can walk this, perturb every leaf,
        and prove the version responds to each. A join is a list someone
        maintains and the forgotten field leaves no trace.
        """

        return {
            "model": self.model,
            "revision": self.revision,
            "configuration": _plain(self.configuration),
            "implementation": self._implementation,
        }

    @property
    def version(self) -> str:
        """What a component configured with this agent declares itself to be."""

        return digest(self.revision, self.manifest)


__all__ = [
    "FIXTURE_MODEL",
    "InnerAgent",
    "UndeclaredAgent",
    "factory_digest",
]
