"""Durable summaries of the ordinary runs nested inside an evaluation.

An inner run is a live object holding its own storage, so it cannot itself go
into an outer evaluation's evidence. What can is a plain value: what the inner
run *declared*, what it produced, what it cost. That is a summary and says so
-- the captured run id is a label, not a handle, because these inner runs are
not persisted independently.

The declarations are the point rather than a detail. A reader who can see two
inner run ids and two scores still cannot tell which agent or which rendered
context produced them, which is the whole question this example is about.
"""

from __future__ import annotations

import dataclasses

import meta_evolve as meta
from meta_evolve.domain import Failure


def _failure(value: Failure | None) -> object:
    if value is None:
        return None
    return {
        "kind": value.kind,
        "message": value.message,
        "details": value.details,
    }


def _usage(value: meta.Usage) -> dict[str, object]:
    return {field.name: getattr(value, field.name) for field in dataclasses.fields(value)}


def _components(declaration: object) -> dict[str, object]:
    """What the inner run said its evaluator and proposer were.

    Both are ``configured_local`` references carrying a version over the agent
    declaration and the rendered context, so this is what lets a reader of the
    outer event stream attribute an inner score to a specific agent and a
    specific candidate rather than to "some rollout".
    """

    return {
        role: {"name": ref.name, "version": ref.version, "origin": ref.origin}
        for role, ref in (
            ("evaluator", declaration.evaluator),
            ("proposer", declaration.proposer),
        )
    }


def capture_run(name: str, run: meta.Run) -> dict[str, object]:
    """Capture one inner history as JSON-like outer evidence."""

    # One validated replay for both halves: the declaration and the attempts
    # come off the same aggregate rather than two passes over the same events.
    inspection = run.inspect()
    attempts: list[dict[str, object]] = []
    for trial in inspection.trials:
        artifact = trial.artifact
        value = artifact.value if artifact is not None else None
        attempts.append(
            {
                "trial_id": trial.id.value,
                "step": trial.logical_step,
                "state": trial.state,
                "artifact": None
                if artifact is None
                else {
                    "id": artifact.id.value,
                    "digest": artifact.digest,
                    "parent_ids": tuple(parent.value for parent in artifact.parent_ids),
                    "source": value.to_payload()
                    if isinstance(value, meta.SourceTree)
                    else None,
                },
                "parent_ids": tuple(parent.value for parent in trial.parent_ids),
                "metrics": trial.metrics,
                "failure": _failure(trial.failure),
                "evidence": tuple(
                    {"kind": item.kind, "data": item.data, "uri": item.uri}
                    for item in trial.evidence
                ),
                "usage": _usage(trial.usage),
            }
        )
    return {
        "name": name,
        "run_id": run.id.value,
        "components": _components(inspection.declaration),
        "attempts": tuple(attempts),
        "usage": _usage(run.usage()),
    }


__all__ = ["capture_run"]
