"""A stable fingerprint of the wrapper surface Python can inspect.

Nothing here runs or observes the wrapper. ``factory_digest`` documents the
verified surface and its limits.
"""

from __future__ import annotations

import inspect
import math
from collections.abc import Callable, Mapping
from hashlib import sha256
from types import CodeType

from meta_evolve.domain import FrozenMap

from declared_identity import canonical


class UndeclaredAgent(Exception):
    """A wrapper whose inspectable implementation cannot be identified safely."""


class _TooDeep(Exception):
    """The helper chain outran the traversal bound and must be refused."""


# Protect recursion; reaching the bound refuses rather than approximates.
_MAX_CHAIN = 64


def _type_name(value: object) -> str:
    """Name a type without unstable instance state such as memory addresses."""

    kind = type(value)
    return f"{kind.__module__}.{kind.__qualname__}"


def _named(value: object) -> str:
    """Distinguish callables such as ``len`` and ``sorted`` that share a type."""

    name = getattr(value, "__qualname__", None)
    if not isinstance(name, str) or not name:
        return _type_name(value)
    return f"{getattr(value, '__module__', None) or '?'}.{name}"


def _source(build: object) -> str | None:
    """The text of a callable, or of the class whose instance it is."""

    for candidate in (build, type(build)):
        try:
            return inspect.getsource(candidate)  # type: ignore[arg-type]
        except (OSError, TypeError):
            continue
    return None


def _entry(build: object) -> Callable[..., object] | None:
    """The callable that runs when the factory is called, function or object."""

    for candidate in (build, getattr(type(build), "__call__", None)):
        if isinstance(getattr(candidate, "__code__", None), CodeType):
            return candidate  # type: ignore[return-value]
    return None


def _stable_value(value: object, trail: tuple[int, ...] = ()) -> object:
    """Read one value canonically, recording cycles and refusing unstable ones."""

    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise UndeclaredAgent("factory defaults cannot contain NaN or infinity")
        return value
    if isinstance(value, bytes):
        return {"bytes": value.hex()}
    if isinstance(value, complex):
        return {"complex": [value.real, value.imag]}
    if value is Ellipsis:
        return {"ellipsis": True}

    marker = id(value)
    if marker in trail:
        return {"cycle": trail.index(marker)}
    if len(trail) >= _MAX_CHAIN:
        raise _TooDeep(
            f"a factory nested deeper than {_MAX_CHAIN} steps cannot be read"
        )
    trail += (marker,)

    if isinstance(value, CodeType):
        return {"code": _executable_identity(value, trail)}
    if isinstance(value, tuple):
        return {"tuple": [_stable_value(item, trail) for item in value]}
    if isinstance(value, frozenset):
        # Set order depends on the hash seed, including frozenset constants in
        # compiled membership tests.
        return {"set": sorted((_stable_value(i, trail) for i in value), key=canonical)}
    if callable(value):
        # A callable default contributes the helper implementation it invokes.
        if _source(value) is None and _entry(value) is None:
            return {"callable": _named(value)}
        return {"callable": _callable_identity(value, trail)}
    raise UndeclaredAgent(
        f"factory defaults must be stable plain values, not {type(value).__name__}"
    )


def _stable_default(value: object, trail: tuple[int, ...], owner: str) -> object:
    """Read immutable defaults; name the factory or helper holding live state."""

    if isinstance(value, (list, set, Mapping)) and not isinstance(value, FrozenMap):
        raise UndeclaredAgent(
            f"{owner} holds a mutable {type(value).__name__} default, whose state "
            "can move after it is declared; give it an immutable default, or "
            "declare non-secret behavior settings in InnerAgent.configuration"
        )
    marker = id(value)
    if marker in trail:
        return {"cycle": trail.index(marker)}
    if len(trail) >= _MAX_CHAIN:
        raise _TooDeep(
            f"a factory nested deeper than {_MAX_CHAIN} steps cannot be read"
        )
    nested = trail + (marker,)
    if isinstance(value, tuple):
        return {"tuple": [_stable_default(item, nested, owner) for item in value]}
    if isinstance(value, FrozenMap):
        # Recursively immutable and key-sorted, unlike a mapping proxy whose
        # backing dictionary can still move.
        return {"map": _stable_default(tuple(value.items()), nested, owner)}
    if isinstance(value, frozenset):
        pairs = (_stable_default(item, nested, owner) for item in value)
        return {"set": sorted(pairs, key=canonical)}
    return _stable_value(value, trail)


def _executable_identity(
    code: CodeType, trail: tuple[int, ...]
) -> Mapping[str, object]:
    """What one code object *does*, with no trace of where it was written.

    Bytecode separates lambdas that share a source line. Nested code is walked;
    source positions are omitted, and constants use the stable value reader.
    """

    return {
        "bytecode": code.co_code.hex(),
        "names": list(code.co_names),
        "positional_only": code.co_posonlyargcount,
        "positional_or_keyword": code.co_argcount - code.co_posonlyargcount,
        "keyword_only": code.co_kwonlyargcount,
        "flags": code.co_flags,
        "arguments": list(
            code.co_varnames[: code.co_argcount + code.co_kwonlyargcount]
        ),
        "constants": [_stable_value(constant, trail) for constant in code.co_consts],
    }


def _captured(entry: Callable[..., object], trail: tuple[int, ...]) -> object:
    """What a factory closed over, as far as a digest can honestly reach.

    Only captured callables are followed; other cell contents are live state.
    ``factory_digest`` states the complete boundary.
    """

    captured: list[Mapping[str, object]] = []
    names = getattr(entry.__code__, "co_freevars", ())
    for name, cell in zip(names, getattr(entry, "__closure__", None) or ()):
        try:
            content = cell.cell_contents
        except ValueError:
            # A cell filled in later -- a closure that refers to itself. There
            # is nothing to read yet, and saying so beats guessing.
            captured.append({"name": name, "state": "unset"})
            continue
        if callable(content):
            captured.append({"name": name, "callable": _stable_value(content, trail)})
        else:
            captured.append({"name": name, "type": _type_name(content)})
    return captured


def factory_digest(build: Callable[..., object]) -> str:
    """Fingerprint the stable factory surface that Python can inspect.

    Source, bytecode, immutable defaults, and captured helper callables are the
    verified part of the agent declaration. Helper chains are followed to a
    cycle or their end; exceeding the traversal bound is refused rather than
    approximated. Mutable defaults are refused and the callable holding one is
    named.

    Non-callable closure state, callable-instance state, globals, SDK behavior,
    and external configuration cannot be verified safely. They remain explicit
    caller declarations: ``revision`` and non-secret ``configuration`` make the
    manifest, not this digest alone, authoritative.
    """

    try:
        identity = _callable_identity(build, (id(build),))
    except _TooDeep as exhausted:
        raise UndeclaredAgent(
            f"cannot identify the implementation of {build!r}: {exhausted}"
        ) from exhausted
    return sha256(canonical(identity).encode("utf-8")).hexdigest()


def _callable_identity(
    build: Callable[..., object], trail: tuple[int, ...]
) -> Mapping[str, object]:
    """Every view of one callable. ``trail`` already names this one."""

    identity: dict[str, object] = {}
    source = _source(build)
    if source is not None:
        identity["source"] = source
    entry = _entry(build)
    if entry is not None:
        defaults = getattr(entry, "__defaults__", None)
        keyword_defaults = getattr(entry, "__kwdefaults__", None)
        owner = _named(build)
        identity["executable"] = {
            "code": _executable_identity(entry.__code__, trail),
            "defaults": None
            if defaults is None
            else {"tuple": [_stable_default(item, trail, owner) for item in defaults]},
            "keyword_defaults": None
            if keyword_defaults is None
            else {
                "mapping": {
                    key: _stable_default(item, trail, owner)
                    for key, item in keyword_defaults.items()
                }
            },
            "captured": _captured(entry, trail),
        }
    if not identity:
        raise UndeclaredAgent(
            f"cannot identify the implementation of {build!r}: declare an agent "
            "whose factory is a function or a class defined in a source file"
        )
    identity["module"] = getattr(build, "__module__", None) or type(build).__module__
    return identity


__all__ = [
    "UndeclaredAgent",
    "factory_digest",
]
