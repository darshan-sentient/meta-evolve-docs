"""The EvoSkill sibling's configuration and search.

``ace_context`` and ``ace_study`` are the same two things for the playbook
sibling. This module holds both for the skill sibling, because a skill run *is*
one outer run -- there is no development phase to publish from, no consolidation
to accept, and no split to hold back, so a lifecycle type would be ceremony
around a single call.

``main.py`` owns the command and the printing and nothing else. It used to own
this too, alongside the CLI and both siblings' reports, which is why the two
siblings did not look like siblings.
"""

from __future__ import annotations

import sys
from collections.abc import Mapping
from pathlib import Path

import meta_evolve as meta
from meta_evolve.ports import Proposer, ProposerContext

HERE = Path(__file__).parent
if str(HERE) not in sys.path:
    # Example modules are plain siblings, not an installed package.
    sys.path.insert(0, str(HERE))

from inner_agent import (  # noqa: E402 -- needs the path entry above
    FIXTURE_MODEL,
    InnerAgent,
)
from skill_episodes import EPISODES  # noqa: E402
from skill_suite import episode_suite  # noqa: E402

# The outer bound that decides what a run with a live wrapper would cost: the
# seed skill set plus at most two mutations, each scored over the whole suite,
# and one session per episode. Worst case is
# SKILL_BUDGET.evaluations * len(EPISODES) == 6 wrapper calls.
SKILL_TRIALS = 2
SKILL_BUDGET = meta.Budget(evaluations=SKILL_TRIALS + 1, trials=SKILL_TRIALS)
SKILL_CALL_CEILING = SKILL_BUDGET.evaluations * len(EPISODES)

# The outer search space. One skill per episode, so a candidate holding
# neither scores 0.0, one scores 0.5, and both score 1.0 -- a real gradient
# for the outer search to climb.
SKILL_LIBRARY: Mapping[str, str] = {
    "skills/interest.md": (
        "# Tagging cash interest\n\n"
        "Northwind discloses cash interest net of capitalized interest, and\n"
        "tags that line with its own extension element\n"
        "`nwi:InterestPaidNetOfCapitalized`. The standard\n"
        "`us-gaap:InterestPaid` is the gross figure and is not what this filer\n"
        "reports here. Write the element name and a trailing newline, nothing\n"
        "else.\n"
    ),
    "skills/leases.md": (
        "# Tagging lease cost\n\n"
        "Operating lease cost stated excluding short-term leases is tagged with\n"
        "the extension element `nwi:OperatingLeaseCostExcludingShortTerm`.\n"
        "The standard `us-gaap:LeaseCost` is the total including finance\n"
        "leases, so it overstates the operating component. Write the element\n"
        "name and a trailing newline, nothing else.\n"
    ),
}


def add_skill(parent: meta.SkillSet, context: ProposerContext) -> meta.SkillSet:
    """The outer proposer: deterministic, local, and model-free."""

    missing = sorted(path for path in SKILL_LIBRARY if path not in parent)
    if not missing:
        return parent
    path = context.rng.choice(missing)
    return meta.SkillSet({**parent, path: SKILL_LIBRARY[path]})


# --8<-- [start:experiment]
def evolve_skills(agent: InnerAgent, *, random_seed: int = 0) -> meta.Run:
    """Evolve the skill set; the agent only ever runs underneath it.

    The agent arrives declared rather than as a factory plus a model id, and
    ``episode_suite`` folds that declaration into the evaluator's version -- so
    two runs over two different agents are refused rather than compared, which
    a shared model id would not have earned.
    """

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=episode_suite(agent),
            artifact=meta.SkillSet,
            objectives=(meta.Maximize("solved", satisfy=1.0),),
            budget=SKILL_BUDGET,
        ),
        seed=meta.SkillSet(),
        proposer=add_skill,
        search=meta.Greedy(max_trials=SKILL_TRIALS),
        random_seed=random_seed,
    )
    return meta.run(experiment)
# --8<-- [end:experiment]


def fixture_agent(instructions: str) -> Proposer:
    """The inner proposer: a deterministic stand-in for a user-owned wrapper.

    It always tags the line, because a live agent does too. What it cannot do
    without the skill is know which element this filer uses, so it writes the
    standard one -- ``us-gaap:InterestPaid`` for the interest note,
    ``us-gaap:LeaseCost`` for the lease note. Both are defensible readings of
    the disclosure and both are wrong here, which is exactly the unguided
    behaviour the live measurements in README.md record. The skill's own
    phrasing in the instructions is the only thing that turns them into the
    filer's extension elements, which is what makes the outer score move.

    It is an ordinary callable, so it crosses the same boundary a real SDK
    wrapper would; returning a bare candidate means it reports no usage, and
    the episode token roll-up prints a measured zero.
    """

    def propose(tree: meta.SourceTree, _context) -> meta.SourceTree:
        note = tree.get("README.md", "")
        target = next(path for path in sorted(tree) if path != "README.md")
        if "interest" in note.lower():
            value = (
                "nwi:InterestPaidNetOfCapitalized\n"
                if "nwi:InterestPaidNetOfCapitalized" in instructions
                else "us-gaap:InterestPaid\n"
            )
        else:
            value = (
                "nwi:OperatingLeaseCostExcludingShortTerm\n"
                if "nwi:OperatingLeaseCostExcludingShortTerm" in instructions
                else "us-gaap:LeaseCost\n"
            )
        return meta.SourceTree({**tree, target: value})

    return propose


# The committed fixture, declared. ``configuration`` is empty and honestly so:
# the factory closes over nothing but its own argument. Secret material stays
# outside Meta-Evolve values and evidence. A live wrapper declares only
# non-secret behavior settings -- such as auth mode, credential-source
# identifier, turn limit, and tools -- that source inspection cannot see.
FIXTURE_AGENT = InnerAgent(
    build=fixture_agent, model=FIXTURE_MODEL, revision="fixture-skill-agent-v1"
)


__all__ = [
    "FIXTURE_AGENT",
    "SKILL_BUDGET",
    "SKILL_CALL_CEILING",
    "SKILL_LIBRARY",
    "SKILL_TRIALS",
    "add_skill",
    "evolve_skills",
    "fixture_agent",
]
