"""What a rollout and a split produced, and whose problem a failure is.

A rollout that fails is not a playbook that scored badly, and the difference
decides who has to act on it. So this module owns two narrow jobs: turn a
kernel-reported failure into this suite's vocabulary, and hold the result of a
split -- including its refusal to report a mean over rollouts that did not all
finish.

It lives apart from ``ace_rollouts`` because attribution is the part most
likely to be wrong: the shipped kinds are ``Failure`` class attributes, and an
earlier version of this table listed ``budget_exhausted`` and
``spend_exhausted`` -- policy *stop reasons*, not failure kinds -- so a real
timeout was reported as the wrapper's fault. Keeping the table alone in a
module with a completeness test over the library's own classes is what turns
that from a comment into something the suite cannot get wrong twice.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType

import meta_evolve as meta
from meta_evolve.domain import EvaluatorFailure

# Three ways to have no usable evidence, because they call for three different
# responses: a wrapper that cannot answer is the candidate's problem, a rollout
# whose target file went missing cannot be judged at all, and an exhausted
# budget or a broken machine is nobody's evidence about anything. None of them
# is a low score.
WRAPPER_FAILED = "wrapper-failed"
UNVERIFIABLE = "unverifiable"
INFRASTRUCTURE_FAILED = "infrastructure-failed"
ROLLOUT_FAULT_KINDS = (WRAPPER_FAILED, UNVERIFIABLE, INFRASTRUCTURE_FAILED)
SPLIT_AGGREGATION = "mean"

# The shipped ``Failure`` kinds an injected wrapper is answerable for: it
# raised, it returned something that is not the declared artifact, or its
# proposal claimed a derivation it was not allowed to observe.
#
# These are the library's own ``Failure.kind`` values, and
# ``test_context_evolution_ace_failures`` pins that -- a name in this set that
# no shipped class carries is the exact bug this module was split out to make
# impossible.
WRAPPER_ATTRIBUTED_KINDS = frozenset(
    {
        "proposer_failure",
        "invalid_output",
        "policy_violation",
    }
)


@dataclass(frozen=True, slots=True)
class RolloutFault:
    """Why one rollout yielded nothing rankable, and what the kernel said.

    ``kind`` is this suite's vocabulary and ``reported`` is the shipped
    ``Failure.kind`` behind it, kept separately because ``detail`` prefers the
    reason a wrapper gave -- and a reader who only had the reason could not
    tell a timeout from a refusal.
    """

    kind: str
    detail: str
    reported: str | None = None


def classify_fault(state: str, fault: object | None) -> RolloutFault:
    """Map a kernel failure onto this suite's vocabulary.

    Anything not positively attributable to the wrapper is infrastructure.
    That default is the whole point: blaming the candidate for a fault nobody
    has identified would let a broken machine argue against a playbook, and
    charging infrastructure for a wrapper's refusal merely loses a signal. Only
    one of those two mistakes can corrupt a result, so the unknown case takes
    the other.
    """

    kind = getattr(fault, "kind", None)
    details = getattr(fault, "details", None) or {}
    detail = state if kind is None else str(details.get("reason", kind))
    declared = details.get("kind")
    if (
        state == "evaluation_failed"
        and type(fault) is EvaluatorFailure
        and declared in ROLLOUT_FAULT_KINDS
    ):
        # The evaluator that refused knows why it refused, and says so in the
        # details. Without this, an unverifiable rollout arrives as an ordinary
        # ``evaluator_failure`` and gets filed under infrastructure -- the same
        # shape of misattribution the guessed kinds used to produce.
        return RolloutFault(str(declared), detail, reported=kind)
    if kind in WRAPPER_ATTRIBUTED_KINDS:
        return RolloutFault(WRAPPER_FAILED, detail, reported=kind)
    return RolloutFault(INFRASTRUCTURE_FAILED, detail, reported=kind)


class SplitIncomplete(Exception):
    """A split with any unfinished rollout has no rankable summary.

    Averaging the rollouts that *did* finish is the one thing a partial split
    must never do. One success beside one timeout would report ``1.0``, which
    is a claim about the playbook the evidence does not support -- and it is
    the same conflation of absent evidence with good evidence that the typed
    fault kinds exist to prevent. A caller that wants a number from a partial
    split has to look at the faults instead.
    """

    def __init__(
        self,
        split: str,
        unfinished: Mapping[str, RolloutFault],
        missing: tuple[str, ...] = (),
    ) -> None:
        # ``missing`` is kept apart from ``unfinished`` because they are
        # different problems: a faulted rollout ran and produced nothing
        # usable, a missing one was declared and never accounted for at all.
        # Collapsing them would hide the second, which is the one that let a
        # half-run split call itself complete.
        reasons = [
            f"{name}: {fault.kind} ({fault.detail})"
            for name, fault in sorted(unfinished.items())
        ]
        reasons.extend(f"{name}: never ran" for name in sorted(missing))
        named = ", ".join(reasons)
        super().__init__(f"the {split} split did not finish: {named or 'nothing ran'}")
        self.split = split
        self.unfinished = MappingProxyType(dict(unfinished))
        self.missing = tuple(missing)


@dataclass(frozen=True, slots=True)
class SplitOutcome:
    """What one split produced: per-task scores, faults, and reported cost.

    ``declared`` is the rollout names the split was *supposed* to run, carried
    rather than inferred. Completeness measured against an outcome's own keys
    can only ask "is this self-consistent", which every outcome is: one score
    out of two declared rollouts looked complete, and two such outcomes looked
    like matched neutral evidence for a consolidation decision. Comparing
    against the declaration is the difference between "nothing went wrong in
    what I ran" and "I ran what I said I would".

    ``sessions`` is how many times the wrapper factory was actually called,
    which stops being ``len(scores) + len(unfinished)`` as soon as a session
    can fail before producing anything -- and is the number a paid run needs
    reported. ``runs`` keeps each rollout's inner run, so its lineage,
    evidence, and declarations stay inspectable instead of being scored and
    thrown away.
    """

    split: str
    condition: str
    declared: tuple[str, ...]
    scores: Mapping[str, float]
    unfinished: Mapping[str, RolloutFault]
    usage: meta.Usage
    sessions: int = 0
    runs: Mapping[str, meta.Run] = field(default_factory=dict)

    def __post_init__(self) -> None:
        declared = tuple(self.declared)
        scores = dict(self.scores)
        unfinished = dict(self.unfinished)
        runs = dict(self.runs)
        if not isinstance(self.split, str) or not self.split:
            raise ValueError("split must be non-empty text")
        if not isinstance(self.condition, str) or not self.condition:
            raise ValueError("split condition must be non-empty text")
        if any(not isinstance(name, str) or not name for name in declared):
            raise ValueError("declared rollout names must be non-empty text")
        if len(declared) != len(set(declared)):
            raise ValueError("declared rollout names must be unique")
        known = set(declared)
        for label, values in (
            ("score", scores),
            ("unfinished", unfinished),
            ("run", runs),
        ):
            unknown = set(values) - known
            if unknown:
                raise ValueError(f"{label} keys must be declared: {sorted(unknown)!r}")
        overlap = set(scores) & set(unfinished)
        if overlap:
            raise ValueError(
                f"rollouts cannot be scored and unfinished: {sorted(overlap)!r}"
            )
        if any(
            isinstance(score, bool)
            or not isinstance(score, (int, float))
            or not math.isfinite(float(score))
            for score in scores.values()
        ):
            raise ValueError("split scores must be finite numbers")
        if any(not isinstance(fault, RolloutFault) for fault in unfinished.values()):
            raise TypeError("unfinished rollouts must contain RolloutFault values")
        if not isinstance(self.usage, meta.Usage):
            raise TypeError("split usage must be a Usage")
        if (
            isinstance(self.sessions, bool)
            or not isinstance(self.sessions, int)
            or self.sessions < 0
        ):
            raise ValueError("split sessions must be a non-negative integer")
        if self.sessions < len(runs):
            raise ValueError("split sessions cannot be fewer than retained runs")
        if any(not isinstance(run, meta.Run) for run in runs.values()):
            raise TypeError("split runs must contain Run values")
        object.__setattr__(self, "declared", declared)
        object.__setattr__(self, "scores", MappingProxyType(scores))
        object.__setattr__(self, "unfinished", MappingProxyType(unfinished))
        object.__setattr__(self, "runs", MappingProxyType(runs))

    @property
    def missing(self) -> tuple[str, ...]:
        """Declared rollouts this outcome accounts for in neither way."""

        seen = set(self.scores) | set(self.unfinished)
        return tuple(name for name in self.declared if name not in seen)

    @property
    def is_complete(self) -> bool:
        """Whether every *declared* rollout produced a rankable score.

        An empty split counts as incomplete rather than perfect: no rollout
        having run is not evidence, and the previous ``0.0`` for that case was
        a number nothing measured.
        """

        return (
            bool(self.declared)
            and not self.unfinished
            and set(self.scores) == set(self.declared)
        )

    @property
    def solved(self) -> float:
        """The mean score, or a refusal when there is not one to report."""

        if not self.is_complete:
            raise SplitIncomplete(self.split, self.unfinished, self.missing)
        return sum(self.scores.values()) / len(self.scores)


__all__ = [
    "INFRASTRUCTURE_FAILED",
    "ROLLOUT_FAULT_KINDS",
    "SPLIT_AGGREGATION",
    "SplitIncomplete",
    "SplitOutcome",
    "RolloutFault",
    "UNVERIFIABLE",
    "WRAPPER_ATTRIBUTED_KINDS",
    "WRAPPER_FAILED",
    "classify_fault",
]
