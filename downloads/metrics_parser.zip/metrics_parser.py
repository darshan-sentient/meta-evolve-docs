"""Report parsing and rejection separately; the default seed check makes no requests."""

import argparse
from dataclasses import replace
from hashlib import sha256
from pathlib import Path

from openai_client import OpenAIClient
from parser import SEED, evaluate, experiment, run_lesson


# --8<-- [start:evaluate]
def evaluate_categories(source):
    measured = evaluate(source)
    if measured.failure is not None:
        return measured
    checks = [item.data for item in measured.evidence if item.kind == "duration-case"]
    metrics = dict(measured.metrics)
    for name, invalid in (("valid_inputs", False), ("invalid_inputs", True)):
        group = [row for row in checks if (row["expected"] is None) == invalid]
        metrics[name] = sum(row["passed"] for row in group) / len(group)
    return replace(measured, metrics=metrics)
# --8<-- [end:evaluate]


# --8<-- [start:declaration]
def declaration(client):
    base = experiment(client)
    task = replace(base.task, evaluator=evaluate_categories, environment={
        **base.task.environment,
        "metrics_source": sha256(Path(__file__).read_bytes()).hexdigest(),
    })
    return replace(base, task=task)
# --8<-- [end:declaration]


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--run", type=Path, metavar="DIRECTORY", help="save a model-backed search")
    args = cli.parse_args()
    if args.run:
        with OpenAIClient.from_environment() as client:
            run_lesson(client, args.run, declaration=declaration(client))
    else:
        for name, value in evaluate_categories(SEED).metrics.items():
            print(f"{name}: {value:.1%}")
