"""Change when the parser is good enough. Makes model calls unless the seed suffices."""

import argparse
from dataclasses import replace
from pathlib import Path

import meta_evolve as meta
from openai_client import OpenAIClient
from parser import experiment, run_lesson


# --8<-- [start:declaration]
def declaration(client, target=0.85):
    base = experiment(client)
    task = replace(base.task, objectives=(meta.Maximize("score", satisfy=target),))
    return replace(base, task=task)
# --8<-- [end:declaration]


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("directory", type=Path, help="new history directory")
    cli.add_argument("--target", type=float, default=0.85)
    args = cli.parse_args()
    with OpenAIClient.from_environment() as client:
        run_lesson(client, args.directory, declaration=declaration(client, args.target))
