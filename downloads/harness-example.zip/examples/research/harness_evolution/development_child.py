"""The confined child's own entry point: read one request, answer it, exit.

Runs inside the copied root ``child_root.py`` materializes, after the OS
policy from ``confinement_policy.py`` is already applied by the launcher
prefix — this file never applies its own restriction and never needs to.

**No ``meta_evolve`` import, and none of this repository's real modules.**
This is a loose script run by absolute interpreter path with a relative
script name (``confinement_policy.launcher`` arranges that), so a package
import would not resolve here even if one were written; and the only module
this imports, ``fixture_responder``, is copied onto this same root rather
than reached through the repository the confinement denies anyway.

**Always exits 0.** Every outcome — a good answer, an unreadable or malformed
request, or the fixture's own code raising — is reported as JSON on stdout,
never as an exit code. The parent process is the one that may raise, and it
decides what each outcome means; a child that claimed to know would be a
claim from the one process this boundary exists to keep unauthoritative.
"""

from __future__ import annotations

import json

import fixture_responder


REQUEST_FILE = "request.json"


def _rehydrate(request: dict) -> dict:
    """Undo what a JSON round-trip does to the tuple fields the fixture reads.

    ``fixture_responder.py`` is the exact same file whether it runs in-process
    or copied onto this child's root, and it type-checks two fields at the
    type their builder put there: a tuple. JSON has no tuple, so the request
    arrives as a dict of otherwise-equal lists; this restores the exact shape
    before handing it to code that does not know the difference.
    """

    rehydrated = dict(request)
    for key in ("editable_surfaces", "parent_citations"):
        if key in rehydrated and isinstance(rehydrated[key], list):
            rehydrated[key] = tuple(rehydrated[key])
    return rehydrated


def main() -> int:
    try:
        with open(REQUEST_FILE, encoding="utf-8") as handle:
            request = json.load(handle)
    except (OSError, ValueError) as error:
        print(json.dumps({"error": f"request unreadable: {error}"}))
        return 0
    if not isinstance(request, dict):
        print(json.dumps({"error": "request must be a JSON object"}))
        return 0
    try:
        raw = fixture_responder.structured_body(_rehydrate(request))
    except BaseException as error:  # noqa: BLE001 - reported, never propagated
        print(json.dumps({"error": f"{type(error).__name__}: {error}"}))
        return 0
    print(json.dumps({"raw": raw}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
