"""The deterministic stand-in for a schema-constrained SDK response.

:mod:`tfd` owns request, decode, authorization, application, and retention and
takes its responder as an argument, so fixture and live paths differ only in
who answers. This module is the fixture's answer, and nothing else — it reads
the same sanitized request a provider would receive and returns JSON text, so
both paths meet the same strict parser rather than one of them shortcutting to
an already-decoded object.

It is deliberately outside the adapter. A responder is the one component the
live run replaces wholesale, and keeping it separate is what makes "the only
difference is the answer" checkable by reading the imports.

**No ``meta_evolve`` import.** This module is also the one copied onto the
confined proposer child's own root (``child_root.py``), so it stays free of
the kernel and of every other package-level import: what it returns is plain
JSON text, never a kernel-typed value. ``confined_responder.py`` and
``tfd.propose_tfd`` each wrap that text into a ``StructuredResponse`` in their
own (unconfined) process, using the same declared model and token cost below,
so the one number the fixture actually costs is declared once.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TypeVar


FIXTURE_MODEL = "fixture-structured-sdk-v1"
# Declared as the pair a provider actually reports, plus the total it bills.
# The total is stated rather than derived so this fixture exercises the same
# validation a live reasoning model does: a provider-reported total may exceed
# input+output (tokens it bills but does not itemize), and ``call_usage``
# accepts that and names the remainder. Here the remainder is deliberately
# non-zero, so the retained shape a phase total is summed from is the general
# one rather than the degenerate case where the check cannot fail.
FIXTURE_INPUT_TOKENS = 3
FIXTURE_OUTPUT_TOKENS = 1
FIXTURE_TOKENS = 5

_Field = TypeVar("_Field")


def _field(request: Mapping[str, object], key: str, kind: type[_Field]) -> _Field:
    """One field of a request, at the type its builder put there.

    Inlined rather than imported from ``proposal_manifest``: that module
    imports ``meta_evolve``, and importing even one name from it would pull
    the kernel into this file regardless of which name was asked for.
    """

    value = request[key]
    if not isinstance(value, kind):
        raise TypeError(f"request field {key!r} is not a {kind.__name__}")
    return value


def structured_body(request: Mapping[str, object]) -> str:
    """The raw JSON text a native structured-output boundary would send."""

    surfaces = _field(request, "editable_surfaces", tuple)
    citations = list(_field(request, "parent_citations", tuple))
    if "repair arithmetic" not in _field(request, "planner", str).lower():
        body = {
            "evidence_citations": citations,
            "surface": surfaces[0],
            "value": "Diagnose requested behavior and repair arithmetic operations.",
            "predicted_fix": "the arithmetic repair episode reaches its verifier",
            "at_risk_regressions": ["episodes that only need the interface kept"],
        }
    elif _field(request, "development_quality", float) == 0.5:
        body = {
            "evidence_citations": citations,
            "surface": surfaces[1],
            "value": {"diagnostics": True},
            "predicted_fix": "the worker sees why the remaining episode fails",
            "at_risk_regressions": ["episodes already passing without diagnostics"],
        }
    else:
        # Nothing left to change: a declared-surface restatement of what the
        # parent already holds, which the shipped boundary refuses as a no-op.
        body = {
            "evidence_citations": citations,
            "surface": surfaces[1],
            "value": dict(_field(request, "context_policy", dict)),
            "predicted_fix": "no further development failure is observable",
            "at_risk_regressions": ["episodes that currently pass"],
        }
    return json.dumps(body)


__all__ = [
    "FIXTURE_INPUT_TOKENS",
    "FIXTURE_MODEL",
    "FIXTURE_OUTPUT_TOKENS",
    "FIXTURE_TOKENS",
    "structured_body",
]
