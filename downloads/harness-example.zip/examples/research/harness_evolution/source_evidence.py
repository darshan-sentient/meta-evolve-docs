"""Publishing one canonical view as evidence the exact evaluation owns.

The evaluator is the only thing that may publish a source view, because it is
the only thing that holds the evaluated artifact under its own authority. What
it publishes is a *value*: a four-draft bundle whose header indexes the three
files behind it. No artifact is minted, no lineage is touched, and nothing here
is selectable by the governed context policy.

The bundle is atomic. ``source_drafts`` returns the complete tuple or a typed
error, never a partial one — a half-published view is the state a reader cannot
tell from a truncated one, and there is no code for it because there is no way
to reach it.

Offsets are navigation, not identity. ``Evaluation.evidence_ids[offset]`` owns
each occurrence; the index says which offsets are source files so a reader opens
those and nothing else. That is what keeps the raw episode capture unreachable
through this channel even though it sits in the same bundle.
"""

from __future__ import annotations

from meta_evolve.domain import SourceTree
from meta_evolve.harness import HarnessArtifact
from meta_evolve.ports import EvidenceDraft

from diagnosis import artifact_digest
from source_decoding import harness_from_view
from source_schema import (
    ERROR_SCHEMA,
    FILE_SCHEMA,
    INDEX_SCHEMA,
    invalid_error,
    invalid_file,
    invalid_index,
)
from source_view import (
    RENDERER,
    SOURCE_LIMITS,
    SOURCE_PATHS,
    SourceViewError,
    canonical_view,
    file_bytes,
    file_digest,
    oversized,
    view_digest,
)


UNAVAILABLE = "canonical harness source view is unavailable"
UNDIGESTIBLE = "harness artifact has no shipped digest"


def shipped_digest(artifact: HarnessArtifact) -> str | None:
    """The digest the kernel commits for this manifest, or ``None`` if it has none.

    Total where ``artifact_digest`` is not. Every draft this module builds — and
    every diagnosis draft beside them — declares this digest, so an artifact
    that cannot produce one cannot be described at all. That is not a gap: the
    kernel digests each candidate payload at proposal completion, so an artifact
    with no digest never commits, never gets an occurrence, and can therefore
    never be the subject of a record a later proposal searches for.

    The evaluator is a plain callable a test or a driver may hand anything
    constructible, so it must say that rather than raise it.
    """

    try:
        return artifact_digest(artifact)
    except ValueError:
        # UnicodeEncodeError is a ValueError: a surface value that is not
        # encodable UTF-8 fails in the shipped codec, which is exactly the
        # failure that stops such a candidate from ever becoming an artifact.
        return None


def verified_view(artifact: HarnessArtifact) -> SourceTree | SourceViewError:
    """Build, bound, and then read back a view before anything publishes it.

    ``harness/export.py`` reconstructs and compares digests before placing an
    export, for the same reason. Without this a producer defect ships a bundle
    only the *consumer* can reject, which reports an evaluator bug as an
    unreadable prior view and refuses every later proposal in the run.
    """

    view = canonical_view(artifact)
    if isinstance(view, SourceViewError):
        return view
    if oversized(view):
        return SourceViewError("view-too-large")
    reconstructed = harness_from_view(view)
    if not isinstance(reconstructed, HarnessArtifact):
        return SourceViewError("view-not-reconstructible")
    if artifact_digest(reconstructed) != artifact_digest(artifact):
        return SourceViewError("view-not-reconstructible")
    return view


def _checked(kind: str, data: dict, invalid) -> EvidenceDraft:
    """Refuse to publish a draft this example's own reader would reject.

    It raises rather than asserts. ``-O`` strips an assertion, and this is the
    one defect whose cost is paid entirely at the far end of a run.
    """

    reason = invalid(data)
    if reason is not None:
        raise AssertionError(f"source evidence draft is invalid: {reason}")
    return EvidenceDraft(kind=kind, data=data)


def source_drafts(
    artifact: HarnessArtifact, split: str
) -> tuple[EvidenceDraft, ...] | SourceViewError:
    """The complete index-and-files bundle, or why there is no view at all."""

    view = verified_view(artifact)
    if isinstance(view, SourceViewError):
        return view
    digest = artifact_digest(artifact)
    identity = view_digest(view)
    index = _checked(
        INDEX_SCHEMA,
        {
            "schema": INDEX_SCHEMA,
            "split": split,
            "artifact_digest": digest,
            "view_digest": identity,
            "renderer": RENDERER,
            "paths": tuple(
                {
                    "path": path,
                    "offset": position + 1,
                    "bytes": file_bytes(view[path]),
                    "digest": file_digest(view[path]),
                }
                for position, path in enumerate(SOURCE_PATHS)
            ),
            "limits": SOURCE_LIMITS,
        },
        invalid_index,
    )
    files = tuple(
        _checked(
            FILE_SCHEMA,
            {
                "schema": FILE_SCHEMA,
                "path": path,
                "content": view[path],
                "bytes": file_bytes(view[path]),
                "digest": file_digest(view[path]),
                "artifact_digest": digest,
                "view_digest": identity,
            },
            invalid_file,
        )
        for path in SOURCE_PATHS
    )
    return (index, *files)


def error_draft(
    artifact: HarnessArtifact, split: str, code: str
) -> EvidenceDraft:
    """The whole of what an evaluator says when it has no view to publish.

    No path, no partial digest list, no content, no rejected value. It declares
    the artifact digest it *would* have described, which is what lets a reader
    tie the absence to the attempt it belongs to without reopening the channel.
    """

    return _checked(
        ERROR_SCHEMA,
        {
            "schema": ERROR_SCHEMA,
            "split": split,
            "artifact_digest": artifact_digest(artifact),
            "code": code,
        },
        invalid_error,
    )


__all__ = [
    "UNAVAILABLE",
    "UNDIGESTIBLE",
    "error_draft",
    "shipped_digest",
    "source_drafts",
    "verified_view",
]
