"""The development episodes and the evaluator wrapper built on them.

Loaded before search: nothing here imports or declares the private/held-out
split, so building the development side alone never pulls the later one in.
That includes its *declared identity* — :data:`CONFIGURATION` is computed from
this split's own membership through :mod:`evaluation_core`, so the trusted
outer process can register and version the development evaluator without any
private or held-out episode having been constructed yet.
"""

from __future__ import annotations

from meta_evolve.ports import EvaluationResult

import evaluation_core
from evaluation_core import _episode


DEVELOPMENT_EPISODES = (
    _episode(
        "repair-increment",
        "Repair increment(value) while preserving its interface.",
        {"math_ops.py": "def increment(value):\n    return value - 1\n"},
        "from math_ops import increment\nraise SystemExit(0 if increment(3) == 4 else 1)\n",
    ),
    _episode(
        "repair-normalize",
        "Repair normalize(text) while preserving its interface.",
        {"normalize.py": "def normalize(text):\n    return text.strip()\n"},
        "from normalize import normalize\nraise SystemExit(0 if normalize(' A ') == 'a' else 1)\n",
    ),
)

DEVELOPMENT_MEMBERSHIP_DIGEST = evaluation_core.membership_digest(
    DEVELOPMENT_EPISODES
)

# The one configuration the development evaluator is registered at. Built here
# rather than by the caller so there is exactly one answer to "what is this
# evaluator", and it is reachable without the later splits.
CONFIGURATION = evaluation_core.evaluator_configuration(
    "development", DEVELOPMENT_EPISODES
)


def evaluate_development(artifact: object) -> EvaluationResult:
    return evaluation_core._evaluate(artifact, DEVELOPMENT_EPISODES, "development")


__all__ = [
    "CONFIGURATION",
    "DEVELOPMENT_EPISODES",
    "DEVELOPMENT_MEMBERSHIP_DIGEST",
    "evaluate_development",
]
