"""Replaying the private phase: the candidate set, the stores, the rule.

Three checks that only make sense together. The candidate set must be exactly
the development run's rankable occurrences -- no fewer, no more, no resurrected
refusal. Every recorded measurement must be supported by the store its
write-ahead plan promised, reopened read-only. And the selection rule, re-run
over those measurements, must reach the same winner the decision names.

The middle one is what the other two cannot do alone: re-running the rule over
the numbers *in* the record catches a record inconsistent with itself, and
catches nothing at all about a record whose evidence has been moved or was
never what it claims.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import RunId

import decision_sections
import phase_plans
import private_selection

from replay_failure import ReplayFailure


def verify_candidate_set(
    development_run: meta.Run, decision: dict[str, object]
) -> None:
    """The decision's private runs cover exactly the rankable occurrences,
    each named once — no fewer, no more, no resurrected refusal."""

    rankable_ids = {
        item.id.value
        for item in private_selection.rankable_candidates(development_run)
    }
    recorded_ids = [item["source_trial_id"] for item in decision["private_runs"]]
    if set(recorded_ids) != rankable_ids:
        raise ReplayFailure(
            "recorded private runs do not match the rankable candidate set: "
            f"recorded={sorted(recorded_ids)} rankable={sorted(rankable_ids)}"
        )
    if len(recorded_ids) != len(set(recorded_ids)):
        raise ReplayFailure("a development occurrence has more than one private run")
    expected = decision_sections.development_occurrences(
        development_run, frozenset(rankable_ids)
    )
    if decision["development_occurrences"] != expected:
        raise ReplayFailure("development occurrences do not match committed trials")
    trials = {trial.id.value: trial for trial in development_run.trials()}
    for row in decision["private_runs"]:
        trial = trials[row["source_trial_id"]]
        if (
            row["source_artifact_id"] != trial.artifact.id.value
            or row["source_logical_step"] != trial.logical_step
        ):
            raise ReplayFailure("private measurement names a different source occurrence")
    selection = decision["selection"]
    selected = trials.get(selection["selected_trial_id"])
    expected_artifact = (
        selected.artifact.id.value if selected is not None and selected.artifact else None
    )
    if selection["selected_artifact_id"] != expected_artifact:
        raise ReplayFailure("selection names a different development artifact")


@dataclass(frozen=True, slots=True)
class _ReplayedOccurrence:
    id: str
    logical_step: int


@dataclass(frozen=True, slots=True)
class _ReplayedPrivateRun:
    occurrence: _ReplayedOccurrence
    quality: float


def verify_selection(decision: dict[str, object]) -> None:
    """Re-execute the declared selection rule over the retained measurements.

    No evaluation is re-run: the private quality values are already committed
    in ``decision["private_runs"]``. This recomputes ``private_selection.
    select`` over them directly and requires it agree with what was sealed —
    the same total rule, over the same retained numbers, is what makes a
    hand-edited or tampered decision record detectable.
    """

    steps_by_trial = {
        item["trial_id"]: item["logical_step"]
        for item in decision["development_occurrences"]
    }
    ranked = tuple(
        _ReplayedPrivateRun(
            occurrence=_ReplayedOccurrence(
                id=item["source_trial_id"],
                logical_step=steps_by_trial[item["source_trial_id"]],
            ),
            quality=item["quality"],
        )
        for item in decision["private_runs"]
        if item["rankable"]
    )
    recomputed = private_selection.select(ranked)
    selected_id = decision["selection"]["selected_trial_id"]
    if recomputed is None:
        if selected_id is not None:
            raise ReplayFailure(
                f"the selection rule recomputes no winner, but the decision "
                f"names {selected_id!r}"
            )
        return
    if recomputed.occurrence.id != selected_id:
        raise ReplayFailure(
            f"the selection rule recomputes {recomputed.occurrence.id!r}, but "
            f"the decision names {selected_id!r}"
        )


def reopen_private(
    root: Path,
    decision: dict[str, object],
    development_run: meta.Run,
    registry: meta.Registry | None = None,
) -> tuple[meta.Run, ...]:
    """Every private run the decision names, reopened where its plan put it.

    The check the recorded numbers cannot make about themselves. ``verify_
    selection`` re-runs the selection rule over the qualities *in the
    decision*, which catches a decision inconsistent with itself but not a
    decision whose private measurements are gone or were never what it says.
    This opens each store the write-ahead plan promised, at the run id the
    decision names, and requires the committed final evaluation agree with
    the recorded row -- rankability and exact quality both.

    A store that has been moved, deleted, or emptied fails here rather than
    replaying successfully against a directory that no longer holds the
    evidence.
    """

    plan = phase_plans.locate(phase_plans.private_plan_path(root))
    if plan is None:
        raise ReplayFailure(f"no private plan found under {root}")
    stores = {item["trial_id"]: item["store"] for item in plan["occurrences"]}
    sources = {trial.id.value: trial.artifact for trial in development_run.trials()}
    reopened = []
    for record in decision["private_runs"]:
        trial_id = record["source_trial_id"]
        store = stores.get(trial_id)
        if store is None:
            raise ReplayFailure(
                f"the private plan names no store for occurrence {trial_id!r}"
            )
        directory = root / store
        if not directory.is_dir():
            raise ReplayFailure(f"the planned private store is missing: {directory}")
        try:
            run = meta.Run(
                RunId(record["private_run_id"]),
                meta.Storage.read_only(directory),
                registry=registry,
            )
            final = run.trials()[-1]
        except Exception as error:  # noqa: BLE001 - any unreadable store is a failure
            raise ReplayFailure(
                f"the private run recorded for {trial_id!r} cannot be reopened "
                f"from {directory}: {type(error).__name__}"
            ) from error
        if (
            len(run.trials()) != 1
            or run.inspect().declaration.seed.value != sources[trial_id].value
        ):
            raise ReplayFailure("private run did not evaluate its source artifact seed-only")
        rankable = final.state == "evaluated" and "quality" in final.metrics
        if rankable != bool(record["rankable"]):
            raise ReplayFailure(
                f"the private run for {trial_id!r} is "
                f"{'rankable' if rankable else 'unrankable'} on disk, but the "
                f"decision records the opposite"
            )
        if rankable and float(final.metrics["quality"]) != record["quality"]:
            raise ReplayFailure(
                f"the private run for {trial_id!r} committed quality "
                f"{float(final.metrics['quality'])!r}, but the decision records "
                f"{record['quality']!r}"
            )
        reopened.append(run)
    if set(stores) != {item["source_trial_id"] for item in decision["private_runs"]}:
        raise ReplayFailure(
            "the private plan and the decision's private runs name different "
            f"occurrences: planned={sorted(stores)} "
            f"recorded={sorted(item['source_trial_id'] for item in decision['private_runs'])}"
        )
    return tuple(reopened)


__all__ = [
    "reopen_private",
    "verify_candidate_set",
    "verify_selection",
]
