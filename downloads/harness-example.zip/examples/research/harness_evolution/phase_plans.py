"""Immutable write-ahead phase plans for private selection and held-out.

The private plan is written, atomically, before any private run begins —
mapping every rankable occurrence to the deterministic store its private run
will use, keyed on logical step and trial id so a resume never has to
re-derive occurrence identity from a development run that could itself be
re-read differently. A resume that finds this plan already sealed knows
exactly which occurrences were meant to run and where each one's store
lives.

The held-out plan is written only after selection completes: either an
execute plan naming both roles and their deterministic stores, or a sealed
skip plan with empty roles when nothing was selected. A skip plan is a
decision record, not unstarted work — resume and replay must never schedule
a held-out run after finding one, and a corrupt or inconsistent plan refuses
rather than guessing which case it was meant to be.
"""

from __future__ import annotations

import json
import os
from pathlib import Path


PRIVATE_PLAN_SCHEMA = "harness-private-plan/v1"
HELD_OUT_PLAN_SCHEMA = "harness-held-out-plan/v1"
HELD_OUT_ROLES = ("baseline", "candidate")

# Why a held-out plan was sealed as a skip, from a closed set. A skip is a
# decision, and a decision with no stated reason is indistinguishable from
# work that was never scheduled -- which is exactly the reading resume and
# replay must not be able to make. Closed rather than free text so a new
# reason has to be declared here before it can be sealed anywhere.
NO_RANKABLE_PRIVATE_OUTCOME = "no-rankable-private-outcome"
SKIP_REASONS = frozenset({NO_RANKABLE_PRIVATE_OUTCOME})


class PlanConflict(Exception):
    """A plan already sealed at this path does not match what was proposed.

    Raised rather than overwritten: a write-ahead plan exists so resume can
    trust it, and a caller that silently replaced a conflicting plan would
    make that trust worthless.
    """


def private_store(logical_step: int, trial_id: str) -> str:
    """The deterministic, root-relative store for one occurrence's private run.

    Keyed on step and trial id — not on artifact digest — so two duplicate-
    content occurrences (distinct trials, equal bytes) still get distinct
    stores, matching the rule that duplicate content stays distinct
    everywhere else in this example.
    """

    return f"private/step-{logical_step:04d}-{trial_id}"


def held_out_store(role: str) -> str:
    if role not in HELD_OUT_ROLES:
        raise ValueError(f"held-out role must be one of {HELD_OUT_ROLES}, got {role!r}")
    return f"{role}-held-out"


def _atomic_write_json(path: Path, payload: dict) -> None:
    """Write-then-rename: readers never observe a partially written file.

    ``os.replace`` is atomic on the same filesystem, which is why the
    temporary file is created as a sibling of the destination rather than
    under a shared system temporary directory.
    """

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(
        json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    os.replace(tmp, path)


def canonical(payload: dict) -> dict:
    """The payload as it will exist once sealed: JSON, and nothing else.

    A sealed plan lives as JSON, and JSON has no tuple. A payload built in
    memory can therefore be *equal* to a sealed one in every way that matters
    and still compare unequal to it, because one side holds ``(2.0, 2.0)``
    where the other holds ``[2.0, 2.0]``. Normalizing both sides through the
    same encoding is what makes "reseal an identical plan" mean identical
    *content* rather than identical Python types -- without it, a resume that
    recomputed exactly the right plan would raise :class:`PlanConflict`
    against its own earlier self the moment any field held a sequence.
    """

    return json.loads(json.dumps(payload, sort_keys=True))


def locate(path: Path) -> dict | None:
    """The plan already sealed at ``path``, or ``None`` if there is none."""

    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def seal(path: Path, payload: dict) -> dict:
    """Seal ``payload`` at ``path``, atomically — or reseal an identical one.

    A resume that recomputes the exact same plan finds it already there and
    gets it back unchanged; a resume (or a bug) that would write something
    different raises :class:`PlanConflict` instead of silently diverging
    from a decision already sealed.
    """

    proposed = canonical(payload)
    existing = locate(path)
    if existing is not None:
        if existing != proposed:
            raise PlanConflict(
                f"a different plan is already sealed at {path}: "
                f"sealed={existing!r} proposed={proposed!r}"
            )
        return existing
    _atomic_write_json(path, proposed)
    return proposed


def private_plan_path(root: Path) -> Path:
    return root / "private-plan.json"


def held_out_plan_path(root: Path) -> Path:
    return root / "held-out-plan.json"


def build_private_plan(
    development_run_id: str, occurrences: tuple
) -> dict[str, object]:
    """The private plan payload for every rankable development occurrence."""

    return {
        "schema": PRIVATE_PLAN_SCHEMA,
        "development_run_id": development_run_id,
        "occurrences": [
            {
                "trial_id": item.id.value,
                "artifact_id": item.artifact.id.value,
                "logical_step": item.logical_step,
                "store": private_store(item.logical_step, item.id.value),
            }
            for item in occurrences
        ],
    }


def build_held_out_plan(
    selected: object | None, *, reason: str = NO_RANKABLE_PRIVATE_OUTCOME
) -> dict[str, object]:
    """The held-out plan payload: an execute plan, or a sealed skip.

    ``selected`` is a :class:`private_selection.PrivateRun` or ``None`` —
    typed loosely here so this module does not need to import that one,
    keeping the write-ahead plan shape independent of the selection rule
    that produced it.

    A skip carries its typed ``reason``; an execute plan carries ``None``,
    because there is nothing to explain about work that went ahead.
    """

    if selected is None:
        if reason not in SKIP_REASONS:
            raise ValueError(
                f"a skipped held-out plan must state one of {sorted(SKIP_REASONS)}, "
                f"got {reason!r}"
            )
        return {
            "schema": HELD_OUT_PLAN_SCHEMA,
            "status": "skipped",
            "reason": reason,
            "selected_trial_id": None,
            "selected_artifact_id": None,
            "roles": [],
            "stores": {},
        }
    return {
        "schema": HELD_OUT_PLAN_SCHEMA,
        "status": "executed",
        "reason": None,
        "selected_trial_id": selected.occurrence.id.value,
        "selected_artifact_id": selected.occurrence.artifact.id.value,
        "roles": list(HELD_OUT_ROLES),
        "stores": {role: held_out_store(role) for role in HELD_OUT_ROLES},
    }


__all__ = [
    "HELD_OUT_PLAN_SCHEMA",
    "HELD_OUT_ROLES",
    "NO_RANKABLE_PRIVATE_OUTCOME",
    "PRIVATE_PLAN_SCHEMA",
    "SKIP_REASONS",
    "PlanConflict",
    "build_held_out_plan",
    "build_private_plan",
    "canonical",
    "held_out_plan_path",
    "held_out_store",
    "locate",
    "private_plan_path",
    "private_store",
    "seal",
]
