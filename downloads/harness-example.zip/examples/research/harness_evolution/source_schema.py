"""The three source evidence schemas, and total validators for each.

Every validator here answers one question — may this payload be *read* as what
it claims to be — and answers it about a payload nothing in this process wrote.
So each is total, checks the whole closed shape rather than the fields it goes
on to index, and returns a constant reason. Constant because a reason travels
into a typed proposer failure, and typed failures are selected whole by the
governed policy: echoing an offending value there would reopen the channel the
refusal closes.

The producer runs them too, against the drafts it is about to publish. A draft
the reader would reject is the one defect that costs a whole run — it is only
detectable at the far end, where it reports an evaluator bug as an unreadable
prior view and refuses every later proposal.

Offsets are checked as a *relation*, not as literals. Each entry must sit at
``position + 1`` and name ``SOURCE_PATHS[position]``, because that relation is
real information the reader consumes: it says which of the evaluation's own
evidence ids to open, and in what order. Pinning ``1, 2, 3`` instead would make
the field the kind of self-asserted redundancy these schemas reject elsewhere.
"""

from __future__ import annotations

from collections.abc import Mapping

from source_view import (
    MANIFEST_PATH,
    POLICY_PATH,
    RENDERER,
    SOURCE_LIMITS,
    SOURCE_PATHS,
    VIEW_ERROR_CODES,
    encodable,
    exceeds_depth,
    file_digest,
)


INDEX_SCHEMA = "harness-source-index/v1"
FILE_SCHEMA = "harness-source-file/v1"
ERROR_SCHEMA = "harness-source-error/v1"
DEVELOPMENT = "development"

_INDEX_FIELDS = frozenset(
    {"schema", "split", "artifact_digest", "view_digest", "renderer", "paths", "limits"}
)
_ENTRY_FIELDS = frozenset({"path", "offset", "bytes", "digest"})
_FILE_FIELDS = frozenset(
    {"schema", "path", "content", "bytes", "digest", "artifact_digest", "view_digest"}
)
_ERROR_FIELDS = frozenset({"schema", "split", "artifact_digest", "code"})


def _is_digest(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _is_count(value: object) -> bool:
    """A byte length or an offset: a real non-negative integer, never a bool."""

    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def _invalid_entry(entry: object, position: int) -> str | None:
    if not isinstance(entry, Mapping) or set(entry) != _ENTRY_FIELDS:
        return "source index entry fields do not match the schema"
    if entry["path"] != SOURCE_PATHS[position]:
        return "source index does not name the declared paths in order"
    if not _is_count(entry["offset"]) or entry["offset"] != position + 1:
        return "source index offsets are not contiguous from the header"
    if not _is_count(entry["bytes"]):
        return "source index byte length is not a non-negative integer"
    if entry["bytes"] > SOURCE_LIMITS["files"][SOURCE_PATHS[position]]:
        return "source index declares a file over its own limit"
    if not _is_digest(entry["digest"]):
        return "source index file digest is malformed"
    return None


def _invalid_limits(value: object) -> str | None:
    if not isinstance(value, Mapping) or set(value) != {"files", "view", "depth"}:
        return "source index limit fields do not match the schema"
    files = value["files"]
    if not isinstance(files, Mapping) or dict(files) != SOURCE_LIMITS["files"]:
        return "source index declares other per-file limits"
    if value["view"] != SOURCE_LIMITS["view"]:
        return "source index declares another view limit"
    if value["depth"] != SOURCE_LIMITS["depth"]:
        return "source index declares another nesting limit"
    return None


def invalid_index(data: object) -> str | None:
    """Say why a payload may not be read as a source index, or ``None``."""

    if not isinstance(data, Mapping) or set(data) != _INDEX_FIELDS:
        return "source index fields do not match the schema"
    if data["schema"] != INDEX_SCHEMA:
        return "source index names another schema"
    if data["split"] != DEVELOPMENT:
        return "source index is not from the development split"
    if not _is_digest(data["artifact_digest"]):
        return "source index artifact digest is malformed"
    if not _is_digest(data["view_digest"]):
        return "source index view digest is malformed"
    if data["renderer"] != RENDERER:
        return "source index names another renderer"
    paths = data["paths"]
    if not isinstance(paths, tuple) or len(paths) != len(SOURCE_PATHS):
        return "source index does not name every declared path once"
    for position, entry in enumerate(paths):
        invalid = _invalid_entry(entry, position)
        if invalid is not None:
            return invalid
    if sum(entry["bytes"] for entry in paths) > SOURCE_LIMITS["view"]:
        return "source index declares a view over its own limit"
    return _invalid_limits(data["limits"])


def invalid_file(data: object) -> str | None:
    """Say why a payload may not be read as one source file, or ``None``.

    The byte length and digest are recomputed from the content rather than
    trusted, so a file that agrees with itself but not with its own bytes is
    refused here rather than at reassembly.
    """

    if not isinstance(data, Mapping) or set(data) != _FILE_FIELDS:
        return "source file fields do not match the schema"
    if data["schema"] != FILE_SCHEMA:
        return "source file names another schema"
    if data["path"] not in SOURCE_PATHS:
        return "source file names an undeclared path"
    content = data["content"]
    if not isinstance(content, str):
        return "source file content is not text"
    # Before any byte length or digest, because both begin with this encode and
    # a validator that raises on hostile input is not a validator.
    if not encodable(content):
        return "source file content is not encodable UTF-8"
    if not _is_count(data["bytes"]) or data["bytes"] != len(content.encode("utf-8")):
        return "source file byte length does not match its content"
    if data["digest"] != file_digest(content):
        return "source file digest does not match its content"
    # Before anything parses it. A file under every byte limit can still nest
    # deeply enough to exhaust the stack in json.loads, in the canonical
    # re-encode, and in FrozenMap.
    if data["path"] in (MANIFEST_PATH, POLICY_PATH) and exceeds_depth(content):
        return "source file nests deeper than the declared limit"
    if not _is_digest(data["artifact_digest"]) or not _is_digest(data["view_digest"]):
        return "source file enclosing digests are malformed"
    return None


def invalid_error(data: object) -> str | None:
    """Say why a payload may not be read as a source error header, or ``None``.

    This is the reader's *only* absence, so it is validated exactly as strictly
    as a success: an evaluator saying "no view exists here" is a claim, and a
    malformed claim is an inconsistency rather than a quieter absence.
    """

    if not isinstance(data, Mapping) or set(data) != _ERROR_FIELDS:
        return "source error fields do not match the schema"
    if data["schema"] != ERROR_SCHEMA:
        return "source error names another schema"
    if data["split"] != DEVELOPMENT:
        return "source error is not from the development split"
    if not _is_digest(data["artifact_digest"]):
        return "source error artifact digest is malformed"
    if not isinstance(data["code"], str) or data["code"] not in VIEW_ERROR_CODES:
        return "source error names an undeclared code"
    return None


__all__ = [
    "DEVELOPMENT",
    "ERROR_SCHEMA",
    "FILE_SCHEMA",
    "INDEX_SCHEMA",
    "invalid_error",
    "invalid_file",
    "invalid_index",
]
