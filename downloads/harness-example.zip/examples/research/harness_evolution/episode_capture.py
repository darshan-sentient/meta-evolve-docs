"""Reducing one finished inner episode run to the raw capture it publishes.

Separate from :mod:`evaluation`, which orchestrates. What lives here turns a
completed inner ``meta.Run`` into the ``episode-capture`` evidence the outer
evaluation carries: every attempt, its typed failure, its process diagnostics,
the source diff, and the inner counts.

This is the *unredacted* channel, and it stays that way on purpose. The governed
diagnosis beside it is built by :mod:`diagnosis` from what the verifier itself
observed, and the context policy selects that one and never this one — so the
capture can hold grader output without any of it becoming a later proposal's
evidence.
"""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.domain import Failure, FrozenMap, SourceTree
from meta_evolve.ports import EvidenceDraft


def _failure(value: Failure | None) -> object:
    if value is None:
        return None
    return {"kind": value.kind, "message": value.message, "details": value.details}


def _diff(before: SourceTree, after: SourceTree) -> FrozenMap:
    paths = sorted(set(before) | set(after))
    return FrozenMap(
        {
            path: {"before": before.get(path), "after": after.get(path)}
            for path in paths
            if before.get(path) != after.get(path)
        }
    )


def captured(run: meta.Run, episode: harness.RepositoryEpisode) -> dict[str, object]:
    attempts: list[dict[str, object]] = []
    for trial in run.trials():
        value = trial.artifact.value if trial.artifact is not None else None
        attempts.append(
            {
                "step": trial.logical_step,
                "state": trial.state,
                "source": value.to_payload() if isinstance(value, SourceTree) else None,
                "metrics": trial.metrics,
                "failure": _failure(trial.failure),
                "diagnostics": tuple(
                    {"kind": item.kind, "data": item.data} for item in trial.evidence
                ),
            }
        )
    final = run.trials()[-1]
    final_source = final.artifact.value if final.artifact is not None else episode.source
    run_usage = run.usage()
    return {
        "name": episode.name,
        "attempts": tuple(attempts),
        "diff": _diff(episode.source, final_source),
        "inner_counts": {
            "evaluations": run_usage.evaluations,
            "trials": run_usage.trials,
        },
    }


def capture_draft(split: str, captures: list[dict[str, object]]) -> EvidenceDraft:
    return EvidenceDraft(
        kind="episode-capture",
        data={"split": split, "episodes": tuple(captures)},
    )


__all__ = ["capture_draft", "captured"]
