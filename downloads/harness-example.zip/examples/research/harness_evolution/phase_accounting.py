"""Per-phase accounting, derived from durable records alone.

Every number here is read back from committed run state (:meth:`meta.Run.usage`,
:meth:`meta.Run.experience_usage`, and the evidence each trial committed)
rather than accumulated by this module as the runs happen — no
hand-maintained total is accepted as evidence. That is why the provider-call,
inner-episode, source-byte, and citation totals below are recomputed from
evidence payloads instead of being counted at the call site: a total the
producer reported about itself cannot detect the producer having under-
reported.

Private and held-out phases account for zero pushed context and zero pull
experience *structurally*: neither phase's ``meta.Experiment`` declares a
context policy or grants experience access, so the zero here is a property of
what was built, not merely what was observed this run.

The two ``*_chars`` fields are measured, not exact. The kernel renders a
pulled record by serializing the whole record, and an evaluation record
carries its own measured ``usage.wall_seconds``, so the byte length of that
text moves between otherwise-identical runs. They are computed here (a phase's
accounting would be incomplete without them) and retained by
:mod:`observations` rather than by the decision record — see that module's
own docstring for the full reason, and ``decision_record._accounting_entry``
for what is therefore excluded from decision identity.
"""

from __future__ import annotations

from dataclasses import dataclass

import meta_evolve as meta

import accounting_evidence
from accounting_evidence import (  # noqa: F401
    CALL_EVIDENCE_KIND,
    CAPTURE_EVIDENCE_KIND,
)


@dataclass(frozen=True, slots=True)
class PhaseAccounting:
    """One phase's exact accounting: what it spent, ran, read, and cited."""

    phase: str
    # Outer run counts, as the kernel committed them.
    evaluations: int
    trials: int
    tokens: int
    spend_micros: int
    wall_seconds: float
    # Pushed context and pulled source, as the kernel accounted for them.
    context_records: int
    context_chars: int
    pull_operations: int
    pull_results: int
    pull_records: int
    pull_chars: int
    # One row per actual provider call the phase's proposals retained.
    provider_calls: int
    call_input_tokens: int
    call_output_tokens: int
    call_total_tokens: int
    call_remainder_tokens: int
    call_spend_micros: int
    # The inner improvement episodes each outer evaluation ran.
    inner_episodes: int
    inner_attempts: int
    inner_evaluations: int
    inner_trials: int
    # The audited source channel, measured from the records returned by successful opens.
    source_indexes: int
    source_files: int
    source_errors: int
    source_bytes: int
    # References the phase's proposals actually declared they derived from.
    citations_admitted: int


def _sum_usage(runs: tuple[meta.Run, ...]) -> meta.Usage:
    total = meta.Usage()
    for run in runs:
        total += run.usage()
    return total


def for_runs(phase: str, *runs: meta.Run) -> PhaseAccounting:
    """Accounting for one or more runs sharing a phase, summed.

    Context and pull usage are read only from the *first* run: every run in
    a phase here shares one context/experience declaration (development has
    exactly one search run; private and held-out declare none at all), so
    summing them would double-count rather than aggregate. Everything else is
    genuinely per-run and is summed across all of them.
    """

    if not runs:
        raise ValueError("for_runs requires at least one run")
    usage = _sum_usage(runs)
    experience = runs[0].experience_usage()
    calls = accounting_evidence.calls(runs)
    episodes = accounting_evidence.episodes(runs)
    source = accounting_evidence.source(runs)
    return PhaseAccounting(
        phase=phase,
        evaluations=usage.evaluations,
        trials=usage.trials,
        tokens=usage.tokens,
        spend_micros=usage.spend_micros,
        wall_seconds=usage.wall_seconds,
        context_records=experience.context.records,
        context_chars=experience.context.chars,
        pull_operations=experience.pull.operations,
        pull_results=experience.pull.results,
        pull_records=experience.pull.records,
        pull_chars=experience.pull.chars,
        provider_calls=calls.count,
        call_input_tokens=calls.input_tokens,
        call_output_tokens=calls.output_tokens,
        call_total_tokens=calls.total_tokens,
        call_remainder_tokens=calls.remainder,
        call_spend_micros=calls.spend_micros,
        inner_episodes=episodes.episodes,
        inner_attempts=episodes.attempts,
        inner_evaluations=episodes.evaluations,
        inner_trials=episodes.trials,
        source_indexes=source.indexes,
        source_files=source.files,
        source_errors=source.errors,
        source_bytes=source.total_bytes,
        citations_admitted=accounting_evidence.citations(runs),
    )


def verify_zero_context_and_pull(accounting: PhaseAccounting) -> None:
    """Private and held-out must account for zero pushed context and pull.

    A structural property of what was built, checked rather than assumed:
    if a future change ever gave either phase a context policy or experience
    grant, this fails loudly instead of silently reporting activity the
    issue requires stay at zero.
    """

    zero_fields = (
        "context_records",
        "context_chars",
        "pull_operations",
        "pull_results",
        "pull_records",
        "pull_chars",
        "source_indexes",
        "source_files",
        "citations_admitted",
    )
    nonzero = {
        name: getattr(accounting, name)
        for name in zero_fields
        if getattr(accounting, name) != 0
    }
    if nonzero:
        raise ValueError(
            f"{accounting.phase} phase must account for zero pushed context "
            f"and zero pull experience, found: {nonzero}"
        )


def verify_candidate_set_cardinality(
    accounting: PhaseAccounting, expected_count: int
) -> None:
    """Private evaluations must equal exactly the candidate set count —
    one seed-only evaluation per occurrence, no fewer, no more."""

    if accounting.evaluations != expected_count:
        raise ValueError(
            f"{accounting.phase} phase recorded {accounting.evaluations} "
            f"evaluations, but the candidate set has {expected_count}"
        )


def verify_inner_episodes(
    accounting: PhaseAccounting, per_evaluation: int, *, rankable_evaluations: int
) -> None:
    """Bound the inner episode count from both sides. The check the outer
    evaluation count alone cannot make: an evaluator that silently graded on
    fewer episodes than its split declares would still report one evaluation.

    Two bounds rather than an equality, because both are exactly true while
    an equality is not. No evaluation may run *more* than its split's
    episodes, so ``evaluations * per_evaluation`` is a ceiling. Every
    evaluation that finished rankably must have run *all* of them -- a mean
    score over the split cannot exist until each episode has been graded -- so
    ``rankable_evaluations * per_evaluation`` is a floor. An evaluation that
    refused before any episode ran, or failed partway through one, lands
    honestly between them instead of failing a check it was never violating.
    """

    ceiling = accounting.evaluations * per_evaluation
    floor = rankable_evaluations * per_evaluation
    if not floor <= accounting.inner_episodes <= ceiling:
        raise ValueError(
            f"{accounting.phase} phase ran {accounting.inner_episodes} inner "
            f"episodes; its split declares {per_evaluation} per evaluation, so "
            f"{accounting.evaluations} evaluations ({rankable_evaluations} of "
            f"them rankable) permit between {floor} and {ceiling}"
        )


def to_payload(accounting: PhaseAccounting, *, exclude: tuple[str, ...] = ()) -> dict:
    """This accounting as a plain mapping, minus any excluded field."""

    names = tuple(
        name for name in PhaseAccounting.__slots__ if name not in {"phase", *exclude}
    )
    return {name: getattr(accounting, name) for name in names}


__all__ = [
    "CALL_EVIDENCE_KIND",
    "CAPTURE_EVIDENCE_KIND",
    "PhaseAccounting",
    "for_runs",
    "to_payload",
    "verify_candidate_set_cardinality",
    "verify_inner_episodes",
    "verify_zero_context_and_pull",
]
