"""Reading a conformance verdict out of a measurement journal.

Pure functions over segments-as-data: nothing here measures anything, opens a
file, or knows where a journal lives. Separated from :mod:`observations`, which
does all three, because "what was measured" and "what that measurement lets you
claim" are different questions and only the second one is a judgement.

The vocabulary lives here for the same reason. ``unknown`` is not a third
outcome tacked onto a pass/fail pair -- it is the verdict an incomplete
measurement forces, and every rule below is written around the fact that it
outranks ``exceeded``: an overrun is something established, and an unmeasured
interval could still be either.
"""

from __future__ import annotations


PENDING = "pending"
COMPLETE = "complete"

CONFORMANT = "conformant"
EXCEEDED = "exceeded"
UNKNOWN = "unknown"


def conformance(elapsed: float | None, ceiling: float) -> str:
    """``"conformant"``, ``"exceeded"``, or ``"unknown"``.

    ``elapsed=None`` is the incomplete-measurement case: report unknown
    rather than inventing a pass, and never silently widen ``ceiling`` to
    make a real overrun disappear.
    """

    if elapsed is None:
        return UNKNOWN
    return CONFORMANT if elapsed <= ceiling else EXCEEDED


def label_conformance(
    segments: tuple[dict[str, object], ...], label: str
) -> dict[str, object]:
    """One unit of work's cumulative verdict across every attempt at it.

    Cumulative *per label*, not per phase, and the distinction is the whole
    point. A label is one logical piece of work -- one private run, one
    held-out role -- and its declared ceiling bounds that piece of work, so an
    attempt that was interrupted and an attempt that resumed it both spent
    time against the same bound and their measured intervals add. Two
    different labels in the same phase are independent runs with independent
    budgets, and adding *those* together would compare a sum against a bound
    that was never about the sum.

    Any pending attempt makes the label ``unknown``: the time that attempt
    consumed was never measured, so no total built without it can establish
    that the ceiling held, however fast the attempt that replaced it was.
    """

    mine = tuple(item for item in segments if item["label"] == label)
    ceilings = {item["declared_ceiling"] for item in mine}
    if len(ceilings) > 1:
        raise ValueError(
            f"label {label!r} recorded more than one declared ceiling: {ceilings}"
        )
    pending = tuple(item for item in mine if item["status"] != COMPLETE)
    measured_total = sum(
        float(item["elapsed_seconds"])
        for item in mine
        if item["elapsed_seconds"] is not None
    )
    ceiling = next(iter(ceilings)) if ceilings else None
    if not mine or pending:
        verdict = UNKNOWN
    else:
        verdict = conformance(measured_total, ceiling)
    return {
        "label": label,
        "attempts": len(mine),
        "unmeasured_attempts": len(pending),
        "measured_seconds": measured_total if mine else None,
        "declared_ceiling": ceiling,
        "conformance": verdict,
    }


def _worst(verdicts: tuple[str, ...]) -> str:
    """``unknown`` beats ``exceeded`` beats ``conformant``.

    Unknown outranks exceeded because it is the weaker claim, not the milder
    one: an overrun is something established, and an unmeasured interval is
    something that could be either.
    """

    if UNKNOWN in verdicts:
        return UNKNOWN
    if EXCEEDED in verdicts:
        return EXCEEDED
    return CONFORMANT


def phase_conformance(
    segments: tuple[dict[str, object], ...], phase: str
) -> dict[str, object]:
    """One phase's verdict: the worst of its labels', with nothing averaged.

    A phase holding one interrupted private run is not "mostly conformant" --
    it is a phase whose ceiling claim cannot be established. Reported with the
    per-label detail beside it so the reason is readable rather than inferred.
    """

    mine = tuple(item for item in segments if item["phase"] == phase)
    labels = tuple(dict.fromkeys(item["label"] for item in mine))
    per_label = tuple(label_conformance(mine, label) for label in labels)
    return {
        "phase": phase,
        "labels": per_label,
        "attempts": len(mine),
        "unmeasured_attempts": sum(
            int(item["unmeasured_attempts"]) for item in per_label
        ),
        "measured_seconds": (
            sum(float(item["measured_seconds"]) for item in per_label)
            if per_label
            else None
        ),
        "conformance": (
            _worst(tuple(str(item["conformance"]) for item in per_label))
            if per_label
            else UNKNOWN
        ),
    }


def conformance_report(
    segments: tuple[dict[str, object], ...], phases: tuple[str, ...]
) -> dict[str, dict[str, object]]:
    """Every declared phase's verdict, including phases that recorded none.

    A phase that recorded nothing at all is ``unknown`` rather than absent:
    "never measured" and "measured and fine" must not read the same.
    """

    return {phase: phase_conformance(segments, phase) for phase in phases}


def verify_complete_coverage(
    segments: tuple[dict[str, object], ...], phases: tuple[str, ...]
) -> None:
    """Every declared phase measured every label it opened. Raises if not."""

    report = conformance_report(segments, phases)
    unresolved = {
        phase: item["conformance"]
        for phase, item in report.items()
        if item["conformance"] != CONFORMANT
    }
    if unresolved:
        raise ValueError(
            f"phases without an established elapsed-time claim: {unresolved}"
        )


__all__ = [
    "COMPLETE",
    "CONFORMANT",
    "EXCEEDED",
    "PENDING",
    "UNKNOWN",
    "conformance",
    "conformance_report",
    "label_conformance",
    "phase_conformance",
    "verify_complete_coverage",
]
