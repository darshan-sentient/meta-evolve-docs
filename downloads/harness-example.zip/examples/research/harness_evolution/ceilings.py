"""Every declared ceiling this decision was made under, in one place.

The accounting beside it says what was *spent*; this says what the spending
was allowed to be. Both belong in the sealed decision, because "the phase
stayed inside its budget" is not a claim a reader can check against a total
alone — it needs the bound the total was compared to, as declared at the time,
not as re-read from whatever the constants happen to say later.

Everything here is a declaration, so everything here is deterministic. Nothing
measured enters: the elapsed-time ceilings are the *declared* ones, and what
was actually measured against them lives in :mod:`observations`.

Assembled from values the caller passes in rather than imported here, so this
module knows nothing about which episodes belong to which split — the same
reason :mod:`decision_record` does not.
"""

from __future__ import annotations

from collections.abc import Iterable

import meta_evolve as meta

import confinement_policy
import confined_responder
import proposal_retention
import source_view


CEILINGS_SCHEMA = "harness-declared-ceilings/v1"


def budget(value: meta.Budget) -> dict[str, object]:
    """One outer budget's four declared dimensions."""

    return {
        "evaluations": value.evaluations,
        "trials": value.trials,
        "tokens": value.tokens,
        "wall_seconds": value.wall_seconds,
    }


def pull_access(value: meta.PullAccess) -> dict[str, object]:
    """The audited reader's declared grant, including its char bound.

    ``max_chars`` belongs here even though the *measured* char total does
    not belong in the decision's accounting. A declared bound is a constant
    this example chose; the measured total against it is a number the kernel
    computed over text containing a measured wall time. Naming the bound and
    excluding the measurement is the whole distinction.
    """

    return {
        "max_operations": value.max_operations,
        "max_results": value.max_results,
        "max_records": value.max_records,
        "max_chars": value.max_chars,
    }


def process(specs: Iterable[meta.ProcessSpec]) -> dict[str, object]:
    """The declared per-process ceilings of one split's episodes, in order."""

    ordered = tuple(specs)
    return {
        "count": len(ordered),
        "timeout_seconds": tuple(item.timeout_seconds for item in ordered),
        "stdout_limits": tuple(item.stdout_limit for item in ordered),
        "stderr_limits": tuple(item.stderr_limit for item in ordered),
    }


def confined_child() -> dict[str, object]:
    """What bounds the confined proposer child, and what it is confined by.

    The policy name rather than the mechanism: which kernel facility a given
    host offers is a fact about the host, and folding it in would make this
    decision's own digest differ between macOS and Linux for a run that made
    the identical decision. That the boundary was enforced at all is not
    optional -- ``confinement_policy.launcher`` refuses rather than running
    unconfined -- so its presence needs no per-host flag here.
    """

    return {
        **confinement_policy.declaration(),
        "response_timeout_seconds": confined_responder.RESPONSE_TIMEOUT_SECONDS,
        "response_stdout_limit": confined_responder.RESPONSE_STDOUT_LIMIT,
        "response_stderr_limit": confined_responder.RESPONSE_STDERR_LIMIT,
        "denied_roots": ("repository", "output_root"),
    }


def build(
    *,
    search_budget: meta.Budget,
    private_budget: meta.Budget,
    held_out_budget: meta.Budget,
    inner_budget: meta.Budget,
    source_access: meta.PullAccess,
    episode_processes: dict[str, tuple[meta.ProcessSpec, ...]],
) -> dict[str, object]:
    """Every declared ceiling, as one deterministic payload."""

    return {
        "schema": CEILINGS_SCHEMA,
        "budgets": {
            "development": budget(search_budget),
            "private": budget(private_budget),
            "held_out": budget(held_out_budget),
            "inner_episode": budget(inner_budget),
        },
        "pull_access": pull_access(source_access),
        "processes": {
            split: process(specs) for split, specs in sorted(episode_processes.items())
        },
        "retained_raw_chars": proposal_retention.RAW_LIMIT,
        "source_view": source_view.SOURCE_LIMITS,
        "confined_child": confined_child(),
    }


__all__ = [
    "CEILINGS_SCHEMA",
    "budget",
    "build",
    "confined_child",
    "process",
    "pull_access",
]
