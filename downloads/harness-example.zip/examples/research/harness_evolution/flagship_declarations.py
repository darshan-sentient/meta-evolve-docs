"""What this flagship declares itself to be, before it does anything.

Constants only: which modules each component's behaviour is made of, what each
phase is allowed to spend, what the audited reader is granted, and the seed
harness the search starts from. Nothing here registers, runs, reads, or writes
-- so a reader asking "what are the bounds of this experiment" has one file to
read, and a change to any of them is a change to a declaration rather than a
change buried in orchestration.

``DEVELOPMENT_EVALUATION_MODULES`` stopping short of the later split is the one
declaration that is load-bearing rather than descriptive; its comment says why.
"""

from __future__ import annotations

from hashlib import sha256

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.domain import ComponentRef

import child_root as child_root_module
import confined_proposer as confined_proposer_module
import confined_responder as confined_responder_module
import confinement_landlock as confinement_landlock_module
import confinement_landlock_entry as confinement_landlock_entry_module
import confinement_policy as confinement_policy_module
import development_child as development_child_module
import diagnosis as diagnosis_module
import development_evaluation as development_evaluation_module
import episode_capture as episode_capture_module
import evaluation_core as evaluation_core_module
import evaluation_identity as evaluation_identity_module
import source_decoding as source_decoding_module
import source_evidence as source_evidence_module
import source_schema as source_schema_module
import source_view as source_view_module


def _version(configuration: object) -> str:
    """One component version, derived from everything that decides its behaviour."""

    return "1+" + sha256(repr(configuration).encode()).hexdigest()[:16]


# What every episode evaluator shares: execution, capture, and the evidence
# schemas each one publishes through.
SHARED_EVALUATION_MODULES = (
    evaluation_core_module,
    evaluation_identity_module,
    episode_capture_module,
    source_evidence_module,
    source_schema_module,
    source_decoding_module,
    source_view_module,
    diagnosis_module,
)

# The development evaluator's closure stops here. It deliberately does *not*
# name ``later_evaluation``: declaring a dependency means importing it, and
# importing it would construct the private and held-out episode membership
# during the pre-search build -- exactly the staging #227 requires stay
# ordered. ``_later_evaluation_modules`` below is the later side's own closure,
# computed only once that module is genuinely due to load.
DEVELOPMENT_EVALUATION_MODULES = (
    development_evaluation_module,
    *SHARED_EVALUATION_MODULES,
)


def _later_evaluation_modules(later_module) -> tuple[object, ...]:
    """The held-out/private closure: the later split, and the shared base.

    ``development_evaluation`` is in it because ``later_evaluation`` really
    imports it -- it is the one module that sees all three splits, and it has
    to, to enforce the cross-split name law.
    """

    return (
        later_module,
        development_evaluation_module,
        *SHARED_EVALUATION_MODULES,
    )

# The confined child boundary: the launcher, the mechanism it selects between,
# and every file child_root.py copies onto the child's own root. None of
# these are reachable by static import alone -- development_child.py and
# confinement_landlock_entry.py are launched by path, never imported -- so
# each is declared here explicitly, or editing one would leave this proposer
# claiming an identity it no longer has. The live driver deliberately does
# not share this closure; its own test asserts that as one named group.
CHILD_BOUNDARY_MODULES = (
    confined_proposer_module,
    confined_responder_module,
    child_root_module,
    development_child_module,
    confinement_policy_module,
    confinement_landlock_module,
    confinement_landlock_entry_module,
)


SEARCH_BUDGET = meta.Budget(
    evaluations=3, trials=2, tokens=100, wall_seconds=30
)
HELD_OUT_BUDGET = meta.Budget(
    evaluations=1, trials=0, tokens=40, wall_seconds=10
)
# Exactly what the audited pull costs, with nothing spare beyond one operation
# slot. One search plus four opens per prior evaluation reaches results=10 and
# records=10 at the second proposal, by design: one additional successful open
# must fail rather than widen a limit. max_chars is a measured bound over the
# worst case these schemas permit, not headroom — see the example README.
SOURCE_ACCESS = meta.PullAccess(
    max_operations=10,
    max_results=10,
    max_records=10,
    max_chars=512_000,
)

PLANNER = ComponentRef(role="planner", name="fixture-worker-planner", version="1")
CONTEXT = ComponentRef(
    role="context-policy", name="fixture-worker-context", version="1"
)
BASELINE = harness.HarnessArtifact(
    planner=harness.TextParam(
        "planner",
        PLANNER,
        "planner-text/v1",
        "Make a conservative change while preserving the interface.",
    ),
    context_policy=harness.PolicyParam(
        "context_policy",
        CONTEXT,
        "context-policy/v1",
        {"diagnostics": False},
    ),
)
