"""Serialize one request, launch the confined child, accept one bounded envelope.

Confinement is a prefix on the argv this launches through the sandbox adapter
already shipped for development episodes
(:class:`~meta_evolve.adapters.development_subprocess.DevelopmentSubprocessSandbox`)
— never a different runner. That is the same "prefixing rather than wrapping"
choice #198's own confinement made, for the same reason: the bounds, timeout,
and output ceilings stay the contract this example already declares.

Every way the child could fail to answer — no mechanism on this platform, the
process itself failing to spawn or capture, a nonzero exit, or stdout that is
not the declared JSON envelope — becomes one :class:`ConfinedResponderFailure`
with a closed set of codes. Nothing here ever falls back to running
unconfined, and nothing here reinterprets a malformed transport as a model
answering badly: those are different failures with different remedies, and
conflating them would let a broken launcher look like a model that misbehaved.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import meta_evolve as meta
from meta_evolve.adapters.development_subprocess import DevelopmentSubprocessSandbox
from meta_evolve.ports import ProcessSpec

import call_usage
import child_root
import confinement_policy
from fixture_responder import (
    FIXTURE_INPUT_TOKENS,
    FIXTURE_MODEL,
    FIXTURE_OUTPUT_TOKENS,
    FIXTURE_TOKENS,
)
from proposal_manifest import StructuredResponse


# The wire contract between this module and ``development_child.py``: a JSON
# object on stdout carrying either ``raw`` or ``error``, and never an exit code
# that means anything. Named so a change to it changes the proposer's declared
# identity -- both halves have to agree, and a silent disagreement is exactly
# the failure a version is for.
ENVELOPE_PROTOCOL = "confined-child-json-envelope/v1"

RESPONSE_TIMEOUT_SECONDS = 10.0
RESPONSE_STDOUT_LIMIT = 65_536
RESPONSE_STDERR_LIMIT = 65_536

_sandbox = DevelopmentSubprocessSandbox()


class ConfinedResponderFailure(Exception):
    """A closed, typed reason the confined child could not be asked or answered.

    ``confined_proposer.py`` maps every one of these codes onto a
    deterministic :class:`~meta_evolve.domain.ProposerFailure` — never onto
    model-manifest invalidity, which is a claim about what a model said
    rather than about whether it could be asked at all.
    """

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def respond(
    request: dict, *, output_root: Path | str | None = None
) -> StructuredResponse:
    """Answer one request through the confined child. Never runs unconfined."""

    workspace = child_root.materialize(request)
    try:
        try:
            prefix = confinement_policy.launcher(
                workspace.root, output_root=output_root
            )
        except confinement_policy.ConfinementUnavailable as error:
            raise ConfinedResponderFailure(
                "confinement-unavailable", str(error)
            ) from error
        spec = ProcessSpec(
            argv=(*prefix, sys.executable, "development_child.py"),
            cwd=".",
            environment={},
            timeout_seconds=RESPONSE_TIMEOUT_SECONDS,
            stdout_limit=RESPONSE_STDOUT_LIMIT,
            stderr_limit=RESPONSE_STDERR_LIMIT,
        )
        result = _sandbox.run(spec, workspace)
        if result.failure is not None:
            raise ConfinedResponderFailure(
                "process-failed",
                f"{type(result.failure).__name__}: {result.failure.message}",
            )
        if result.exit_code != 0:
            raise ConfinedResponderFailure(
                "child-nonzero",
                f"confined child exited {result.exit_code}: "
                f"{result.stderr.strip()[:400]}",
            )
        try:
            envelope = json.loads(result.stdout)
        except ValueError as error:
            raise ConfinedResponderFailure(
                "malformed-transport", f"child stdout is not valid JSON: {error}"
            ) from error
        if not isinstance(envelope, dict):
            raise ConfinedResponderFailure(
                "malformed-transport", "child response is not a JSON object"
            )
        if "error" in envelope:
            raise ConfinedResponderFailure(
                "child-refused", str(envelope["error"])[:400]
            )
        raw = envelope.get("raw")
        if not isinstance(raw, str):
            raise ConfinedResponderFailure(
                "malformed-transport",
                "child response does not declare a text 'raw' field",
            )
        return StructuredResponse(
            raw=raw,
            model=FIXTURE_MODEL,
            usage=meta.Usage(tokens=FIXTURE_TOKENS),
            # The same declared breakdown the in-process fixture reports. The
            # child answers the request; it does not get to report what
            # answering it cost, so this is built here, in the trusted parent,
            # from the constants declared beside the fixture's own logic.
            call=call_usage.derive(
                input_tokens=FIXTURE_INPUT_TOKENS,
                output_tokens=FIXTURE_OUTPUT_TOKENS,
                total_tokens=FIXTURE_TOKENS,
            ),
        )
    finally:
        child_root.dispose(workspace)


__all__ = ["ENVELOPE_PROTOCOL", "ConfinedResponderFailure", "respond"]
