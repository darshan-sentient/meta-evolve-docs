"""Measured elapsed time and measured byte totals, retained outside decision
identity.

Two kinds of number live here, for one reason. Elapsed wall time is an
observation: two runs of the same decision on different hardware measure
different times, so folding it into ``decision_record.py``'s payload would
make the decision's own digest differ between otherwise-identical replays.
The pushed-context and pulled-source **character** totals are observations for
the same reason, which is less obvious and worth stating exactly. The kernel
renders a pulled record by serializing the whole record
(``application/experience_contract.render_records``), and an evaluation record
carries its own measured ``usage.wall_seconds`` -- so the decimal expansion of
a measured float is inside the text whose length is being counted, and the
count moves by a byte or two between identical runs. Every *count* dimension
(operations, results, records, evaluations, trials, tokens) is exact and
reconciles every time; only the char totals inherit the measurement, so only
they are kept here.

Retained atomically and append-only, per attempt: a resume that measures a
later phase must not erase what an earlier phase recorded.

**An interrupted measurement leaves a marker rather than a gap.** A segment is
opened *before* its work starts, with no elapsed time and ``unknown``
conformance, and closed only when the work returns. A process that dies in
between leaves that open segment behind exactly as it was -- so the journal
says "this phase was started and never measured" instead of saying nothing at
all, and the resumed attempt appends a second segment rather than
overwriting the first. An incomplete measurement cannot establish
``elapsed <= ceiling``, so a phase holding one reports ``unknown`` cumulatively
however fast its later attempts were.
"""

from __future__ import annotations

import json
import os
from collections.abc import Callable
from pathlib import Path


OBSERVATIONS_SCHEMA = "harness-phase-observations/v2"

# Re-exported so a caller that holds this module can read a verdict without
# also having to know which module decides what a verdict means.
from observation_conformance import (  # noqa: E402, F401
    COMPLETE,
    CONFORMANT,
    EXCEEDED,
    PENDING,
    UNKNOWN,
    conformance,
    conformance_report,
    label_conformance,
    phase_conformance,
    verify_complete_coverage,
)


def segment(
    phase: str,
    declared_ceiling: float,
    elapsed: float | None,
    *,
    label: str | None = None,
    attempt: int = 1,
    status: str = COMPLETE,
    measured: dict[str, object] | None = None,
) -> dict[str, object]:
    """One attempt at measuring one phase, complete or still pending."""

    return {
        "phase": phase,
        "label": label if label is not None else phase,
        "attempt": attempt,
        "declared_ceiling": declared_ceiling,
        "elapsed_seconds": elapsed,
        "conformance": conformance(elapsed, declared_ceiling),
        "status": status,
        "measured": dict(measured or {}),
    }


def path_for(root: Path) -> Path:
    return root / "observations.json"


def load(root: Path) -> tuple[dict[str, object], ...]:
    path = path_for(root)
    if not path.exists():
        return ()
    payload = json.loads(path.read_text(encoding="utf-8"))
    return tuple(payload["segments"])


def _atomic_write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(
        json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    os.replace(tmp, path)


def _write(root: Path, segments: tuple[dict[str, object], ...]) -> None:
    _atomic_write_json(
        path_for(root),
        {"schema": OBSERVATIONS_SCHEMA, "segments": list(segments)},
    )


def append(root: Path, entry: dict[str, object]) -> tuple[dict[str, object], ...]:
    """Atomically append one segment to the retained journal."""

    updated = (*load(root), entry)
    _write(root, updated)
    return updated


def open_segment(
    root: Path, phase: str, declared_ceiling: float, *, label: str | None = None
) -> int:
    """Record that this phase's work has started, and return its index.

    Written before the work runs, which is the whole point: if the process
    does not come back, this pending segment is what says so.
    """

    existing = load(root)
    name = label if label is not None else phase
    attempt = 1 + sum(1 for item in existing if item["label"] == name)
    append(
        root,
        segment(
            phase,
            declared_ceiling,
            None,
            label=name,
            attempt=attempt,
            status=PENDING,
        ),
    )
    return len(existing)


def close_segment(
    root: Path,
    index: int,
    elapsed: float,
    *,
    measured: dict[str, object] | None = None,
) -> dict[str, object]:
    """Close the segment at ``index`` with what the clock actually measured."""

    segments = list(load(root))
    entry = dict(segments[index])
    if entry["status"] != PENDING:
        raise ValueError(
            f"segment {index} of {path_for(root)} is already {entry['status']}"
        )
    entry["elapsed_seconds"] = elapsed
    entry["conformance"] = conformance(elapsed, entry["declared_ceiling"])
    entry["status"] = COMPLETE
    entry["measured"] = dict(measured or {})
    segments[index] = entry
    _write(root, tuple(segments))
    return entry


def measure(
    clock: Callable[[], float],
    root: Path,
    phase: str,
    declared_ceiling: float,
    work: Callable[[], object],
    *,
    label: str | None = None,
    measured: Callable[[object], dict[str, object]] | None = None,
) -> object:
    """Run ``work`` between two clock readings, journalling both edges.

    ``clock`` is injected so tests can drive boundary cases (an interval
    exactly at the ceiling, or past it) without depending on real-machine
    timing. ``measured`` is called with ``work``'s result and contributes the
    non-identity byte totals this module exists to keep out of the decision.

    On an exception from ``work``, the opened segment is left pending. No
    elapsed time is invented from the point of failure -- an interrupted
    interval is not a measurement of the work -- and nothing is deleted
    either, so the journal keeps saying that this attempt happened.
    """

    index = open_segment(root, phase, declared_ceiling, label=label)
    started = clock()
    result = work()
    elapsed = clock() - started
    close_segment(
        root,
        index,
        elapsed,
        measured=measured(result) if measured is not None else None,
    )
    return result


__all__ = [
    "COMPLETE",
    "CONFORMANT",
    "EXCEEDED",
    "OBSERVATIONS_SCHEMA",
    "PENDING",
    "UNKNOWN",
    "append",
    "close_segment",
    "conformance",
    "conformance_report",
    "label_conformance",
    "load",
    "measure",
    "open_segment",
    "path_for",
    "phase_conformance",
    "segment",
    "verify_complete_coverage",
]
