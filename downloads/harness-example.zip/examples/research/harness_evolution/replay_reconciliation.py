"""The half of replay that recomputes rather than compares.

Reopening a store and checking a committed id against a sealed one is a
comparison: both sides already exist, and replay only has to notice that they
differ. Reconciling a phase's accounting, or re-digesting an export off disk,
is a derivation -- the number or the digest is *rebuilt* from the record, which
is what makes an edited total or a swapped file detectable at all.

Kept apart from :mod:`decision_replay` for that reason, and because these are
the checks that need to know how accounting is derived and how a harness export
is encoded, which the comparison half does not.
"""

from __future__ import annotations

import json
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import ContentDigest
from meta_evolve.errors import RunsNotComparable
from meta_evolve.harness.codec import HarnessArtifactCodec

import decision_record
import phase_accounting

from replay_failure import ReplayFailure


def _reconcile(phase: str, recorded: dict[str, object] | None, *runs) -> None:
    """One phase's recorded accounting against what its runs actually hold."""

    if recorded is None:
        if runs:
            raise ReplayFailure(
                f"the {phase} phase has {len(runs)} reopened run(s) but no "
                "recorded accounting"
            )
        return
    if not runs:
        raise ReplayFailure(
            f"the {phase} phase records accounting but no run to derive it from"
        )
    recomputed = phase_accounting.to_payload(
        phase_accounting.for_runs(phase, *runs),
        exclude=decision_record.MEASURED_ACCOUNTING,
    )
    differing = {
        name: (recorded.get(name), value)
        for name, value in recomputed.items()
        if recorded.get(name) != value
    }
    if differing or set(recorded) != set(recomputed):
        raise ReplayFailure(
            f"the {phase} phase's recorded accounting does not reconcile with "
            f"its committed records: {differing or (sorted(recorded), sorted(recomputed))}"
        )


def verify_accounting(
    decision: dict[str, object],
    development_run: meta.Run,
    private_runs: tuple[meta.Run, ...],
    held_out_runs: tuple[meta.Run, ...],
) -> None:
    """Every recorded per-phase total, recomputed from the reopened runs.

    Derived, not trusted. The decision's accounting is a claim about what the
    phases spent; the runs are the record. Recomputing here is what makes an
    edited total detectable, and it is possible at all only because the three
    measured fields that carry a wall time are excluded from the record --
    those could never reconcile across two hosts.
    """

    accounting = decision["accounting"]
    _reconcile("development", accounting["development"], development_run)
    _reconcile("private", accounting["private"], *private_runs)
    _reconcile("held_out", accounting["held_out"], *held_out_runs)


def verify_comparison(
    decision: dict[str, object],
    development_run: meta.Run,
    held_out_runs: tuple[meta.Run, ...],
) -> None:
    """The matched held-out roles evaluated the baseline and private winner."""

    if not held_out_runs:
        if decision["selection"]["selected_trial_id"] is not None:
            raise ReplayFailure("a selected occurrence has no held-out comparison")
        return
    if len(held_out_runs) != 2:
        raise ReplayFailure("held-out comparison must contain exactly two roles")
    baseline, candidate = held_out_runs
    selected = next(
        (
            trial for trial in development_run.trials()
            if trial.id.value == decision["selection"]["selected_trial_id"]
        ),
        None,
    )
    if selected is None or selected.artifact is None:
        raise ReplayFailure("held-out comparison has no selected development artifact")
    if (
        baseline.inspect().declaration.seed.value
        != development_run.inspect().declaration.seed.value
        or candidate.inspect().declaration.seed.value != selected.artifact.value
    ):
        raise ReplayFailure("held-out roles do not evaluate the baseline and selected artifact")
    try:
        comparison = meta.compare_harnesses(baseline, candidate)
    except RunsNotComparable as error:
        raise ReplayFailure("held-out comparison controls do not match") from error
    if decision["held_out"]["comparison_eligible"] != (comparison.verdict != "unrankable"):
        raise ReplayFailure("held-out comparison eligibility does not match committed evaluations")
    if (decision["export"] is not None) != comparison.promotion_eligible:
        raise ReplayFailure("export does not match held-out promotion eligibility")


def verify_export(
    root: Path, decision: dict[str, object], development_run: meta.Run
) -> None:
    """The export on disk is the selected occurrence, at the recorded digest.

    Three claims, all of which need the bytes rather than the record: the
    export directory is a valid harness export at all (``load_harness``
    re-derives its digest from its own content and refuses a mismatch), that
    digest is the one the decision sealed, and the content is the *selected*
    development occurrence rather than some other artifact that happened to
    be exported into the same place.

    The read-only development Run uses the built-in harness codec. All three
    checks therefore run with or without a registry.
    """

    recorded = decision["export"]
    destination = root / "selected-harness"
    if recorded is None:
        if destination.exists():
            raise ReplayFailure(
                f"the decision records no export, but {destination} exists"
            )
        return
    if not destination.is_dir():
        raise ReplayFailure(f"the recorded export is missing from {destination}")
    try:
        exported = meta.load_harness(destination)
    except (OSError, ValueError) as error:
        raise ReplayFailure(f"{destination} is not a valid harness export: {error}") from error
    digest = ContentDigest.for_payload(HarnessArtifactCodec().encode(exported)).value
    if digest != recorded["digest"]:
        raise ReplayFailure(
            f"the export at {destination} digests to {digest!r}, but the "
            f"decision records {recorded['digest']!r}"
        )
    if recorded["selected_trial_id"] != decision["selection"]["selected_trial_id"]:
        raise ReplayFailure("export does not name the selected development occurrence")
    selected = next(
        (
            trial
            for trial in development_run.trials()
            if trial.id.value == recorded["selected_trial_id"]
        ),
        None,
    )
    if selected is None or selected.artifact is None:
        raise ReplayFailure(
            "the exported occurrence is not a development occurrence of the "
            f"reopened run: {recorded['selected_trial_id']!r}"
        )
    if selected.artifact.value != exported:
        raise ReplayFailure(
            "the exported harness is not the content of the selected "
            "development occurrence"
        )
    manifest = json.loads(
        (destination / "harness-manifest.json").read_text(encoding="utf-8")
    )
    if manifest["artifact_id"] != selected.artifact.id.value:
        raise ReplayFailure("export manifest names a different artifact occurrence")


__all__ = ["verify_accounting", "verify_comparison", "verify_export"]
