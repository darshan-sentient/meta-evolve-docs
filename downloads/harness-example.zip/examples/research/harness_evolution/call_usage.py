"""Validated call-usage evidence: input/output/total tokens and spend for one
actual provider call.

The one rule this validates, stated once so both the fixture and a future
live retention path apply it the same way: a provider-reported total larger
than the input/output pair is accepted, and the remainder is named — a
correct reasoning-model response may report more total tokens than
input+output accounts for (reasoning tokens the provider bills but does not
itemize), and refusing that as malformed transport would refuse a good
response for a shape this validator, not the model, failed to anticipate. A
total *smaller* than input+output is refused: that is not a remainder, it is
an inconsistent report, and this validator runs before manifest decoding, so
letting it through would have a transport defect read as a bad model answer.
"""

from __future__ import annotations

from dataclasses import dataclass


_FIELDS = ("input_tokens", "output_tokens", "total_tokens", "spend_micros")


@dataclass(frozen=True, slots=True)
class CallUsage:
    """One actual call's exact accounting. Never a hand-maintained total."""

    input_tokens: int
    output_tokens: int
    total_tokens: int
    spend_micros: int

    def __post_init__(self) -> None:
        for name in _FIELDS:
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(
                    f"call usage {name} must be a non-negative integer, got {value!r}"
                )
        if self.input_tokens + self.output_tokens > self.total_tokens:
            raise ValueError(
                "call usage input+output "
                f"({self.input_tokens + self.output_tokens}) exceeds the "
                f"reported total ({self.total_tokens}); a provider-reported "
                "total may be larger than input+output but never smaller"
            )

    @property
    def remainder(self) -> int:
        """Tokens the total reports beyond input+output — e.g. reasoning tokens."""

        return self.total_tokens - self.input_tokens - self.output_tokens


def derive(
    *,
    input_tokens: int,
    output_tokens: int,
    total_tokens: int | None,
    spend_micros: int = 0,
) -> CallUsage:
    """Build a :class:`CallUsage`, deriving ``total`` when the provider
    reported none at all — distinct from a provider that reported a total
    and it happened to equal input+output; both are valid, and this is the
    one place either is turned into the same committed shape."""

    resolved_total = (
        input_tokens + output_tokens if total_tokens is None else total_tokens
    )
    return CallUsage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=resolved_total,
        spend_micros=spend_micros,
    )


def to_payload(usage: CallUsage) -> dict[str, int]:
    return {
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
        "total_tokens": usage.total_tokens,
        "spend_micros": usage.spend_micros,
    }


def from_payload(payload: dict[str, object]) -> CallUsage:
    """The strict inverse of :func:`to_payload`: every field required and
    typed, never derived here — derivation is :func:`derive`'s job, for a
    live call that has not yet been normalized into a committed payload."""

    missing = [name for name in _FIELDS if name not in payload]
    if missing:
        raise ValueError(f"call usage payload is missing fields: {missing}")
    return CallUsage(**{name: payload[name] for name in _FIELDS})


__all__ = ["CallUsage", "derive", "from_payload", "to_payload"]
