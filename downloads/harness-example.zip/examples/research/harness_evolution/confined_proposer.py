"""The registered proposer, answered by the confined child.

``propose_tfd``'s counterpart: the exact same contract
(``harness.HarnessArtifact, meta.ProposerContext -> meta.ProposalResult``),
answered through ``confined_responder.respond`` instead of the fixture
called in-process. Maps only a closed ``ConfinedResponderFailure`` to a
deterministic ``ProposerFailure`` — it never runs unconfined, never retains
unsafe process text, and never converts a transport failure into model
invalidity: ``tfd.propose``'s own manifest decoding is untouched, so a
confinement problem and a model answering badly stay two different failures
with two different remedies.

**The output root is part of the boundary, so it is part of the registered
callable's contract.** A registered proposer is resolved from the registry by
name and called with two arguments, so there is nowhere in that signature to
put "which directory this run's own decision records live in" — and it cannot
go into the proposer's declared *configuration* either, because that would
make the proposer's identity, and therefore the run id and the decision digest
built on it, vary with wherever the caller pointed ``--output``. It is bound
out of band instead, by :func:`confined_to`, and the binding is **required**:
an unbound root raises rather than launching a child that could read the very
records the private-selection decision is sealed into. Binding ``None`` is a
distinct, explicit declaration — "this run has no output root to protect",
which is true of an in-memory run — so "nobody said" and "there is nothing to
say" never collapse into the same silent default.
"""

from __future__ import annotations

import contextvars
from collections.abc import Iterator
from contextlib import contextmanager
from functools import partial
from pathlib import Path

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.domain import ProposerFailure

import tfd
from confined_responder import ConfinedResponderFailure, respond


class OutputRootUnbound(RuntimeError):
    """The registered proposer was called without declaring an output root.

    Raised rather than defaulting to ``None``. A default would silently mean
    "deny nothing extra", which is exactly the vacuous boundary this example
    refuses everywhere else it could have quietly widened one.
    """


_UNBOUND = object()
_OUTPUT_ROOT: contextvars.ContextVar[object] = contextvars.ContextVar(
    "m8_confined_output_root", default=_UNBOUND
)


@contextmanager
def confined_to(output_root: Path | str | None) -> Iterator[None]:
    """Declare the output root every confined child in this scope is denied.

    A :class:`~contextvars.ContextVar` rather than a module attribute, so the
    binding is scoped to the block that made it and restored on the way out —
    a search that finished, raised, or was interrupted never leaves a stale
    root behind for the next one to inherit.
    """

    token = _OUTPUT_ROOT.set(
        None if output_root is None else Path(output_root).resolve()
    )
    try:
        yield
    finally:
        _OUTPUT_ROOT.reset(token)


def bound_output_root() -> Path | None:
    """The declared output root, or a refusal if none was ever declared."""

    current = _OUTPUT_ROOT.get()
    if current is _UNBOUND:
        raise OutputRootUnbound(
            "the confined proposer was called without an output root binding; "
            "wrap the run in confined_to(root) -- or confined_to(None) to "
            "declare that this run has no output root to protect"
        )
    return current  # type: ignore[return-value]


def propose_confined(
    parent: harness.HarnessArtifact,
    context: meta.ProposerContext,
    *,
    output_root: Path | str | None,
) -> meta.ProposalResult:
    """``propose_tfd``'s confined counterpart: same contract, isolated responder.

    ``output_root`` is required rather than defaulted, for the same reason
    :func:`bound_output_root` refuses an unbound binding: a default of
    ``None`` would silently mean "deny nothing extra", and a caller who simply
    forgot would get a child that can read this run's own decision records.
    Passing ``None`` explicitly is still allowed -- it is the declaration that
    there is no output root to protect.
    """

    try:
        return tfd.propose(parent, context, partial(respond, output_root=output_root))
    except ConfinedResponderFailure as error:
        return meta.ProposalResult(
            failure=ProposerFailure(
                message="confined proposer child could not be asked or answered",
                # The closed code, and nothing the child wrote. The details of
                # a typed proposer failure are selected whole into a later
                # proposal's governed bundle, so any child-authored text kept
                # here -- its stderr, an exception message quoting a path --
                # would be a channel from the confined process straight into
                # the next prompt. The code is this example's own word for
                # what went wrong; it is enough to act on and it is the only
                # thing here the child did not write.
                details={"code": error.code},
            )
        )


def propose_confined_fixture(
    parent: harness.HarnessArtifact, context: meta.ProposerContext
) -> meta.ProposalResult:
    """The registered two-argument callable, answered by the confined fixture.

    The output root comes from the surrounding :func:`confined_to` binding, so
    the registered path and the explicit ``propose_confined(..., output_root=)``
    path deny exactly the same roots.
    """

    return propose_confined(parent, context, output_root=bound_output_root())


__all__ = [
    "OutputRootUnbound",
    "bound_output_root",
    "confined_to",
    "propose_confined",
    "propose_confined_fixture",
]
