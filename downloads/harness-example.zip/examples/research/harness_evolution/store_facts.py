"""What every phase store says about itself, gathered in the run's own layout.

:mod:`store_reading` knows how to read one store; :mod:`phase_plans` knows
where each phase's store lives. This is the small join between them, kept out
of the orchestration so ``run_flagship`` reads as its phases rather than as
directory arithmetic.

Registry-free throughout, deliberately: what is gathered here is sealed into
the decision, and replay re-derives it the same way from the same events. If
this needed a registry, the comparison at replay would be against whatever the
components say today rather than against what the run committed.
"""

from __future__ import annotations

from pathlib import Path

import phase_plans
import store_reading


DEVELOPMENT_STORE = "search-run"


def gather(
    root: Path, evaluated: tuple, executed_held_out: bool
) -> dict[str, object]:
    """Every phase's committed facts, keyed the way the decision records them.

    ``evaluated`` is the private outcomes in order -- all of them, rankable or
    not, because each one has a store and each store is part of what the
    decision claims.
    """

    return {
        "development": store_reading.phase_facts(root, DEVELOPMENT_STORE),
        "private": {
            item.occurrence.id.value: store_reading.phase_facts(
                root,
                phase_plans.private_store(
                    item.occurrence.logical_step, item.occurrence.id.value
                ),
            )
            for item in evaluated
        },
        "held_out": (
            {
                role: store_reading.phase_facts(
                    root, phase_plans.held_out_store(role)
                )
                for role in phase_plans.HELD_OUT_ROLES
            }
            if executed_held_out
            else {}
        ),
    }


__all__ = ["DEVELOPMENT_STORE", "gather"]
