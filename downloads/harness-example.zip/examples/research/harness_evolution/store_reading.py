"""Reading a sealed run's committed declarations from its store alone.

Everything here works on a ``Storage.read_only`` handle and a run id, with no
registry, no codecs, and no example component of any kind. That is the whole
point of the module: #227 requires replay to receive only the output
directory, and a check that first rebuilds today's components in order to look
at yesterday's run is not reading the record -- it is comparing the record
against whatever the code says now.

What the committed event stream carries, and this exposes:

- the ``RunStarted`` declaration: the task's evaluator reference, the run
  budget, the random seed, the execution mode, and -- the part forgery
  detection needs -- the **component manifests**, each with its own
  implementation and configuration digest;
- every ``EvaluationCompleted``: its own evaluation occurrence id, which is a
  distinct identity from the trial that produced it, plus the metrics,
  failure, and usage that evaluation actually committed;
- every ``EvidenceRecorded``: the kind and payload each occurrence published.

None of it is decoded back into typed domain values. An artifact still needs
its codec, and codecs live in a registry; nothing below reads one.
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import RunId


def plain(value: object) -> object:
    """A committed event body as plain data, however deeply it nests."""

    if is_dataclass(value) and not isinstance(value, type):
        return {key: plain(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [plain(item) for item in value]
    return value


def open_store(directory: Path) -> meta.Storage:
    """The store at ``directory``, read-only. Raises if there is none."""

    if not directory.is_dir():
        raise FileNotFoundError(f"no durable store at {directory}")
    return meta.Storage.read_only(directory)


def sole_run_id(storage: meta.Storage) -> RunId:
    """The one run in a dedicated store; more than one is a caller error."""

    runs = storage.runs()
    if len(runs) != 1:
        raise ValueError(f"expected exactly one run in a dedicated store, found {runs}")
    return runs[0]


def _bodies(storage: meta.Storage, run_id: RunId, name: str) -> list[object]:
    return [
        event.body
        for event in storage.events.read(run_id)
        if type(event.body).__name__ == name
    ]


def declaration(storage: meta.Storage, run_id: RunId) -> dict[str, object]:
    """The ``RunStarted`` body, as plain data."""

    started = _bodies(storage, run_id, "RunStarted")
    if len(started) != 1:
        raise ValueError(f"run {run_id.value!r} has {len(started)} start declarations")
    return plain(started[0])  # type: ignore[return-value]


def component_manifests(
    storage: meta.Storage, run_id: RunId
) -> dict[str, dict[str, object]]:
    """Every component this run committed, keyed ``role:name``.

    The manifest -- not the reference. A ``ComponentRef`` names a role, a name,
    and a version; the manifest beside it carries the implementation and
    configuration digests those were derived from, which is what makes a
    forged version string detectable rather than merely unusual.
    """

    capabilities = declaration(storage, run_id).get("capabilities") or {}
    manifests = capabilities.get("component_manifests") or ()
    return {f"{item['role']}:{item['name']}": dict(item) for item in manifests}


def evaluations(storage: meta.Storage, run_id: RunId) -> tuple[dict[str, object], ...]:
    """Every committed evaluation, in order, as plain data.

    Each carries its *own* occurrence id. A trial and the evaluation of that
    trial are two occurrences with two identities, and recording the trial's
    where the evaluation's belongs would name the wrong thing -- silently,
    since both are opaque strings.
    """

    return tuple(
        plain(body.evaluation)  # type: ignore[arg-type]
        for body in _bodies(storage, run_id, "EvaluationCompleted")
    )


def final_evaluation(storage: meta.Storage, run_id: RunId) -> dict[str, object] | None:
    """The last committed evaluation, or ``None`` if the run committed none."""

    committed = evaluations(storage, run_id)
    return dict(committed[-1]) if committed else None


def evidence(storage: meta.Storage, run_id: RunId) -> tuple[dict[str, object], ...]:
    """Every committed evidence occurrence: its kind, and its payload."""

    return tuple(
        plain(body.evidence)  # type: ignore[arg-type]
        for body in _bodies(storage, run_id, "EvidenceRecorded")
    )


def metric(evaluation: dict[str, object] | None, name: str) -> float | None:
    """One metric off a committed evaluation, or ``None`` if it has none.

    Committed metrics arrive as a frozen mapping's plain form, so the lookup
    is written once here rather than at each call site guessing the shape.
    """

    if evaluation is None:
        return None
    metrics = evaluation.get("metrics") or {}
    items = metrics.get("_items") if isinstance(metrics, dict) else None
    pairs = dict(items) if items else (metrics if isinstance(metrics, dict) else {})
    value = pairs.get(name)
    return None if value is None else float(value)


def phase_facts(root: Path, relative: str) -> dict[str, object]:
    """Everything one phase store says about itself, registry-free.

    This is the material a *resealed* forgery cannot survive. A digest check
    catches a decision edited without recomputing its filename; it cannot
    catch one edited and resealed, because then the content and the filename
    agree again. What does catch that is comparing the sealed claims against
    the store they are claims about -- which is why the manifests and the
    evaluation identity are recorded here and re-derived at replay from the
    same events, rather than trusted from the record.
    """

    storage = open_store(root / relative)
    run_id = sole_run_id(storage)
    final = final_evaluation(storage, run_id)
    return {
        "store": relative,
        "run_id": run_id.value,
        "component_manifests": component_manifests(storage, run_id),
        "final_evaluation_id": None if final is None else final["id"]["value"],
        "quality": metric(final, "quality"),
        "failed": final is not None and final.get("failure") is not None,
        "evaluations": len(evaluations(storage, run_id)),
    }


__all__ = [
    "phase_facts",
    "component_manifests",
    "declaration",
    "evaluations",
    "evidence",
    "final_evaluation",
    "metric",
    "open_store",
    "plain",
    "sole_run_id",
]
