"""Linux Landlock: ctypes declarations, ABI check, and ruleset construction.

Ported faithfully from ``examples/research/systems_optimization/landlock.py``
at ``6d340ce`` (#198), which spent several review rounds getting this exact
shape right -- the rights table, the ABI floor, and the per-path right
narrowing below are not re-derived here. What changed for this example: the
entry point (parsing argv and calling ``execv``) moved to
``confinement_landlock_entry.py``, a separate tiny script, so this module
stays under the repository's line guideline without discarding any of the
review-hardened logic.

**Standard library only, on purpose.** Nothing here imports ``meta_evolve``.
This module is imported by the entry script *before* the restriction is
applied, so what it loads is code running with full authority. The less of
that, the better.

**Nothing happens on import.** Every syscall is inside a function; importing
this module restricts nothing.
"""

from __future__ import annotations

import ctypes
import os
import sys


# The three syscalls, by number: ``landlock_create_ruleset``,
# ``landlock_add_rule``, ``landlock_restrict_self``. Numbers rather than names
# because there is no libc wrapper for any of them.
CREATE_RULESET, ADD_RULE, RESTRICT_SELF = 444, 445, 446
RULE_PATH_BENEATH = 1
PR_SET_NO_NEW_PRIVS = 38

# Filesystem access rights. ``READ_FILE`` alone lets a confined process open a
# file for writing under an allow-listed read path, which is why ``READ_DIR``
# and the write bits are separate rights rather than assumed together.
# ``WRITE`` is bits 1 and 4 through 12: write, both removes, and the seven
# make-a-node rights. Execute remains deliberately absent so the confined
# interpreter can start.
WRITE_FILE = 1 << 1
READ_FILE = 1 << 2
READ_DIR = 1 << 3
WRITE = WRITE_FILE | (((1 << 9) - 1) << 4)
REFER = 1 << 13
TRUNCATE = 1 << 14

# The rights a *file* can hold. Landlock refuses a rule that names a
# directory-only right on something that is not a directory, so a rule for a
# file outside its workspace (the one path this example ever writes there)
# has to be the handled set narrowed to these.
FILE_RIGHTS = WRITE_FILE | READ_FILE | TRUNCATE

# The ABI this boundary needs before it will call a Linux kernel one.
# ``LANDLOCK_ACCESS_FS_TRUNCATE`` arrives in ABI 3, and without it
# ``truncate(2)`` is not governed at all: a confined process on ABI 1 or 2
# could not open a denied file for writing, but could still empty it.
MINIMUM_LANDLOCK_ABI = 3

_QUERY = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32]
_ADD = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
_RESTRICT = [ctypes.c_int, ctypes.c_uint32]


class _Ruleset(ctypes.Structure):
    _fields_ = [("handled_access_fs", ctypes.c_uint64)]


class _Beneath(ctypes.Structure):
    _pack_ = 1
    _fields_ = [("allowed_access", ctypes.c_uint64), ("parent_fd", ctypes.c_int32)]


def libc() -> ctypes.CDLL:
    """The C library, with both symbols this boundary calls typed and resolved.

    ``ctypes`` reports a missing symbol through ``CDLL.__getattr__``, which
    raises ``AttributeError`` -- not ``OSError`` -- which is why every caller
    guards both. This makes the function Linux-only rather than portable:
    ``prctl`` is a Linux call, so on any other platform the lookup fails here.
    """

    handle = ctypes.CDLL(None, use_errno=True)
    handle.syscall.restype = ctypes.c_long
    handle.prctl.restype = ctypes.c_int
    return handle


def _call(handle: ctypes.CDLL, number: int, *arguments: object, types: list) -> tuple:
    handle.syscall.argtypes = [ctypes.c_long, *types]
    return handle.syscall(number, *arguments), ctypes.get_errno()


def abi(handle: ctypes.CDLL) -> tuple[int, int]:
    """The kernel's Landlock ABI version and errno. Negative means no Landlock."""

    return _call(
        handle,
        CREATE_RULESET,
        None,
        ctypes.c_size_t(0),
        ctypes.c_uint32(1),
        types=_QUERY,
    )


def handled_for(version: int) -> int:
    """Every right the ruleset takes charge of, for the ABI actually reported.

    Naming a right the running kernel does not know makes
    ``landlock_create_ruleset`` fail outright rather than degrade, so this is
    computed from the reported version instead of assumed. ``REFER`` -- rename
    and link across directories -- arrives in ABI 2, and ``TRUNCATE`` in ABI 3.
    A right that is *handled* and never granted is denied everywhere, which is
    the point: the allow-list grants writes on the workspace alone.
    """

    handled = READ_FILE | READ_DIR | WRITE
    if version >= 2:
        handled |= REFER
    if version >= 3:
        handled |= TRUNCATE
    return handled


def rules_for(
    readable: list[str], writable: list[str], handled: int
) -> list[tuple[str, int]]:
    """The exact rights granted to each allow-listed path.

    Readable paths may open files and enumerate directories but never mutate
    them. Writable paths receive every right the ruleset handles. A path that
    is not a directory receives only the subset a file can hold, because
    naming a directory-only right on a file makes ``landlock_add_rule`` fail --
    and a rule that fails to be added is confinement that is not applied.
    """

    def granted(rights: int, path: str) -> int:
        return rights if os.path.isdir(path) else rights & FILE_RIGHTS

    rules = [(path, granted(READ_FILE | READ_DIR, path)) for path in readable]
    rules.extend((path, granted(handled, path)) for path in writable)
    return rules


def restrict(readable: list[str], writable: list[str]) -> str | None:
    """Apply the ruleset to this process, or say why it could not.

    A message rather than an exception, because the caller's job is to exit
    with it: failing to confine has to be loud and fatal, never a warning that
    leaves a process running with authority the record says it did not have.
    """

    if sys.platform != "linux":
        return f"landlock is a Linux facility; this is {sys.platform!r}"
    try:
        handle = libc()
    except (AttributeError, OSError) as unusable:
        return f"landlock is unavailable: this libc cannot be called ({unusable})"
    version, errno = abi(handle)
    if version < 1:
        return f"landlock is unavailable: ABI query returned {version} errno {errno}"
    if version < MINIMUM_LANDLOCK_ABI:
        return (
            f"landlock ABI {version} is below the {MINIMUM_LANDLOCK_ABI} this "
            "boundary requires: without TRUNCATE a file can still be emptied"
        )
    handled = handled_for(version)
    attribute = _Ruleset(handled_access_fs=handled)
    ruleset, errno = _call(
        handle,
        CREATE_RULESET,
        ctypes.byref(attribute),
        ctypes.c_size_t(ctypes.sizeof(attribute)),
        ctypes.c_uint32(0),
        types=_QUERY,
    )
    if ruleset < 0:
        return f"landlock_create_ruleset failed with errno {errno}"
    for path, rights in rules_for(readable, writable, handled):
        if not path or not os.path.exists(path):
            continue
        parent = os.open(path, os.O_PATH | os.O_CLOEXEC)
        rule = _Beneath(allowed_access=rights, parent_fd=parent)
        added, errno = _call(
            handle,
            ADD_RULE,
            ctypes.c_int(ruleset),
            ctypes.c_int(RULE_PATH_BENEATH),
            ctypes.byref(rule),
            ctypes.c_uint32(0),
            types=_ADD,
        )
        os.close(parent)
        if added:
            return f"landlock_add_rule({path}) failed with errno {errno}"
    # Without this, ``landlock_restrict_self`` refuses for an unprivileged caller.
    if handle.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0):
        return "prctl(PR_SET_NO_NEW_PRIVS) failed"
    applied, errno = _call(
        handle, RESTRICT_SELF, ctypes.c_int(ruleset), ctypes.c_uint32(0),
        types=_RESTRICT,
    )
    if applied:
        return f"landlock_restrict_self failed with errno {errno}"
    os.close(ruleset)
    return None


__all__ = [
    "ADD_RULE", "CREATE_RULESET", "FILE_RIGHTS", "MINIMUM_LANDLOCK_ABI",
    "READ_DIR", "READ_FILE", "REFER", "RESTRICT_SELF", "TRUNCATE", "WRITE",
    "WRITE_FILE", "abi", "handled_for", "libc", "restrict", "rules_for",
]
