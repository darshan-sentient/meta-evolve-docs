"""Present a reading as the text the run commits, and check one back.

Split from the projection because it is the one place that produces prose.
``render`` is the whole of what a proposer is shown, and ``validate_bundle``
is the trusted adapter re-deriving that text from the exact records beside it
— so a bundle whose rendering its own records do not support is refused rather
than read.
"""

from __future__ import annotations

from collections.abc import Mapping

from meta_evolve.domain import ContextBundle

from diagnosis_reading import Attempt, DiagnosisError, summarize


def _render_diagnosis(data: Mapping[str, object], lines: list[str]) -> None:
    for cluster in data["failures"]:
        lines.append(
            f"    verifier={cluster['verifier']} "
            f"exit_code={cluster['exit_code']} failure={cluster['failure']}"
        )
        for episode in cluster["episodes"]:
            lines.append(f"      - {episode['name']}: {episode['instruction']}")
    if not data["failures"]:
        lines.append("    none")
    lines.append("  passing invariants:")
    for episode in data["passing"]:
        lines.append(f"    - {episode['name']}: {episode['instruction']}")
    if not data["passing"]:
        lines.append("    none")
    if not data["complete"]:
        failure = data["evaluator_failure"]
        lines.append(f"  incomplete evaluation: {failure['kind']}")


def render(reading: tuple[Attempt, ...] | DiagnosisError) -> str:
    """The deterministic presentation committed by ``ContextSelected``."""

    if isinstance(reading, DiagnosisError):
        where = "" if reading.trial is None else f" at {reading.trial}"
        return f"diagnosis unavailable: {reading.code}{where}"
    lines = [f"development diagnosis over {len(reading)} prior attempt(s)"]
    for attempt in reading:
        state = attempt.state
        if attempt.failure is not None:
            state = f"{state} ({attempt.failure})"
        quality = "none" if attempt.quality is None else f"{attempt.quality}"
        lines.append("")
        lines.append(f"attempt at step {attempt.step} · trial {attempt.trial}")
        lines.append(f"  parent: {attempt.parent or 'none'}")
        lines.append(f"  edit: {attempt.surface or attempt.note}")
        lines.append(f"  outcome: {state} · quality={quality}")
        if attempt.diagnosis is None:
            lines.append("  observed failures: unavailable")
            continue
        lines.append("  observed failures:")
        _render_diagnosis(attempt.diagnosis, lines)
    return "\n".join(lines)


def validate_bundle(
    bundle: ContextBundle,
) -> tuple[Attempt, ...] | DiagnosisError:
    """Re-derive the reading from the exact records the run committed."""

    reading = summarize(bundle.records)
    if isinstance(reading, DiagnosisError):
        return reading
    if render(reading) != bundle.rendered:
        return DiagnosisError(code="rendering does not match its records")
    return reading


__all__ = ["render", "validate_bundle"]
