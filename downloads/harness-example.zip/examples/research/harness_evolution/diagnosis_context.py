"""The governed diagnosis context policy declared by the harness search.

Example-local and deterministic. It selects exact committed development
records and commits the reading's deterministic rendering; it creates no
evidence of its own, ranks nothing, and holds no evaluation authority. Raw
episode captures and candidate-authored *evidence* are never selected, so the
proposer cannot reach grader output, hidden expectations, or held-out facts
through this channel.

Typed outcome failures are a deliberate exception, and the claim stops there.
Selecting an exact committed record means never redacting one, and a trial
outcome carries a free-form failure message and details — so whatever a
proposer wrote into its own typed failure stays visible to a later proposal.
That is prior model output, never an evaluator or grader fact; this example's
adapter keeps model-authored text out of those details rather than relying on
the policy to strip it.

A proposal's own manifest is excluded by the same rule seen from the other side.
``predicted_fix`` and ``at_risk_regressions`` are model-authored predictions
committed to the ``proposal`` record, and ``proposal`` is not among the kinds
this policy selects — so a prediction stays auditable in the run's history
without becoming the next attempt's evidence. That exclusion is load-bearing
rather than incidental: the manifest contract is what made those fields real,
and widening the selected kinds would make every later proposal a reader of the
previous one's guesses.

When the required attempts do not fit the declared bounds the bundle is marked
truncated and the proposer refuses. This policy never silently drops an
attempt to fit, and never widens its own bounds.
"""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.application.experience import ExperienceQuery
from meta_evolve.domain import (
    ContextBundle,
    ContextRecord,
    ContextSpec,
    ContextUsage,
    PolicyRef,
)

from diagnosis_reading import authorized_diagnoses, selected, summarize
from diagnosis_rendering import render


@dataclass(frozen=True, slots=True)
class HarnessDiagnosisContext:
    """Push every prior development attempt, and nothing else, to a proposer."""

    max_records: int = 30
    max_chars: int = 32_000
    policy = PolicyRef("harness-diagnosis", "1")

    def __post_init__(self) -> None:
        ContextSpec(
            policy=self.policy,
            max_records=self.max_records,
            max_chars=self.max_chars,
        )

    def select(self, task, candidate, graph, spec: ContextSpec) -> ContextBundle:
        unrestricted = ExperienceQuery(task_id=graph.task_id, run_id=graph.run_id)
        current = graph.node(candidate, unrestricted)
        # One construction path, so the committed rendering is always the
        # rendering of the committed records: the seed has no prior step to
        # query, not a different contract.
        seed = current.logical_step == 0
        eligible: tuple[ContextRecord, ...] = ()
        if not seed:
            state = graph.state_at(
                ExperienceQuery(
                    task_id=graph.task_id,
                    run_id=graph.run_id,
                    as_of=current.logical_step - 1,
                )
            )
            authorized = authorized_diagnoses(state.records)
            eligible = tuple(
                item for item in state.records if selected(item, authorized)
            )
        records = tuple(
            ContextRecord(
                ref=item.ref,
                logical_step=item.logical_step,
                event_sequence=item.event_sequence,
                value=item.value,
            )
            for item in eligible[: spec.max_records]
        )
        complete = render(summarize(records))
        rendered = complete[: spec.max_chars]
        return ContextBundle(
            records=records,
            rendered=rendered,
            reason=(
                "the seed trial has no prior attempt"
                if seed
                else "governed development diagnosis"
            ),
            truncated=(
                len(records) < len(eligible) or len(rendered) < len(complete)
            ),
            usage=ContextUsage(records=len(records), chars=len(rendered)),
        )


def build_harness_diagnosis_context(spec: ContextSpec) -> HarnessDiagnosisContext:
    """Rebuild the policy from its recorded bounds for durable execution."""

    return HarnessDiagnosisContext(
        max_records=spec.max_records, max_chars=spec.max_chars
    )


__all__ = ["HarnessDiagnosisContext", "build_harness_diagnosis_context"]
