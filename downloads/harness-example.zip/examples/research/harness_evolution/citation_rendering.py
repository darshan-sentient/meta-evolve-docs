"""What the model may read about each observation, and which ones are the parent's.

The counterpart to :mod:`diagnosis_rendering` on the citation side. That module
decides what the governed bundle *says*; this one decides what each observation
is *called* when it is offered as citable, and which tokens name the attempt the
proposal is descended from.

Two rules live here because they are the same rule seen twice: nothing in an
entry may let a durable identity be reconstructed, and nothing in it may be text
a candidate wrote. A record kind is the kernel's own word except on evidence,
where ``Evidence.kind`` is the part a candidate can influence — so only the
governed diagnosis schema is echoed and everything else falls back to the
stable record kind.
"""

from __future__ import annotations

from meta_evolve.domain import ContextRecord, Evidence

from citation_ledger import CitationEntry, Ledger
from diagnosis import DIAGNOSIS_SCHEMA
from diagnosis_reading import Attempt


def record_kind(record: ContextRecord) -> str:
    """The kernel's word for this record, or the one evidence kind we trust."""

    value = record.value
    if isinstance(value, Evidence) and value.kind == DIAGNOSIS_SCHEMA:
        return value.kind
    return record.kind


def ledger_for(records: tuple[ContextRecord, ...]) -> Ledger:
    """Every exact selected record, citable in canonical bundle order.

    Its presentation exposes only the channel, a safe kind, and logical step —
    never a durable identity the model could reconstruct.

    Bundle order is not a presentation choice. Proposal completion checks
    ``derived_from`` against the kernel's own observation ledger, which is the
    pushed bundle references followed by each succeeded pull result in
    operation order. A ledger built in any other order still resolves in the
    adapter and is then refused there as an unordered subsequence — a policy
    violation whose details name nothing, since the proposal itself reported no
    failure. So a later channel appends after these entries, in that same
    order, and never interleaves with them.
    """

    return Ledger(
        entries=tuple(
            CitationEntry(
                ref=record.ref,
                presentation=(
                    f"governed-diagnosis · {record_kind(record)} "
                    f"· step {record.logical_step}"
                ),
            )
            for record in records
        )
    )


def parent_citations(report: Attempt, ledger: Ledger) -> tuple[str, str]:
    """Resolve the exact parent observations retained by the projection.

    Both checks below are internal invariants rather than typed refusals, and
    they raise rather than assert. ``-O`` strips an assertion, and these two do
    not degrade alike if one were ever false: the fixture would land on a typed
    citation refusal, while the live driver joins these tokens into its prompt
    and would raise mid-flight in an authorized paid run. An explicit raise
    fails the same way in every mode.
    """

    if report.diagnosis_ref is None or report.evaluation is None:
        # _parent_report selects only a complete projected attempt.
        raise AssertionError("projected parent attempt is missing a reference")
    diagnosis = ledger.token_for(report.diagnosis_ref)
    evaluation = ledger.token_for(report.evaluation)
    if diagnosis is None or evaluation is None:
        # The ledger and projection come from the same validated bundle.
        raise AssertionError("projected parent reference is not in the ledger")
    positions = {token: position for position, token in enumerate(ledger.tokens())}
    if positions[diagnosis] < positions[evaluation]:
        return diagnosis, evaluation
    return evaluation, diagnosis


__all__ = ["ledger_for", "parent_citations", "record_kind"]
