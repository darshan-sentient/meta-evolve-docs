"""Recomputing a phase's spend from the evidence its trials committed.

Every total here is derived from committed records rather than counted at the
call site, and that is the point rather than an implementation detail: a total
the producer reported about itself cannot detect the producer having
under-reported. Separated from :mod:`phase_accounting`, which assembles those
totals into one value and states the laws they have to satisfy -- deriving a
number and judging it are different jobs, and the judging half is what a
promotion decision is read against.

Nothing here reads a file, opens a store, or knows what a phase is. Each
function takes finished runs and walks the evidence they already hold.
"""

from __future__ import annotations

from dataclasses import dataclass

import meta_evolve as meta
from meta_evolve.domain import Evidence, ExperienceObservation

import call_usage
import source_schema


CALL_EVIDENCE_KIND = "sdk-structured-output"
CAPTURE_EVIDENCE_KIND = "episode-capture"


@dataclass(frozen=True, slots=True)
class _Calls:
    count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    remainder: int = 0
    spend_micros: int = 0


def calls(runs: tuple[meta.Run, ...]) -> _Calls:
    """Every retained provider call, validated through :mod:`call_usage`.

    A retained call whose payload does not satisfy the one validation rule
    raises rather than being skipped: an unaccountable call is worse than a
    counted one, and this phase total is the number a promotion decision is
    read against.
    """

    count = 0
    totals = [0, 0, 0, 0, 0]
    for run in runs:
        for trial in run.trials():
            for item in trial.evidence:
                if item.kind != CALL_EVIDENCE_KIND:
                    continue
                payload = item.data.get("call")
                if payload is None:
                    continue
                usage = call_usage.from_payload(dict(payload))
                count += 1
                totals[0] += usage.input_tokens
                totals[1] += usage.output_tokens
                totals[2] += usage.total_tokens
                totals[3] += usage.remainder
                totals[4] += usage.spend_micros
    return _Calls(count, *totals)


@dataclass(frozen=True, slots=True)
class _Episodes:
    episodes: int = 0
    attempts: int = 0
    evaluations: int = 0
    trials: int = 0


def episodes(runs: tuple[meta.Run, ...]) -> _Episodes:
    """Inner episode work, counted from the capture each evaluation published."""

    episodes = attempts = evaluations = trials = 0
    for run in runs:
        for trial in run.trials():
            for item in trial.evidence:
                if item.kind != CAPTURE_EVIDENCE_KIND:
                    continue
                for episode in item.data["episodes"]:
                    episodes += 1
                    attempts += len(episode["attempts"])
                    counts = episode["inner_counts"]
                    evaluations += counts["evaluations"]
                    trials += counts["trials"]
    return _Episodes(episodes, attempts, evaluations, trials)


@dataclass(frozen=True, slots=True)
class _Source:
    indexes: int = 0
    files: int = 0
    errors: int = 0
    total_bytes: int = 0


def source(runs: tuple[meta.Run, ...]) -> _Source:
    """Source records returned by successful opens, including repeated reads.

    The public Run view exposes aggregate pull usage, not individual opens.
    This example-local accounting edge reads the kernel's validated projection
    for those committed observations; it never queries a live reader. A
    truncated rendering still returned its structured records and spent bytes.
    Denied/exhausted opens and source publication alone contribute nothing.
    """

    indexes = files = errors = total = 0
    for run in runs:
        projection = run._projection()
        requests = {item.operation_id: item.request for item in projection.experience_attempts}
        for opened in projection.experience_successes:
            if requests[opened.operation_id].operation != "open":
                continue
            if not isinstance(opened.result, ExperienceObservation):
                raise ValueError("a successful open must return an observation")
            for record in opened.result.records:
                item = record.value
                if not isinstance(item, Evidence):
                    continue
                if item.kind == source_schema.INDEX_SCHEMA:
                    indexes += 1
                elif item.kind == source_schema.ERROR_SCHEMA:
                    errors += 1
                elif item.kind == source_schema.FILE_SCHEMA:
                    files += 1
                    total += int(item.data["bytes"])
    return _Source(indexes, files, errors, total)


def citations(runs: tuple[meta.Run, ...]) -> int:
    return sum(len(trial.derived_from) for run in runs for trial in run.trials())


__all__ = [
    "CALL_EVIDENCE_KIND",
    "CAPTURE_EVIDENCE_KIND",
    "calls",
    "citations",
    "episodes",
    "source",
]
