"""The audited pull: one search, then only the offsets an index names.

This is #226's admission rule getting its first production caller. Everything
the model may cite from this channel was opened here, in the order the kernel
will check, and validated before it was adopted.

Exactly one thing is an absence: a *valid* ``harness-source-error/v1`` header,
which is the evaluator successfully saying no view exists for that occurrence.
Everything else is an inconsistency and refuses the whole proposal — including
an evaluation carrying no evidence at all. In a valid harness run every searched
development evaluation carries either a source index or an explicit error
header, so an evidence-less one is a broken run rather than a quiet gap, and
proceeding from it would be the silent fallback the repository forbids.

Nothing here opens the episode capture or the diagnosis. The index names which
of its evaluation's own offsets are source files, and those are the only ones
opened — so the raw grader-adjacent record sitting in the same bundle stays
unreachable through this channel by construction rather than by a filter.
"""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import Evaluation, ExperienceRef, SourceTree
from meta_evolve.errors import ExperienceAccessDenied, ExperienceBudgetExhausted

from citation_ledger import Ledger
from diagnosis import artifact_digest
from diagnosis_reading import Attempt
from source_decoding import harness_from_view
from source_pull import exposed, open_once
from source_rendering import file_presentation, index_presentation
from source_schema import (
    ERROR_SCHEMA,
    FILE_SCHEMA,
    INDEX_SCHEMA,
    invalid_error,
    invalid_file,
    invalid_index,
)
from source_view import SOURCE_PATHS, SourceViewError, canonical_view, view_digest


UNREADABLE = "prior canonical source view is unreadable"
NO_READER = "no audited experience reader is available"


@dataclass(frozen=True, slots=True)
class SourceRefusal:
    """Why no proposal may be built from this run's prior source views."""

    message: str
    code: str


@dataclass(frozen=True, slots=True)
class SourceReading:
    """Every prior view that could be read, and the ledger that may cite them."""

    ledger: Ledger
    priors: tuple[tuple[int, SourceTree | None], ...]


def _refuse(code: str) -> SourceRefusal:
    return SourceRefusal(message=UNREADABLE, code=code)


def _describe(step: int):
    """A presentation for whichever of the two citable payloads came back.

    Called only on admission, and its result is kept only if the caller then
    adopts the candidate ledger — so the constant below is never shown to a
    model. It exists because ``describe`` must return text on every path.
    """

    def describe(record) -> str:
        value = record.value
        kind = getattr(value, "kind", None)
        data = getattr(value, "data", None)
        if kind == INDEX_SCHEMA and invalid_index(data) is None:
            return index_presentation(data, step)
        if kind == FILE_SCHEMA and invalid_file(data) is None:
            return file_presentation(data, step)
        return "unreadable source evidence"

    return describe


def _evidence_ref(evaluation_ref: ExperienceRef, evidence_id: object) -> ExperienceRef:
    return ExperienceRef(
        run_id=evaluation_ref.run_id,
        kind="evidence",
        occurrence_id=evidence_id.value,
    )


def _opened(reader, ledger: Ledger, ref: ExperienceRef, step: int):
    """Open ``ref``, and hand back the exposure separately from the admission.

    Exposure and admission are not the same decision. Recording what an
    operation exposed is a statement about the run's own pull order, and it
    stays true whether or not the caller goes on to cite what came back — so a
    discarded admission must not take the exposure down with it. It stays in
    ``exposure``, is never counted among the admitted, and blocks nothing.
    """

    exposure = exposed(ledger, ref)
    return exposure, open_once(reader, exposure, ref, _describe(step))


def _reassembled(
    files: dict[str, object], digest: str, identity: str
) -> SourceTree | None:
    """The three validated files as one view, or nothing if they disagree."""

    if set(files) != set(SOURCE_PATHS):
        return None
    if any(item["artifact_digest"] != digest for item in files.values()):
        return None
    if any(item["view_digest"] != identity for item in files.values()):
        return None
    try:
        view = SourceTree({path: item["content"] for path, item in files.items()})
        if view_digest(view) != identity:
            return None
    except (TypeError, ValueError):
        # Unreachable while every file has passed its own validator, and
        # guarded anyway: this is the second place untrusted content is
        # encoded, and the reader may not raise on any of it.
        return None
    reconstructed = harness_from_view(view)
    if isinstance(reconstructed, SourceViewError):
        return None
    if artifact_digest(reconstructed) != digest:
        return None
    rebuilt = canonical_view(reconstructed)
    if not isinstance(rebuilt, SourceTree) or rebuilt != view:
        return None
    return view


def _prior(reader, ledger: Ledger, record, attempt: Attempt):
    """One prior occurrence: its view and the ledger that may now cite it.

    Returns the refusal instead if anything about it is inconsistent, and
    ``(ledger, None)`` when the evaluator itself stated there is no view.
    """

    evaluation = record.value
    if not isinstance(evaluation, Evaluation):
        return _refuse("searched record is not an evaluation")
    if not evaluation.evidence_ids:
        return _refuse("evaluation published no evidence")
    digest = attempt.diagnosis["artifact_digest"]
    header_ref = _evidence_ref(record.ref, evaluation.evidence_ids[0])
    ledger, header = _opened(reader, ledger, header_ref, attempt.step)
    if isinstance(header, str):
        return _refuse("source header could not be opened")
    payload = header.payload(INDEX_SCHEMA, ERROR_SCHEMA)
    if payload is None:
        return _refuse("source header is not an index or an error record")
    if invalid_error(payload) is None:
        # The one absence, and the evaluator had to state it to get it. The
        # candidate ledger is discarded so no token is assigned, while the
        # exposure this open really did make is kept.
        if payload["artifact_digest"] != digest:
            return _refuse("source header describes another artifact")
        return ledger, None
    if invalid_index(payload) is not None:
        return _refuse("source header is neither an index nor an error")
    if payload["artifact_digest"] != digest:
        return _refuse("source header describes another artifact")
    ledger = header.ledger
    files: dict[str, object] = {}
    for entry in payload["paths"]:
        offset = entry["offset"]
        if offset >= len(evaluation.evidence_ids):
            return _refuse("source index names an offset the evaluation lacks")
        ref = _evidence_ref(record.ref, evaluation.evidence_ids[offset])
        ledger, opened = _opened(reader, ledger, ref, attempt.step)
        if isinstance(opened, str):
            return _refuse("source file could not be opened")
        body = opened.payload(FILE_SCHEMA)
        if body is None or invalid_file(body) is not None:
            return _refuse("source file does not match its schema")
        if body["path"] != entry["path"] or body["digest"] != entry["digest"]:
            return _refuse("source file does not match its index entry")
        if body["bytes"] != entry["bytes"]:
            return _refuse("source file does not match its index entry")
        files[body["path"]] = body
        ledger = opened.ledger
    view = _reassembled(files, digest, payload["view_digest"])
    if view is None:
        return _refuse("source files do not reassemble the indexed view")
    return ledger, view


def read_sources(experience, reading: tuple[Attempt, ...], ledger: Ledger):
    """Every prior development view this trial is authorized to read."""

    if experience is None:
        return SourceRefusal(message=NO_READER, code="no reader")
    try:
        observation = experience.search(record_kinds=("evaluation",))
    except ExperienceAccessDenied:
        # ``with_opened`` reports these as reasons rather than raising, so the
        # opens below are already total. The search is not, and letting it
        # escape would report a shortfall in this channel through the kernel's
        # generic message instead of the one constant refusal this adapter
        # owns. Only these two: anything else the reader raises is a bug.
        return _refuse("the grant does not authorize the evaluation search")
    except ExperienceBudgetExhausted:
        return _refuse("the experience budget cannot fund the evaluation search")
    if observation.truncated:
        return _refuse("the evaluation search is truncated")
    if len(observation.references) != len(observation.records):
        return _refuse("the evaluation search is inconsistent")
    # A no-op in every run this example declares, and kept because it is the
    # rule rather than the observation: the pushed selection has already made
    # each searched evaluation citable, so ``with_exposure`` gives it no pull
    # position. A policy that ever selected fewer records would make this live,
    # and without it those references would then be unexposed and unopenable.
    ledger = ledger.with_exposure(observation.references)
    priors: list[tuple[int, SourceTree | None]] = []
    for record in observation.records:
        matches = [
            item
            for item in reading
            if item.evaluation == record.ref and item.diagnosis is not None
        ]
        if len(matches) != 1:
            return _refuse("no single validated diagnosis for this evaluation")
        outcome = _prior(experience, ledger, record, matches[0])
        if isinstance(outcome, SourceRefusal):
            return outcome
        ledger, view = outcome
        priors.append((matches[0].step, view))
    return SourceReading(ledger=ledger, priors=tuple(priors))


__all__ = [
    "NO_READER",
    "UNREADABLE",
    "SourceReading",
    "SourceRefusal",
    "read_sources",
]
