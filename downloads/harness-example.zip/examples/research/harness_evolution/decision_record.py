"""The immutable, content-addressed private-selection decision record.

Written once, after the last reachable phase — private selection alone on a
no-selection outcome, or held-out too once it has run. Not a Meta-Evolve
artifact: it never enters selection, lineage, export, or promotion. Its own
digest names its filename (``decision-<digest>.json``), so ``locate`` can
find it without trusting a caller-supplied name, and a conflicting write is
definitionally impossible — the digest *is* the content's own identity, the
same atomic seal-or-reseal contract :mod:`phase_plans` uses for its plans.

Duplicate-content occurrences stay distinct throughout: every occurrence
below is named by its exact trial and artifact ids, never by content digest
alone, so two development trials with equal bytes remain two separate rows.
Export, when eligible, names the *development* occurrence — never the
artifact occurrence a seed-only private run itself creates.
"""

from __future__ import annotations

from pathlib import Path

from meta_evolve.domain import ContentDigest, FrozenMap

import decision_sections
import phase_plans
import private_selection
from decision_sections import MEASURED_ACCOUNTING  # noqa: F401


DECISION_SCHEMA = "harness-private-selection-decision/v3"



def build(
    *,
    random_seed: int,
    development_run: object,
    proposer_identity: str,
    development_evaluator_identity: str,
    private_evaluator_identity: str,
    held_out_evaluator_identity: str,
    private_plan: dict[str, object],
    evaluated: tuple[private_selection.PrivateRun, ...],
    selected: private_selection.PrivateRun | None,
    held_out_plan: dict[str, object],
    episode_membership: dict[str, str],
    ceilings: dict[str, object],
    store_facts: dict[str, object],
    comparison: object | None = None,
    baseline_run: object | None = None,
    candidate_run: object | None = None,
    exported: object | None = None,
    development_accounting: phase_accounting.PhaseAccounting | None = None,
    private_accounting: phase_accounting.PhaseAccounting | None = None,
    held_out_accounting: phase_accounting.PhaseAccounting | None = None,
) -> dict[str, object]:
    """The full decision payload. Deterministic given its inputs alone."""

    rankable_ids = frozenset(
        item.id.value for item in private_selection.rankable_candidates(development_run)
    )
    return {
        "schema": DECISION_SCHEMA,
        "random_seed": random_seed,
        "search_run_id": development_run.id.value,
        "component_identities": {
            "proposer": proposer_identity,
            "development_evaluator": development_evaluator_identity,
            "private_evaluator": private_evaluator_identity,
            "held_out_evaluator": held_out_evaluator_identity,
        },
        # Which episodes each split holds, and that all three are disjoint --
        # a claim about the whole suite, which no single split can make, so it
        # is recorded once here rather than folded into three evaluator
        # versions that each only know their own membership.
        "episode_membership": dict(sorted(episode_membership.items())),
        # What the spending below was allowed to be, as declared at the time.
        "ceilings": ceilings,
        "development_occurrences": decision_sections.development_occurrences(
            development_run, rankable_ids
        ),
        "private_plan_digest": digest_of(private_plan),
        "private_runs": decision_sections.private_records(
            evaluated, store_facts.get("private", {})
        ),
        "selection": decision_sections.selection_record(selected),
        "held_out_plan_digest": digest_of(held_out_plan),
        "held_out": decision_sections.held_out_record(
            held_out_plan,
            comparison,
            baseline_run,
            candidate_run,
            store_facts.get("held_out", {}),
        ),
        # What each phase's store says about itself, read from its committed
        # events with no registry. A digest check catches a decision edited
        # without reseal; only comparing these against the stores catches one
        # edited *and* resealed, where content and filename agree again.
        "stores": store_facts,
        "accounting": {
            "development": decision_sections.accounting_entry(development_accounting),
            "private": decision_sections.accounting_entry(private_accounting),
            "held_out": decision_sections.accounting_entry(held_out_accounting),
        },
        "export": (
            {
                "selected_trial_id": selected.occurrence.id.value,
                "digest": exported.digest,
            }
            if selected is not None and exported is not None
            else None
        ),
        "promotion": "external",
    }


def digest_of(payload: dict[str, object]) -> str:
    """This record's identity, defined over the form it is sealed in.

    Canonicalized first, so the digest of a payload built in memory and the
    digest of that same payload read back from its sealed JSON are the same
    number by construction rather than by coincidence. Without that, a field
    holding a tuple would digest one way before sealing and another way after
    -- and ``decision_replay`` checks exactly that equality.
    """

    return ContentDigest.for_payload(
        FrozenMap(phase_plans.canonical(payload))
    ).value


def filename_for(payload: dict[str, object]) -> str:
    return f"decision-{digest_of(payload)}.json"


def path_for(root: Path, payload: dict[str, object]) -> Path:
    return root / filename_for(payload)


def seal(root: Path, payload: dict[str, object]) -> dict[str, object]:
    """Seal the decision at its own digest-named path.

    The digest names the file, so two different payloads can never collide
    at the same path — a conflict here would mean the digest itself
    collided, not that two decisions disagreed about one filename.
    """

    sealed = phase_plans.canonical(payload)
    return phase_plans.seal(path_for(root, sealed), sealed)


def locate(root: Path, digest: str) -> dict[str, object] | None:
    return phase_plans.locate(root / f"decision-{digest}.json")


__all__ = [
    "DECISION_SCHEMA",
    "build",
    "digest_of",
    "filename_for",
    "locate",
    "path_for",
    "seal",
]
