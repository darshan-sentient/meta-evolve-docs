"""The two registration stages, and the two run shapes they feed.

The staging is the load-bearing part. ``build_development_components`` is
complete on its own -- it registers the proposer, the context policy, and the
development evaluator, and nothing it touches constructs the private or
held-out episode membership. ``register_later_components`` adds the other two
evaluators to that same registry afterwards, importing the later split at the
moment it is genuinely due. Building only the first is what proves the staging
is real rather than merely conventional.

What each component *is* -- its budget, its grant, its declared module closure
-- lives in :mod:`flagship_declarations`, which this module re-exports so
``main`` keeps one import for both.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.domain import ComponentRef

import durable_runs

from diagnosis_context import (
    HarnessDiagnosisContext,
    build_harness_diagnosis_context,
)
from development_evaluation import evaluate_development
from confined_proposer import propose_confined_fixture
from fixture_responder import FIXTURE_MODEL

from flagship_declarations import (
    BASELINE,
    CHILD_BOUNDARY_MODULES,
    CONTEXT,
    DEVELOPMENT_EVALUATION_MODULES,
    HELD_OUT_BUDGET,
    PLANNER,
    SEARCH_BUDGET,
    SHARED_EVALUATION_MODULES,
    SOURCE_ACCESS,
    _later_evaluation_modules,
    _version,
    child_root_module,
    citation_ledger_module,
    citation_rendering_module,
    confined_proposer_module,
    confined_responder_module,
    confinement_policy_module,
    development_evaluation_module,
    diagnosis_context_module,
    diagnosis_module,
    diagnosis_reading_module,
    diagnosis_rendering_module,
    call_usage_module,
    evaluation_core_module,
    fixture_responder_module,
    proposal_manifest_module,
    proposal_retention_module,
    source_decoding_module,
    source_pull_module,
    source_reading_module,
    source_rendering_module,
    source_schema_module,
    source_view_module,
    tfd_module,
)


@dataclass(frozen=True, slots=True)
class DevelopmentComponents:
    """Everything the development search needs, and nothing later needs.

    Building only this — never ``Components`` below — is what proves private
    and held-out are registered after the search completes rather than
    merely used after it: nothing here imports or registers either.
    """

    registry: meta.Registry
    proposer: ComponentRef
    development_evaluator: ComponentRef


@dataclass(frozen=True, slots=True)
class Components:
    registry: meta.Registry
    proposer: ComponentRef
    development_evaluator: ComponentRef
    held_out_evaluator: ComponentRef
    private_evaluator: ComponentRef


def build_development_components() -> DevelopmentComponents:
    """The trusted outer process's pre-search build: development side only."""

    registry = meta.Registry()
    proposer = registry.register_proposer(
        "m8:tfd-fixture",
        "3",
        propose_confined_fixture,
        deterministic=True,
        retry_safe=True,
        dependencies=(
            tfd_module,
            fixture_responder_module,
            source_reading_module,
            source_pull_module,
            source_rendering_module,
            source_schema_module,
            source_decoding_module,
            source_view_module,
            proposal_manifest_module,
            proposal_retention_module,
            citation_rendering_module,
            citation_ledger_module,
            call_usage_module,
            diagnosis_rendering_module,
            diagnosis_reading_module,
            diagnosis_module,
            *CHILD_BOUNDARY_MODULES,
        ),
        configuration={
            "model": FIXTURE_MODEL,
            "schema": proposal_manifest_module.SCHEMA,
            # The confined boundary is this proposer's behaviour, so it is in
            # this proposer's identity. The declared modules above cover what
            # a static walk can see; these three cover what it cannot -- the
            # exact bytes copied onto the child's root, the policy the child
            # is launched under, and the envelope the two sides agree on.
            "child": child_root_module.child_identity(),
            "confinement": confinement_policy_module.CONFINEMENT_POLICY,
            "protocol": confined_responder_module.ENVELOPE_PROTOCOL,
        },
    )
    # durable-local rebuilds the context policy from the registry for both
    # fresh execution and resume, so the declaration below is a promise the
    # registry has to be able to keep. An unregistered policy fails closed
    # before any event is written.
    registry.register_context_policy(
        "harness-diagnosis",
        "1",
        build_harness_diagnosis_context,
        deterministic=True,
        retry_safe=True,
        dependencies=(
            diagnosis_context_module,
            diagnosis_rendering_module,
            diagnosis_reading_module,
            diagnosis_module,
        ),
    )
    # The development split's own declared identity, reachable without any
    # later membership existing -- see development_evaluation.CONFIGURATION.
    development = development_evaluation_module.CONFIGURATION
    development_evaluator = registry.register_evaluator(
        "m8:repository-episodes",
        _version(development),
        evaluate_development,
        deterministic=True,
        retry_safe=True,
        dependencies=DEVELOPMENT_EVALUATION_MODULES,
        configuration=development,
    )
    return DevelopmentComponents(registry, proposer, development_evaluator)


def _later_evaluation():
    """The later split's module, imported at the moment it is genuinely due.

    One accessor rather than an import statement in each caller, so "the
    private and held-out membership is constructed after the search" has a
    single place it can be observed -- and a single place it could be broken.
    """

    import later_evaluation

    return later_evaluation


def register_later_components(development: DevelopmentComponents) -> Components:
    """Registered only after the development search has completed.

    Shares ``development``'s registry: durable-local resolves every
    component from the registry by name, so a private or held-out run needs
    these registered before it starts, not before the search does.

    The import is here, in the function body, rather than at module scope.
    That is the staging itself, not a style choice: ``later_evaluation`` builds
    the private and held-out episode membership at import time, so a top-level
    import would construct both the moment ``main`` was loaded -- before the
    development components were built, let alone before the search ran.
    """

    later_module = _later_evaluation()
    modules = _later_evaluation_modules(later_module)
    held_out = later_module.evaluator_configuration("held_out")
    held_out_evaluator = development.registry.register_evaluator(
        "m8:held-out-repository-episodes",
        _version(held_out),
        later_module.evaluate_held_out,
        deterministic=True,
        retry_safe=True,
        dependencies=modules,
        configuration=held_out,
    )
    private = later_module.evaluator_configuration("private")
    private_evaluator = development.registry.register_evaluator(
        "m8:private-repository-episodes",
        _version(private),
        later_module.evaluate_private,
        deterministic=True,
        retry_safe=True,
        dependencies=modules,
        configuration=private,
    )
    return Components(
        development.registry,
        development.proposer,
        development.development_evaluator,
        held_out_evaluator,
        private_evaluator,
    )


def build_components() -> Components:
    """Convenience for callers that want the whole registry built at once.

    ``run_flagship`` never calls this — it calls the two stages above
    directly, with the development search in between, which is the staging
    #227 requires. This exists for tests that only need a working registry.
    """

    return register_later_components(build_development_components())


def _search(
    root: Path,
    components: DevelopmentComponents,
    storage: meta.Storage | None = None,
) -> meta.Run:
    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=components.development_evaluator,
            artifact=harness.HarnessArtifact,
            objectives=(meta.Maximize("quality", satisfy=1.0),),
            budget=SEARCH_BUDGET,
        ),
        seed=BASELINE,
        proposer=components.proposer,
        search=meta.Greedy(max_trials=2),
        context=HarnessDiagnosisContext(),
        experience=SOURCE_ACCESS,
        random_seed=0,
        registry=components.registry,
    )
    # The one place a confined child is actually launched from, so the one
    # place the output root it must be denied is declared. Bound around the
    # run rather than at registration: the binding is a fact about *this*
    # invocation's filesystem, and folding it into the proposer's declared
    # configuration would make the run id -- and the decision digest built on
    # it -- vary with wherever the caller pointed ``--output``.
    with confined_proposer_module.confined_to(root):
        return durable_runs.run_or_resume(
            experiment,
            storage or meta.Storage.durable(root / "search-run"),
            components.registry,
        )


def _held_out(
    root: Path,
    seed: harness.HarnessArtifact,
    components: Components,
) -> meta.Run:
    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=components.held_out_evaluator,
            artifact=harness.HarnessArtifact,
            objectives=(meta.Maximize("quality"),),
            budget=HELD_OUT_BUDGET,
        ),
        seed=seed,
        proposer=components.proposer,
        search=meta.Greedy(max_trials=0),
        random_seed=0,
        registry=components.registry,
    )
    return durable_runs.run_or_resume(
        experiment, meta.Storage.durable(root), components.registry
    )
