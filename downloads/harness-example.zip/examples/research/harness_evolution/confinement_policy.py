"""Kernel-enforced confinement for the process that holds proposer authority.

Ported from ``examples/research/systems_optimization/confinement.py`` at
``6d340ce`` (#198), which demonstrates the same claim for a different
candidate: *a confined process can neither read nor write what it is being
judged against, apart from the interpreter installation inside it.* Only the
scope changed. #198 confines a worker that runs in place inside its
repository; this example's confined child runs from a copied minimal root
(``child_root.py``), so what must stay denied is the *original* repository
(source, later-split modules, everything) **and** this run's own output root
-- the directory holding decision records and the harness export, which a
copied-root design does not put out of reach on its own. Neither guard is
re-derived: the mechanism, the rights, and the failure-closed shape are
#198's.

**Why the kernel and not Python.** An in-process guard is an ordinary Python
function a confined child could patch or step around through ``gc``. The
operating system is asked instead: the confined process cannot patch it, and
it holds across ``exec`` into every child.

**Two mechanisms, one repository policy.** macOS's ``file-read-data`` denial
covers both file contents and directory enumeration; Landlock names
``READ_FILE`` and ``READ_DIR`` separately and grants both only on its
allow-list. ``declaration()`` names the boundary they share and never the
mechanism: two machines enforcing it by different means must declare one
evaluator identity, or a fixed seed would stop producing one decision
identity.

**Where the mechanisms live.** macOS is a profile this module writes, because
it is a handful of lines of SBPL. Linux is ``confinement_landlock.py``
(ctypes/ABI/ruleset) plus ``confinement_landlock_entry.py`` (the small script
that applies the ruleset and ``exec``s the child) -- split in two so neither
file crosses the repository's line guideline.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import confinement_landlock
from confinement_landlock import MINIMUM_LANDLOCK_ABI


HERE = Path(__file__).resolve().parent
# ``examples/research/harness_evolution`` -> the repository that holds it.
REPOSITORY = HERE.parents[2]

# The policy, not the mechanism. Retained in the proposer's declared identity,
# so it has to mean the same thing on every platform that can enforce it.
CONFINEMENT_POLICY = "confined-child-cannot-read-or-write-outside-its-copied-root-v1"

SANDBOX_EXEC = Path("/usr/bin/sandbox-exec")
LANDLOCK_ENTRY_FILE = HERE / "confinement_landlock_entry.py"

# Everything the confined interpreter legitimately reads, beyond the child
# root itself. The original repository and the run's output root are absent,
# which is the point; ``sys.prefix`` is present even when it lives inside the
# repository, because that is where the interpreter and its standard library
# are -- ``readable_paths`` refuses outright rather than silently widening the
# boundary if an exemption would reach either one.
_LINUX_READABLE = (
    "/usr", "/lib", "/lib64", "/bin", "/sbin",
    "/etc", "/dev", "/proc",
)
# ``/tmp`` and ``/var/tmp`` are deliberately *not* in that list, and their
# absence is load-bearing rather than tidy. Landlock is allow-list only -- it
# has no deny rule, so ``denied_roots`` below cannot be expressed on Linux at
# all -- and a run's output root is very often a temporary directory. A
# blanket ``/tmp`` exemption would therefore hand the confined child read
# access to exactly the private-selection and decision records this boundary
# exists to keep it away from, on the one platform where nothing else could
# take that access back. The child's own root lives under a temporary
# directory too, and it is granted by its exact path a few lines below, so
# removing the blanket costs the child nothing it is entitled to.

# The one path outside its own child root a confined process writes:
# ``/dev/null``, for whatever the responder's own code sends to its standard
# streams. Writes are an allow-list on both platforms, matching Landlock's own
# model, so a leaked write has nowhere but the workspace and this to land.
BLACKHOLE = "/dev/null"

# What a path may not contain if it is going to be quoted into an SBPL string.
# All three end the string early: a quote closes it, a newline ends the rule,
# and a trailing backslash escapes the closing quote so the rest of the
# profile is read as part of the path.
UNSAFE_IN_A_PROFILE = ('"', "\\", "\n")


class ConfinementUnavailable(RuntimeError):
    """Raised instead of running anything without a boundary."""


def landlock_abi() -> int:
    """The kernel's Landlock ABI, or a negative number when it has none."""

    if sys.platform != "linux":
        return -1
    try:
        version, _ = confinement_landlock.abi(confinement_landlock.libc())
    except (AttributeError, OSError):  # pragma: no cover - no `syscall` in libc
        return -1
    return int(version)


def mechanism() -> str:
    """Which kernel facility would confine a process here, or ``""``.

    An ABI below ``MINIMUM_LANDLOCK_ABI`` is *no* mechanism rather than a
    weaker one: this example would rather refuse to run than declare a
    boundary the kernel underneath it cannot hold.
    """

    if sys.platform == "darwin" and SANDBOX_EXEC.is_file():
        return "sandbox-exec"
    return "landlock" if landlock_abi() >= MINIMUM_LANDLOCK_ABI else ""


def supported() -> bool:
    return bool(mechanism())


def declaration() -> dict[str, object]:
    """What the record says was enforced. Deliberately mechanism-free."""

    return {"candidate_confinement": CONFINEMENT_POLICY}


def denied_roots(output_root: Path | str | None) -> tuple[Path, ...]:
    """Every root a confined process must never read or write.

    The original repository always; the run's own output root when the
    caller has one to protect -- private selection and held-out decision
    records live there, and a copied child root does not put them out of
    reach on its own.
    """

    roots = [REPOSITORY]
    if output_root is not None:
        roots.append(Path(output_root).resolve())
    return tuple(roots)


def readable_paths(
    workspace: Path, *, output_root: Path | str | None = None
) -> tuple[str, ...]:
    """The interpreter, its standard library, and the child's own copied root.

    ``sys.prefix`` is exempt because CPython cannot start otherwise. A refusal,
    not a warning, if any exemption would reach this example's own directory
    or the run's output root -- covering it would hand back exactly what the
    boundary exists to hide.
    """

    paths = [sys.prefix, sys.base_prefix, str(workspace)]
    if sys.platform == "linux":
        paths.extend(_LINUX_READABLE)
    ordered = _ordered(paths)
    output = None if output_root is None else Path(output_root).resolve()
    for path in ordered:
        resolved = Path(path)
        if HERE.is_relative_to(resolved):
            raise ConfinementUnavailable(
                f"a readable exemption ({path}) covers this example's own "
                f"directory ({HERE}); the boundary would be vacuous, so this "
                "example refuses to run rather than pretending to confine"
            )
        if output is not None and output.is_relative_to(resolved):
            raise ConfinementUnavailable(
                f"a readable exemption ({path}) covers this run's own output "
                f"root ({output}); the boundary would be vacuous, so this "
                "example refuses to run rather than pretending to confine"
            )
    return ordered


def writable_paths(workspace: Path) -> tuple[str, ...]:
    """Where a confined process may write: its own child root, and one black hole."""

    return _ordered([str(workspace), BLACKHOLE])


def launcher(
    workspace: Path, *, output_root: Path | str | None = None
) -> tuple[str, ...]:
    """The argv prefix that confines one process, or a refusal.

    Prefixing rather than wrapping keeps the shipped sandbox adapter as it is:
    the bounds, timeout, and output ceilings stay the contract this example
    already declares.
    """

    readable = readable_paths(workspace, output_root=output_root)
    writable = writable_paths(workspace)
    chosen = mechanism()
    if chosen == "sandbox-exec":
        return (
            str(SANDBOX_EXEC),
            "-p",
            _profile(readable, writable, denied_roots(output_root)),
        )
    if chosen == "landlock":
        # ``confinement_landlock_entry.py`` receives these ``os.pathsep``-joined,
        # so a path holding the separator arrives as two that do not exist --
        # and a rule that is skipped is confinement that is not applied.
        if any(os.pathsep in path for path in (*readable, *writable)):
            raise ConfinementUnavailable(
                f"a path to declare contains {os.pathsep!r}: {readable + writable}"
            )
        # ``-B`` is not decoration: without it the interpreter would write
        # ``__pycache__`` into this example's own directory, before applying
        # the restriction that would have stopped it.
        return (
            sys.executable,
            "-I",
            "-B",
            str(LANDLOCK_ENTRY_FILE),
            os.pathsep.join(readable),
            os.pathsep.join(writable),
        )
    raise ConfinementUnavailable(
        f"no confinement on {sys.platform!r}: this example refuses to launch a "
        "confined child in a process it cannot keep away from its source tree"
    )


def _ordered(paths: list[str]) -> tuple[str, ...]:
    """Canonical, de-duplicated, order preserved -- and canonical is load-bearing.

    The kernel acts on the real path: Landlock opens the rule's directory, and
    macOS matches a resolved ``subpath``. Resolving here is what keeps the
    guards above and the rules below from disagreeing about a symlinked
    exemption.
    """

    resolved = (str(Path(path).resolve()) for path in paths if path)
    return tuple(dict.fromkeys(resolved))


def _profile(
    readable: tuple[str, ...], writable: tuple[str, ...], denied: tuple[Path, ...]
) -> str:
    """A ``sandbox-exec`` profile: reads allowed but for the denied roots, writes
    allowed nowhere but the allow-list.

    Later rules win in SBPL, and the asymmetry is deliberate. *Reading* is
    allow-by-default minus the denied roots: deny-by-default reading does not
    survive interpreter startup. *Writing* is deny-by-default from ``/`` down,
    then handed back on the child root and ``/dev/null`` alone -- which is
    exactly what Landlock does on the other platform.
    """

    for path in (*(str(root) for root in denied), *readable, *writable):
        if any(character in path for character in UNSAFE_IN_A_PROFILE):
            raise ConfinementUnavailable(f"path is unsafe in a profile: {path!r}")
    return "\n".join(
        (
            "(version 1)",
            "(allow default)",
            *(f'(deny file-read-data (subpath "{root}"))' for root in denied),
            # From the root down, before anything is handed back.
            '(deny file-write* (subpath "/"))',
            *(f'(allow file-read-data (subpath "{path}"))' for path in readable),
            *(f'(allow file-write* (subpath "{path}"))' for path in writable),
        )
    )


__all__ = [
    "BLACKHOLE",
    "CONFINEMENT_POLICY",
    "LANDLOCK_ENTRY_FILE",
    "MINIMUM_LANDLOCK_ABI",
    "UNSAFE_IN_A_PROFILE",
    "ConfinementUnavailable",
    "declaration",
    "denied_roots",
    "landlock_abi",
    "launcher",
    "mechanism",
    "readable_paths",
    "supported",
    "writable_paths",
]
