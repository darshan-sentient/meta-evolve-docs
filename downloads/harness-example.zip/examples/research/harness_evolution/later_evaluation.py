"""The held-out and private episodes, their evaluators, and the suite law.

Loaded only after the development search has completed. This is the one split
allowed to depend on the other direction: it imports ``development_evaluation``
to enforce, in one place, the law no single split can check alone — that no
episode name is reused across development, held-out, and private.

It does *not* fold the three splits into one shared evaluator identity.
``evaluation_core.evaluator_configuration`` versions each evaluator on its own
membership, so the development evaluator's identity is computable before this
module exists. The combined suite is still built -- the kernel's own ``EpisodeSuite`` law
is half of the disjointness check -- and :data:`SUITE_DIGEST` is its digest.
That digest is deliberately *not* what the decision record carries: it covers
two of the three splits and embeds the interpreter's absolute path, so
recording it would make this decision's identity both incomplete and
host-dependent. :func:`membership_digests` records all three splits plus a
portable combined digest instead, which is where a claim about the whole
suite belongs.
"""

from __future__ import annotations

from meta_evolve.harness import EpisodeSuite

from meta_evolve.ports import EvaluationResult

import evaluation_core
import development_evaluation
from evaluation_core import _episode


HELD_OUT_EPISODES = (
    _episode(
        "repair-slug",
        "Repair slug(text) while preserving its interface.",
        {"slug.py": "def slug(text):\n    return text.strip()\n"},
        "from slug import slug\nraise SystemExit(0 if slug(' A B ') == 'a-b' else 1)\n",
    ),
)

# The private phase's own graded batch: matched cases the development-phase
# proposer never saw, used to confirm the development winner before the one
# untouched held-out comparison. Distinct content from both other splits --
# the uniqueness check right below is the kernel's own law
# (``EpisodeSuite.__post_init__``) extended over a third, example-local tuple
# it does not know about.
PRIVATE_EPISODES = (
    _episode(
        "repair-double",
        "Repair double(value) while preserving its interface.",
        {"double.py": "def double(value):\n    return value\n"},
        "from double import double\nraise SystemExit(0 if double(3) == 6 else 1)\n",
    ),
)

SUITE = EpisodeSuite(
    development=development_evaluation.DEVELOPMENT_EPISODES,
    held_out=HELD_OUT_EPISODES,
)
SUITE_DIGEST = SUITE.digest

_ALL_NAMES = tuple(
    item.name
    for item in (*SUITE.development, *SUITE.held_out, *PRIVATE_EPISODES)
)
if len(set(_ALL_NAMES)) != len(_ALL_NAMES):
    raise ValueError(
        "episode names must be unique across development, held-out, and "
        f"private splits: {_ALL_NAMES}"
    )

_EPISODES_BY_SPLIT = {
    "development": development_evaluation.DEVELOPMENT_EPISODES,
    "held_out": HELD_OUT_EPISODES,
    "private": PRIVATE_EPISODES,
}

HELD_OUT_MEMBERSHIP_DIGEST = evaluation_core.membership_digest(HELD_OUT_EPISODES)
PRIVATE_MEMBERSHIP_DIGEST = evaluation_core.membership_digest(PRIVATE_EPISODES)


def _membership_digest(episodes: tuple) -> str:
    """Kept as this module's own name for the one law it owns.

    The implementation is :func:`evaluation_core.membership_digest`, so every
    split is identified the same way; this is the name the private split's own
    order-sensitivity check is written against.
    """

    return evaluation_core.membership_digest(episodes)


def evaluator_configuration(split: str) -> dict[str, object]:
    """The declared configuration for any of the three splits, by name.

    Delegates to the one implementation in :mod:`evaluation_core` with that
    split's own episodes, so the configuration the development side registers
    before this module loads and the configuration this dispatcher returns for
    ``"development"`` cannot disagree — they are the same call.
    """

    if split not in _EPISODES_BY_SPLIT:
        raise ValueError(
            f"split must be one of {sorted(_EPISODES_BY_SPLIT)}, got {split!r}"
        )
    return evaluation_core.evaluator_configuration(split, _EPISODES_BY_SPLIT[split])


def membership_digests() -> dict[str, str]:
    """Every split's membership identity, plus the combined suite digest.

    Recorded in the decision record: a claim about the whole suite (that all
    three splits are disjoint, and exactly which episodes each holds) is a
    claim only this module can make, so this is where it is stated.
    """

    return {
        "development": development_evaluation.DEVELOPMENT_MEMBERSHIP_DIGEST,
        "held_out": HELD_OUT_MEMBERSHIP_DIGEST,
        "private": PRIVATE_MEMBERSHIP_DIGEST,
        # All three at once, in split order, through the same portable
        # derivation as the three above. Deliberately not ``SUITE.digest``:
        # the kernel's own digest covers two of the three splits and embeds
        # the interpreter's absolute path, so recording it here would make
        # this decision's identity both incomplete and host-dependent. The
        # ``EpisodeSuite`` is still built -- its uniqueness law is half of the
        # disjointness check above -- it is just not the thing digested.
        "all_splits": evaluation_core.membership_digest(
            (
                *development_evaluation.DEVELOPMENT_EPISODES,
                *HELD_OUT_EPISODES,
                *PRIVATE_EPISODES,
            )
        ),
    }


def evaluate_held_out(artifact: object) -> EvaluationResult:
    return evaluation_core._evaluate(artifact, HELD_OUT_EPISODES, "held_out")


def evaluate_private(artifact: object) -> EvaluationResult:
    """Graded on the private cases alone; the same dark channels as held-out.

    ``_evaluate``'s own split gate publishes no diagnosis and no source view
    for any split but development, so private is dark here for the identical
    structural reason held-out already is — not a separate rule to keep in
    sync with it.
    """

    return evaluation_core._evaluate(artifact, PRIVATE_EPISODES, "private")


__all__ = [
    "HELD_OUT_EPISODES",
    "HELD_OUT_MEMBERSHIP_DIGEST",
    "PRIVATE_EPISODES",
    "PRIVATE_MEMBERSHIP_DIGEST",
    "SUITE",
    "SUITE_DIGEST",
    "evaluate_held_out",
    "evaluate_private",
    "evaluator_configuration",
    "membership_digests",
]
