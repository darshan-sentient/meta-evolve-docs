"""The checks replay can make from the output directory alone.

No registry, no codecs, no example component. Each one re-derives a claim from
the store it is a claim *about* and requires the sealed record to agree.

That distinction is what makes these worth having. Verifying a decision's
filename against its own content catches an edit made without recomputing the
digest. It cannot catch an edit that was *resealed* -- recompute the digest,
rename the file, and content and filename agree again. Forged component
identities, a forged membership or ceiling declaration, a private measurement
that never happened, an executed phase relabelled as skipped: every one of
those survives a reseal, and none of them survives being compared against the
events the run actually committed.
"""

from __future__ import annotations

from pathlib import Path

import phase_plans
import store_reading

from replay_failure import ReplayFailure


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ReplayFailure(message)


def verify_stores(root: Path, decision: dict[str, object]) -> None:
    """Every sealed store claim, re-derived from that store's own events.

    The manifests are the load-bearing part: each carries the implementation
    and configuration digest a component's version was derived from, so a
    version string edited to name a different component no longer matches the
    run that used it.
    """

    sealed = decision.get("stores")
    _require(isinstance(sealed, dict), "the decision seals no store facts to check")

    def _compare(label: str, claim: dict[str, object]) -> None:
        relative = claim.get("store")
        _require(
            isinstance(relative, str), f"{label} seals no store path to re-read"
        )
        try:
            actual = store_reading.phase_facts(root, str(relative))
        except (FileNotFoundError, ValueError) as error:
            raise ReplayFailure(
                f"{label}: {relative} cannot be read back: {error}"
            ) from error
        differing = {
            key: (claim.get(key), value)
            for key, value in actual.items()
            if claim.get(key) != value
        }
        _require(
            not differing,
            f"{label} does not match the store it names ({relative}): {differing}",
        )

    _compare("the development phase", sealed["development"])
    for trial_id, claim in sorted(sealed.get("private", {}).items()):
        _compare(f"the private run for {trial_id!r}", claim)
    for role, claim in sorted(sealed.get("held_out", {}).items()):
        _compare(f"the {role} held-out role", claim)


def verify_identities(decision: dict[str, object]) -> None:
    """The sealed component references really are the ones the store recorded.

    Silent for a run that recorded none, which is a property of the run and
    not a hole here: the kernel writes component manifests only for a run it
    resolved through a registry (``RunCapabilities`` refuses them outright for
    a local one), so a run configured around a provider client commits nothing
    to compare these identities against. The opt-in live driver is exactly
    that run, by necessity -- an SDK client cannot be rebuilt from a name --
    and it used to reach "the development store records 0 proposer
    manifests", which reads as a forgery. :func:`unverifiable` names the gap
    instead, beside the two declarations that share it.

    A forgery cannot reach here by blanking the sealed block:
    :func:`verify_stores` has already compared it against the store's own
    events, so emptied manifests are a mismatch there.
    """

    manifests = decision["stores"]["development"]["component_manifests"]
    if not manifests:
        return
    identities = decision["component_identities"]
    for role_name, declared in (
        ("proposer", identities["proposer"]),
        ("evaluator", identities["development_evaluator"]),
    ):
        matching = [
            item
            for key, item in manifests.items()
            if key.startswith(f"{role_name}:")
        ]
        _require(
            len(matching) == 1,
            f"the development store records {len(matching)} {role_name} manifests",
        )
        version = matching[0]["version"]
        _require(
            f"version='{version}'" in declared,
            f"the sealed {role_name} identity names a version the development "
            f"store does not record: sealed={declared!r} recorded={version!r}",
        )


def verify_recorded_identities(decision: dict[str, object]) -> None:
    """Every identity the decision states twice must state the same thing.

    ``stores`` is verified against committed events; the private rows and
    held-out roles then repeat several of those identities in their own
    shape. A repeated field is a second place a forgery can live, and it had
    one: a held-out role's ``evaluation_id`` could be edited and resealed
    while the ``stores`` block beside it stayed correct, because nothing
    compared the two.
    """

    stores = decision["stores"]
    _require(
        decision["search_run_id"] == stores["development"]["run_id"],
        "the decision's development run id is not the one its store records",
    )
    for row in decision["private_runs"]:
        trial = row["source_trial_id"]
        facts = stores["private"].get(trial)
        _require(facts is not None, f"private row {trial!r} has no store facts")
        for field, against in (
            ("private_run_id", "run_id"),
            ("private_evaluation_id", "final_evaluation_id"),
            ("private_store", "store"),
            ("quality", "quality"),
        ):
            _require(
                row[field] == facts[against],
                f"private row {trial!r} states {field}={row[field]!r} while its "
                f"store records {facts[against]!r}",
            )
        _require(
            row["rankable"] == (facts["quality"] is not None and not facts["failed"]),
            f"private row {trial!r} claims rankable={row['rankable']!r} against "
            "a store that says otherwise",
        )
    for role, info in decision["held_out"]["roles"].items():
        facts = stores["held_out"].get(role)
        _require(facts is not None, f"held-out role {role!r} has no store facts")
        for field, against in (
            ("run_id", "run_id"),
            ("evaluation_id", "final_evaluation_id"),
            ("store", "store"),
        ):
            _require(
                info[field] == facts[against],
                f"held-out role {role!r} states {field}={info[field]!r} while its "
                f"store records {facts[against]!r}",
            )


def verify_declarations(
    decision: dict[str, object],
    *,
    episode_membership: dict[str, str],
    ceilings: dict[str, object],
) -> None:
    """The two sealed fields the output directory cannot check on its own.

    ``episode_membership`` and ``ceilings`` are *declarations*. Nothing in a
    committed event stream is derived from them, so there is no counterpart
    in the output directory to compare them against, and a replay reading
    only that directory genuinely cannot tell a forged one from a real one.
    Saying so is the point of this function existing separately: the limit is
    named and testable rather than hidden inside a check that quietly does
    not cover them.

    A caller that *holds the example code* can close it, and this is how.
    Note what the comparison means: this asks whether the decision's
    declarations match what the code declares now, which is a reproducibility
    question, not a question about what the run committed.
    """

    # Through the same encoding both sides will have been sealed in: a sealed
    # declaration is JSON, and JSON has no tuple, so a live declaration can be
    # equal in every way that matters and still compare unequal on type alone.
    _require(
        decision["episode_membership"] == phase_plans.canonical(episode_membership),
        f"the sealed episode membership is not the one this code declares: "
        f"sealed={decision['episode_membership']!r}",
    )
    _require(
        decision["ceilings"] == phase_plans.canonical(ceilings),
        "the sealed ceilings are not the ones this code declares",
    )


def verify_plan_consistency(
    decision: dict[str, object],
    private_plan: dict[str, object],
    held_out_plan: dict[str, object],
) -> None:
    """A plan and the decision built on it must describe the same phases.

    A skip plan beside an executed decision -- or the reverse -- is the one
    inconsistency that would let a promotion look planned when it was not, or
    a planned comparison vanish without a trace.
    """

    held_out = decision["held_out"]
    _require(
        held_out["status"] == held_out_plan["status"],
        f"the held-out plan says {held_out_plan['status']!r} and the decision "
        f"says {held_out['status']!r}",
    )
    _require(
        held_out_plan["selected_trial_id"] == decision["selection"]["selected_trial_id"],
        "the held-out plan and the decision name different selected occurrences",
    )
    if held_out["status"] == "skipped":
        _require(
            held_out_plan.get("reason") == held_out.get("reason"),
            "the skipped held-out plan and the decision give different reasons",
        )
        _require(not held_out["roles"], "a skipped held-out phase names roles")
        _require(decision["export"] is None, "a skipped held-out phase has an export")
    else:
        _require(
            sorted(held_out["roles"]) == sorted(held_out_plan["roles"]),
            "the held-out plan and the decision name different roles",
        )
    planned = {item["trial_id"] for item in private_plan["occurrences"]}
    recorded = {item["source_trial_id"] for item in decision["private_runs"]}
    _require(
        planned == recorded,
        f"the private plan and the decision name different occurrences: "
        f"planned={sorted(planned)} recorded={sorted(recorded)}",
    )
    for item in decision["private_runs"]:
        _require(
            item["private_store"]
            in {entry["store"] for entry in private_plan["occurrences"]},
            f"private run {item['source_trial_id']!r} names a store the plan "
            "never promised",
        )


def verify_selection_rule(decision: dict[str, object]) -> None:
    """Re-run the declared rule over the sealed keys, registry-free.

    Each rankable row carries the exact key it was ranked by, so this is the
    rule applied to the record rather than the record's winner taken on trust.
    """

    keys = {
        item["source_trial_id"]: item["selection_key"]
        for item in decision["private_runs"]
        if item["rankable"]
    }
    for item in decision["private_runs"]:
        expected = (
            None
            if not item["rankable"]
            else [item["quality"], -item["source_logical_step"]]
        )
        _require(
            item["selection_key"] == expected,
            f"private row {item['source_trial_id']!r} seals a selection key that "
            f"does not match its own quality and step",
        )
    selected = decision["selection"]["selected_trial_id"]
    if not keys:
        _require(
            selected is None,
            f"no private row ranked, but the decision selects {selected!r}",
        )
        return
    winner = max(keys, key=lambda trial: keys[trial])
    _require(
        selected == winner,
        f"the declared rule elects {winner!r} over the sealed keys, but the "
        f"decision names {selected!r}",
    )
    _require(
        decision["selection"]["selected_key"] == keys[winner],
        "the decision's winning key is not the key its winner was ranked by",
    )


__all__ = [
    "verify_declarations",
    "verify_identities",
    "verify_recorded_identities",
    "verify_plan_consistency",
    "verify_selection_rule",
    "verify_stores",
]
