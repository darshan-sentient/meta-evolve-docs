"""Deterministic M8 flagship: trusted programmable harness evolution.

The command itself, and nothing else: the three phases in order, each measured
and each sealed before the next begins. What a phase is *made of* lives in
:mod:`flagship_components`; how a finished run is *printed* lives in
:mod:`flagship_report`. Shared constants and dependency declarations live in
:mod:`flagship_declarations`.
"""

from __future__ import annotations

import argparse
import time
from collections.abc import Callable
from pathlib import Path

import meta_evolve as meta
from meta_evolve import harness

import ceilings
import decision_record
import observations
import phase_accounting
import phase_plans
import private_selection
import store_facts

import development_evaluation
import evaluation_core

import flagship_components
import flagship_declarations
import flagship_report


def _measured_chars(phase: str):
    """The non-identity byte totals for one run, for the observations journal.

    Handed to ``observations.measure`` rather than computed into the decision:
    these two counts inherit a measured wall time through the kernel's record
    rendering (see :mod:`observations`), so they are retained beside the
    elapsed time they came from rather than inside a digest that has to be
    reproducible.
    """

    def measured(run) -> dict[str, object]:
        accounting = phase_accounting.for_runs(phase, run)
        return {
            "context_chars": accounting.context_chars,
            "pull_chars": accounting.pull_chars,
            "committed_wall_seconds": accounting.wall_seconds,
        }

    return measured


def _rankable(*runs: meta.Run) -> int:
    """How many of these runs' final evaluations produced an exact quality."""

    return sum(
        1
        for run in runs
        if run is not None
        and run.trials()[-1].state == "evaluated"
        and "quality" in run.trials()[-1].metrics
    )


def _declared_ceilings(later) -> dict[str, object]:
    """Every bound this decision was made under, from the modules that own it."""

    return ceilings.build(
        search_budget=flagship_declarations.SEARCH_BUDGET,
        private_budget=private_selection.PRIVATE_BUDGET,
        held_out_budget=flagship_declarations.HELD_OUT_BUDGET,
        inner_budget=evaluation_core.INNER_BUDGET,
        source_access=flagship_declarations.SOURCE_ACCESS,
        episode_processes={
            "development": tuple(
                item.process
                for item in development_evaluation.DEVELOPMENT_EPISODES
            ),
            "private": tuple(item.process for item in later.PRIVATE_EPISODES),
            "held_out": tuple(item.process for item in later.HELD_OUT_EPISODES),
        },
    )


def run_flagship(
    root: Path,
    *,
    overwrite: bool = False,
    clock: Callable[[], float] = time.monotonic,
) -> flagship_report.FlagshipResult:
    development = flagship_components.build_development_components()
    search = observations.measure(
        clock,
        root,
        "development",
        flagship_declarations.SEARCH_BUDGET.wall_seconds,
        lambda: flagship_components._search(root, development),
        label="search-run",
        measured=_measured_chars("development"),
    )
    components = flagship_components.register_later_components(development)
    later = flagship_components._later_evaluation()

    # Write-ahead: the private plan is sealed before any private run begins,
    # naming every rankable occurrence and where its private run will live.
    candidates = private_selection.rankable_candidates(search)
    private_plan = phase_plans.seal(
        phase_plans.private_plan_path(root),
        phase_plans.build_private_plan(search.id.value, candidates),
    )

    def _around_private(occurrence, run_one):
        """Each private run measured on its own, under its own ceiling."""

        return observations.measure(
            clock,
            root,
            "private",
            private_selection.PRIVATE_BUDGET.wall_seconds,
            run_one,
            label=phase_plans.private_store(
                occurrence.logical_step, occurrence.id.value
            ),
            measured=_measured_chars("private"),
        )

    evaluated = private_selection.evaluate_candidates(
        search,
        private_evaluator=components.private_evaluator,
        proposer=components.proposer,
        registry=components.registry,
        storage_for=lambda occurrence: meta.Storage.durable(
            root
            / phase_plans.private_store(occurrence.logical_step, occurrence.id.value)
        ),
        around=_around_private,
    )
    selected = private_selection.select(evaluated)

    # Sealed after selection: an execute plan naming both held-out roles, or
    # an empty-role skip -- never held-out work without a plan committed
    # first, and never a plan committed before selection has an answer.
    held_out_plan = phase_plans.seal(
        phase_plans.held_out_plan_path(root), phase_plans.build_held_out_plan(selected)
    )

    baseline = candidate = comparison = exported = None
    if selected is not None:
        def _role(role: str, seed: harness.HarnessArtifact) -> meta.Run:
            store = phase_plans.held_out_store(role)
            return observations.measure(
                clock,
                root,
                "held_out",
                flagship_declarations.HELD_OUT_BUDGET.wall_seconds,
                lambda: flagship_components._held_out(root / store, seed, components),
                label=store,
                measured=_measured_chars("held_out"),
            )

        baseline = _role("baseline", flagship_declarations.BASELINE)
        candidate = _role("candidate", selected.occurrence.artifact.value)
        comparison = meta.compare_harnesses(baseline, candidate)
        if comparison.promotion_eligible:
            exported = meta.export_harness(
                selected.occurrence.artifact,
                root / "selected-harness",
                overwrite=overwrite,
            )

    development_accounting = phase_accounting.for_runs("development", search)
    phase_accounting.verify_inner_episodes(
        development_accounting,
        len(development_evaluation.DEVELOPMENT_EPISODES),
        rankable_evaluations=len(candidates),
    )
    private_accounting = None
    if evaluated:
        private_accounting = phase_accounting.for_runs(
            "private", *[item.run for item in evaluated]
        )
        # Structural, and checked rather than asserted in prose: neither later
        # phase declares a context policy or an experience grant, so both must
        # account for zero pushed context, zero pull, and zero source records.
        phase_accounting.verify_zero_context_and_pull(private_accounting)
        phase_accounting.verify_candidate_set_cardinality(
            private_accounting, len(evaluated)
        )
        phase_accounting.verify_inner_episodes(
            private_accounting,
            len(later.PRIVATE_EPISODES),
            rankable_evaluations=sum(1 for item in evaluated if item.rankable),
        )
    held_out_accounting = None
    if baseline is not None:
        held_out_accounting = phase_accounting.for_runs(
            "held_out", baseline, candidate
        )
        phase_accounting.verify_zero_context_and_pull(held_out_accounting)
        phase_accounting.verify_inner_episodes(
            held_out_accounting,
            len(later.HELD_OUT_EPISODES),
            rankable_evaluations=_rankable(baseline, candidate),
        )

    # Read back off each phase's own store, registry-free, so the sealed
    # record carries what a later replay can re-derive and compare against.
    facts = store_facts.gather(root, evaluated, baseline is not None)
    decision = decision_record.seal(
        root,
        decision_record.build(
            random_seed=0,
            development_run=search,
            proposer_identity=str(components.proposer),
            development_evaluator_identity=str(components.development_evaluator),
            private_evaluator_identity=str(components.private_evaluator),
            held_out_evaluator_identity=str(components.held_out_evaluator),
            private_plan=private_plan,
            evaluated=evaluated,
            selected=selected,
            held_out_plan=held_out_plan,
            episode_membership=later.membership_digests(),
            ceilings=_declared_ceilings(later),
            store_facts=facts,
            comparison=comparison,
            baseline_run=baseline,
            candidate_run=candidate,
            exported=exported,
            development_accounting=development_accounting,
            private_accounting=private_accounting,
            held_out_accounting=held_out_accounting,
        ),
    )
    return flagship_report.FlagshipResult(
        root, search, baseline, candidate, comparison, exported, decision
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--overwrite", action="store_true")
    arguments = parser.parse_args()
    result = run_flagship(arguments.output, overwrite=arguments.overwrite)
    print(flagship_report.report(result))


if __name__ == "__main__":
    main()
