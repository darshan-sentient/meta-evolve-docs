"""User-owned Textual Feedback Descent callable with structured output.

The trusted adapter refuses partial diagnosis, derives editable surfaces from
the exact parent declaration, and hands the structured-output boundary one
request built from those two things alone.

What comes back is a manifest, not a bare edit. :func:`propose` owns request,
decode, authorization, application, and retention, and takes the responder as
an argument so fixture and live paths differ only in who answers.

Retention is staged, because refusal is not all-or-nothing. Citations resolve
first and survive a later invalid field; a complete manifest survives a typed
mutation failure. What a stage never established is never invented.
"""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.domain import FrozenMap, ProposerFailure, SourceTree

import call_usage
import proposal_retention

from citation_ledger import DuplicateCitation, Ledger
from citation_rendering import ledger_for, parent_citations
from diagnosis import artifact_digest
from diagnosis_reading import Attempt, DiagnosisError
from diagnosis_rendering import validate_bundle
from fixture_responder import (
    FIXTURE_INPUT_TOKENS,
    FIXTURE_MODEL,
    FIXTURE_OUTPUT_TOKENS,
    FIXTURE_TOKENS,
    structured_body,
)
from source_reading import SourceRefusal, read_sources
from source_rendering import prior_source_comparison
from source_view import canonical_view
from proposal_manifest import (
    ManifestRefusal,
    Responder,
    StructuredResponse,
    decode,
)


# The fixture's one declared call cost, built through the same validator a
# live responder's report goes through -- so "the only difference is the
# answer" stays true of the accounting as well as of the text.
FIXTURE_CALL = call_usage.derive(
    input_tokens=FIXTURE_INPUT_TOKENS,
    output_tokens=FIXTURE_OUTPUT_TOKENS,
    total_tokens=FIXTURE_TOKENS,
)


def editable_surfaces(parent: harness.HarnessArtifact) -> tuple[str, ...]:
    """The allowlist comes from the parent declaration, never from context."""

    return (parent.planner.name, parent.context_policy.name)


def _request(
    parent: harness.HarnessArtifact,
    diagnosis: str,
    quality: object,
    ledger: Ledger,
    parent_tokens: tuple[str, ...],
    comparison: str,
) -> dict[str, object]:
    """The exact input handed to the structured-output boundary."""

    return {
        # Every array rule the decoder enforces is stated here, because the
        # provider schema cannot carry two of them: Structured Outputs lists no
        # `uniqueItems` among its supported keywords, so a fully conforming
        # response can still repeat a token or a risk, and ordering is not
        # expressible at all. A live model refused for a constraint it was
        # never told would be a refusal about this prompt rather than about the
        # proposal.
        "instruction": (
            "Propose exactly one HarnessMutation on a declared surface and "
            "return the harness proposal manifest: cite the authorized "
            "observations the edit rests on by token, each token at most once "
            "and in the order they are listed; name the development behavior "
            "the edit should fix; and name what it puts at risk, each risk at "
            "most once."
        ),
        "editable_surfaces": editable_surfaces(parent),
        "planner": parent.planner.value,
        "context_policy": dict(parent.context_policy.configuration),
        "development_quality": quality,
        "governed_diagnosis": diagnosis,
        "citable_evidence": ledger.render(),
        "parent_citations": parent_tokens,
        # Example-owned rendering over two values this adapter already
        # holds. Not an M8.7 diff_source operation, and it costs no
        # reader operation.
        "prior_source_comparison": comparison,
    }


def _refuse(message: str, **details: object) -> meta.ProposalResult:
    """Unrankable, with no candidate — never a low score.

    Details stay evaluator- or parent-derived because the governed policy
    selects typed outcome failures whole for later proposals.
    """

    return meta.ProposalResult(
        failure=ProposerFailure(message=message, details=details)
    )


def _parent_report(
    reading: tuple[Attempt, ...], parent: harness.HarnessArtifact
) -> Attempt | None:
    """The parent's own evaluated attempt, found by the digest it was evaluated at.

    Parent, not latest. The bundle now carries rejected siblings too, and after
    a regression the most recent evaluation in it is not the one that produced
    this parent — so ordering would report a quality no attempt here holds.
    The port exposes only the parent digest while the projection keeps equal
    content occurrences separate. Two matching attempts are therefore truly
    ambiguous and cause a refusal rather than a guess.
    """

    digest = artifact_digest(parent)
    matches = [
        item
        for item in reading
        if item.diagnosis is not None
        and item.diagnosis_ref is not None
        and item.diagnosis["artifact_digest"] == digest
        and item.quality is not None
        and item.evaluation is not None
    ]
    return matches[0] if len(matches) == 1 else None


def propose(
    parent: harness.HarnessArtifact,
    context: meta.ProposerContext,
    respond: Responder,
) -> meta.ProposalResult:
    """One governed observation, one manifest, one mapping onto shipped records."""

    if context.bundle.truncated:
        return _refuse(
            "governed diagnosis bundle is truncated",
            records=context.bundle.usage.records,
            chars=context.bundle.usage.chars,
        )
    reading = validate_bundle(context.bundle)
    if isinstance(reading, DiagnosisError):
        return _refuse(
            "governed diagnosis bundle is unreadable",
            code=reading.code,
            trial=reading.trial or "",
        )
    report = _parent_report(reading, parent)
    if report is None:
        return _refuse("no single authorized evaluation of this parent")
    try:
        ledger = ledger_for(context.bundle.records)
    except DuplicateCitation:
        # Only this one exception is a fact about the bundle. Catching
        # ``ValueError`` would report a future bug in building or rendering the
        # ledger as an unreadable context, and a typed refusal is the one
        # outcome a run keeps — so anything else propagates as the bug it is.
        return _refuse(
            "governed diagnosis bundle is unreadable",
            code="duplicate experience reference",
            trial="",
        )
    citations = parent_citations(report, ledger)
    # The pulled channel appends to the pushed ledger and never interleaves
    # with it: the kernel orders its selection before every pull result, and a
    # derivation in any other order is refused as an unordered subsequence.
    sources = read_sources(context.experience, reading, ledger)
    if isinstance(sources, SourceRefusal):
        return _refuse(sources.message, code=sources.code)
    view = canonical_view(parent)
    if not isinstance(view, SourceTree):
        # Unreachable through a run — the kernel digested this artifact at
        # proposal completion — and typed anyway, because a total function
        # whose caller assumes success is only total on paper.
        return _refuse("parent canonical source view is unbuildable", code=view.code)
    request = _request(
        parent,
        context.bundle.rendered,
        report.quality,
        sources.ledger,
        citations,
        prior_source_comparison(view, sources.priors),
    )
    response = respond(request)
    decoded = decode(response.raw, sources.ledger, editable_surfaces(parent))
    if isinstance(decoded, ManifestRefusal):
        return proposal_retention.incomplete(response, decoded)
    value = decoded.value
    applied = parent.apply(
        harness.HarnessMutation(
            surface=decoded.surface,
            # A mapping value becomes the kernel's frozen one, which is what
            # the mutation's own constructor would make of it anyway.
            value=value if isinstance(value, str) else FrozenMap(value),
        )
    )
    retained = proposal_retention.complete(response, decoded)
    if not isinstance(applied, harness.HarnessArtifact):
        return meta.ProposalResult(failure=applied, **retained)
    return meta.ProposalResult(candidate=applied, **retained)


def structured_response(request: dict) -> StructuredResponse:
    """Wrap the fixture's plain JSON text into the kernel-typed envelope.

    ``fixture_responder`` stays free of ``meta_evolve`` — it is also the
    module copied onto the confined proposer child's own root — so this is
    the one place that reads its declared model and token cost and builds the
    value :func:`propose` requires. Kept under this name (rather than
    imported directly) so existing tests that monkeypatch
    ``tfd.structured_response`` to spy on or replace the fixture's answer
    keep working unchanged.
    """

    return StructuredResponse(
        raw=structured_body(request),
        model=FIXTURE_MODEL,
        usage=meta.Usage(tokens=FIXTURE_TOKENS),
        call=FIXTURE_CALL,
    )


def propose_tfd(
    parent: harness.HarnessArtifact,
    context: meta.ProposerContext,
) -> meta.ProposalResult:
    """The registered two-argument callable, answered by the fixture."""

    return propose(parent, context, structured_response)


__all__ = ["FIXTURE_CALL", "editable_surfaces", "propose", "propose_tfd"]
