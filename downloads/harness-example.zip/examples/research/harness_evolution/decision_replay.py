"""Verify a sealed decision using only its output directory.

Read-only Run views use the shipped harness codec, without rebuilding a registry
or executing an evaluator, proposer, provider, or candidate. They establish exact
candidate coverage, source occurrence identity, private measurements, selection,
held-out comparison, accounting, and exported content. Raw store facts retain
the component manifests and evaluation IDs absent from the public trial view.

Ceilings and episode membership remain sealed declarations; component identities
also remain unverifiable for runs that recorded no manifests. See unverifiable()
and the README for those limits. A registry is optional, not a weaker replay mode.
"""

from __future__ import annotations

import json
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import RunId

import decision_record
import phase_plans
import private_selection
import replay_integrity

from replay_failure import ReplayFailure
from replay_private import (
    reopen_private,
    verify_candidate_set,
    verify_selection,
)
from replay_reconciliation import verify_accounting, verify_comparison, verify_export


def find_decision_path(root: Path) -> Path:
    """The one decision record under ``root``."""

    matches = sorted(root.glob("decision-*.json"))
    if not matches:
        raise ReplayFailure(f"no decision record found under {root}")
    if len(matches) > 1:
        raise ReplayFailure(f"more than one decision record under {root}: {matches}")
    return matches[0]


def load_decision(root: Path) -> dict[str, object]:
    """Load and verify the decision: its filename names its own digest."""

    path = find_decision_path(root)
    claimed_digest = path.name.removeprefix("decision-").removesuffix(".json")
    payload = json.loads(path.read_text(encoding="utf-8"))
    computed_digest = decision_record.digest_of(payload)
    if computed_digest != claimed_digest:
        raise ReplayFailure(
            f"{path} does not match its own filename digest: content hashes "
            f"to {computed_digest!r}"
        )
    if decision_record.locate(root, claimed_digest) != payload:
        raise ReplayFailure(f"{path} is not reachable through decision_record.locate")
    return payload


def reopen_development(
    root: Path, decision: dict[str, object], registry: meta.Registry | None = None
) -> meta.Run:
    """The development run the decision names, read-only.

    ``meta.Run`` is a read-only query view over committed events — unlike
    ``meta.resume``, which requires writable storage because it may complete
    pending work. A finished run has none, so a plain view is both correct
    and the only thing ``Storage.read_only`` permits.
    """

    storage = meta.Storage.read_only(root / "search-run")
    return meta.Run(RunId(decision["search_run_id"]), storage, registry=registry)


def verify_held_out(
    root: Path, decision: dict[str, object], registry: meta.Registry | None = None
) -> tuple[meta.Run, ...]:
    """Reopen both held-out runs if executed; confirm each evaluation id."""

    held_out = decision["held_out"]
    if held_out["status"] == "skipped":
        if decision["export"] is not None:
            raise ReplayFailure("a skipped held-out phase must have no export")
        return ()
    reopened = []
    for role, info in sorted(held_out["roles"].items()):
        directory = root / phase_plans.held_out_store(role)
        if not directory.is_dir():
            raise ReplayFailure(f"the {role} held-out store is missing: {directory}")
        try:
            run = meta.Run(
                RunId(info["run_id"]),
                meta.Storage.read_only(directory),
                registry=registry,
            )
            final = run.trials()[-1]
        except Exception as error:  # noqa: BLE001 - any unreadable store is a failure
            raise ReplayFailure(
                f"the {role} held-out run cannot be reopened from {directory}: "
                f"{type(error).__name__}"
            ) from error
        # The *trial* id here, against the field that names a trial. The
        # evaluation's own occurrence id is a different identity and is
        # checked registry-free, against the store, in ``replay_integrity``.
        if final.id.value != info["trial_id"]:
            raise ReplayFailure(
                f"{role} held-out trial id does not match the sealed record"
            )
        reopened.append(run)
    return tuple(reopened)


def verify_plans(root: Path, decision: dict[str, object]) -> None:
    """The sealed private and held-out plans still match their own digests."""

    private_plan = phase_plans.locate(phase_plans.private_plan_path(root))
    if private_plan is None:
        raise ReplayFailure(f"no private plan found under {root}")
    if decision_record.digest_of(private_plan) != decision["private_plan_digest"]:
        raise ReplayFailure("the private plan no longer matches its sealed digest")
    held_out_plan = phase_plans.locate(phase_plans.held_out_plan_path(root))
    if held_out_plan is None:
        raise ReplayFailure(f"no held-out plan found under {root}")
    if decision_record.digest_of(held_out_plan) != decision["held_out_plan_digest"]:
        raise ReplayFailure("the held-out plan no longer matches its sealed digest")


def unverifiable(decision: dict[str, object]) -> tuple[str, ...]:
    """What this record's own replay could not check, named rather than implied.

    ``ceilings`` and ``episode_membership`` are unconditional: both are sealed
    declarations with no counterpart in any committed event, so a resealed
    forgery of either is indistinguishable from the truth to a reader holding
    only the output directory. ``component_identities`` joins them exactly
    when the development store recorded no component manifests -- a
    registry-free run. Per-record rather than a constant, because the
    deterministic path does record them and a reader has to be able to tell
    which kind of record this is.
    """

    always = ("ceilings", "episode_membership")
    if decision["stores"]["development"]["component_manifests"]:
        return always
    return (*always, "component_identities")


def replay(
    root: Path, registry: meta.Registry | None = None
) -> dict[str, object]:
    """Verify the sealed decision under ``root``. Executes nothing.

    Both call forms run the same checks. Built-in harness decoding needs no registry.
    """

    decision = load_decision(root)
    private_plan = phase_plans.locate(phase_plans.private_plan_path(root))
    held_out_plan = phase_plans.locate(phase_plans.held_out_plan_path(root))
    verify_plans(root, decision)
    replay_integrity.verify_plan_consistency(decision, private_plan, held_out_plan)
    replay_integrity.verify_stores(root, decision)
    replay_integrity.verify_identities(decision)
    replay_integrity.verify_recorded_identities(decision)
    # Before the selection rule, because a rule re-run over a candidate set
    # that has quietly lost a member elects the right winner from the wrong
    # field and reports nothing.
    replay_integrity.verify_selection_rule(decision)
    development_run = reopen_development(root, decision, registry)
    verify_candidate_set(development_run, decision)
    expected_plan = phase_plans.build_private_plan(
        development_run.id.value, private_selection.rankable_candidates(development_run)
    )
    if private_plan != expected_plan:
        raise ReplayFailure("the private plan does not match committed development occurrences")
    private_runs = reopen_private(root, decision, development_run, registry)
    verify_selection(decision)
    held_out_runs = verify_held_out(root, decision, registry)
    verify_accounting(decision, development_run, private_runs, held_out_runs)
    verify_export(root, decision, development_run)
    verify_comparison(decision, development_run, held_out_runs)
    return decision


__all__ = [
    "ReplayFailure",
    "unverifiable",
    "find_decision_path",
    "load_decision",
    "reopen_development",
    "reopen_private",
    "replay",
    "verify_accounting",
    "verify_candidate_set",
    "verify_export",
    "verify_held_out",
    "verify_plans",
    "verify_selection",
]
