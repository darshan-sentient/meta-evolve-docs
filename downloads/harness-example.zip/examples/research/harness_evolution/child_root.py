"""Materialize the confined proposer child's minimal root.

Copies exactly two files — ``development_child.py``, the entry point, and
``fixture_responder.py``, the fixture's decision logic — into a fresh
directory outside both this repository and any run's output root, then writes
the request the child is meant to answer. Nothing else reaches the child's
root: what is not copied here is not on the machine the confined process
starts on, which is the structural half of #227's isolation claim. It is not
the authority boundary on its own — ``confinement_policy.py`` is — but
together they mean a child that somehow referenced an absolute path back into
the repository would still find nothing to import and, failing that, the
kernel refusing to open it.
"""

from __future__ import annotations

import json
import shutil
import tempfile
from hashlib import sha256
from pathlib import Path

from meta_evolve.ports import Workspace


HERE = Path(__file__).resolve().parent
CHILD_MODULES = ("development_child.py", "fixture_responder.py")
REQUEST_FILE = "request.json"


def materialize(request: dict) -> Workspace:
    """A fresh child root: the two files above, plus the serialized request."""

    root = Path(tempfile.mkdtemp(prefix="m8-confined-child-"))
    for name in CHILD_MODULES:
        shutil.copy2(HERE / name, root / name)
    (root / REQUEST_FILE).write_text(json.dumps(request), encoding="utf-8")
    return Workspace(root)


def dispose(workspace: Workspace) -> None:
    shutil.rmtree(workspace.root, ignore_errors=True)


def child_identity() -> dict[str, object]:
    """The exact bytes this puts on the child's root, named by content.

    Part of the *proposer's* declared identity, not a diagnostic. The confined
    child is where the proposer's answer actually comes from, and these files
    are the whole of what runs there -- so editing one changes what this
    proposer does while leaving every module the registry can statically walk
    untouched. ``development_child.py`` is launched by path and
    ``fixture_responder.py`` is imported only inside the child, so neither is
    reachable by the dependency declaration that covers ordinary imports.

    Content digests rather than paths: where the copy came from is a fact
    about this checkout, and putting it in an identity would make the same
    proposer read as two different ones on two machines.
    """

    return {
        "request_file": REQUEST_FILE,
        "modules": {
            name: sha256((HERE / name).read_bytes()).hexdigest()
            for name in sorted(CHILD_MODULES)
        },
    }


__all__ = [
    "CHILD_MODULES",
    "REQUEST_FILE",
    "child_identity",
    "dispose",
    "materialize",
]
