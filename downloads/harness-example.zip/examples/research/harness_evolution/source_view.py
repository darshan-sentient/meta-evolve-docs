"""The canonical source view of a harness artifact: layout, encoding, bounds.

A view is a three-file :class:`SourceTree` *value*: the complete mutable
surface values of one evaluated harness, in a layout fixed here. It is never an
artifact. Nothing in this module mints an identity, reads a record, or touches
a run — it turns one already-committed artifact into bytes, so the evidence and
reader modules above it can be about authority rather than about encoding.
Reading those bytes back is :mod:`source_decoding`, which faces a different
input domain and is kept separate for that reason.

The layout is deliberately not ``harness/export.py``'s. That one is the egress
contract for a *selected* harness: flat, indented for a human, and carrying the
artifact id and digest it was exported from. Those identities are exactly what
an evidence value must not carry, and a format that may evolve for human
readers is exactly what a wire schema must not be pinned to. Two contracts that
happen to describe the same two surfaces, kept apart on purpose.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from hashlib import sha256

from meta_evolve.domain import ContentDigest, SourceTree
from meta_evolve.harness import HarnessArtifact, PolicyParam, TextParam


VIEW_SCHEMA = "agent-harness/v1"
RENDERER = "canonical-harness-source-view/v1"

MANIFEST_PATH = "manifest.json"
PLANNER_PATH = "surfaces/planner.md"
POLICY_PATH = "surfaces/context_policy.json"
SOURCE_PATHS = (MANIFEST_PATH, PLANNER_PATH, POLICY_PATH)

SOURCE_LIMITS = {
    "files": {MANIFEST_PATH: 8192, PLANNER_PATH: 16384, POLICY_PATH: 16384},
    "view": 40960,
    # Nesting is a size bound too, and the one a byte count does not catch.
    # 1,810 bytes of "[[[[..." is under every limit above and still exhausts
    # the interpreter's stack in json.loads, in the canonical re-encode, and in
    # FrozenMap. A declared depth makes that a typed refusal at a fixed number
    # rather than a crash at whatever the recursion limit happens to be.
    "depth": 32,
}

VIEW_ERROR_CODES = frozenset(
    {"view-too-large", "view-not-canonical", "view-not-reconstructible"}
)


@dataclass(frozen=True, slots=True)
class SourceViewError:
    """Why no view exists, as one of three fixed internal codes.

    It carries no rejected value. The code travels into evidence a later
    proposal may read, and a schema that echoed the input would publish the
    surface value the refusal exists to withhold.
    """

    code: str

    def __post_init__(self) -> None:
        if self.code not in VIEW_ERROR_CODES:
            raise ValueError("source view error code is not declared")


def dumps(value: object) -> str:
    r"""The one JSON encoding both files use, and the reader re-runs.

    ``ensure_ascii=False`` is load-bearing rather than cosmetic. It is what
    makes an unencodable surface value reach :class:`SourceTree` and be refused
    there; escaped to ``\udNNN`` it would survive encoding and round-trip back
    into an artifact, and the refusal would never happen.
    """

    return (
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
    )


def _plain(value: object) -> object:
    """Frozen configuration as the plain JSON types, recursively."""

    if isinstance(value, Mapping):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_plain(item) for item in value]
    return value


def _declaration(surface: TextParam | PolicyParam, kind: str, path: str) -> dict:
    return {
        "type": kind,
        "name": surface.name,
        "component": {
            "role": surface.component.role,
            "name": surface.component.name,
            "version": surface.component.version,
            "origin": surface.component.origin,
        },
        "interface": surface.interface,
        "path": path,
    }


def canonical_view(artifact: HarnessArtifact) -> SourceTree | SourceViewError:
    """The complete surface values of one artifact, or why they do not encode.

    Pure, and total over every constructible ``HarnessArtifact``. ``FrozenMap``
    already refuses a non-string configuration key and ``PolicyParam`` already
    refuses NaN and infinity, so ``allow_nan=False`` and the key check are
    defense in depth; the one refusal a constructible artifact can still reach
    is an unencodable surface value, which ``SourceTree`` raises on.

    That refusal is a law about this function, not a path a run reaches. The
    kernel digests every candidate payload at proposal completion, so an
    artifact carrying an unencodable surface fails there and is never evaluated.
    """

    if not isinstance(artifact, HarnessArtifact):
        raise TypeError("a canonical view is taken of a HarnessArtifact")
    manifest = {
        "schema": VIEW_SCHEMA,
        "surfaces": [
            _declaration(artifact.planner, "text", PLANNER_PATH),
            _declaration(artifact.context_policy, "policy", POLICY_PATH),
        ],
    }
    try:
        return SourceTree(
            {
                MANIFEST_PATH: dumps(manifest),
                PLANNER_PATH: artifact.planner.value,
                POLICY_PATH: dumps(_plain(artifact.context_policy.configuration)),
            }
        )
    except (TypeError, ValueError, RecursionError):
        return SourceViewError("view-not-canonical")


def encodable(content: str) -> bool:
    """Whether this text can become UTF-8 bytes at all.

    A lone surrogate cannot. ``TextParam`` accepts one and ``SourceTree``
    refuses it, so the producer never publishes one — but a validator reading
    another occurrence's payload must decide that rather than raise, because
    every byte length and digest below starts with this same encode.
    """

    try:
        content.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return True


def file_bytes(content: str) -> int:
    return len(content.encode("utf-8"))


def view_bytes(view: SourceTree) -> int:
    """The sum of the exact file lengths — not the size of any rendering."""

    return sum(file_bytes(content) for content in view.values())


def file_digest(content: str) -> str:
    return sha256(content.encode("utf-8")).hexdigest()


def view_digest(view: SourceTree) -> str:
    return ContentDigest.for_payload(view.to_payload()).value


def exceeds_depth(text: str, limit: int = 0) -> bool:
    """Whether this JSON text nests deeper than the declared bound.

    Scanned off the raw text rather than the parsed value, because parsing is
    the thing that recurses. Strings are skipped, so a bracket inside a surface
    value is not nesting.
    """

    bound = limit or SOURCE_LIMITS["depth"]
    depth = 0
    in_string = False
    escaped = False
    for character in text:
        if in_string:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                in_string = False
            continue
        if character == '"':
            in_string = True
        elif character in "[{":
            depth += 1
            if depth > bound:
                return True
        elif character in "]}":
            depth -= 1
    return False


def oversized(view: SourceTree) -> bool:
    """Every bound, checked independently rather than as one total.

    Depth is enforced here as well as in the reader, because a view the
    producer publishes and its own reader then refuses is exactly the poison
    the self-check in :mod:`source_evidence` exists to prevent.
    """

    if view_bytes(view) > SOURCE_LIMITS["view"]:
        return True
    if any(
        file_bytes(view.get(path, "")) > limit
        for path, limit in SOURCE_LIMITS["files"].items()
    ):
        return True
    return any(
        exceeds_depth(view.get(path, ""))
        for path in (MANIFEST_PATH, POLICY_PATH)
    )


__all__ = [
    "MANIFEST_PATH",
    "PLANNER_PATH",
    "POLICY_PATH",
    "RENDERER",
    "SOURCE_LIMITS",
    "SOURCE_PATHS",
    "SourceViewError",
    "VIEW_ERROR_CODES",
    "VIEW_SCHEMA",
    "canonical_view",
    "dumps",
    "encodable",
    "exceeds_depth",
    "file_bytes",
    "file_digest",
    "oversized",
    "view_bytes",
    "view_digest",
]
