"""Verifier-grounded diagnosis facts emitted by the fixed development evaluator.

These facts are evaluator-owned, not candidate-owned: every value here is
something the fixed verifier itself observed. Hidden grader source, expected
values, process output, candidate-authored evidence, and every held-out fact
are excluded by construction rather than filtered out afterwards, so the
governed context policy never has to trust a redaction step.

Surfaces are published as digests only. That is enough for a later attempt to
be told *which* declared surface an earlier attempt changed without publishing
what it changed it to, which stays the separate audited-source concern.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping

import meta_evolve as meta
from meta_evolve.domain import ContentDigest, Failure
from meta_evolve.harness import HarnessArtifact, RepositoryEpisode
from meta_evolve.harness.codec import HarnessArtifactCodec
from meta_evolve.ports import EvidenceDraft


DIAGNOSIS_SCHEMA = "harness-diagnosis/v1"
DEVELOPMENT = "development"

_CODEC = HarnessArtifactCodec()


def artifact_digest(artifact: HarnessArtifact) -> str:
    """The digest the kernel commits for this exact manifest."""

    return ContentDigest.for_payload(_CODEC.encode(artifact)).value


def surface_digests(artifact: HarnessArtifact) -> dict[str, str]:
    """One digest per declared surface. No surface value ever leaves here."""

    return {
        artifact.planner.name: ContentDigest.for_payload(
            artifact.planner.value
        ).value,
        artifact.context_policy.name: ContentDigest.for_payload(
            artifact.context_policy.configuration
        ).value,
    }


def _exit_code(trial: object) -> int | None:
    """The grader's exit status — never its stdout or stderr."""

    for item in trial.evidence:
        if item.kind == "process-result":
            code = item.data.get("exit_code")
            return code if isinstance(code, int) else None
    return None


def episode_facts(run: meta.Run, episode: RepositoryEpisode) -> dict[str, object]:
    """Reduce one finished inner episode to what the verifier observed.

    The episode name and instruction are public task text the worker already
    received. Everything else is the fixed grader's own verdict. The score is
    read to reach that verdict and then left behind: publishing a number the
    diagnosis never renders would widen the channel for nothing.
    """

    final = run.trials()[-1]
    score = final.metrics.get("score")
    if final.failure is not None:
        verifier = "failed"
    elif score == 1.0:
        verifier = "passed"
    else:
        verifier = "rejected"
    return {
        "name": episode.name,
        "instruction": episode.instruction,
        "verifier": verifier,
        "exit_code": _exit_code(final),
        "failure": final.failure.kind if final.failure is not None else None,
    }


def _participant(facts: Mapping[str, object]) -> dict[str, object]:
    return {"name": facts["name"], "instruction": facts["instruction"]}


def diagnosis_evidence(
    artifact: HarnessArtifact,
    facts: Iterable[Mapping[str, object]],
    split: str,
    *,
    evaluator_failure: Failure | None = None,
) -> EvidenceDraft:
    """Cluster observed failures and record the invariants already holding.

    Only episodes that actually completed contribute. An evaluation cut short
    keeps the facts it did observe and preserves its typed failure; it never
    invents a passing invariant for work that never ran.
    """

    clusters: dict[tuple[object, ...], list[dict[str, object]]] = {}
    passing: list[dict[str, object]] = []
    for item in facts:
        if item["verifier"] == "passed":
            passing.append(_participant(item))
            continue
        key = (item["verifier"], item["exit_code"], item["failure"])
        clusters.setdefault(key, []).append(_participant(item))
    return EvidenceDraft(
        kind=DIAGNOSIS_SCHEMA,
        data={
            "schema": DIAGNOSIS_SCHEMA,
            "split": split,
            "artifact_digest": artifact_digest(artifact),
            "surfaces": surface_digests(artifact),
            "failures": tuple(
                {
                    "verifier": verifier,
                    "exit_code": exit_code,
                    "failure": failure,
                    "episodes": tuple(members),
                }
                for (verifier, exit_code, failure), members in clusters.items()
            ),
            "passing": tuple(passing),
            "complete": evaluator_failure is None,
            "evaluator_failure": (
                None
                if evaluator_failure is None
                else {"kind": evaluator_failure.kind}
            ),
        },
    )


_FIELDS = frozenset(
    {
        "schema",
        "split",
        "artifact_digest",
        "surfaces",
        "failures",
        "passing",
        "complete",
        "evaluator_failure",
    }
)
_CLUSTER_FIELDS = frozenset({"verifier", "exit_code", "failure", "episodes"})
_EPISODE_FIELDS = frozenset({"name", "instruction"})
# A passing episode becomes an invariant, never a failure cluster, so only the
# two negative verdicts may key one.
_CLUSTER_VERDICTS = frozenset({"rejected", "failed"})


def _is_digest(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _invalid_episodes(value: object) -> str | None:
    if not isinstance(value, tuple):
        return "diagnosis episode list is not a sequence"
    for item in value:
        if not isinstance(item, Mapping) or set(item) != _EPISODE_FIELDS:
            return "diagnosis episode fields do not match the schema"
        if not all(
            isinstance(item[name], str) and item[name] for name in _EPISODE_FIELDS
        ):
            return "diagnosis episode fields are not non-empty text"
    return None


def _invalid_cluster(cluster: object) -> str | None:
    """Check what a cluster *says*, not only which keys it carries."""

    if not isinstance(cluster, Mapping) or set(cluster) != _CLUSTER_FIELDS:
        return "diagnosis failure cluster fields do not match the schema"
    verifier = cluster["verifier"]
    # isinstance before membership: a validator that raises on hostile input
    # is not a validator. Committed evidence normalizes an unhashable value
    # into a FrozenMap, but nothing stops a caller passing a raw dict.
    if not isinstance(verifier, str) or verifier not in _CLUSTER_VERDICTS:
        return "diagnosis failure cluster names an unknown verdict"
    failure = cluster["failure"]
    if failure is not None and not isinstance(failure, str):
        return "diagnosis failure kind is not text"
    if (cluster["verifier"] == "failed") != (failure is not None):
        return "diagnosis verdict contradicts its failure kind"
    exit_code = cluster["exit_code"]
    if exit_code is not None and (
        isinstance(exit_code, bool) or not isinstance(exit_code, int)
    ):
        return "diagnosis exit code is not an integer"
    invalid = _invalid_episodes(cluster["episodes"])
    if invalid is not None:
        return invalid
    if not cluster["episodes"]:
        return "diagnosis failure cluster names no episode"
    return None


def invalid_diagnosis(data: object) -> str | None:
    """Say why a payload may not be read as evaluator diagnosis, or ``None``.

    A reader must not assume the shape of anything it did not build, so this
    checks the whole schema rather than the fields it happens to index. The
    ``split`` check is load-bearing beyond tidiness: it is what would keep a
    later private or held-out split out of a proposer's view even if some
    evaluator started publishing one.
    """

    if not isinstance(data, Mapping) or set(data) != _FIELDS:
        return "diagnosis fields do not match the schema"
    if data["schema"] != DIAGNOSIS_SCHEMA:
        return "diagnosis names another schema"
    if data["split"] != DEVELOPMENT:
        return "diagnosis is not from the development split"
    if not _is_digest(data["artifact_digest"]):
        return "diagnosis artifact digest is malformed"
    surfaces = data["surfaces"]
    if not isinstance(surfaces, Mapping) or not surfaces:
        return "diagnosis declares no surfaces"
    if any(
        not isinstance(name, str) or not _is_digest(digest)
        for name, digest in surfaces.items()
    ):
        return "diagnosis surface digests are malformed"
    if not isinstance(data["complete"], bool):
        return "diagnosis completeness is not a boolean"
    if not isinstance(data["failures"], tuple):
        return "diagnosis failure clusters are not a sequence"
    for cluster in data["failures"]:
        invalid = _invalid_cluster(cluster)
        if invalid is not None:
            return invalid
    invalid = _invalid_episodes(data["passing"])
    if invalid is not None:
        return invalid
    failure = data["evaluator_failure"]
    if data["complete"] != (failure is None):
        return "diagnosis completeness contradicts its evaluator failure"
    if failure is not None and (
        not isinstance(failure, Mapping)
        or set(failure) != {"kind"}
        or not isinstance(failure["kind"], str)
    ):
        return "diagnosis evaluator failure fields do not match the schema"
    return None


def evidence_for(
    artifact: HarnessArtifact,
    split: str,
    capture: EvidenceDraft,
    facts: Iterable[Mapping[str, object]],
    failure: Failure | None,
) -> tuple[EvidenceDraft, ...]:
    """Publish the raw capture, and the governed diagnosis for development only.

    Order is load-bearing, and it is the *evaluator* that owns it rather than
    this function. These two drafts are the tail of a development bundle whose
    head is the source header and its indexed files, so the capture is no longer
    at offset 0 — an earlier version of this docstring promised it always would
    be, and that promise did not survive the pulled channel. What holds is the
    relative order: the diagnosis sits immediately behind the capture.

    Held-out evaluations emit no diagnosis at all, which is why no policy can
    reach a held-out fact through this channel.
    """

    if split != DEVELOPMENT:
        return (capture,)
    return (
        capture,
        diagnosis_evidence(artifact, facts, split, evaluator_failure=failure),
    )


__all__ = [
    "DEVELOPMENT",
    "DIAGNOSIS_SCHEMA",
    "artifact_digest",
    "diagnosis_evidence",
    "episode_facts",
    "evidence_for",
    "invalid_diagnosis",
    "surface_digests",
]
