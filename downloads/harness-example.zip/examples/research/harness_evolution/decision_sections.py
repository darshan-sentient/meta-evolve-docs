"""Each section of the decision payload, built from one phase's outcome.

:mod:`decision_record` owns the record as a whole -- its schema, its
content-addressed identity, and the atomic seal that gives it one. These are
the parts it assembles: what development produced, what each private
evaluation concluded, which occurrence the rule elected, what held-out did or
did not run, and the deterministic slice of a phase's accounting.

Split out because the two answer different questions. "What is this record"
is one contract, checked by its digest; "what does a private outcome look
like" is another, and the second is where the detail lives that a reader has
to be able to audit row by row.
"""

from __future__ import annotations

import phase_accounting
import private_selection


# The three fields of a phase's accounting that are measurements rather than
# identity, and so are retained by ``observations`` instead of sealed here.
# ``wall_seconds`` is elapsed time. The two char totals are elapsed time too,
# one step removed: the kernel renders a pulled record by serializing the
# whole record, an evaluation record carries its own measured
# ``usage.wall_seconds``, and so the decimal expansion of a measured float is
# inside the text whose length is being counted. Every count dimension beside
# them is exact and reconciles every time.
MEASURED_ACCOUNTING = ("wall_seconds", "context_chars", "pull_chars")


def development_occurrences(
    development_run, rankable_ids: frozenset[str]
) -> list[dict[str, object]]:
    """Every development trial, in order, with its private-eligibility flag.

    Recorded for every trial regardless of state: a refusal, a proposer
    failure, or an unrankable evaluation stays inspectable here even though
    it was never privately evaluated.
    """

    return [
        {
            "trial_id": trial.id.value,
            "logical_step": trial.logical_step,
            "state": trial.state,
            "artifact_id": trial.artifact.id.value if trial.artifact is not None else None,
            "eligible_for_private": trial.id.value in rankable_ids,
        }
        for trial in development_run.trials()
    ]


def selection_key(quality: float | None, logical_step: int) -> list[object] | None:
    """The exact tuple the selection rule maximizes, as sealed data.

    Recorded per rankable row rather than left implicit in the winner. The
    rule is "highest private quality, ties broken by the earlier development
    logical step"; sealing the key each row was ranked by is what lets a
    reader re-run that rule over the record instead of taking the winner on
    trust -- and lets replay do the same without knowing the rule's shape.
    """

    return None if quality is None else [quality, -logical_step]


def _outcome(item: private_selection.PrivateRun) -> dict[str, object]:
    """The typed outcome of one private evaluation, rankable or not."""

    if item.rankable:
        return {"state": "evaluated", "failure_kind": None, "unrankable_state": None}
    failure = item.run.trials()[-1].failure
    return {
        "state": "unrankable",
        # The failure's *kind* only. A message is evaluator-authored text and
        # this record is content-addressed identity, not a log.
        "failure_kind": None if failure is None else failure.kind,
        "unrankable_state": item.unrankable_state,
    }


def private_records(
    evaluated: tuple[private_selection.PrivateRun, ...],
    facts: dict[str, dict[str, object]],
) -> list[dict[str, object]]:
    """Every private outcome, rankable or not, one row each.

    A private evaluation that failed is recorded with ``rankable=False`` and
    no quality, rather than omitted. It really happened, it really consumed
    this phase's accounting, and the candidate set it belongs to is the one
    replay reconciles against the development run.
    """

    return [
        {
            "source_trial_id": item.occurrence.id.value,
            "source_artifact_id": item.occurrence.artifact.id.value,
            "source_logical_step": item.occurrence.logical_step,
            "private_run_id": item.run.id.value,
            # The evaluation's own occurrence id, read off the store rather
            # than substituted from the trial that produced it: a trial and
            # its evaluation are two occurrences with two identities, and both
            # are opaque strings, so naming the wrong one is silent.
            "private_evaluation_id": (
                facts.get(item.occurrence.id.value, {}).get("final_evaluation_id")
            ),
            "private_store": facts.get(item.occurrence.id.value, {}).get("store"),
            "rankable": item.rankable,
            "quality": item.quality,
            "outcome": _outcome(item),
            "selection_key": selection_key(
                item.quality, item.occurrence.logical_step
            ),
        }
        for item in evaluated
    ]


def selection_record(
    selected: private_selection.PrivateRun | None,
) -> dict[str, object]:
    if selected is None:
        return {
            "policy": "highest-private-quality-then-earliest-logical-step",
            "selected_trial_id": None,
            "selected_artifact_id": None,
            "selected_key": None,
            "reason": "no privately evaluated occurrence was rankable",
        }
    return {
        "policy": "highest-private-quality-then-earliest-logical-step",
        "selected_trial_id": selected.occurrence.id.value,
        "selected_artifact_id": selected.occurrence.artifact.id.value,
        # The winning key, so "this row won" is checkable against the rows.
        "selected_key": selection_key(
            selected.quality, selected.occurrence.logical_step
        ),
        "reason": None,
    }


def held_out_record(
    held_out_plan: dict[str, object],
    comparison: object | None,
    baseline_run: object | None,
    candidate_run: object | None,
    facts: dict[str, dict[str, object]],
) -> dict[str, object]:
    if held_out_plan["status"] == "skipped":
        return {
            "status": "skipped",
            "reason": held_out_plan.get("reason"),
            "roles": {},
            "comparison_eligible": False,
        }
    return {
        "status": "executed",
        "reason": None,
        "roles": {
            "baseline": {
                "run_id": baseline_run.id.value,
                "trial_id": baseline_run.trials()[-1].id.value,
                # The evaluation's own id, off the store. This used to be the
                # trial id under an ``evaluation_id`` name -- a real identity,
                # but not the one the field claimed.
                "evaluation_id": facts.get("baseline", {}).get("final_evaluation_id"),
                "store": facts.get("baseline", {}).get("store"),
            },
            "candidate": {
                "run_id": candidate_run.id.value,
                "trial_id": candidate_run.trials()[-1].id.value,
                "evaluation_id": facts.get("candidate", {}).get("final_evaluation_id"),
                "store": facts.get("candidate", {}).get("store"),
            },
        },
        # Whether the comparison *rests on two matched rankable evaluations*,
        # which is a different question from whether it favoured the
        # candidate. This was aliased to ``promotion_eligible`` -- the
        # kernel sets that to ``verdict == "improvement"`` -- so a tie and a
        # regression both sealed ``comparison_eligible: False`` beside
        # ``status: "executed"``, reporting an ineligible comparison that had
        # in fact been made on good evidence. #227 separates the two, and
        # gating the export on promotion (which is what ``export`` does) was
        # never in question.
        #
        # ``unrankable`` is the kernel's own name for the case this field is
        # about: ``compare_harnesses`` returns it exactly when either role
        # produced no quality, so anything else is a verdict with matched
        # evidence underneath it.
        "comparison_eligible": bool(
            comparison is not None and comparison.verdict != "unrankable"
        ),
    }


def accounting_entry(
    accounting: phase_accounting.PhaseAccounting | None,
) -> dict[str, object] | None:
    """The deterministic whole of one phase's accounting.

    Everything :class:`~phase_accounting.PhaseAccounting` derives, minus
    :data:`MEASURED_ACCOUNTING` — so the provider-call breakdown, the inner
    episode counts, the source byte total, the citation admissions, and every
    outer and pull *count* are all here, and the three fields that carry a
    measured wall time (directly or through a rendered record) are not.
    Including those would make this record's own digest differ between two
    otherwise-identical runs on different hardware, which would make replay's
    central check unusable. They are retained by :mod:`observations`, keyed to
    phase, so nothing is discarded — only relocated out of identity.
    """

    if accounting is None:
        return None
    return phase_accounting.to_payload(accounting, exclude=MEASURED_ACCOUNTING)


__all__ = [
    "MEASURED_ACCOUNTING",
    "accounting_entry",
    "development_occurrences",
    "held_out_record",
    "private_records",
    "selection_key",
    "selection_record",
]
