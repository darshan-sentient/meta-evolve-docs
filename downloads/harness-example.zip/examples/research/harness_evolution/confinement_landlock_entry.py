"""Restrict this process to an allow-list of paths, then become the real command.

This is the Linux entry point ``confinement_policy.launcher`` prefixes the
real argv with: ``python -I -B <this file> <readable> <writable> <argv...>``.
So this process starts unconfined, applies the ruleset to itself via
``confinement_landlock.restrict``, and then ``execv``s what it was asked to
run. Landlock is inherited across ``exec`` and cannot be undone, which is what
makes a prefix sufficient: the process that ends up holding the confined
child's code never had the authority in the first place.

Split out from the ctypes/ABI logic in ``confinement_landlock.py`` (ported
from #198 @ ``6d340ce``) so that module stays under the repository's line
guideline: this file is the one part of the boundary no test on a non-Linux
machine can execute, so it is kept small and reviewable on its own.

**Standard library only, on purpose.** Nothing here imports ``meta_evolve``
or this example's own package. It runs before the restriction is applied, so
what it loads is code running with full authority. The less of that, the
better -- and a relative import would not resolve when this file is invoked
by absolute path as a loose script.

Its one sibling has to be reached explicitly, and that is what ``-I`` costs.
Isolated mode leaves ``sys.path`` without the script's own directory, so
``import confinement_landlock`` raised ``ModuleNotFoundError`` before the
restriction was ever attempted -- and because this file is the one part of the
boundary a non-Linux machine never executes, a green local suite said nothing
about it. The directory is restored below and nothing else is: ``-I`` still
ignores the environment and the user site, which is the isolation that
matters here.
"""

from __future__ import annotations

import os
import sys

# Before the import, because the import is what needs it.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import confinement_landlock  # noqa: E402


def main(argv: list[str]) -> int:
    """``<readable> <writable> <argv...>``: restrict this process, then become argv.

    The two lists arrive ``os.pathsep``-joined, which is why
    ``confinement_policy.launcher`` refuses a path containing the separator:
    it would arrive here as two that do not exist, and ``restrict`` skips what
    is absent. That refusal belongs to the sender; the shape is checked again
    on arrival because this module can be run by path, and every declared path
    has to be absolute.
    """

    if len(argv) < 3:
        sys.exit(f"usage: {sys.argv[0]} <readable> <writable> <argv...>")
    readable, writable = argv[0].split(os.pathsep), argv[1].split(os.pathsep)
    relative = [path for path in (*readable, *writable) if not os.path.isabs(path)]
    if relative:
        sys.exit(
            f"every path to declare has to be absolute, and {relative} is not: "
            f"a path holding {os.pathsep!r} arrives here as two that do not exist"
        )
    failure = confinement_landlock.restrict(readable, writable)
    if failure is not None:
        sys.exit(failure)
    os.execv(argv[2], argv[2:])
    return 1  # pragma: no cover - ``execv`` replaced this process, or raised


if __name__ == "__main__":  # pragma: no cover - exercised as a subprocess
    raise SystemExit(main(sys.argv[1:]))
