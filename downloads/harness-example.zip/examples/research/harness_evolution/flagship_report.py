"""The finished run, and the seven labelled sections it prints.

Separated from the orchestration for the reason the output audit exists at
all: what the flagship *decided* and how that decision is *rendered* are two
contracts, and a change to the second must not need a change to the first.
Every function here reads a completed result and returns text; none of them
can start work, seal anything, or fail a run.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import meta_evolve as meta
from meta_evolve import harness

import decision_record
import observations
from regression_report import below_seed, held_out_regressions, quality


@dataclass(frozen=True, slots=True)
class FlagshipResult:
    root: Path
    search: meta.Run
    # ``None`` only when private selection found nothing rankable: a sealed
    # no-selection decision, which skips held-out and export entirely rather
    # than falling back to a default winner.
    baseline_held_out: meta.Run | None
    candidate_held_out: meta.Run | None
    comparison: harness.HarnessComparison | None
    exported: harness.HarnessExport | None
    decision: dict[str, object]


_PHASES = ("development", "private", "held_out")

# What the decision section prints instead of the record's own digest. The
# digest and the filename it names are machine-specific -- episode identity
# faithfully covers the absolute interpreter path (see
# ``evaluation_identity``), so two hosts seal two different ones for the same
# decision. #227 keeps those in the sealed output-directory record and has
# stdout report a stable verification status, which is what these are.
DECISION_STATUS = "sealed"
REPLAY_SURFACE = "output-directory"


def _budget_line(value: dict[str, object] | None) -> str:
    if value is None:
        return "unavailable"
    return ",".join(f"{name}:{value[name]}" for name in sorted(value))


def _per_phase(accounting: dict[str, object], field: str) -> str:
    """One accounting field across every phase that recorded any."""

    present = [
        f"{phase}:{accounting[phase][field]}"
        for phase in _PHASES
        if accounting.get(phase) is not None
    ]
    return ",".join(present) if present else "none"


def _accounting_section(decision: dict[str, object]) -> list[str]:
    """The same five accounting lines whatever the outcome was.

    Printed on the no-selection path too. A run that reached no winner still
    spent a development budget and still ran every private evaluation, and a
    report that goes quiet exactly there is quiet about the spending that most
    needs explaining.
    """

    accounting = decision.get("accounting") or {}
    return [
        "[accounting]",
        "accounting=" + _per_phase(accounting, "evaluations"),
        "provider_calls=" + _per_phase(accounting, "provider_calls"),
        "inner_episodes=" + _per_phase(accounting, "inner_episodes"),
        "source_bytes=" + _per_phase(accounting, "source_bytes"),
        "citations=" + _per_phase(accounting, "citations_admitted"),
    ]


def _decision_section(decision: dict[str, object]) -> list[str]:
    """Stable status only. The digest lives in the output directory."""

    return [
        "[decision]",
        f"decision={DECISION_STATUS}",
        f"schema={decision.get('schema', 'unavailable')}",
        f"replay={REPLAY_SURFACE}",
    ]


def report(result: FlagshipResult) -> str:
    """The seven labelled sections of #227's output audit, byte-exact.

    Byte-exact means two things here, and the second is why this function
    prints less than it could.

    It does not depend on where ``--output`` points: ``exported.destination``
    is an absolute path built from the caller's own argument, so it is printed
    relative to this run's output root.

    And it does not depend on *how the run went*, only on what it decided. No
    measured quantity appears: not elapsed time, not the conformance verdict
    derived from it, not the pushed/pulled character totals. All of those are
    retained in ``observations.json``. Printing a conformance verdict would
    have made an uninterrupted run and a resumed one print differently while
    having decided exactly the same thing -- which is the opposite of what a
    byte-exact snapshot is for. The decision's own digest is absent for a
    related reason: episode identity faithfully covers the absolute
    interpreter path, so it is machine-specific, and #227 keeps it in the
    sealed record while stdout reports stable status.

    Sections follow the issue's order -- development, private selection,
    held-out, decision, accounting, export, external promotion. That places
    ``export`` before ``promotion=external``, which reverses their order in
    the A4 flagship this grew from. The reversal is deliberate and is the one
    original-field reordering here: #227 defines the section order, and every
    original field is still printed, unrenamed, with its original value.

    Total over any sealed decision, including a no-selection one: every field
    is read with a fallback rather than indexed, because a reporter that
    raises has told the reader nothing.

    The two lines above ``promotion=external`` are read from retained evidence
    after the run and touch no decision: ``below_seed`` over the development
    run's committed trials, ``held_out_regressions`` over the final held-out
    episode captures. Both print ``unavailable`` whenever a measurement is
    missing, so the values they do print are measured claims rather than
    defaults -- and both are deterministic functions of committed scores, so
    the snapshot stays byte-exact.
    """

    decision = result.decision
    budgets = (decision.get("ceilings") or {}).get("budgets") or {}
    private_runs = decision.get("private_runs") or []
    selection = decision.get("selection") or {}
    selected_id = selection.get("selected_trial_id")
    held_out = decision.get("held_out") or {}

    lines = [
        "[development]",
        f"development={[quality(item) for item in result.search.trials()]}",
        f"development_ceiling={_budget_line(budgets.get('development'))}",
        "[private-selection]",
        f"private_candidates={len(private_runs)}",
        f"private_rankable={sum(1 for item in private_runs if item['rankable'])}",
    ]
    if result.comparison is None or selected_id is None:
        # No privately evaluated occurrence was rankable: a sealed decision,
        # not a fallback to development quality or the baseline. Held-out and
        # export never ran -- and every remaining section still prints, with
        # the typed reason the plan sealed, rather than the report stopping.
        lines.extend(
            [
                "selection=none",
                f"selection_reason={selection.get('reason', 'unavailable')}",
                f"private_ceiling={_budget_line(budgets.get('private'))}",
                "[held-out]",
                f"held_out={held_out.get('status', 'unavailable')}",
                f"held_out_reason={selection.get('reason', 'unavailable')}",
                f"held_out_ceiling={_budget_line(budgets.get('held_out'))}",
                *_decision_section(decision),
                *_accounting_section(decision),
                "[export]",
                "export=none",
                "[promotion]",
                f"below_seed={below_seed(result.search)}",
                "held_out_regressions=unavailable",
                "promotion=external",
            ]
        )
        return "\n".join(lines)
    private_quality = next(
        item["quality"] for item in private_runs if item["source_trial_id"] == selected_id
    )
    lines.extend(
        [
            f"private_quality={private_quality}",
            f"private_ceiling={_budget_line(budgets.get('private'))}",
            "[held-out]",
            f"held_out_baseline={result.comparison.baseline.quality}",
            f"held_out_candidate={result.comparison.candidate.quality}",
            f"verdict={result.comparison.verdict}",
            f"promotion_eligible={result.comparison.promotion_eligible}",
            f"held_out_ceiling={_budget_line(budgets.get('held_out'))}",
            *_decision_section(decision),
            *_accounting_section(decision),
            "[export]",
        ]
    )
    if result.exported is not None:
        relative = result.exported.destination.relative_to(result.root)
        lines.append(f"export={relative}")
        lines.append(f"digest={result.exported.digest}")
    else:
        lines.append("export=none")
    lines.extend(
        [
            "[promotion]",
            f"below_seed={below_seed(result.search)}",
            f"held_out_regressions={held_out_regressions(result)}",
            "promotion=external",
        ]
    )
    return "\n".join(lines)
