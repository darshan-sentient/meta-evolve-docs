"""Reading a canonical view back, from bytes this process did not write.

Split from :mod:`source_view` because the input domain is different, and that
difference is the whole design. ``canonical_view`` runs on an artifact the
kernel has already digested; this module runs on bytes another occurrence
committed and a proposer pulled, so every shape below is hostile until checked:
a wrong file set, non-JSON text, a manifest naming another schema or another
layout, a file that is semantically equal but differently encoded.

The last of those is why validating fields is not enough. After checking the
shape, each JSON file is re-encoded with the producer's own call and required to
match byte for byte, which rejects duplicate keys, alternative key order, and
non-canonical whitespace together — none of which a field-by-field check sees.

Total, and never raises. A refusal here becomes the adapter's typed refusal
about a prior occurrence; an exception here would become a crash in a paid run.

Nesting gets two defences, deliberately, and they cover different inputs. The
declared depth is checked before anything parses, so a view one level over the
bound is refused at a number this schema states — nothing about it recurses, and
no other check here would notice it. ``RecursionError`` is the backstop for the
far end of the same axis: 1,810 bytes of ``[[[[...`` is under every byte limit
and exhausts the stack in ``json.loads``, in the canonical re-encode, and in
``FrozenMap`` before any of those returns. Remove either and the other still
refuses; remove both and the decoder raises, which is the state neither may be
left in.
"""

from __future__ import annotations

import json

from meta_evolve.domain import ComponentRef, FrozenMap, SourceTree
from meta_evolve.harness import HarnessArtifact, PolicyParam, TextParam

from source_view import (
    MANIFEST_PATH,
    PLANNER_PATH,
    POLICY_PATH,
    SOURCE_PATHS,
    VIEW_SCHEMA,
    SourceViewError,
    dumps,
    exceeds_depth,
)


_SURFACE_FIELDS = frozenset({"type", "name", "component", "interface", "path"})
_COMPONENT_FIELDS = frozenset({"role", "name", "version", "origin"})


def _invalid_component(value: object) -> bool:
    return (
        not isinstance(value, dict)
        or set(value) != _COMPONENT_FIELDS
        or any(
            not isinstance(value[name], str) or not value[name]
            for name in _COMPONENT_FIELDS
        )
    )


def _invalid_declaration(value: object, kind: str, path: str) -> bool:
    if not isinstance(value, dict) or set(value) != _SURFACE_FIELDS:
        return True
    if value["type"] != kind or value["path"] != path:
        return True
    if any(
        not isinstance(value[name], str) or not value[name]
        for name in ("name", "interface")
    ):
        return True
    return _invalid_component(value["component"])


def _manifest_of(view: SourceTree) -> dict | None:
    """The manifest exactly as the producer would have written it, or nothing.

    Surface order is checked rather than searched. The declaration order is
    part of the schema, so a view listing the policy first is a different view
    and not a permutation of this one.
    """

    try:
        if exceeds_depth(view[MANIFEST_PATH]):
            return None
        manifest = json.loads(view[MANIFEST_PATH])
    except (KeyError, ValueError, RecursionError):
        return None
    if not isinstance(manifest, dict) or set(manifest) != {"schema", "surfaces"}:
        return None
    if manifest["schema"] != VIEW_SCHEMA:
        return None
    surfaces = manifest["surfaces"]
    if not isinstance(surfaces, list) or len(surfaces) != 2:
        return None
    if _invalid_declaration(surfaces[0], "text", PLANNER_PATH):
        return None
    if _invalid_declaration(surfaces[1], "policy", POLICY_PATH):
        return None
    if dumps(manifest) != view[MANIFEST_PATH]:
        return None
    return manifest


def _configuration_of(view: SourceTree) -> FrozenMap | None:
    """The policy configuration, frozen back exactly as it was published.

    ``FrozenMap`` freezes reloaded objects and arrays back to ``FrozenMap`` and
    tuples, so the round trip is lossless and needs no separate freezing pass.
    """

    try:
        if exceeds_depth(view[POLICY_PATH]):
            return None
        configuration = json.loads(view[POLICY_PATH])
    except (KeyError, ValueError, RecursionError):
        return None
    if not isinstance(configuration, dict):
        return None
    if dumps(configuration) != view[POLICY_PATH]:
        return None
    try:
        return FrozenMap(configuration)
    except (TypeError, ValueError, RecursionError):
        return None


def harness_from_view(view: SourceTree) -> HarnessArtifact | SourceViewError:
    """Reconstruct the exact artifact, or say the bytes are not a view."""

    if not isinstance(view, SourceTree):
        return SourceViewError("view-not-canonical")
    if tuple(sorted(view)) != tuple(sorted(SOURCE_PATHS)):
        return SourceViewError("view-not-canonical")
    manifest = _manifest_of(view)
    configuration = _configuration_of(view)
    if manifest is None or configuration is None:
        return SourceViewError("view-not-canonical")
    planner, policy = manifest["surfaces"]
    try:
        return HarnessArtifact(
            planner=TextParam(
                planner["name"],
                ComponentRef(**planner["component"]),
                planner["interface"],
                view[PLANNER_PATH],
            ),
            context_policy=PolicyParam(
                policy["name"],
                ComponentRef(**policy["component"]),
                policy["interface"],
                configuration,
            ),
        )
    except (TypeError, ValueError, RecursionError):
        return SourceViewError("view-not-canonical")


__all__ = ["harness_from_view"]
