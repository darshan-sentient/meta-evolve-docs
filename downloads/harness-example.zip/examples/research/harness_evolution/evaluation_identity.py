"""What an episode evaluator declares itself to be.

The constants every split's grading shares, and the derivation that turns one
split's episodes into the identity its evaluator is registered at. Separated
from :mod:`evaluation_core`, which knows how to *run* an episode: what a
component is and what it does are two contracts, and only one of them has to
be computable before any episode has been constructed.

That last point is load-bearing rather than tidy. The development evaluator's
identity must be reachable during the pre-search build, when the private and
held-out membership deliberately does not exist yet -- so the derivation lives
here, takes a split's episodes as an argument, and knows nothing about which
splits there are.
"""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.adapters import EvaluationEnvironment
from meta_evolve.domain import ContentDigest, FrozenMap

import diagnosis
import source_schema
from source_view import RENDERER, SOURCE_LIMITS, SOURCE_PATHS


INNER_BUDGET = meta.Budget(evaluations=2, trials=1, tokens=20, wall_seconds=5)
WORKER_MODEL = "deterministic-fixture-worker-v1"
ENVIRONMENT = EvaluationEnvironment(name="python", version="fixture-v1")
SCORING_VERSION = "mean-binary-episode-score-v1"


MEMBERSHIP_SCHEMA = "repository-episode-membership/v2"

# The inherited episode factory puts the absolute ``sys.executable`` into every
# ``ProcessSpec.argv``, so it is inside every payload digested below, and this
# membership digest therefore moves when the interpreter or the checkout moves.
#
# That is retained deliberately rather than normalized away. It is a faithful
# declaration of what actually runs these episodes, and #227's settled plan
# (§3.7) is explicit that portable logical-interpreter identity is *deferred*:
# do not strip identity fields, and do not claim equal decision digests after
# changing the interpreter or checkout environment. A marker substituted here
# would make two genuinely different interpreters declare the same identity,
# which is a worse failure than a digest that honestly varies.
#
# What follows from that, and is honoured elsewhere: cross-host equality of
# decision digests is not an acceptance gate, so the machine-specific digest
# and its filename stay in the sealed output-directory record and never enter
# byte-exact stdout, which reports stable verification status instead.


def membership_digest(episodes: tuple[harness.RepositoryEpisode, ...]) -> str:
    """The ordered, content-addressed identity of one split's membership.

    Not ``EpisodeSuite.digest``: that kernel type has exactly two named
    splits, and private is a third this example owns alone — so every split
    is named the same way here rather than two of them sharing a combined
    digest and the third having none. Order is part of the identity on
    purpose: the private phase's selection rule is
    ``(private_quality, -logical_step)``, so the ceiling this membership
    bounds has to name which position each episode holds, not only which
    episodes are present.

    Environment-sensitive on purpose: the comment above ``MEMBERSHIP_SCHEMA``
    says which field carries that sensitivity and why it is retained rather
    than normalized away.
    """

    return ContentDigest.for_payload(
        FrozenMap(
            {
                "schema": MEMBERSHIP_SCHEMA,
                "episodes": tuple(item.to_payload() for item in episodes),
            }
        )
    ).value


def evaluator_configuration(
    split: str, episodes: tuple[harness.RepositoryEpisode, ...]
) -> dict[str, object]:
    """One split's declared evaluator identity, from that split alone.

    Deliberately *not* a combined suite digest. An evaluator's identity is
    what it publishes and how it grades, and no split's grading depends on
    which episodes another split holds — so folding a combined digest in
    here would make the development evaluator's identity move when held-out
    episodes changed, and would make computing the development evaluator's
    identity require loading the very membership #227 requires stay unloaded
    until the search has finished. Cross-split disjointness is a law over the
    whole suite, enforced where the whole suite is first visible
    (``later_evaluation``), and recorded in the decision as its own digest
    rather than smuggled into three evaluator versions.
    """

    return {
        "membership_digest": membership_digest(episodes),
        "split": split,
        "worker_model": WORKER_MODEL,
        "inner_budget": {
            "evaluations": INNER_BUDGET.evaluations,
            "trials": INNER_BUDGET.trials,
            "tokens": INNER_BUDGET.tokens,
            "wall_seconds": INNER_BUDGET.wall_seconds,
        },
        "timeouts": tuple(item.process.timeout_seconds for item in episodes),
        "environment": {"name": ENVIRONMENT.name, "version": ENVIRONMENT.version},
        "scoring": SCORING_VERSION,
        # Held-out and private declare "none", so "those facts have no
        # diagnosis record" lives in evaluator identity, not only in a test.
        "diagnosis": (
            diagnosis.DIAGNOSIS_SCHEMA
            if split == diagnosis.DEVELOPMENT
            else "none"
        ),
        # Same rule for the pulled channel: changing a schema, renderer, path,
        # or limit changes what this evaluator publishes, so it has to change
        # what this evaluator *is* rather than only what some test asserts.
        "source_view": (
            {
                "index_schema": source_schema.INDEX_SCHEMA,
                "file_schema": source_schema.FILE_SCHEMA,
                "error_schema": source_schema.ERROR_SCHEMA,
                "renderer": RENDERER,
                "paths": SOURCE_PATHS,
                "limits": SOURCE_LIMITS,
            }
            if split == diagnosis.DEVELOPMENT
            else "none"
        ),
    }


__all__ = [
    "ENVIRONMENT",
    "INNER_BUDGET",
    "MEMBERSHIP_SCHEMA",
    "SCORING_VERSION",
    "WORKER_MODEL",
    "evaluator_configuration",
    "membership_digest",
]
