"""Shared repository-episode execution and evidence construction.

No split membership: this module knows how to run one episode and build the
evidence for a graded batch of them, but nothing here decides which episodes
belong to development, private selection, or the held-out comparison. That
belongs to the modules built on top of it, so that importing this module (or
either of theirs) never pulls in a split it does not itself own.
"""

from __future__ import annotations

import sys
from typing import Iterable

import meta_evolve as meta
from meta_evolve import harness
from meta_evolve.adapters import DirectoryWorkspaces
from meta_evolve.domain import EvaluatorFailure, SourceTree
from meta_evolve.ports import EvaluationResult, EvidenceDraft, ProposalResult
from meta_evolve.ports.workspaces import Workspace

import diagnosis
import source_evidence
from episode_capture import capture_draft, captured
from source_view import SourceViewError

# Re-exported, not redefined. Callers reach an evaluator's declared identity
# through this module because this is the module they already hold; what that
# identity *is* belongs beside the constants it is built from.
import evaluation_identity  # noqa: F401
from evaluation_identity import (  # noqa: F401
    ENVIRONMENT,
    INNER_BUDGET,
    MEMBERSHIP_SCHEMA,
    SCORING_VERSION,
    WORKER_MODEL,
    evaluator_configuration,
    membership_digest,
)


def _episode(
    name: str, instruction: str, source: dict[str, str], test: str
) -> harness.RepositoryEpisode:
    return harness.RepositoryEpisode(
        name=name,
        instruction=instruction,
        source=SourceTree(source),
        evaluator_tests=SourceTree({"_meta_evolve_test.py": test}),
        process=meta.ProcessSpec(
            argv=(sys.executable, "_meta_evolve_test.py"),
            timeout_seconds=2,
            stdout_limit=2_000,
            stderr_limit=2_000,
        ),
    )


class HiddenTestWorkspaces:
    """Inject evaluator tests only after the worker's candidate is captured."""

    def __init__(self, tests: SourceTree) -> None:
        self.tests = tests
        self.inner = DirectoryWorkspaces()

    def materialize(self, artifact: object) -> Workspace:
        if not isinstance(artifact, SourceTree):
            raise TypeError("repository episode candidates must be SourceTree")
        overlap = set(artifact) & set(self.tests)
        if overlap:
            raise ValueError(f"candidate shadows evaluator files: {sorted(overlap)!r}")
        return self.inner.materialize(SourceTree({**artifact, **self.tests}))

    def capture(self, workspace: Workspace) -> SourceTree:
        captured = self.inner.capture(workspace)
        return SourceTree(
            (path, content) for path, content in captured.items() if path not in self.tests
        )

    def dispose(self, workspace: Workspace) -> None:
        self.inner.dispose(workspace)


def _repair(
    parent: SourceTree,
    artifact: harness.HarnessArtifact,
    instruction: str,
) -> SourceTree:
    files = dict(parent)
    planner_ready = "repair arithmetic" in artifact.planner.value.lower()
    policy_ready = artifact.context_policy.configuration.get("diagnostics") is True
    if planner_ready and "increment" in instruction.lower():
        files["math_ops.py"] = files["math_ops.py"].replace(
            "return value - 1", "return value + 1"
        )
    if policy_ready and "normalize" in instruction.lower():
        files["normalize.py"] = files["normalize.py"].replace(
            "return text.strip()", "return text.strip().lower()"
        )
    if planner_ready and policy_ready and "slug" in instruction.lower():
        files["slug.py"] = files["slug.py"].replace(
            "return text.strip()",
            'return text.strip().lower().replace(" ", "-")',
        )
    # Private's own repair, needing both conditions like slug's — so private
    # selection actually discriminates the fully-improved development
    # occurrence from a baseline or partial one, rather than every candidate
    # tying on a task none of them can fix.
    if planner_ready and policy_ready and "double" in instruction.lower():
        files["double.py"] = files["double.py"].replace(
            "return value", "return value * 2"
        )
    return SourceTree(files)


def run_episode(
    artifact: harness.HarnessArtifact,
    episode: harness.RepositoryEpisode,
) -> meta.Run:
    """Run one fresh isolated inner improvement episode."""

    instruction = episode.instruction

    def worker(parent: SourceTree, *, context: meta.ProposerContext) -> ProposalResult:
        candidate = _repair(parent, artifact, instruction)
        return ProposalResult(
            candidate=candidate,
            usage=meta.Resources(tokens=3),
            evidence=(
                EvidenceDraft(
                    kind="worker-attempt",
                    data={
                        "worker": WORKER_MODEL,
                        "instruction": instruction,
                    },
                ),
            ),
        )

    evaluator = meta.CommandEvaluator(
        command=episode.process,
        environment=ENVIRONMENT,
        workspaces=HiddenTestWorkspaces(episode.evaluator_tests),
    )
    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=evaluator,
            artifact=SourceTree,
            budget=INNER_BUDGET,
        ),
        seed=episode.source,
        proposer=worker,
        search=meta.Greedy(max_trials=1),
    )
    return meta.run(experiment)


def _unavailable(
    artifact: harness.HarnessArtifact, split: str, error: SourceViewError
) -> EvaluationResult:
    """No view, so no episode runs — and the attempt stays diagnosable anyway.

    The incomplete diagnosis is not politeness. #225's bundle reader treats an
    evaluated attempt carrying no diagnosis as corruption of the whole bundle,
    which would refuse every later proposal in the run over one failed view. It
    is built from ``diagnosis_evidence`` directly rather than ``evidence_for``,
    because no episode ran and there is no capture to publish.
    """

    failure = EvaluatorFailure(
        message=source_evidence.UNAVAILABLE, details={"code": error.code}
    )
    return EvaluationResult(
        failure=failure,
        evidence=(
            source_evidence.error_draft(artifact, split, error.code),
            diagnosis.diagnosis_evidence(
                artifact, (), split, evaluator_failure=failure
            ),
        ),
    )


def _undigestible(split: str) -> EvaluationResult:
    """No digest, so no record of any kind can name this artifact.

    Every source and diagnosis draft declares the shipped artifact digest, so
    there is nothing truthful to publish — an error header would have to assert
    a digest that does not exist. It returns no evidence for the same reason the
    non-``HarnessArtifact`` branch above does: the kernel digests each candidate
    at proposal completion, so such an artifact never commits and no later
    proposal can ever search for it. Section 4.3's "empty evidence is an
    inconsistency" is a rule about *committed* development evaluations, and this
    is not one.
    """

    return EvaluationResult(
        failure=EvaluatorFailure(
            message=source_evidence.UNDIGESTIBLE, details={"split": split}
        )
    )


def _prepared(
    artifact: harness.HarnessArtifact, split: str
) -> tuple[EvidenceDraft, ...] | SourceViewError:
    """Development publishes its source view; held-out has no such channel."""

    if split != diagnosis.DEVELOPMENT:
        return ()
    return source_evidence.source_drafts(artifact, split)


def _evaluate(
    artifact: object,
    episodes: Iterable[harness.RepositoryEpisode],
    split: str,
) -> EvaluationResult:
    if not isinstance(artifact, harness.HarnessArtifact):
        return EvaluationResult(
            failure=EvaluatorFailure(message="episode suite requires HarnessArtifact")
        )
    # The digest first, because every draft below declares it and the evaluator
    # must stay total over any artifact a caller can construct.
    if split == diagnosis.DEVELOPMENT and (
        source_evidence.shipped_digest(artifact) is None
    ):
        return _undigestible(split)
    # Before any episode: a view that cannot be built is not a low score, and
    # spending episode work to find that out would only add usage to a refusal.
    prepared = _prepared(artifact, split)
    if isinstance(prepared, SourceViewError):
        return _unavailable(artifact, split, prepared)
    captures: list[dict[str, object]] = []
    facts: list[dict[str, object]] = []
    scores: list[float] = []
    total = meta.Usage()
    for episode in episodes:
        inner = run_episode(artifact, episode)
        capture = captured(inner, episode)
        captures.append(capture)
        facts.append(diagnosis.episode_facts(inner, episode))
        final = inner.trials()[-1]
        # usage() over summary(), so an episode that scores nothing cannot
        # discard the dollars already counted; without_counts because the inner
        # run's trial and evaluation counts are its own.
        total += inner.usage().without_counts
        if final.failure is not None or "score" not in final.metrics:
            failure = EvaluatorFailure(
                message="repository episode did not finish rankably",
                details={"episode": episode.name, "state": final.state},
            )
            return EvaluationResult(
                failure=failure,
                evidence=prepared
                + diagnosis.evidence_for(
                    artifact,
                    split,
                    capture_draft(split, captures),
                    facts,
                    failure,
                ),
                usage=total.resources,
            )
        scores.append(float(final.metrics["score"]))
    return EvaluationResult(
        metrics={"quality": sum(scores) / len(scores)},
        evidence=prepared
        + diagnosis.evidence_for(
            artifact, split, capture_draft(split, captures), facts, None
        ),
        usage=total.resources,
    )


__all__ = [
    "ENVIRONMENT",
    "INNER_BUDGET",
    "MEMBERSHIP_SCHEMA",
    "SCORING_VERSION",
    "WORKER_MODEL",
    "evaluator_configuration",
    "membership_digest",
    "run_episode",
]
