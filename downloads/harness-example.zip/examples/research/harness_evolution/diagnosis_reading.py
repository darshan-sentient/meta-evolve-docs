"""Read committed development records as prior attempts, or refuse to.

A pure projection: same records in, same summaries and same rendered text out,
with no access to a run, a model, or an evaluator. The reading covers *every*
prior attempt and is keyed by trial occurrence rather than by content, so a
rejected, invalid, or failed attempt stays visible and two attempts that
happen to agree stay distinct.

Nothing here invents a fact. When the records do not support a reading it
returns a typed :class:`DiagnosisError` for the proposer to refuse on, rather
than guessing an edit or an intent.

Totality has a stated boundary. ``Evidence.kind`` and ``Evidence.data`` are
the parts a candidate can influence, so evidence is checked for its type
before it is indexed. Trial, outcome, and evaluation records are the kernel's
own and are read at their declared types: a record that lies about its kind
would be a policy bug rather than untrusted input.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import (
    ContextRecord,
    Evaluation,
    Evidence,
    ExperienceRef,
    Failure,
)

from diagnosis import DIAGNOSIS_SCHEMA, invalid_diagnosis


@dataclass(frozen=True, slots=True)
class Attempt:
    """One prior trial occurrence as the governed projection presents it."""

    trial: str
    step: int
    parent: str | None
    state: str
    failure: str | None
    quality: float | None
    surface: str | None
    note: str
    diagnosis_ref: ExperienceRef | None
    diagnosis: Mapping[str, object] | None
    evaluation: ExperienceRef | None


@dataclass(frozen=True, slots=True)
class DiagnosisError:
    """Why the committed records do not form a readable diagnosis."""

    code: str
    trial: str | None = None


@dataclass(slots=True)
class _Row:
    """Records belonging to one trial, gathered as the stream is walked."""

    step: int = 0
    parents: tuple[object, ...] = ()
    artifacts: tuple[object, ...] = ()
    outcome_failure: Failure | None = None
    has_evaluation: bool = False
    evaluation_failure: Failure | None = None
    metrics: Mapping[str, object] = field(default_factory=dict)
    evaluation_ref: ExperienceRef | None = None
    diagnoses: tuple[tuple[ExperienceRef, Mapping[str, object]], ...] = ()
    diagnosis_ref: ExperienceRef | None = None
    diagnosis: Mapping[str, object] | None = None


def authorized_diagnoses(records: tuple[ContextRecord, ...]) -> frozenset[object]:
    """Evidence ids an evaluator attached to one of its own evaluations.

    This, and not the evidence kind, is the ownership check. A candidate may
    return an ``EvidenceDraft`` under any kind it likes — including this one —
    but candidate evidence reaches ``TrialOutcome.evidence_ids``, while only an
    evaluator's own ``EvaluationResult`` reaches ``Evaluation.evidence_ids``.
    """

    return frozenset(
        item
        for record in records
        if record.kind == "evaluation" and isinstance(record.value, Evaluation)
        for item in record.value.evidence_ids
    )


def owned_diagnosis(record: object, authorized: frozenset[object]) -> bool:
    """Structurally an evaluator's own diagnosis record — not yet a readable one.

    Kind and ownership only. Whether the payload can be *read* is a separate
    question, because the two callers want different answers to it: selection
    drops an unreadable payload outright, while the reading wants to name the
    reason it is unreadable.
    """

    return (
        record.kind == "evidence"
        and isinstance(record.value, Evidence)
        and record.value.kind == DIAGNOSIS_SCHEMA
        and record.value.id in authorized
    )


def selected(record: object, authorized: frozenset[object]) -> bool:
    """Keep verifier facts and readable evaluator diagnosis; drop the rest.

    Validity gates *selection*, not just interpretation. A bundle's records are
    candidate-facing in their own right, so refusing to read a diagnosis while
    still selecting its record would hand the proposer the very payload the
    refusal was about. Omitting it instead leaves its evaluation without a
    readable diagnosis, which the adapter turns into a typed refusal.
    """

    if record.kind in {"trial", "outcome", "evaluation"}:
        return True
    return (
        owned_diagnosis(record, authorized)
        and invalid_diagnosis(record.value.data) is None
    )


def _gather(records: tuple[ContextRecord, ...]) -> tuple[list[str], dict[str, _Row]]:
    authorized = authorized_diagnoses(records)
    diagnoses = {
        record.value.id: (record.ref, record.value.data)
        for record in records
        if owned_diagnosis(record, authorized)
    }
    order: list[str] = []
    rows: dict[str, _Row] = {}
    for record in records:
        value = record.value
        if record.kind == "trial":
            key = value.id.value
            if key not in rows:
                order.append(key)
            row = rows.setdefault(key, _Row())
            row.step = value.logical_step
            row.parents = tuple(value.spec.parent_ids)
        elif record.kind == "outcome":
            row = rows.setdefault(value.trial_id.value, _Row())
            row.artifacts = tuple(value.artifact_ids)
            row.outcome_failure = value.failure
        elif record.kind == "evaluation":
            row = rows.setdefault(value.trial_id.value, _Row())
            row.has_evaluation = True
            row.evaluation_failure = value.failure
            row.metrics = value.metrics
            row.evaluation_ref = record.ref
            row.diagnoses = tuple(
                diagnoses[item] for item in value.evidence_ids if item in diagnoses
            )
    return order, rows


def _state(row: _Row) -> tuple[str, str | None]:
    if row.outcome_failure is not None:
        return "trial_failed", row.outcome_failure.kind
    if not row.has_evaluation:
        return "unevaluated", None
    if row.evaluation_failure is not None:
        return "evaluation_failed", row.evaluation_failure.kind
    return "evaluated", None


def _parent(row: _Row, owner: Mapping[object, str]) -> str | None:
    """The single prior occurrence whose artifact this attempt was built from."""

    parents = {owner[item] for item in row.parents if item in owner}
    return next(iter(parents)) if len(parents) == 1 else None


def _decode_surface(
    key: str, row: _Row, rows: Mapping[str, _Row], parent_key: str | None
) -> tuple[str | None, str] | DiagnosisError:
    """Name the changed surface by comparing an attempt with its own parent.

    Parent, never predecessor: after a rejected candidate the next attempt is
    a sibling of the rejection, so comparing with the previous attempt in
    commit order would name the wrong surface.
    """

    if row.diagnosis is None:
        if row.has_evaluation:
            return DiagnosisError(code="evaluation has no diagnosis", trial=key)
        if row.artifacts:
            return None, "not evaluated"
        return None, "no decoded edit"
    if not row.parents:
        return None, "seed"
    if parent_key is None:
        return DiagnosisError(code="unresolved parent occurrence", trial=key)
    parent = rows[parent_key]
    if parent.diagnosis is None:
        return DiagnosisError(code="parent has no diagnosis", trial=key)
    before = parent.diagnosis["surfaces"]
    after = row.diagnosis["surfaces"]
    if set(before) != set(after):
        return DiagnosisError(code="declared surfaces differ", trial=key)
    changed = tuple(name for name in sorted(after) if before[name] != after[name])
    if len(changed) != 1:
        return DiagnosisError(code="not exactly one changed surface", trial=key)
    return changed[0], "decoded"


def summarize(
    records: tuple[ContextRecord, ...],
) -> tuple[Attempt, ...] | DiagnosisError:
    """Read the selected records as prior attempts, or say why they do not."""

    order, rows = _gather(records)
    # Selection already drops anything invalid, so this repeats that check
    # for records that arrived some other way — a bundle handed to
    # validate_bundle, or a replayed one. An attempt is read against its
    # parent's digests, so a malformed parent must be refused before it is
    # indexed.
    for key in order:
        row = rows[key]
        if len(row.diagnoses) > 1:
            return DiagnosisError(code="more than one diagnosis", trial=key)
        if row.diagnoses:
            diagnosis_ref, diagnosis = row.diagnoses[0]
            reason = invalid_diagnosis(diagnosis)
            if reason is not None:
                return DiagnosisError(code=reason, trial=key)
            row.diagnosis_ref = diagnosis_ref
            row.diagnosis = diagnosis
    owner = {
        artifact: key for key in order for artifact in rows[key].artifacts
    }
    attempts: list[Attempt] = []
    for key in order:
        row = rows[key]
        parent = _parent(row, owner)
        decoded = _decode_surface(key, row, rows, parent)
        if isinstance(decoded, DiagnosisError):
            return decoded
        surface, note = decoded
        state, failure = _state(row)
        quality = row.metrics.get("quality")
        attempts.append(
            Attempt(
                trial=key,
                step=row.step,
                parent=parent,
                state=state,
                failure=failure,
                quality=None if quality is None else float(quality),
                surface=surface,
                note=note,
                diagnosis_ref=row.diagnosis_ref,
                diagnosis=row.diagnosis,
                evaluation=row.evaluation_ref,
            )
        )
    return tuple(attempts)


__all__ = [
    "Attempt",
    "DiagnosisError",
    "authorized_diagnoses",
    "owned_diagnosis",
    "selected",
    "summarize",
]
