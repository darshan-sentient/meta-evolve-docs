"""Opaque citation tokens over an ordered ledger of authorized observations.

The model never emits a durable identifier. It is shown ``e0``, ``e1``, ... and
a short model-safe presentation of each entry, and it returns those tokens; the
trusted side resolves them back to the exact references it put in. So a
fabricated identity cannot become a derivation, and a real one it was never
shown cannot either.

Deliberately empty of domain knowledge. The ledger knows nothing about
diagnosis records, evidence kinds, or source views — its caller decides what is
citable and how to describe it safely, and this module assigns tokens, resolves
them totally, and admits occurrences. That is what lets a later slice append a
different channel without changing anything here.

Admission *performs the read*, and that is the whole reason the rule holds. Only
a completed ``open`` is citable here, and no inspection of a value could enforce
that: a one-result ``search`` returns exactly what an ``open`` does, and the
kernel's own observation ledger authorizes searched references too, so a
searched occurrence admitted by mistake would meet no later refusal anywhere. A
caller passing in an observation plus a label describing how it got it would be
asserting the provenance rather than establishing it. So the boundary opens the
reference itself, and there is no parameter through which anything else can
arrive.

Owning the read means owning what is done with it. The one open an admission
performs is also the only authorized view of that occurrence, so the entry's
presentation is derived from the record it returned rather than named in
advance. A caller whose presentation *is* the content it cites — a source view —
would otherwise have to open every occurrence twice: once to read it and once
to admit it.

Order is the kernel's, not this ledger's. Proposal completion accepts
``derived_from`` only as an ordered subsequence of the observation ledger the
run committed — the pushed selection, then each succeeded pull result in
operation order, deduplicated by first observation. So a reference's canonical
position is fixed by the operation that first *exposed* it and not by the order
a caller got around to opening it: a search that returns two references, opened
in reverse, resolves perfectly here and is discarded there under a policy
violation whose details name nothing. An admission therefore requires the
caller to have recorded what its own operations exposed, and admits only in
that recorded order.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace

from meta_evolve.domain import ContextRecord, ExperienceObservation, ExperienceRef
from meta_evolve.errors import ExperienceAccessDenied, ExperienceBudgetExhausted


class DuplicateCitation(ValueError):
    """One occurrence admitted twice: a caller bug, not a model refusal.

    Its own type because a caller translates it into a typed failure about the
    context it was given. Catching ``ValueError`` there would report any future
    bug in building or rendering a ledger as an unreadable bundle.
    """


@dataclass(frozen=True, slots=True)
class CitationEntry:
    """One citable observation: the exact ref, and what the model may read.

    ``presentation`` is the whole of what the prompt says about this entry, so
    it is the caller's job to keep a durable identity out of it.
    """

    ref: ExperienceRef
    presentation: str


@dataclass(frozen=True, slots=True)
class Ledger:
    """Tokens in the order their observations were committed.

    ``exposure`` is the caller's own record of the pull side of that order:
    every reference one of its own operations has exposed, in the order that
    operation exposed them. A ledger built from a pushed selection alone leaves
    it empty, because pushed references precede every pull result in the
    kernel's ledger and so can never be ordered wrongly against one.
    """

    entries: tuple[CitationEntry, ...] = ()
    exposure: tuple[ExperienceRef, ...] = ()

    def __post_init__(self) -> None:
        refs = tuple(entry.ref for entry in self.entries)
        if len(set(refs)) != len(refs):
            raise DuplicateCitation("ledger references must be unique")
        if len(set(self.exposure)) != len(self.exposure):
            raise ValueError("ledger exposure must record each reference once")

    def with_exposure(self, references: object) -> Ledger:
        """Record what one operation just exposed, in the order it exposed it.

        Deduplicated by first observation, exactly as the kernel's observation
        ledger is: a reference a second search returns again keeps the position
        the first one gave it, because that is the position the kernel kept.

        An occurrence already citable gets no position at all. A search may
        return a reference the pushed selection already put in this ledger, and
        the kernel observed that one in the selection — before every pull
        result. Giving it a pull position would order it after references the
        kernel ordered before it, and the freshly exposed ones would then be
        refused for arriving too early.

        Nothing here becomes citable — only a completed ``open`` does, so this
        asserts no provenance. It is trusted caller code stating what its own
        operation returned, and passing anything else is a bug rather than a
        refusal, so it raises.
        """

        if not isinstance(references, tuple) or any(
            not isinstance(item, ExperienceRef) for item in references
        ):
            raise TypeError("exposed references must be a tuple of ExperienceRefs")
        fresh = tuple(
            ref
            for position, ref in enumerate(references)
            if ref not in self.exposure
            and ref not in references[:position]
            and self.token_for(ref) is None
        )
        return replace(self, exposure=self.exposure + fresh)

    def tokens(self) -> tuple[str, ...]:
        return tuple(f"e{position}" for position in range(len(self.entries)))

    def token_for(self, ref: ExperienceRef) -> str | None:
        for position, entry in enumerate(self.entries):
            if entry.ref == ref:
                return f"e{position}"
        return None

    def render(self) -> str:
        """The citable observations exactly as the prompt states them."""

        if not self.entries:
            return "none"
        return "\n".join(
            f"{token}: {entry.presentation}"
            for token, entry in zip(self.tokens(), self.entries)
        )

    def resolve(self, citations: object) -> tuple[ExperienceRef, ...] | str:
        """Total: the exact ordered references, or a reason naming no input.

        Order is required, not merely recorded. Accepting any permutation would
        make the resolved tuple depend on text the model chose, and the tuple is
        committed as ``derived_from``; requiring the ledger's own order leaves
        the model choosing only the subset.

        Every reason below is a constant. A reason travels into a typed failure,
        and typed failures are selected whole by the governed policy, so echoing
        the offending token here would reopen the channel the refusal closes.
        """

        if not isinstance(citations, list) or not citations:
            return "evidence citations must be a non-empty array"
        if any(not isinstance(item, str) for item in citations):
            return "evidence citations must be strings"
        index = {token: position for position, token in enumerate(self.tokens())}
        positions: list[int] = []
        for token in citations:
            if token not in index:
                return "evidence citation is not in the authorized ledger"
            positions.append(index[token])
        if len(set(positions)) != len(positions):
            return "evidence citations must be unique"
        if positions != sorted(positions):
            return "evidence citations must follow the ledger order"
        return tuple(self.entries[position].ref for position in positions)

    def with_opened(
        self,
        reader: object,
        ref: object,
        describe: Callable[[ContextRecord], str],
    ) -> tuple[Ledger, str | None]:
        """Open ``ref`` through ``reader`` and admit what came back, or nothing.

        Total, and the admission rule rather than the reading rule: it chooses
        nothing about *what* to read and inspects no evidence kind. It performs
        the one read whose completion is the rule, because a caller that handed
        in the result instead could only assert that provenance — see the module
        docstring for why no check on the value can recover it.

        That one read also serves the prompt. ``describe`` is handed the record
        this call opened and returns the whole of what the prompt will say about
        the entry. A presentation named up front could only describe an
        occurrence its caller had not read yet, so a caller citing content would
        need a second open to write it — and that second open lands after this
        entry in the kernel's own pull-operation order, which is the order this
        ledger has to keep.

        ``describe`` is trusted caller code, called only on an admission and
        never on a refusal. It is given the record and not the observation,
        because ``observation.rendered`` is the reader's own rendering and
        carries durable identities; keeping the record's ref out of the entry
        stays the caller's job.

        Order is part of the rule, and it is the run's order rather than this
        call's. An occurrence is admissible only if the caller recorded an
        operation exposing it, and only while no already-citable occurrence was
        exposed after it — otherwise the tokens would resolve to a derivation
        the kernel refuses as unordered. Refusing is the whole remedy available:
        the ledger cannot know where an unexposed reference belongs, and a
        refusal before the read costs nothing, while admitting first and
        repairing afterwards would have already spent the open.

        An occurrence already citable is refused before the read too, since a
        second open would spend audited experience budget to learn what this
        ledger already holds.

        A denied or exhausted grant is a reason rather than an exception, so an
        adapter built on this stays total. Anything else the reader raises is a
        bug and not a refusal, and propagates.

        A truncated open is refused because a partial view is still a view the
        model would cite as though it were whole.
        """

        if not isinstance(ref, ExperienceRef):
            return self, "an admission must name the reference to open"
        if self.token_for(ref) is not None:
            return self, "the occurrence is already citable"
        order = {
            reference: position
            for position, reference in enumerate(self.exposure)
        }
        if ref not in order:
            return self, "no recorded observation exposed this occurrence"
        admitted = [order[entry.ref] for entry in self.entries if entry.ref in order]
        if admitted and order[ref] < max(admitted):
            return self, "the occurrence was exposed before one already citable"
        operation = getattr(reader, "open", None)
        if not callable(operation):
            return self, "no experience reader is available to open with"
        try:
            observation = operation(ref)
        except ExperienceAccessDenied:
            return self, "the grant does not authorize opening this occurrence"
        except ExperienceBudgetExhausted:
            return self, "the experience budget cannot fund this open"
        if not isinstance(observation, ExperienceObservation):
            return self, "the reader did not return an ExperienceObservation"
        if observation.truncated:
            return self, "a truncated observation is not citable"
        if len(observation.references) != 1 or len(observation.records) != 1:
            return self, "exactly one opened occurrence is citable"
        if observation.references[0] != ref:
            return self, "the observation is not of the requested occurrence"
        if observation.records[0].ref != ref:
            return self, "the opened record does not match its reference"
        entry = CitationEntry(
            ref=ref, presentation=describe(observation.records[0])
        )
        return replace(self, entries=self.entries + (entry,)), None


__all__ = ["CitationEntry", "DuplicateCitation", "Ledger"]
