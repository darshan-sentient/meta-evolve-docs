"""The two lines above ``promotion=external``, read from retained evidence.

``below_seed`` and ``held_out_regressions`` are this flagship's answer to the
safe-inheritance question: how many development successors scored below the
seed, and on which held-out episodes the selected harness lost to the
baseline. Both are read after the run from committed records and touch no
decision. Both print ``unavailable`` rather than a default whenever a
measurement is missing, so ``0/2`` and ``[]`` are measured claims.

``quality`` and ``below_seed`` are spelled identically in the policy example,
which cannot import this module; a test pins the two copies equal.
"""

from __future__ import annotations

import math

import meta_evolve as meta


def quality(trial) -> float | None:
    """One committed trial's finite ``quality`` score, or ``None``.

    Total over every state a trial can reach. A refusal, a proposer failure,
    an evaluation that published no ``quality``, a boolean, or a non-finite
    number all yield ``None`` rather than raising, because a reporter that
    raises on an inspectable outcome reports nothing at all. ``None`` prints
    as ``None``, distinguishable from every real score including zero.
    """

    value = trial.metrics.get("quality")
    if trial.state != "evaluated" or trial.failure is not None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def below_seed(run) -> str:
    """Strictly worse development successors over all successors, or ``unavailable``.

    The seed is trial zero and is excluded from the count. Any trial without a
    finite score makes the whole ratio ``unavailable``: a missing measurement
    is not a loss, and it is not a non-loss either.
    """

    scores = [quality(trial) for trial in run.trials()]
    if not scores or any(score is None for score in scores):
        return "unavailable"
    minimize = isinstance(run.inspect().declaration.objectives[0], meta.Minimize)
    losses = sum(
        (score > scores[0]) if minimize else (score < scores[0])
        for score in scores[1:]
    )
    return f"{losses}/{len(scores) - 1}"


def episode_scores(run, expected):
    """Final held-out score per episode from one run's ``episode-capture``.

    ``None`` whenever the capture cannot support a per-episode claim: an
    incomplete run, more than one trial, more or fewer than one capture, a
    capture from another split, an episode outside ``expected`` or listed
    twice, an episode with no attempts, or a final attempt that did not
    evaluate to a finite score. The *last* attempt is the measurement.
    """

    if run is None:
        return None
    inspection = run.inspect()
    if inspection.overview.lifecycle != "complete" or len(inspection.trials) != 1:
        return None
    trial = inspection.trials[0]
    if quality(trial) is None:
        return None
    captures = [item for item in trial.evidence if item.kind == "episode-capture"]
    if len(captures) != 1 or captures[0].data.get("split") != "held_out":
        return None
    scores = {}
    for episode in captures[0].data.get("episodes", ()):
        name = episode.get("name")
        attempts = episode.get("attempts", ())
        if name not in expected or name in scores or not attempts:
            return None
        final = attempts[-1]
        value = final.get("metrics", {}).get("score")
        if (
            final.get("state") != "evaluated"
            or final.get("failure") is not None
            or isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
        ):
            return None
        scores[name] = float(value)
    return scores if set(scores) == expected else None


def held_out_regressions(result):
    """Held-out episodes where the selected harness scored strictly worse.

    Read from the two final held-out runs' retained captures, never from the
    aggregate comparison. Any ambiguity -- no selection, an unrankable verdict,
    a missing quality, differing objectives, or a capture ``episode_scores``
    refuses -- yields ``unavailable`` rather than ``[]``, so an empty list is a
    measured claim.
    """

    if (
        result.comparison is None
        or result.comparison.verdict == "unrankable"
        or result.baseline_held_out is None
        or result.candidate_held_out is None
        or result.comparison.baseline.quality is None
        or result.comparison.candidate.quality is None
    ):
        return "unavailable"
    # Reporting runs after selection. Do not import later split membership
    # into development execution or give it to the proposer.
    from later_evaluation import HELD_OUT_EPISODES

    expected = {episode.name for episode in HELD_OUT_EPISODES}
    if len(expected) != len(HELD_OUT_EPISODES):
        return "unavailable"
    left = episode_scores(result.baseline_held_out, expected)
    right = episode_scores(result.candidate_held_out, expected)
    if not expected or left is None or right is None:
        return "unavailable"
    baseline_objective = result.baseline_held_out.inspect().declaration.objectives[0]
    candidate_objective = result.candidate_held_out.inspect().declaration.objectives[0]
    if baseline_objective != candidate_objective:
        return "unavailable"
    minimize = isinstance(baseline_objective, meta.Minimize)

    def regressed(name):
        return right[name] > left[name] if minimize else right[name] < left[name]

    return sorted(name for name in expected if regressed(name))
