"""The one exception replay raises, in a module both halves can import.

Its own file rather than either half's, so neither half has to import the
other to raise it -- which is what would otherwise make the split circular.
"""

from __future__ import annotations


class ReplayFailure(Exception):
    """The output directory does not reconcile with its own decision record."""


__all__ = ["ReplayFailure"]
