"""One audited open, admitted only if the caller then wants it.

``Ledger.with_opened`` is generic on purpose: it performs the read and admits
what came back, and it knows nothing about source views. But it builds the
citation entry *before* this example can check that the payload is a source
index or a source file — and #224 authorizes citing only those two. An error
header and a malformed payload are both real answers from a real open, and
neither may become a model-visible citation token.

So the ledger it returns is a *candidate*. The caller validates the record this
module hands back and then either adopts the candidate or keeps the ledger it
had. Discarding is order-safe: a non-adopted reference stays in ``exposure``,
is never counted among the admitted, and blocks no later admission.

Adopting first and repairing afterwards would not do. A token, once assigned, is
what the model is shown, and there is no way to withdraw it from a prompt that
has already been built.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass

from meta_evolve.domain import ContextRecord, Evidence, ExperienceRef

from citation_ledger import Ledger


@dataclass(frozen=True, slots=True)
class Opened:
    """A completed open: the record it returned, and the ledger it *could* make."""

    ledger: Ledger
    record: ContextRecord

    def payload(self, *kinds: str) -> object:
        """The evidence data, only if this occurrence really is one of ``kinds``.

        ``Evidence.kind`` and ``Evidence.data`` are both parts a candidate can
        influence, so both are checked and they are checked against each other.
        Validating the payload alone would let any evidence whose data happens
        to look like a source record enter the source citation allowlist — an
        ``episode-capture`` carrying an index-shaped payload would be admitted
        and given a token, which is precisely the record this channel exists to
        keep out of reach.

        The outer kind must also equal the payload's own ``schema``. Otherwise a
        record could claim one kind on the envelope and another in the body, and
        the two validators below would disagree about which one it is.
        """

        value = self.record.value
        if not isinstance(value, Evidence) or value.kind not in kinds:
            return None
        data = value.data
        if not isinstance(data, Mapping) or data.get("schema") != value.kind:
            return None
        return data


def open_once(
    reader: object,
    ledger: Ledger,
    ref: ExperienceRef,
    describe: Callable[[ContextRecord], str],
) -> Opened | str:
    """Open ``ref`` and hand back both outcomes, or the reason it did not.

    The captured slot is filled only on admission, because ``describe`` is
    called only on admission. An empty slot after a ``None`` reason would mean
    the ledger admitted without describing, which is a bug in this example
    rather than a fact about the run — so it raises rather than refusing.
    """

    captured: list[ContextRecord] = []

    def capture(record: ContextRecord) -> str:
        captured.append(record)
        return describe(record)

    candidate, reason = ledger.with_opened(reader, ref, capture)
    if reason is not None:
        return reason
    if len(captured) != 1:
        raise AssertionError("an admission described no record exactly once")
    return Opened(ledger=candidate, record=captured[0])


def exposed(ledger: Ledger, ref: ExperienceRef) -> Ledger:
    """State the position this open is about to take in the kernel's ledger.

    Per open rather than in a batch, so the order the caller declares cannot
    drift from the order it actually attempts. An occurrence already citable
    from the pushed selection gets no pull position at all, which is what keeps
    this ledger's order equal to the kernel's.
    """

    return ledger.with_exposure((ref,))


__all__ = ["Opened", "exposed", "open_once"]
