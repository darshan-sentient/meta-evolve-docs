"""Private selection: confirm the development winner against matched cases
the development-phase proposer never saw, before the one untouched held-out
comparison.

Rankable means ``state == "evaluated"``, an artifact occurrence is present,
and the exact finite ``quality`` objective is present — state alone is
insufficient, and a development evaluator that forgot to publish quality
must fail loudly rather than silently rank as the worst score. Duplicate
content stays distinct: two occurrences with equal content are still two
entries here, each with its own artifact id and its own private run.

Every rankable occurrence gets one seed-only ``Greedy(max_trials=0)`` private
run, with the full declared :data:`PRIVATE_BUDGET` applied independently —
no depleting shared quota, context, or experience, so an earlier occurrence's
consumption never reduces a later one's allowance.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

import meta_evolve as meta
from meta_evolve import harness

import durable_runs

if TYPE_CHECKING:
    from meta_evolve.application.views import TrialView


PRIVATE_BUDGET = meta.Budget(evaluations=1, trials=0, tokens=40, wall_seconds=10)


def rankable_candidates(run: meta.Run) -> tuple["TrialView", ...]:
    """Every development trial with an artifact occurrence and a quality score."""

    return tuple(
        trial
        for trial in run.trials()
        if trial.state == "evaluated"
        and trial.artifact is not None
        and "quality" in trial.metrics
    )


def run_private(
    seed: harness.HarnessArtifact,
    *,
    private_evaluator: object,
    proposer: object,
    registry: meta.Registry | None,
    storage: meta.Storage,
) -> meta.Run:
    """One seed-only private run over ``seed``, with the full declared budget.

    Independent of every other private run: its own storage, its own fresh
    accounting against :data:`PRIVATE_BUDGET`, no shared quota or context —
    the same shape ``flagship_components._held_out`` already uses for the held-out phase.
    """

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=private_evaluator,
            artifact=harness.HarnessArtifact,
            objectives=(meta.Maximize("quality"),),
            budget=PRIVATE_BUDGET,
        ),
        seed=seed,
        proposer=proposer,
        search=meta.Greedy(max_trials=0),
        random_seed=0,
        registry=registry,
    )
    return durable_runs.run_or_resume(experiment, storage, registry)


@dataclass(frozen=True, slots=True)
class PrivateRun:
    """One occurrence's private confirmation: what it was, and how it went.

    ``quality`` is ``None`` when the private run itself did not finish
    rankably. That outcome is *retained*, not dropped: a private evaluation
    that failed is a fact about this decision, it consumed the phase's
    accounting, and a candidate set that quietly lost a member would make the
    sealed record disagree with the development run it was derived from. It is
    not a zero score either -- :func:`select` filters it out rather than
    ranking it, so a real zero-quality confirmation and a failure to confirm
    at all stay two different things.
    """

    occurrence: "TrialView"
    run: meta.Run
    quality: float | None
    unrankable_state: str | None = None

    @property
    def rankable(self) -> bool:
        return self.quality is not None


def evaluate_candidates(
    development_run: meta.Run,
    *,
    private_evaluator: object,
    proposer: object,
    registry: meta.Registry | None,
    storage_for: Callable[["TrialView"], meta.Storage],
    around: Callable[["TrialView", Callable[[], meta.Run]], meta.Run] | None = None,
) -> tuple[PrivateRun, ...]:
    """One private run per rankable development occurrence — every outcome kept.

    Exactly one :class:`PrivateRun` per member of the candidate set, whether
    or not its private evaluation finished rankably. Dropping the failures
    here would make three separate claims false at once: the decision record
    would not name what was actually attempted, the phase accounting would
    reconcile against a set smaller than the one that consumed it, and replay
    -- which checks the recorded private runs cover exactly the rankable
    development occurrences -- would fail on a legitimate private failure.
    Filtering belongs to :func:`select`, which is the one step entitled to
    ignore an outcome.
    """

    results = []
    for occurrence in rankable_candidates(development_run):
        def _run(occurrence=occurrence) -> meta.Run:
            return run_private(
                occurrence.artifact.value,
                private_evaluator=private_evaluator,
                proposer=proposer,
                registry=registry,
                storage=storage_for(occurrence),
            )

        # ``around`` wraps each private run individually rather than the batch,
        # because each one has its own independent budget and its own declared
        # elapsed ceiling -- so a caller measuring them has to be able to
        # measure them one at a time. Absent, this is exactly the loop it was.
        run = _run() if around is None else around(occurrence, _run)
        final = run.trials()[-1]
        rankable = final.state == "evaluated" and "quality" in final.metrics
        results.append(
            PrivateRun(
                occurrence,
                run,
                float(final.metrics["quality"]) if rankable else None,
                None if rankable else final.state,
            )
        )
    return tuple(results)


def select(evaluated: tuple[PrivateRun, ...]) -> PrivateRun | None:
    """``(private_quality, -logical_step)``: highest quality, earliest step.

    The one step that filters. Outcomes that did not finish rankably are
    retained everywhere else and ignored *here*, which is what keeps "no
    private evaluation succeeded" distinguishable from "every private
    evaluation scored zero". ``None`` when nothing rankable remains — a sealed
    decision that no selection could be made, never a default winner.
    """

    ranked = tuple(item for item in evaluated if item.quality is not None)
    if not ranked:
        return None
    return max(
        ranked, key=lambda item: (item.quality, -item.occurrence.logical_step)
    )


__all__ = [
    "PRIVATE_BUDGET",
    "PrivateRun",
    "evaluate_candidates",
    "rankable_candidates",
    "run_private",
    "select",
]
