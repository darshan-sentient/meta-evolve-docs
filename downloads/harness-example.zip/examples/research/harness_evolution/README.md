# Trusted, programmable harness evolution

This is the deterministic M8 flagship. It improves a typed harness on two
development repository repairs, confirms the winner against one matched
private repair the development-phase proposer never saw, then runs the
unchanged baseline and the private-selected harness once each on one
untouched held-out repair with `Greedy(max_trials=0)`. Export occurs only
after the strict comparison reports eligibility; deployment and promotion
remain external.

Run it from a clean checkout with an explicit output directory:

```bash
uv run python examples/research/harness_evolution/main.py --output /tmp/meta-evolve-m8
```

The exact expected output, byte for byte. Every field here is content rather
than a host path, and both digests are computed from content alone — so two
machines and two `--output` directories print the identical block, and
`tests/test_harness_readme_transcript.py` fails if this drifts from what the
command actually prints. Elapsed time is deliberately absent: it is a
measurement, so it lives in `observations.json` beside the output and never
enters the decision digest.

```text
[development]
development=[0.0, 0.5, 1.0]
development_ceiling=evaluations:3,tokens:100,trials:2,wall_seconds:30.0
[private-selection]
private_candidates=3
private_rankable=3
private_quality=1.0
private_ceiling=evaluations:1,tokens:40,trials:0,wall_seconds:10.0
[held-out]
held_out_baseline=0.0
held_out_candidate=1.0
verdict=improvement
promotion_eligible=True
held_out_ceiling=evaluations:1,tokens:40,trials:0,wall_seconds:10.0
[decision]
decision=sealed
schema=harness-private-selection-decision/v3
replay=output-directory
[accounting]
accounting=development:3,private:3,held_out:2
provider_calls=development:2,private:0,held_out:0
inner_episodes=development:6,private:3,held_out:2
source_bytes=development:1599,private:0,held_out:0
citations=development:4,private:0,held_out:0
[export]
export=selected-harness
digest=3e17167e53c4dce212440c3a3004fd318144ef0d1616c79df87f51855a1a63af
[promotion]
below_seed=0/2
held_out_regressions=[]
promotion=external
```

The seven labelled sections are #227's own output audit, in its order.
`decision` and `replay` say *what kind* of record exists and where it is
verified from -- `sealed` and `output-directory` -- rather than naming it: the
content digest and the filename it produces are machine-specific, so they stay
in the output directory and out of a transcript CI compares byte for byte. For
the same reason no measured quantity appears above: the elapsed-time
conformance verdict is retained in `observations.json`, keyed by phase, and is
deliberately not part of this story. `accounting` and the four lines under it
are per-phase totals recomputed from committed records, not counters kept as
the run went.

`below_seed` and `held_out_regressions` are read from retained evidence after
the run and touch no decision. The first counts strictly worse measured
development successors over all successors, seed excluded; the second names
every held-out episode where the selected harness scored strictly worse than
the baseline, under the declared direction. Either prints `unavailable` when a
measurement is missing or incomplete, so `0/2` and `[]` are measured claims
rather than defaults. With one held-out repair the list can only be empty or
name that repair, and a zero here is a property of this fixture, not evidence
of safe inheritance or transfer. Verdict, eligibility, export, and external
promotion are unchanged.

## Boundaries demonstrated

On the survey's ladder this flagship is strategy autonomy under fixed
evaluation, with a fixture proposer: it demonstrates the boundary, not
recursive self-improvement. See [where Meta-Evolve sits on the ladder](../../../docs/comparison.md#where-this-sits-on-the-self-improvement-ladder).

- The user-owned TFD callable asks a fixture SDK boundary for a closed
  `harness-proposal-manifest/v1` object — the observations the edit cites, one
  declared surface and its value, the development behavior it predicts will
  improve, and the regressions it puts at risk — applies the matching declared
  surface, and returns an ordinary `ProposalResult` with usage, evidence,
  hypothesis, predictions, metadata, and authorized observation references. An
  edit that cannot state all five is not ranked low; it is a typed unrankable
  outcome. The opt-in live driver sends the same schema and shares the same
  decoder, so the two boundaries differ only in who answers.
- Citations are positional tokens, never identifiers. Before the request is
  built, the adapter assigns `e0`, `e1`, ... to the ordered authorized
  observations and shows the model only those tokens and a short safe
  description; what comes back resolves against that exact ledger, in that
  order, and becomes `derived_from`. The governed rendering does name each
  prior attempt's trial, so an identifier is visible — the point is that it is
  not usable: returning one cites nothing the ledger knows and refuses.
- Refusal is staged, so retention is too. Citations resolve first and survive a
  later invalid field, keeping the fact that the model cited correctly; a
  complete manifest survives a typed mutation failure, keeping its predictions
  beside that exact failure; and a response that established nothing keeps only
  the bounded raw text, the model identity, and the measured usage. No stage
  invents what an earlier one did not supply.
- Core proposal completion encodes the returned harness and independently
  validates it against its one parent before artifact commit. The wrapper
  helper is never the authority boundary.
- Each outer evaluation launches a fresh inner `meta.run()` per repository
  episode. The worker receives the instruction and public source; evaluator
  tests are injected only into a fresh evaluation workspace.
- Outer evidence captures attempts, process diagnostics, source diffs, typed
  failures, and inner counts. Only tokens and elapsed time roll into outer
  `Usage`.
- The proposer observes a governed diagnosis bundle, never the raw capture.
  The fixed development evaluator publishes `harness-diagnosis/v1` — failure
  clusters grouped by the verifier's own verdict, the invariants already
  passing, and one digest per declared surface — and an example-local context
  policy projects every prior attempt from those committed records, including
  the rejected and failed ones. Diagnosis is selected by the evaluation that
  owns it rather than by evidence kind, so a candidate cannot impersonate it by
  publishing evidence under the same name. Grader output, candidate-authored
  proposal evidence, and every held-out fact are excluded by construction:
  held-out evaluations publish no diagnosis at all. Typed trial outcomes are
  selected whole, because selecting an exact committed record means never
  redacting one — so whatever a proposer wrote into its own typed failure
  stays visible to a later proposal. That is prior model output rather than an
  evaluator fact, and this example's adapter keeps model-authored text out of
  those details.
- The proposer derives its editable surfaces from the parent declaration
  rather than from anything the context said, and refuses a truncated or
  unreadable bundle with a typed unrankable outcome instead of proposing from
  partial evidence. That allowlist is checked before the mutation boundary, not
  by it: `HarnessArtifact.apply()` echoes an undeclared surface name into its
  failure details, and those details reach an outcome record the policy later
  selects whole, so an undeclared name never gets that far. The provider
  schema's surface `enum` is a convenience for the model; the parent's own
  declaration is the authority, and a test pins the two equal.
- Assembling the bundle costs no evaluation, episode, or model call — only its
  exact recorded context records and characters. Its bound is a known one: an
  evaluated attempt contributes four records, so `max_records=30` refuses
  rather than omits from roughly the eighth attempt onward.
  `Greedy(max_trials=2)` is the only reason this flagship never reaches it.
- Each evaluator component version covers *its own split's* episode
  membership digest, plus the split name, worker/model declaration, inner
  budget, per-episode timeouts, environment, and scoring version. Its own
  split's, not a combined suite digest: no split's grading depends on which
  episodes another split holds, and computing the development evaluator's
  identity must not require loading membership that is meant to stay unloaded
  until the search has finished. That the three splits are disjoint is a claim
  about the whole suite, enforced where the whole suite is first visible and
  recorded in the decision as its own digest.
- Durable resume is guaranteed at committed outer-evaluation boundaries.
  Uncommitted inner episode work may repeat after interruption.

The proposer also *pulls*, under audit. The fixed development evaluator
publishes each evaluated harness's complete mutable surface values as a
canonical source view — a three-file value, `manifest.json` plus
`surfaces/planner.md` and `surfaces/context_policy.json` — indexed by a
`harness-source-index/v1` header at offset 0 of its own evidence bundle. The
adapter searches once for prior evaluations, opens exactly the offsets each
validated index names, reassembles the view, reconstructs the harness, and
recomputes its artifact digest against the diagnosis's independently committed
digest. Matching labels alone do not establish that the bytes describe that
harness. A view is a value,
never an artifact: it enters no lineage, selection, export, or promotion, and
its layout is deliberately not `harness/export.py`'s, because an export says
which occurrence it came from and evidence may not.

Only a completed, validated open is citable. `Ledger.with_opened()` performs
the read and builds the entry before this example can check that the payload is
an index or a file, so the ledger it returns is a *candidate*: the adapter
validates first and then adopts it or keeps the one it had. An evaluator-stated
`harness-source-error/v1` header is reported to the model as unavailable and
gets no token; every other shortfall — a malformed payload, a digest that
disagrees, an evaluation carrying no evidence at all — is a typed unrankable
outcome rather than a quieter kind of absence. Discarding an admission does not
discard the exposure: the open really happened and took a position in the
kernel's own pull order, so the record of it stays while the token does not.

Both halves of a record are checked, and against each other. `Evidence.kind` and
`Evidence.data` are each things a candidate can influence, so a payload that
looks like an index does not become citable under some other kind — an
`episode-capture` carrying index-shaped data is refused, which matters because
that capture is exactly the record this channel exists to keep out of reach —
and the outer kind must equal the payload's own `schema`, so no record can claim
one thing on the envelope and another in the body.

Every byte length and digest starts with one encode, so whether the text can be
encoded at all is decided before them. A lone surrogate is text Python holds
happily and UTF-8 cannot represent; `SourceTree` refuses one, so the producer
never publishes it, which is exactly why only a hostile payload reaches that
path — and a validator that raises on hostile input is not a validator.

Nesting is a declared bound, because a byte count does not catch it. Roughly
1,800 bytes of `[[[[...` sits under every size limit and still exhausts the
stack in `json.loads`, in the canonical re-encode, and in `FrozenMap`. The view
schema therefore declares a maximum depth, enforced by the producer before it
publishes and by the reader before it parses, so an adversarial view is a typed
refusal at a stated number rather than a crash at whatever the interpreter's
recursion limit happens to be.

That rule holds because the admission boundary performs the open itself: a
one-result `search()` returns exactly what an `open()` does, and the kernel's
own observation ledger authorizes searched references too, so a caller handing
in an observation plus a label describing how it got it would be asserting the
provenance rather than establishing it. `Ledger.with_opened()` takes a reader, a
reference, and a function that describes the record its own open returns —
there is no parameter through which anything else can arrive, and a token is
backed by the run's own audited `open`. That one read is also what the entry's
text is written from, so a source view, whose presentation *is* the content it
names, never opens an occurrence twice.

The pull has a known bound, exactly as the push does. One search plus four
opens per prior evaluation reaches `max_results=10` and `max_records=10` at the
second proposal with one operation slot spare, so a third proposal fails closed
rather than widening a limit. `max_chars=512_000` is measured rather than
generous: `serialization.dumps` expands a control character roughly six-fold, so
two complete 40 KiB views of adversarial-yet-legal surface values render to
about 500,000 characters — within a few per cent of the declared cap. Crossing
it truncates an open, which is refused, so the failure stays typed and closed;
a test derives that arithmetic from the declared limits so raising one fails
loudly.

Position is the kernel's too. `derived_from` is accepted only as an ordered
subsequence of the observations a run committed, and a reference's place there
is fixed by the operation that first exposed it — not by the order a caller
later opened it in. So a caller records what its own search exposed, through
`Ledger.with_exposure()`, and an occurrence that no recorded observation
exposed, or that was exposed before one already citable, is refused before the
read rather than discarded at completion under a violation that names nothing.

## Private selection

Three graded suites, not two: development guides proposals, one matched
private repair (`repair-double`) confirms the development winner, and one
untouched held-out repair validates the confirmed choice. Private and
held-out publish no diagnosis and no source view — the same structural gate,
so private is dark for the identical reason held-out already is, not a
second rule to keep in sync with it.

The candidate set is exactly the development run's rankable occurrences:
`state == "evaluated"`, an artifact present, and the exact finite `quality`
metric — state alone is insufficient, and a development occurrence whose
evaluator never published `quality` is outside the candidate set rather than
ranked as zero. Duplicate-content
occurrences stay distinct: two development trials with equal bytes still get
two private runs, each independently paying the full declared private
budget — an earlier occurrence's consumption never reduces a later one's
allowance. Selection is one total rule: highest private quality, ties broken
by the earlier development logical step, reading exact occurrence identity
rather than content digest alone. No rankable private outcome commits a
sealed no-selection decision instead — held-out and export never run, and
the report says why rather than falling back to development quality or the
baseline.

Every private outcome is retained, including one that did not finish
rankably: it is recorded with `rankable: false` and no quality, and only
selection filters it. Dropping it would make three separate claims false —
the record would not name what was attempted, the phase accounting would
reconcile against a smaller set than the one that actually consumed it, and
replay (which requires the recorded private runs cover exactly the rankable
development occurrences) would fail on a legitimate private failure. A
failure is not a zero: ranked as one, a batch where every private run failed
would elect a winner instead of sealing a no-selection decision.

The private phase can and does overturn development. A private suite the
development winner cannot pass elects an earlier occurrence, and the
untouched held-out comparison then follows that choice rather than
development's — changing the promotion outcome, not only the trial id
printed. That case is driven end to end in
`tests/test_harness_private_overturns.py`; without it, this phase would only
be shown running, never deciding.

Meta-Harness demonstrates that a fixed harness improves under audited
inspection of prior candidates; this slice demonstrates the closing half of
the same claim, that the improvement generalizes past what development
already confirmed, before it is validated once more on data untouched by
either phase.

## The confined proposer child

The fixed proposer's decision-making — today the deterministic fixture, in
future a live model — never runs in this process. `child_root.py` copies
only two files (the child's own entry point and the fixture's decision
logic, free of any `meta_evolve` import) onto a fresh root outside both this
repository and the run's own output directory, and `confinement_policy.py`
launches it there under the operating system's own enforcement: macOS
`sandbox-exec` or Linux Landlock, whichever this host supports, denying read
and write access to the original repository and to the output directory
holding this run's own decision records.

The output root is declared per invocation rather than baked into the
proposer's identity: `_search` binds it around the run, and the registered
proposer *refuses* to launch a child with no binding at all. "Nobody said"
and "there is nothing to protect" are different claims, and only the caller
knows which is true — an in-memory run genuinely has no output root, and says
so by binding `None`. It cannot go into the proposer's declared
configuration, because that would make the run id, and the decision digest
built on it, vary with wherever `--output` happened to point. The two
platforms reach the same denial differently: `sandbox-exec` reads
allow-by-default and names the denied roots explicitly, while Landlock is
allow-list only and has no deny rule at all — so on Linux the fix is that
`/tmp` and `/var/tmp` are *not* blanket-readable, and the child's own root is
granted by its exact path instead. A structural absence — the child
simply not having a copy of the later-split modules — is not treated as the
authority boundary on its own; the kernel-enforced denial is what makes the
claim true even against a child that tries.

Canaries drive that claim rather than merely observing it: an absolute path
back to the repository, a relative traversal to the same file, an attempted
import of this project's own package after appending its `src/` to
`sys.path`, no ambient environment reaching the child, the request never
appearing in its `argv`, and a genuinely unrelated exception (a bug, not a
confinement failure) propagating rather than being swallowed into the same
typed outcome. A machine with no confinement mechanism refuses to launch the
child at all; it never runs a proposal unconfined.

## Durable decision and replay

One immutable, content-addressed decision record is sealed after the last
reachable phase, named by its own digest (`decision-<digest>.json`) so it
can be located without trusting a caller-supplied name. It names every
development occurrence and its private eligibility, every private run and
its source occurrence and quality, the selection policy and its winner (or
the typed no-selection reason), both held-out roles, which episodes each of
the three splits holds, every ceiling the run was declared under (each
phase's budget, the audited grant, the per-episode process timeouts and
output limits, the retained-raw bound, and the confined child's own limits),
and per-phase accounting — outer evaluations, trials, tokens and spend; the
provider-call breakdown behind them; inner episode and attempt counts;
successfully opened source records and their exact byte total (counting repeat
opens, excluding source publication alone); and admitted citations.
Every one of those is *derived from committed records* rather than
accumulated as the run goes, because a total the producer reported about
itself cannot detect the producer having under-reported.

Three fields are deliberately excluded from the record: `wall_seconds` and
the two `*_chars` totals. Elapsed time is a measurement, not decision
identity. The character totals are elapsed time one step removed, and the
mechanism is worth stating exactly: the kernel renders a pulled record by
serializing the whole record, an evaluation record carries its own measured
`usage.wall_seconds`, and so the decimal expansion of a measured float sits
inside the text whose length is being counted — the total moves by a byte or
two between identical runs. Every *count* dimension beside them is exact and
reconciles every time. The excluded three are retained in
`observations.json` instead, so nothing is discarded, only kept out of
identity.

The digest is reproducible across `--output` directories and **not** across
machines, deliberately. Each episode's `ProcessSpec` names `sys.executable`,
so the absolute interpreter path is inside every digested payload, and #227's
plan defers portable logical-interpreter identity: retain faithful
declarations, document the sensitivity, do not strip identity fields, and do
not claim equal digests after the interpreter or checkout changes. Substituting
a marker would let two genuinely different interpreters declare one identity,
which is a worse failure than a digest that honestly varies. That is why the
digest and its filename stay in the sealed record and never reach byte-exact
stdout, which reports stable status instead.

`observations.json` is append-only and per unit of work, not per phase: the
search, each private run, and each held-out role are measured separately,
because each has its own independent budget. A segment is opened *before* its
work starts and closed only when the work returns, so a process that dies in
between leaves a pending, `unknown` marker rather than a gap — and a phase
holding one reports `unknown` cumulatively however fast the attempt that
resumed it was. Tests drive all of this through an injected clock, so
conformance boundaries are provable without depending on real-machine speed.

Replay reads only the output directory and runs no evaluator, proposer,
provider, or candidate code. `replay(root)` takes **no registry**: every
component manifest, evaluation occurrence id, metric, and evidence payload it
needs is in the committed event stream. It verifies the decision's filename
against its own content; both write-ahead plans against the digests it sealed
them at; plan and decision against each other, including a skip that claims to
be an execution; every phase store's manifests, run and evaluation identities,
and measurements against the store's own events; every identity the decision
repeats in a second place against the first; the selection rule re-run over
the sealed keys; and the exported harness re-digested from the bytes on disk.
Because those comparisons are against the *store* rather than against the
record's own digest, a forgery that reseals — recomputing the digest and
renaming the file so content and filename agree again — is still refused.

Two things it does not cover, and the distinction is worth stating rather than
discovering. `ceilings` and `episode_membership` are declarations with no
counterpart in any committed event, so the output directory alone cannot tell
a forged one from a real one; a caller that also holds the example code closes
that with `replay_integrity.verify_declarations`, which answers "does this
match what the code declares now" rather than "is this what the run
committed". All occurrence and accounting checks use read-only `meta.Run`
views with the built-in harness codec; no registry or component execution is
needed. Replay compares the exact committed candidate set, not its sealed
eligibility flags or evaluation count, and binds the exported bytes to the
private-selected occurrence and its matched held-out comparison.

Every phase is independently resumable. An interruption before the final
record leaves whatever completed inspectable in its own durable store;
resuming reuses each completed run by its own id rather than repeating it,
and converges on the identical decision.

The single held-out repository is a compact execution-boundary demonstration,
not statistically strong evidence of generalization or production readiness.
The private suite is one matched repair, not a held-out-sized validation set
of its own — its claim is that development and private disagree exactly
when development has not yet generalized, not that one additional case is
statistically representative. Confinement is scoped to this repository and
this run's output directory; it does not claim to isolate network, CPU,
memory, or syscalls generally, and a host with neither `sandbox-exec` nor a
sufficient Landlock ABI is refused rather than silently run unconfined.
