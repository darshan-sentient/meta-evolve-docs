"""Start a durable-local run, or resume the one already at that storage.

Every phase in this example — development search, each private run, each
held-out role — gets its own dedicated durable store, one run per store. An
interruption between phases leaves some stores with a completed run and
others with none at all; re-running the flagship must not repeat the
completed ones; ``meta.run`` itself refuses a second start against a store
that already holds a run (``RunError: an identical run already exists``), so
this is the one seam that decides start vs. resume for all of them.
"""

from __future__ import annotations

import meta_evolve as meta


def run_or_resume(
    experiment: meta.Experiment,
    storage: meta.Storage,
    registry: meta.Registry | None,
) -> meta.Run:
    """Start ``experiment`` at ``storage``, or resume what is already there.

    A store dedicated to one experiment holds at most one run; more than
    that is a caller error (two experiments sharing a store), not a resume
    ambiguity to guess at.

    ``registry=None`` is the *unregistered* case, and it is a narrower
    capability rather than a laxer one. Resume rebuilds every component from
    the registry by name, so a run whose components were never registered --
    the live driver's, which configures its proposer and evaluators locally
    around an SDK client that cannot be reconstructed from a name -- can be
    started durably and read back durably, but not resumed. Finding an
    existing run in that case raises rather than silently starting a second
    one beside it: what the caller wanted was the completed run, and this
    configuration cannot hand it back.
    """

    existing = storage.runs()
    if not existing:
        if registry is None:
            return meta.run(experiment, storage=storage)
        return meta.run(experiment, storage=storage, mode="durable-local")
    if len(existing) > 1:
        raise ValueError(
            f"expected at most one run in a dedicated store, found {len(existing)}: "
            f"{existing}"
        )
    if registry is None:
        raise ValueError(
            f"{storage} already holds run {existing[0].value!r}, and this "
            "experiment's components are unregistered, so it cannot be "
            "resumed; give the run a fresh output directory"
        )
    return meta.resume(existing[0], storage=storage, registry=registry)


__all__ = ["run_or_resume"]
