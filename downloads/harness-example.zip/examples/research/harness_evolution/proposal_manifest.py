"""The closed manifest a harness proposal must return, and its total decoder.

One wire contract for the deterministic fixture and the opt-in live driver:
which authorized observations the edit rests on, the single surface and value it
changes, what it predicts will improve, and what it puts at risk. Every field is
required, so an edit that cannot say what it expects is not an edit this example
will rank — it is a typed unrankable outcome.

The provider schema and this decoder are not the same authority. A schema is
sent to a service that may or may not honor it, and its surface ``enum`` is a
convenience for the model rather than the allowlist: the parent's own
declaration is, and only the caller holds the parent. So :func:`decode` never
trusts the schema to have been enforced, never raises, and checks the surface
against the tuple its caller derived from that parent.

Refusal messages are constants. A typed failure is committed to the trial
outcome and the governed policy selects outcome records whole, so a message that
quoted the offending value would hand the next proposal the text this refusal
exists to reject.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import TypeAlias, TypeVar

from meta_evolve.domain import (
    ExperienceRef,
    Failure,
    InvalidOutput,
    ProposerFailure,
    Usage,
)

from call_usage import CallUsage
from citation_ledger import Ledger


SCHEMA = "harness-proposal-manifest/v1"
SURFACES = ("planner", "context_policy")
FIELDS: tuple[str, ...] = (
    "evidence_citations",
    "surface",
    "value",
    "predicted_fix",
    "at_risk_regressions",
)

MANIFEST_SCHEMA: dict[str, object] = {
    "type": "object",
    "properties": {
        "evidence_citations": {
            "type": "array",
            "items": {"type": "string", "pattern": r"^e[0-9]+$"},
            "minItems": 1,
        },
        "surface": {"type": "string", "enum": list(SURFACES)},
        "value": {
            "anyOf": [
                {"type": "string"},
                {
                    "type": "object",
                    "properties": {"diagnostics": {"type": "boolean"}},
                    "required": ["diagnostics"],
                    "additionalProperties": False,
                },
            ]
        },
        "predicted_fix": {"type": "string", "pattern": r"\S"},
        "at_risk_regressions": {
            "type": "array",
            "items": {"type": "string", "pattern": r"\S"},
            "minItems": 1,
        },
    },
    "required": list(FIELDS),
    "additionalProperties": False,
}


@dataclass(frozen=True, slots=True)
class StructuredResponse:
    """One responder's exact reply: the text, who wrote it, what it cost."""

    raw: str
    model: str
    usage: Usage = Usage()
    # The provider-reported breakdown behind ``usage``, when the responder had
    # one. Additive and optional: ``usage`` remains the kernel-typed cost the
    # run accounts against a budget, and nothing about decoding reads this.
    # It exists because a budget total cannot answer "how many actual calls,
    # and what did each report" -- which is what a phase's provider-call
    # accounting has to reconcile. ``None`` means the responder reported no
    # breakdown, which is a different claim from reporting zeroes.
    call: CallUsage | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.raw, str):
            raise TypeError("structured response raw output must be text")
        if not isinstance(self.model, str) or not self.model:
            raise ValueError("structured response must name its model")
        if not isinstance(self.usage, Usage):
            raise TypeError("structured response usage must be a Usage")
        if self.call is not None and not isinstance(self.call, CallUsage):
            raise TypeError("structured response call usage must be a CallUsage")


Responder: TypeAlias = Callable[[Mapping[str, object]], StructuredResponse]


@dataclass(frozen=True, slots=True)
class Manifest:
    """A complete manifest, with its citations already resolved."""

    tokens: tuple[str, ...]
    citations: tuple[ExperienceRef, ...]
    surface: str
    value: str | Mapping[str, object]
    predicted_fix: str
    at_risk_regressions: tuple[str, ...]

    def as_data(self) -> dict[str, object]:
        """The manifest as retained evidence — tokens, never durable ids."""

        return {
            "schema": SCHEMA,
            "evidence_citations": self.tokens,
            "surface": self.surface,
            "value": self.value,
            "predicted_fix": self.predicted_fix,
            "at_risk_regressions": self.at_risk_regressions,
        }


@dataclass(frozen=True, slots=True)
class ManifestRefusal:
    """Why the response is not a manifest, plus whatever it did establish.

    ``citations`` is empty unless they resolved before the refusal. Retaining
    them is not generosity: they are trusted references the adapter itself
    produced, and dropping them would lose the fact that the model cited
    correctly and then failed at something else.
    """

    failure: Failure
    citations: tuple[ExperienceRef, ...] = ()


_Field = TypeVar("_Field")


def request_field(
    request: Mapping[str, object], key: str, kind: type[_Field]
) -> _Field:
    """One field of a request, at the type its builder put there.

    A :data:`Responder` is handed the opaque mapping a provider would receive,
    so every field of it arrives as ``object``. A field of the wrong type is a
    bug in whoever built the request rather than anything a model said, so this
    raises instead of refusing.
    """

    value = request[key]
    if not isinstance(value, kind):
        raise TypeError(f"request field {key!r} is not a {kind.__name__}")
    return value


def _reject_duplicates(pairs: list[tuple[str, object]]) -> dict[str, object]:
    keys = [key for key, _ in pairs]
    if len(set(keys)) != len(keys):
        raise ValueError("duplicate key")
    return dict(pairs)


def loads(raw: str) -> dict[str, object] | None:
    """Parse one JSON object, rejecting duplicate keys at every level.

    ``json.loads`` keeps the last of two equal keys and says nothing, so a
    response carrying ``surface`` twice would decode as though it named one.
    """

    try:
        value = json.loads(raw, object_pairs_hook=_reject_duplicates)
    except (ValueError, RecursionError):
        return None
    return value if isinstance(value, dict) else None


def _valid_value(value: str | Mapping[str, object]) -> bool:
    if isinstance(value, str):
        return True
    return set(value) == {"diagnostics"} and isinstance(value["diagnostics"], bool)


def _valid_risks(value: list[object]) -> bool:
    return (
        bool(value)
        and all(isinstance(item, str) and bool(item.strip()) for item in value)
        and len(set(value)) == len(value)
    )


def _decoded(
    body: Mapping[str, object], citations: tuple[ExperienceRef, ...]
) -> Manifest | str:
    """The manifest this body carries, or the first reason it carries none.

    Checking and keeping are one step because they are one claim: a field is
    well-formed *and* it is the value the manifest holds. Read apart, the
    construction could only assert the types a separate validator established —
    which is what the ``type: ignore`` comments here were, and an unchecked
    assertion is not narrowing.
    """

    if set(body) != set(FIELDS):
        return "manifest fields do not match the declared contract"
    tokens = body["evidence_citations"]
    surface = body["surface"]
    value = body["value"]
    predicted_fix = body["predicted_fix"]
    risks = body["at_risk_regressions"]
    if not isinstance(tokens, list):
        # ``resolve`` refused anything else before this, and returns the same
        # constant; stated again here because this is where the type is kept.
        return "evidence citations must be a non-empty array"
    if not isinstance(surface, str) or not surface.strip():
        return "manifest surface must be a non-empty name"
    if not isinstance(value, (str, dict)) or not _valid_value(value):
        return "manifest value must be text or {diagnostics: boolean}"
    if not isinstance(predicted_fix, str) or not predicted_fix.strip():
        return "manifest predicted fix must be non-empty"
    if not isinstance(risks, list) or not _valid_risks(risks):
        return "manifest at-risk regressions must be unique non-empty text"
    return Manifest(
        tokens=tuple(tokens),
        citations=citations,
        surface=surface,
        value=value,
        predicted_fix=predicted_fix,
        at_risk_regressions=tuple(risks),
    )


def decode(
    raw: str, ledger: Ledger, editable: tuple[str, ...]
) -> Manifest | ManifestRefusal:
    """Parse, resolve, validate, then authorize — in that order, always total.

    The order is the retention rule. Citations resolve before the remaining
    fields are read, so a response that cited correctly and then omitted a
    prediction still carries the references it earned; and the surface is
    authorized last, against ``editable``, so no undeclared name reaches the
    caller's mutation boundary.

    Building the manifest is not authorizing it. Its fields are kept where they
    are checked, because a value narrowed anywhere else is only asserted — and
    the surface it carries is still tested against ``editable`` before anything
    is returned.
    """

    body = loads(raw)
    if body is None:
        return ManifestRefusal(
            failure=InvalidOutput(message="response is not a JSON object")
        )
    citations = ledger.resolve(body.get("evidence_citations"))
    if isinstance(citations, str):
        return ManifestRefusal(failure=InvalidOutput(message=citations))
    decoded = _decoded(body, citations)
    if isinstance(decoded, str):
        return ManifestRefusal(
            failure=InvalidOutput(message=decoded), citations=citations
        )
    if decoded.surface not in editable:
        return ManifestRefusal(
            failure=ProposerFailure(
                message="mutation names a surface the parent does not declare",
                details={"declared": editable},
            ),
            citations=citations,
        )
    return decoded


__all__ = [
    "MANIFEST_SCHEMA",
    "SCHEMA",
    "SURFACES",
    "Manifest",
    "ManifestRefusal",
    "Responder",
    "StructuredResponse",
    "decode",
    "loads",
    "request_field",
]
