"""What a proposal keeps, stage by stage, and what it never invents.

Refusal is not all-or-nothing, and this module is where that is decided.
Citations resolve before the remaining manifest fields are read, so a response
that cited correctly and then omitted a prediction still carries the references
it earned; a complete manifest survives a typed mutation failure, so a rejected
edit still says what it expected; a response that established nothing keeps
only the envelope, bounded.

Separated from :mod:`tfd`, which owns the *flow* -- request, decode,
authorize, apply. Retention is the one part of that flow whose rule is about
evidence rather than about control, and it is the part a reader has to be able
to check against §4's retention contract without reading the adapter around
it.

Nothing here decides whether a proposal succeeded. Each function is handed an
already-typed outcome and answers one question: what may be written down.
"""

from __future__ import annotations

from typing import TypedDict

import meta_evolve as meta
from meta_evolve.domain import ExperienceRef

import call_usage
from proposal_manifest import Manifest, ManifestRefusal, StructuredResponse


# How much of an unusable response is kept. A bound on *retention*, so it
# lives with retention rather than with the decoder: an unbounded refusal
# would let a response that established nothing cost more storage than one
# that succeeded.
RAW_LIMIT = 2_000


def bounded_raw(raw: str) -> str:
    """At most ``RAW_LIMIT`` characters of an unusable response."""

    return raw[:RAW_LIMIT]


def call_payload(response: StructuredResponse) -> dict[str, int] | None:
    """The provider-reported breakdown for this one call, or nothing.

    Retained on the call evidence rather than folded into ``usage``: the
    kernel's ``Usage`` is the budgeted cost, and a phase's provider-call
    accounting has to answer a different question -- how many actual calls
    happened, and what each one reported. ``None`` stays ``None``: a responder
    that reported no breakdown must not be recorded as having reported zeroes.
    """

    if response.call is None:
        return None
    return call_usage.to_payload(response.call)


def evidence(**data: object) -> tuple[meta.EvidenceDraft, ...]:
    return (meta.EvidenceDraft(kind="sdk-structured-output", data=data),)


def incomplete(
    response: StructuredResponse, refusal: ManifestRefusal
) -> meta.ProposalResult:
    """Keep what was established, bound what was not, invent nothing.

    The raw text is bounded rather than dropped: it is the only record of what
    the model actually said, and an unbounded one would let a refusal cost more
    storage than a success. It is retained as proposer evidence, which the
    governed policy never selects.
    """

    return meta.ProposalResult(
        failure=refusal.failure,
        metadata={"model": response.model, "structured_output": True},
        evidence=evidence(
            model=response.model,
            raw=bounded_raw(response.raw),
            complete=False,
            call=call_payload(response),
        ),
        usage=response.usage,
        derived_from=refusal.citations,
    )


class Retained(TypedDict):
    """Every keyword a complete manifest contributes to its proposal.

    Named as a type so the splat below is checked against ``ProposalResult``
    rather than passed as an untyped mapping: this is the one place a retention
    key could be renamed and still typecheck.
    """

    hypothesis: str
    predicted_outcomes: dict[str, object]
    metadata: dict[str, object]
    evidence: tuple[meta.EvidenceDraft, ...]
    usage: meta.Usage
    derived_from: tuple[ExperienceRef, ...]


def complete(response: StructuredResponse, manifest: Manifest) -> Retained:
    """The contract a complete manifest keeps, whether or not it applied."""

    return {
        "hypothesis": manifest.predicted_fix,
        "predicted_outcomes": {
            "predicted_fix": manifest.predicted_fix,
            "at_risk_regressions": manifest.at_risk_regressions,
        },
        "metadata": {"model": response.model, "structured_output": True},
        "evidence": evidence(
            model=response.model,
            manifest=manifest.as_data(),
            complete=True,
            call=call_payload(response),
        ),
        "usage": response.usage,
        "derived_from": manifest.citations,
    }


__all__ = ["RAW_LIMIT", "Retained", "bounded_raw", "complete", "incomplete"]
