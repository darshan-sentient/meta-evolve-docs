"""What the model may read about a pulled source view.

The counterpart to :mod:`citation_rendering` on the pulled channel. Two rules,
which are one rule seen twice: nothing here may let a durable identity be
reconstructed, and nothing here may be text a candidate wrote *about itself*.

Surface values are candidate-authored, and they are published anyway — that is
the whole point of the slice. What stays out is every occurrence identity: no
run, trial, evaluation, or evidence id, no serialized reference, no raw record.
Content digests and logical steps are allowed. A digest is derived from content
rather than from an occurrence, and :mod:`citation_rendering` already exposes
logical step, so this widens nothing #226 had closed.

The parent view is rendered once, at the top. Repeating it inside every prior
block would put N identical copies of the same text in one prompt and would make
a determinism test pin the wrong shape.
"""

from __future__ import annotations

from collections.abc import Mapping

from meta_evolve.domain import SourceTree

from source_view import SOURCE_PATHS, file_bytes


UNAVAILABLE = "canonical source view unavailable"


def index_presentation(data: Mapping[str, object], step: int) -> str:
    """Its renderer, both content digests, and the paths it indexes, in order."""

    paths = ", ".join(entry["path"] for entry in data["paths"])
    return (
        f"canonical-source-index · {data['renderer']} · step {step} "
        f"· artifact {data['artifact_digest']} · view {data['view_digest']} "
        f"· {paths}"
    )


def file_presentation(data: Mapping[str, object], step: int) -> str:
    """Its path, and the complete exact content it is a citation for."""

    return (
        f"canonical-source-file · {data['path']} · step {step} "
        f"· {data['bytes']} bytes · {data['digest']}\n{data['content']}"
    )


def _files(view: SourceTree) -> str:
    return "\n".join(
        f"  {path} ({file_bytes(view[path])} bytes)\n{view[path]}"
        for path in SOURCE_PATHS
    )


def _comparison(parent: SourceTree, prior: SourceTree) -> str:
    lines: list[str] = []
    for path in SOURCE_PATHS:
        if prior[path] == parent[path]:
            lines.append(f"  {path}: same")
            continue
        lines.append(f"  {path}: differs\n{prior[path]}")
    return "\n".join(lines)


def prior_source_comparison(
    parent: SourceTree, priors: tuple[tuple[int, SourceTree | None], ...]
) -> str:
    """The parent view once, then one block per prior in the order pulled.

    Example-owned rendering over two values already held. It is not an M8.7
    ``diff_source`` operation and costs no reader operation.
    """

    blocks = [f"parent canonical view\n{_files(parent)}"]
    for step, view in priors:
        body = UNAVAILABLE if view is None else _comparison(parent, view)
        blocks.append(f"prior attempt at step {step}\n{body}")
    return "\n\n".join(blocks)


__all__ = [
    "UNAVAILABLE",
    "file_presentation",
    "index_presentation",
    "prior_source_comparison",
]
