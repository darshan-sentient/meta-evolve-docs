"""How one rollout runs, and what a whole split produced.

``ace_rollouts`` owns the tasks: the three splits, what each asks for, and the
rule that judges it. This module owns *running* them -- one session per task,
each inside its own inner run, and the typed outcome that comes back.

Split off when the two together outgrew this repo's module budget, along the
seam that was already there: a task is a value, running one is a procedure with
a failure boundary in the middle of it. ``test_context_evolution_sessions``
tests this half on its own.
"""

from __future__ import annotations

import meta_evolve as meta
from meta_evolve.domain import ComponentRef
from meta_evolve.errors import ExecutionAccountingUnknown
from meta_evolve.ports import Proposer

from ace_outcomes import (
    SPLIT_AGGREGATION,
    WRAPPER_FAILED,
    RolloutFault,
    SplitOutcome,
    classify_fault,
)
from ace_rollouts import (
    BASE_INSTRUCTIONS,
    CHECK_REVISION,
    ROLLOUT_BUDGET,
    ROLLOUT_SESSION_COMPONENT,
    Rollout,
    instructions_for,
    rollouts_in,
)
from declared_identity import digest, field_manifest
from inner_agent import InnerAgent
from playbook import Playbook


SPLIT_CONDITION_REVISION = "1"


def _condition(agent: InnerAgent, tasks: tuple[Rollout, ...]) -> str:
    """Everything governed that two comparable outcomes must share.

    Governed, and nothing else. The *rendered candidate* is deliberately
    absent: consolidation compares a playbook against its own pruning, so the
    candidate content is the one thing the two sides are meant to differ in.
    Folding it in here made the predicate refuse exactly the comparison it
    exists to make -- and the regression ``ace_consolidation`` says the
    re-score is there to catch, a change that started rendering retired items,
    came back as an ``UnmatchedEvidence`` escaping the whole study instead of
    the typed ``regressed`` decision it has a reason code for. So this covers
    the agent, the base instructions every rollout starts from, the aggregation
    and checking rules, the inner budget, and the ordered task definitions.
    """

    return digest(
        SPLIT_CONDITION_REVISION,
        {
            "agent": dict(agent.manifest),
            "instructions": BASE_INSTRUCTIONS,
            "aggregation": SPLIT_AGGREGATION,
            "check_revision": CHECK_REVISION,
            "budget": field_manifest(ROLLOUT_BUDGET),
            "rollouts": tuple(
                {
                    "name": rollout.name,
                    "split": rollout.split,
                    "target": rollout.target,
                    "answer": rollout.answer,
                    "source": dict(rollout.source.items()),
                }
                for rollout in tasks
            ),
        },
    )

def declared_session(session: Proposer, version: str) -> Proposer:
    """The caller's session, wrapped in a callable this module can declare.

    Declared through a local wrapper rather than by setting an attribute on
    whatever the factory returned: that object belongs to the caller and may
    not accept one at all -- a ``functools.partial`` does not.
    """

    def propose(tree, context):
        return session(tree, context)

    propose.component = ComponentRef.configured_local(
        "proposer", propose, name=ROLLOUT_SESSION_COMPONENT, version=version
    )
    return propose


def run_rollout(rollout: Rollout, session: Proposer, version: str) -> meta.Run:
    """One rollout: a plain inner run over an ordinary source-tree task.

    Both components are declared. Left name-only, the inner run recorded a
    module-and-qualname reference for a closure holding an entire playbook --
    so one task under contradicting instructions produced the *same* inner run
    id while scoring 0.0 and 1.0, and no reader of that run could tell which
    playbook had been in force.
    """

    experiment = meta.Experiment(
        task=meta.Task(
            evaluator=rollout.check,
            artifact=meta.SourceTree,
            # No ``satisfy``: the rollout must always reach its one proposal, so
            # a missing second evaluation means the agent failed rather than
            # that the inner search stopped early.
            objectives=(meta.Maximize("solved"),),
            budget=ROLLOUT_BUDGET,
        ),
        seed=rollout.source,
        proposer=declared_session(session, version),
        search=meta.Greedy(max_trials=1),
    )
    return meta.run(experiment)


def run_split(split: str, playbook: Playbook, agent: InnerAgent) -> SplitOutcome:
    """Roll out one split and report it without deciding anything."""

    instructions = instructions_for(playbook)
    tasks = rollouts_in(split)
    # What the inner runs were configured with: this agent, and this playbook
    # rendered into instructions. Both are inside the session closure, where a
    # run-local reference cannot see either.
    version = digest(
        agent.revision,
        {"agent": dict(agent.manifest), "instructions": instructions},
    )
    condition = _condition(agent, tasks)
    usage = meta.Usage()
    scores: dict[str, float] = {}
    unfinished: dict[str, RolloutFault] = {}
    runs: dict[str, meta.Run] = {}
    sessions = 0
    for rollout in tasks:
        # One session per rollout, never one per split. The factory is called
        # again for each task because a live wrapper holds conversation state:
        # reusing it would let the second rollout answer from the first, and
        # every task in a split asks for the same convention over a different
        # file -- precisely the leak that would look like the playbook working.
        # The fixture agents are stateless, so nothing here would have noticed.
        sessions += 1
        try:
            session = agent.build(instructions)
        except ExecutionAccountingUnknown:
            raise
        except Exception as unstarted:
            # Opening the session happens outside the inner run's failure
            # boundary, so a wrapper that cannot open one used to raise
            # straight out of ``study_playbook`` -- past every typed outcome,
            # and discarding the cost the earlier rollouts of this split had
            # already reported along with it. Catching broadly is the point
            # rather than a lapse: the factory is the caller's code, and this
            # is the boundary where it becomes an outcome. ``BaseException``
            # is deliberately not caught, so an interrupt still interrupts.
            unfinished[rollout.name] = RolloutFault(
                WRAPPER_FAILED, f"session did not start: {unstarted}"
            )
            continue
        result = run_rollout(rollout, session, version)
        # Kept rather than scored and dropped: the inner run holds the lineage,
        # the wrapper's own evidence, and the declarations above -- none of
        # which can be recovered from a float.
        runs[rollout.name] = result
        # Only reported cost rolls up. The inner runs own their own counts; the
        # outer kernel mints and owns its own.
        usage += result.usage().without_counts
        _, attempt = result.trials()
        if attempt.state != "evaluated":
            # The reason when the wrapper recorded one, the kind otherwise:
            # `proposer_failure` alone hides whether the session ran out of
            # time or the wrapped SDK refused the request. An absent target
            # arrives here too, because the check refuses it rather than
            # scoring it -- so this branch no longer has a sibling patching
            # the aggregate after a rankable zero was already recorded.
            unfinished[rollout.name] = classify_fault(attempt.state, attempt.failure)
        else:
            scores[rollout.name] = float(attempt.metrics["solved"])
    return SplitOutcome(
        split=split,
        condition=condition,
        declared=tuple(rollout.name for rollout in tasks),
        scores=scores,
        unfinished=unfinished,
        usage=usage,
        sessions=sessions,
        runs=runs,
    )


__all__ = ["declared_session", "run_rollout", "run_split"]
