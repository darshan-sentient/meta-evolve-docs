# Context evolution

<!-- Kept together despite exceeding 300 lines: the paired fixtures share setup,
authority, accounting, and replay boundaries; their side-by-side comparison avoids
duplicating those contracts across sibling guides. -->

The company-convention skill example below remains an offline regression
fixture. The maintained [EvoSkill walkthrough](https://sentient-xyz.github.io/meta-evolve-docs/build-patterns/evoskill/)
and `evoskill.ipynb` now use Claude SDK agents, native skill folders and real
OfficeQA questions; their source lives in `examples/research/evoskill/`.
The ACE fixture and its notebook continue to use this directory.

Two ways to evolve what an agent is *told*, side by side, behind one command.

```bash
uv run python examples/research/context_evolution/main.py
```

No credentials, no network, no cost: the script injects deterministic fixture
agents, and `--sibling evoskill` or `--sibling ace` runs one sibling.
[Run it](#run-it) has the exact transcript. Each sibling is one call taking a
declared inner agent, and this block runs as it stands from the repository root:

```python
import sys
sys.path.insert(0, "examples/research/context_evolution")  # plain sibling modules

import meta_evolve as meta

from ace_context import playbook_fixture_agent
from ace_study import study_playbook
from inner_agent import InnerAgent
from skill_context import evolve_skills, fixture_agent


# Swap either fixture for your own build(instructions) wrapper. The declaration
# travels with it, because a model id is not an agent: two differently
# configured wrappers on one model would record one evaluator, and `compare`
# would then rank an uncontrolled comparison.
def declared(build, revision):
    return InnerAgent(build=build, model="deterministic-fixture", revision=revision)


study = study_playbook(declared(playbook_fixture_agent, "fixture-playbook-agent-v1"))
if study.aborted:                      # no playbook: an outcome, not an error
    print(study.aborted)
else:
    print(study.playbook.identities)
    # A split with an unfinished rollout has no rankable score, so ask first.
    print(study.held_out.solved if study.held_out.is_complete
          else study.held_out.unfinished)
print(study.failures)                  # retained whether or not it aborted

run = evolve_skills(declared(fixture_agent, "fixture-skill-agent-v1"))
try:
    best, trial = run.best(), run.best_trial()
except meta.NoSuccessfulEvaluation:
    for attempt in run.trials():
        if attempt.failure is not None:
            print(attempt.failure.kind, attempt.failure.message)
    print(run.usage())
else:
    print(list(best.value), trial.metrics["solved"])
```

`build(instructions)` is yours: any model SDK wrapped in an ordinary proposer
callable. [Bring your own agent](#bring-your-own-agent) covers that boundary and
what a live run costs before it costs anything. Both siblings keep the candidate
*above* the inner agent -- the outer proposer is deterministic Python with no
model in it -- and neither needed a new artifact type.

| sibling | candidate | shape it suits | method mapping |
|---|---|---|---|
| `evoskill` | `meta.SkillSet` | prose an agent reads whole, one `skills/<name>.md` per skill | [EvoSkill](https://arxiv.org/abs/2603.02766) |
| `ace` | `meta.Text` holding canonical JSON | entries that need citing, amending, and retiring one at a time | [ACE](https://arxiv.org/abs/2510.04618) |

That one is about *representation*; this one is about fidelity -- what each
paper motivates, what runs here, and what is left out on purpose.

| sibling | paper mechanism | example implementation | Meta-Evolve role | deliberately omitted |
|---|---|---|---|---|
| `evoskill` | reusable skill artifacts | `meta.SkillSet`, one `skills/<name>.md` per skill, proposed a whole document at a time | a shipped artifact and codec — no memory subsystem, no new artifact type | agentic skill builders: the documents come from a fixed `SKILL_LIBRARY`, and nothing in the example writes one |
| `evoskill` | failure-driven discovery | `add_skill` adds a document the candidate lacks, drawn with the run's seeded RNG | `ProposerContext.rng`, so a deterministic rerun repeats the draw | the failure-driven part: no failed episode is read, so nothing decides *which* skill to write next |
| `evoskill` | held-out selection | the two episodes *are* the objective, and every candidate is scored on both | evaluator authority over the episode list, budget, and objective | a selection split: these episodes are held out from the **agent** — the policy appears in no workspace file — not from selection. Splits are the ACE sibling's demonstration |
| `ace` | itemized context with stable identities | `playbook.py` items carry identity, section, content, and status; items are independently amended or retired, and generation appends the first uncovered item | `meta.Text` over canonical JSON, plus typed codec and transition rejections | semantic deduplication: identity is a literal string, so two items wording one rule stay two items |
| `ace` | incremental generation, reflection on execution feedback, curation | `ace_curation.py` curates before it generates, over lessons published only from development rollouts that **finished and were wrong** | the evaluator decides what is published; the transition guard refuses a candidate that erases the record | a model in the loop: reflection is the suite comparing an answer to the expected element, and both curator and generator are deterministic Python. The model runs only *inside* a rollout |
| `ace` | explicit consolidation | `ace_consolidation.py` prunes retired items, re-scores the private split under the same budget, and keeps the pruning only if it was neutral on matched evidence | `Budget` re-applied, and a matched-condition comparison rather than two unmatched means | online adaptation: consolidation runs once, after selection — not continuously against live traffic |
| both | the outer search | `meta.Greedy(max_trials=2)` over one `Maximize("solved", satisfy=1.0)` | a shipped search policy, budget enforcement, and seeded deterministic search decisions | Pareto and multi-objective search, and every benchmark number either paper reports |

**These are mechanism demonstrations.** See [Non-claims](#non-claims) before
citing anything here.

The directory is split by what can be tested on its own, and both siblings have
the same shape: a `_context` module for configuration, an `_episodes` module for
the evaluator, and neither sibling's logic in `main.py`. Every module's docstring
says what it owns, so the list is the directory rather than a copy of it here.

## Authority

- The candidate changes **its own content only** -- skill documents, or playbook
  items -- never the evaluator, splits, tasks, objective, budget, declaration, or
  promotion decision.
- Proposal and acceptance are separate roles: **consolidation acceptance is the
  evaluator's call** even though the candidate marks an item retired.
- A split with any unfinished rollout is **unrankable, not averaged**: one
  success beside one timeout is not `1.0`, so `SplitOutcome.solved` refuses.
- A lesson is published only for a development rollout that **finished and was
  wrong**; an incomplete development split publishes nothing at all.
- Four **typed, unrankable outcomes**, none of which becomes a low score:

  | kind | what happened |
  |---|---|
  | `invalid` | not a playbook: malformed, duplicate identities, unknown fields, or a refused item transition |
  | `wrapper-failed` | the injected wrapper produced no candidate |
  | `unverifiable` | a candidate arrived, but the file the check reads is gone, so there is nothing left to judge |
  | `infrastructure-failed` | an exhausted budget, a timeout, or a broken machine — nobody's evidence |

  Without `unverifiable`, an agent that *deleted* the target file scored
  identically to one that wrote the wrong value. Anything not positively
  attributable to the wrapper *is* infrastructure: a candidate blamed for an
  unidentified fault can corrupt a result, while infrastructure charged for a
  refusal only loses a signal.

## Non-claims

On the survey's ladder these siblings are the search and experience loops
with fixture agents. They demonstrate the boundary, and they are not
evidence of recursive self-improvement. See [where Meta-Evolve sits on the ladder](../../../docs/research/recursive-self-improvement-survey.md#where-this-sits-on-the-self-improvement-ladder).

Stated plainly, because the papers claim more than this demonstrates:

- **Not reproductions.** Neither sibling reproduces its paper's system,
  benchmarks, transfer results, or gains. They demonstrate a mechanism.
- **No cross-task transfer claim.** The held-out `1.0` shows *this* mechanism
  carrying *these* conventions to files it never saw, not that ACE generalises.
- **The lessons are authored, not learned.** The evaluator publishes what it saw
  the agent get wrong; the proposer decides where it belongs and what it retires.
- **No live measurement.** Every number here comes from the fixture agents.
- **Not portable.** Both suites are local closures over their rollout lists;
  the portable `EpisodeSuite` type is a later milestone's deliverable.

## The ACE sibling's three splits

| split | rolled out | who sees it |
|---|---|---|
| development | once, before the search | **public** — a mistagged line publishes the filer's policy as a lesson, and lessons are all a proposer learns from |
| private | once per outer evaluation | selection only; the proposer sees no name, task, or score |
| held out | once, after selection | nobody — never enters proposal context, never contributes to the objective |

`ace_curation.revise(lessons)` closes over the published lessons and nothing
else, so "held-out cannot reach proposal context" is a closure property that
`test_context_evolution_ace.py` walks.

## Why these tasks

Both siblings tag amounts in a filer's notes, where Northwind Industries files
its own **taxonomy extension** element rather than the standard `us-gaap` one:

| the note says | the standard element | what Northwind files |
|---|---|---|
| "Cash paid for interest, net of $6 million capitalized, was $214 million." | `us-gaap:InterestPaid` | `nwi:InterestPaidNetOfCapitalized` |
| "Operating lease cost, excluding short-term leases, was $88 million." | `us-gaap:LeaseCost` | `nwi:OperatingLeaseCostExcludingShortTerm` |

Which element gets filed is a policy written in the filer's tagging manual and
nowhere else. The standard one is the answer a capable agent gives -- a good
reading of the disclosure, and wrong for this filer -- and an extension element
cannot be reached by reasoning about the workspace at all, so the score moves
because the context carried knowledge. **Context earns its place by carrying
knowledge the model cannot infer, not a habit it already has**, which live runs
of this example's pre-removal form established by scoring `1.0` unguided on
tasks that tested habits; `ace_rollouts.py` owns the rest of the argument.

## The agent's configuration is inside the evaluator, so the suite declares it

The agent lives *inside* the evaluator, so whatever configured it is captured
state that a run-local component reference cannot show -- such a reference is
named by module and qualname alone. Two skill runs over two differently
configured agents would declare the **same** evaluator, and `Run.compare` would
rank them: a winner, silently, out of an uncontrolled comparison. So
`episode_suite` declares itself through `ComponentRef.configured_local`,
versioned by a digest over an explicit *manifest* rather than a hand-joined line
whose forgotten field leaves no trace: a manifest is a value a test can walk and
perturb leaf by leaf, which `test_context_evolution_identity.py` does across
every field either suite names. Two runs whose declarations differ raise
`RunsNotComparable`.

**A model id is not an agent declaration.** Wrapper revision, SDK version,
system-instruction construction, permitted tools, turn limit: each changes what
an agent does while the model id holds still, and declaring the model alone let
two factories reaching *opposite* results record one run id and one evaluator.
So both siblings take an `InnerAgent`, and what it verifies is bounded:
`factory_digest` fingerprints the surface Python can inspect -- source,
executable code, argument shape, immutable defaults, captured helpers -- to the
end of that chain rather than a fixed depth, identically in every process,
refusing what it cannot read rather than approximating it. It does not prove
behavioral identity for arbitrary callables, which is why `revision` is required
and non-secret `configuration` declared. `inner_agent.py` and
`factory_identity.py` state that boundary exactly, including which defaults are
refused and what the refusal names.

## Run it

```bash
uv run python examples/research/context_evolution/main.py
```

The script injects deterministic fixture agents: proposer callables following
exactly the conventions present in their instructions and nothing more. They need
no credentials, cost nothing, and always print:

```text
== evoskill: skill documents ==
skills: ['skills/interest.md', 'skills/leases.md']
solved: 1.0
reported cost: 0 tokens, 0 spend_micros, 0.0 wall_seconds
outer kernel: 3 evaluations, 2 trials
wrapper calls: 6 of at most 6

== ace: context playbook ==
development solved: 0.0
lessons published: ['interest-element', 'lease-element']
items: ['interest-element', 'scale-in-thousands', 'lease-element']
active: ['interest-element', 'lease-element']
trial scores: ['0.0', '0.5', '1.0']
solved: 1.0
reported cost: 0 tokens, 0 spend_micros, 0.0 wall_seconds
outer kernel: 3 evaluations, 2 trials
wrapper calls: 14 of at most 14
consolidated: True (neutral) -> ['interest-element', 'lease-element']
held-out solved: 1.0
```

Both searches climb a real gradient: the EvoSkill seed holds no skills and
scores `0.0`, one skill `0.5`, both `1.0`, and the ACE seed scores `0.0` because
its manual names the standard element for cash interest and says nothing about
leases, so the first proposal has to curate before the second can add what was
missing. `scale-in-thousands` then stays in `items` but not in `active`: retiring
keeps an entry in the record while stopping it being rendered, and consolidation
prunes it -- `neutral` being why that pruning was *kept*, beside
`nothing-retired`, `regressed`, and `incomplete`. The zero cost is measured.

## Notebooks

The standalone scripts remain the primary runnable examples. Run one sibling at
a time with:

```bash
uv run python examples/research/context_evolution/main.py --sibling evoskill
uv run python examples/research/context_evolution/main.py --sibling ace
```

The executed [ACE notebook](../../../docs/notebooks/context_evolution/ace.ipynb)
steps through the ACE fixture a cell at a time. It is committed with its outputs;
`tests/test_context_evolution_notebooks.py` re-executes it and its closing exercise.
The [EvoSkill notebook](../../../docs/notebooks/context_evolution/evoskill.ipynb)
now follows the separate [Claude/OfficeQA example](../evoskill/README.md), with
captured live responses and paid calls when rerun. For the deterministic skill
fixture, use `main.py --sibling evoskill` above.

The dev environment installs a kernel, not a front-end. This command executes a
fresh copy of the credential-free ACE lesson into `/tmp`:

```bash
uv run jupyter nbconvert --to notebook --execute docs/notebooks/context_evolution/ace.ipynb --output-dir /tmp
```

## Bring your own agent

Both siblings take an `InnerAgent`, so a live agent enters through the user-owned
SDK boundary: pass any `build(instructions)` wrapping your SDK in an ordinary
proposer callable -- or one returning `ProposalResult` to report tokens, elapsed
time, and evidence -- with the declaration describing it. The wrapper stays
outside Meta-Evolve and owns authentication, session lifecycle, tools,
permissions, and timeouts; see
[`docs/guides/providers.md`](../../../docs/guides/providers.md).

**A live wrapper makes real requests and may incur cost.** Both outer budgets
allow three candidates -- the seed plus two revisions -- and every rollout is
bounded by the wall budget its inner run declares. `evoskill` costs at most
**6 wrapper calls** and `ace` at most **14**:

| sibling | outer | inner rollout | worst-case wrapper calls |
|---|---|---|---|
| `evoskill` | `Budget(evaluations=3, trials=2)` | `Budget(evaluations=2, trials=1, wall_seconds=120)` | **6** = outer evaluations x 2 episodes |
| `ace` | `Budget(evaluations=3, trials=2)` | `Budget(evaluations=2, trials=1, wall_seconds=120)` | **14** = 2 development + 2 x 3 private + 2 held out + 2 x 2 consolidation check |

`wrapper_call_ceiling` computes the ACE number from the split sizes rather than
restating it, and a test pins it. The default command drives both siblings, so
budget for **20** unless you pass `--sibling`;
[`docs/live-agent-track.md`](../../../docs/live-agent-track.md) records both
ceilings for opt-in drivers. Each suite reports one `EvaluationResult` per
candidate, so only what the inner runs *report* rolls up into it.

**The factory is called once per rollout, not once per split.** A live wrapper
holds conversation state, so a session spanning two rollouts would let the second
answer from the first -- and since every task in a split asks the same convention
over a different file, that leak reads exactly like the playbook working.
`study.usage` covers all four phases, so it is what to check against the ceiling.

A live run is not reproducible: the outer search is deterministic given
`random_seed`, but each episode's score comes from a real session. Two live runs
of this example's unchanged pre-removal form reached `1.0` and `0.5` -- two
samples, not a before and an after.

**Durable replay covers the outer search run; a seeded rerun is not replay.**
Pass `storage=meta.Storage.durable(path)` to `study_playbook`, and
`meta.Run(run_id, storage)` reopens the search phase in another process,
answering every query -- trials, lineage, evidence, both declarations, the
winning bytes, and captured inner rollout histories -- from recorded events
without calling the wrapper again. Those captures retain inner run ids,
attempts, lineage, failures, evidence, and usage, but are summaries rather than
reopenable child runs. The development, consolidation, and held-out phases are
**in-memory study outcomes**: they are not persisted, and their evidence lives
on the returned `PlaybookStudy` for as long as the caller holds it. So budget
for one authorized run, and read `test_context_evolution_replay.py`, which
drives both sides of that boundary.

## Tests

Every test drives the example's own functions through the same fixture agents:

```bash
uv run pytest tests -k context_evolution
```

They split by what can fail on its own rather than by sibling, and each file's
docstring names the defect it catches.
