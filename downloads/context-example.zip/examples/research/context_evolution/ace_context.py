"""The ACE sibling's configuration: seed, budgets, and the fixture agent.

``ace_study`` owns the lifecycle and ``main.py`` the command. This module owns
what the sibling is *set up with*, which is the shape ``skill_context`` has for
the other sibling, so neither has to be read to understand the other.

The seed is deliberately not empty. It states one convention wrongly and one
thing nothing supports, so the first proposal has to *curate* -- amend the
rescuable entry, retire the unsupported one -- before the second can grow the
playbook. A seed of nothing would only ever exercise generation, and the
curation half of the mechanism would go untested by the script a reader runs.
"""

from __future__ import annotations

import sys
from pathlib import Path

import meta_evolve as meta
from meta_evolve.ports import Proposer

HERE = Path(__file__).parent
if str(HERE) not in sys.path:
    # Example modules are plain siblings, not an installed package.
    sys.path.insert(0, str(HERE))

from ace_episodes import wrapper_call_ceiling  # noqa: E402 -- needs the path
from inner_agent import FIXTURE_MODEL, InnerAgent  # noqa: E402
from playbook import Playbook, PlaybookItem  # noqa: E402

# The outer bound's outer bound. Same shape as the skill search: the seed
# playbook plus at most two revisions. ``wrapper_call_ceiling`` turns that into
# the worst-case number of injected-wrapper rollouts, counting the development
# pass, one private split per outer evaluation, the held-out pass, and the
# consolidation check.
PLAYBOOK_TRIALS = 2
PLAYBOOK_BUDGET = meta.Budget(evaluations=PLAYBOOK_TRIALS + 1, trials=PLAYBOOK_TRIALS)
PLAYBOOK_CALL_CEILING = wrapper_call_ceiling(PLAYBOOK_BUDGET.evaluations)

# The seed is deliberately not empty. It is a tagging manual that already
# exists and is already partly wrong, which is the state a real one is in: it
# names the standard element for cash interest, which is defensible and not
# what this filer reports, and it carries a presentation rule nothing in the
# evidence supports. So the first proposal has to *curate* -- amend the
# rescuable entry, retire the unsupported one -- before the second can add the
# entry the manual is missing. A seed of nothing would only ever exercise
# generation, and the curation half of the mechanism would go untested by the
# script a reader runs.
SEED_PLAYBOOK = Playbook(
    (
        PlaybookItem(
            identity="interest-element",
            section="debt",
            content="Cash interest is tagged us-gaap:InterestPaid.",
        ),
        PlaybookItem(
            identity="scale-in-thousands",
            section="presentation",
            content="Scale every tagged amount to thousands before filing.",
        ),
    )
)


def playbook_fixture_agent(instructions: str) -> Proposer:
    """The ACE sibling's inner proposer: the same stand-in, more disclosures.

    It reads the note rather than the filename, because the three splits tag
    the same two policies in six differently worded disclosures -- which is
    what makes a manual entry worth carrying instead of a lookup table.
    Without the entry in its instructions it writes the standard element a
    careful analyst would reach for, which is exactly the sensible wrong
    answer a capable agent gives.
    """

    def propose(tree: meta.SourceTree, _context) -> meta.SourceTree:
        note = tree.get("README.md", "")
        target = next(path for path in sorted(tree) if path != "README.md")
        if "interest" in note.lower():
            value = (
                "nwi:InterestPaidNetOfCapitalized\n"
                if "nwi:InterestPaidNetOfCapitalized" in instructions
                else "us-gaap:InterestPaid\n"
            )
        else:
            value = (
                "nwi:OperatingLeaseCostExcludingShortTerm\n"
                if "nwi:OperatingLeaseCostExcludingShortTerm" in instructions
                else "us-gaap:LeaseCost\n"
            )
        return meta.SourceTree({**tree, target: value})

    return propose


# The committed fixture, declared. ``configuration`` is empty and honestly so:
# the factory closes over nothing but its own argument. Secret material stays
# outside Meta-Evolve values and evidence. A live wrapper declares only
# non-secret behavior settings -- such as auth mode, credential-source
# identifier, turn limit, and tools -- that source inspection cannot see.
PLAYBOOK_FIXTURE_AGENT = InnerAgent(
    build=playbook_fixture_agent,
    model=FIXTURE_MODEL,
    revision="fixture-playbook-agent-v1",
)
