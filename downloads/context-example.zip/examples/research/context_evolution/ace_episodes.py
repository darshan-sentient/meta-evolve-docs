"""The playbook's evaluator: what gets published, scored, and accepted.

``ace_rollouts`` owns the tasks. This module owns every *decision* about them,
and all of it is governed infrastructure the candidate cannot reach:

* **What a proposer may learn.** ``development_lessons`` publishes a lesson for
  each development rollout the agent got wrong, and derives it from the
  development split alone. No private or held-out score is an input, so neither
  has a route into proposal context.
* **What selection is scored on.** ``evaluate_playbook`` runs the private split
  and reports one ``EvaluationResult``, so the outer kernel records exactly one
  evaluation per candidate.
* **When the held-out split runs.** Once, after selection. Consolidation
  acceptance is the other decision of this kind and lives next door in
  ``ace_consolidation``, which needs this module's private-split scoring.
* **What the evaluator declares.** ``playbook_suite`` folds the agent
  declaration and the split membership into a component version, so two runs
  over differently configured agents are refused comparison rather than ranked.

Nothing here lets a candidate rank itself, and a candidate that is not a valid
playbook gets a typed outcome with no metric at all.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, EvaluatorFailure
from meta_evolve.ports import EvaluationResult, EvidenceDraft

from ace_outcomes import (
    ROLLOUT_FAULT_KINDS,
    SPLIT_AGGREGATION,
    SplitIncomplete,
    SplitOutcome,
)
from declared_identity import digest, field_manifest
from inner_agent import InnerAgent
from inner_capture import capture_run
from ace_rollouts import (
    BASE_INSTRUCTIONS,
    CHECK_REVISION,
    DEVELOPMENT,
    HELD_OUT,
    PRIVATE,
    ROLLOUTS,
    ROLLOUT_BUDGET,
    Lesson,
    rollouts_in,
)
from ace_sessions import run_split
from playbook import Playbook, PlaybookRejection
from playbook_codec import decode

PLAYBOOK_SUITE_COMPONENT = "context-evolution:playbook-suite"
PLAYBOOK_SUITE_VERSION = "1"

# A candidate that is not a playbook at all. The three rollout kinds live in
# ``ace_outcomes`` because they are properties of a rollout's execution; this
# one is a property of the candidate, so it belongs here. Together these are
# the four unrankable outcomes #194's authority contract names.
INVALID = "invalid"
FAILURE_KINDS = (INVALID, *ROLLOUT_FAULT_KINDS)


def development_lessons(outcome: SplitOutcome) -> tuple[Lesson, ...]:
    """Publish a lesson for each *completed* development rollout got wrong.

    This is the whole of what a proposer is allowed to learn from, and it is
    derived from the *development* split alone. A private or held-out task
    cannot reach it, because no private or held-out score is an input here.

    Only a completed wrong answer licenses a lesson. The failed set used to
    union ``outcome.unfinished`` as well, so a rollout that timed out, or whose
    wrapper produced nothing, published the evaluator-owned correct answer on
    the strength of no evidence whatsoever -- feedback bought with a fault. A
    lesson says "the agent needed to be told this and was not", and only a
    finished, wrong rollout is grounds for saying it.

    An incomplete split is refused outright rather than partly harvested,
    because the manifest a proposer declares has to be the manifest the
    evidence supports. Publishing the subset that happened to finish would
    configure the search from a truncated view and record it as complete.
    """

    if not outcome.is_complete:
        raise SplitIncomplete(outcome.split, outcome.unfinished)
    failed = {name for name, score in outcome.scores.items() if score < 1.0}
    return tuple(
        rollout.lesson for rollout in rollouts_in(DEVELOPMENT) if rollout.name in failed
    )


def evaluate_playbook(
    candidate: meta.Text, agent: InnerAgent
) -> EvaluationResult:
    """Score one playbook on the private split.

    A candidate that is not a valid playbook is a typed, unrankable outcome: it
    reports no metric at all, so it can never out-rank a playbook that merely
    scored badly. The same is true of a rollout whose agent produced nothing --
    that is absence of evidence, not evidence of a bad playbook.
    """

    try:
        playbook = decode(candidate)
    except PlaybookRejection as rejection:
        return EvaluationResult(
            failure=EvaluatorFailure(
                message="candidate is not a valid playbook",
                details={
                    "kind": INVALID,
                    "rejection": rejection.kind,
                    **dict(rejection.details),
                },
            )
        )

    outcome = run_split(PRIVATE, playbook, agent)
    evidence = (
        EvidenceDraft(
            kind="context-evolution.private-rollouts",
            data={
                "scores": outcome.scores,
                "active_items": float(len(playbook.active())),
                # How many wrapper sessions this evaluation actually opened.
                # Recorded here because it is the only place that knows: the
                # study can total the phases it holds, but the search's splits
                # happen inside evaluations and would otherwise be guessed
                # from the declared ceiling.
                "sessions": float(outcome.sessions),
                "runs": tuple(
                    capture_run(name, run) for name, run in outcome.runs.items()
                ),
            },
        ),
    )
    if outcome.unfinished:
        # Name every kind present rather than collapsing to one message. A
        # timeout and a refusing wrapper call for different responses, and a
        # reader who only sees "no candidate" cannot tell them apart. The
        # reported cost gathered before the fault is kept either way.
        kinds = tuple(sorted({fault.kind for fault in outcome.unfinished.values()}))
        return EvaluationResult(
            failure=EvaluatorFailure(
                message=f"a rollout produced no usable evidence: {', '.join(kinds)}",
                details={
                    "kinds": kinds,
                    "unfinished_rollouts": {
                        name: {"kind": fault.kind, "detail": fault.detail}
                        for name, fault in outcome.unfinished.items()
                    },
                },
            ),
            evidence=evidence,
            usage=outcome.usage,
        )
    return EvaluationResult(
        metrics={"solved": outcome.solved}, evidence=evidence, usage=outcome.usage
    )


def held_out_report(
    playbook: Playbook, agent: InnerAgent
) -> SplitOutcome:
    """Roll out the held-out split once, after selection has already happened.

    Calling this earlier would not fail loudly, which is why the proposer is
    built over development lessons alone rather than handed this function.
    """

    return run_split(HELD_OUT, playbook, agent)


# How per-rollout scores become the one metric the outer search ranks. Declared
# rather than implied: a suite that took the worst rollout instead of the mean
# would rank different playbooks and must not claim the same evaluator.
AGGREGATION = SPLIT_AGGREGATION


def evaluator_manifest(agent: InnerAgent) -> Mapping[str, object]:
    """Everything this evaluator's behaviour depends on, as one plain value.

    The previous version joined four things into a line: a revision, the model,
    the rollout timeout, and ``split:name`` per rollout. Everything else was
    invisible to it -- change a task's README, its target file, the answer a
    check accepts, a published lesson's wording, or the rollout budget, and two
    materially different evaluators declared the same version. ``compare``
    requires exact equality of that version and nothing else, so the guard was
    reporting a controlled comparison for runs that had measured different
    things.

    Hashing a manifest instead of a join is the point. A join is a list someone
    maintains and the forgotten field leaves no trace;
    ``test_context_evolution_identity`` walks this structure, perturbs every
    leaf in it, and requires the version to move for each -- which no
    hand-written list of fields could keep honest.
    """

    return {
        "revision": PLAYBOOK_SUITE_VERSION,
        "agent": agent.manifest,
        "aggregation": AGGREGATION,
        "check_revision": CHECK_REVISION,
        "instructions": BASE_INSTRUCTIONS,
        "budget": field_manifest(ROLLOUT_BUDGET),
        "rollouts": tuple(
            {
                "name": rollout.name,
                "split": rollout.split,
                "target": rollout.target,
                "answer": rollout.answer,
                "source": dict(rollout.source.items()),
                "lesson": {
                    "id": rollout.lesson.identity,
                    "section": rollout.lesson.section,
                    "marker": rollout.lesson.marker,
                    "content": rollout.lesson.content,
                },
            }
            for rollout in ROLLOUTS
        ),
    }


def suite_version(agent: InnerAgent) -> str:
    """What this evaluator was configured with, as a durable version string."""

    return digest(PLAYBOOK_SUITE_VERSION, evaluator_manifest(agent))


def playbook_suite(
    agent: InnerAgent,
) -> Callable[[meta.Text], EvaluationResult]:
    """Bind the private split to one declared agent, and declare itself.

    Same reasoning as the SkillSet sibling: the agent lives inside this
    closure, so without its declaration two runs over two different agents
    would record the same evaluator and ``Run.compare`` would rank an
    uncontrolled comparison.
    """

    def score_playbook(candidate: meta.Text) -> EvaluationResult:
        return evaluate_playbook(candidate, agent)

    score_playbook.component = ComponentRef.configured_local(
        "evaluator",
        score_playbook,
        name=PLAYBOOK_SUITE_COMPONENT,
        version=suite_version(agent),
    )
    return score_playbook


def wrapper_call_ceiling(outer_evaluations: int) -> int:
    """Every rollout an injected wrapper can be asked for, worst case.

    One development pass, one private split per outer evaluation, one held-out
    pass, and the consolidation check's two private passes.
    """

    per_split = len(rollouts_in(PRIVATE))
    return (
        len(rollouts_in(DEVELOPMENT))
        + per_split * outer_evaluations
        + len(rollouts_in(HELD_OUT))
        + per_split * 2
    )


__all__ = [
    "AGGREGATION",
    "FAILURE_KINDS",
    "INVALID",
    "development_lessons",
    "evaluate_playbook",
    "evaluator_manifest",
    "held_out_report",
    "playbook_suite",
    "suite_version",
    "wrapper_call_ceiling",
]
