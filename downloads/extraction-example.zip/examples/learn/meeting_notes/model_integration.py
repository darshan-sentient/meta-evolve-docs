"""Compose user-owned response/rewrite callables; this module makes no calls.

Both callables return ProposalResult with text or a typed failure plus usage.
SDK authentication, timeouts, retry enforcement, and telemetry stay user-owned.
"""

from hashlib import sha256
import json
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import ComponentRef, InvalidOutput

from meeting_components import evaluator
from prompt_feedback import feedback_report
from prompt_variants import SEED


def experiment(respond, rewrite, *, model_configuration):
    """Compose respond(prompt, notes) and rewrite(parent, report) ProposalResults.

    Declare every behavior-changing model/wrapper setting in configuration;
    wrappers enforce those settings. Construction makes no model calls.
    """
    root = Path(__file__).parent
    declaration = json.dumps(model_configuration, sort_keys=True)

    def propose(parent, context):
        result = rewrite(parent, feedback_report(context))
        if result.failure is None and (
            not isinstance(result.candidate, str) or not result.candidate.strip()
        ):
            return meta.ProposalResult(
                failure=InvalidOutput(message="rewrite must return a nonempty prompt string"),
                usage=result.usage, evidence=result.evidence,
            )
        return result

    implementation = b"".join((root / name).read_bytes() for name in (
        "model_integration.py", "prompt_feedback.py",
    ))
    propose.component = ComponentRef.configured_local(
        "proposer", propose, name="meeting-notes:model-rewrite",
        version=sha256(declaration.encode() + implementation).hexdigest(),
    )
    return meta.Experiment(
        task=meta.Task(evaluator=evaluator(model=respond, model_name=declaration)),
        seed=SEED, proposer=propose, search=meta.Greedy(max_trials=2),
        context=meta.AncestorsOnly(max_records=100),
    )
