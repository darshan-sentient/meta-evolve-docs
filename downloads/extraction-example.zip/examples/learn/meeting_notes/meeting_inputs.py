"""Inputs only. Expected extractions live separately in meeting_cases.py."""

NOTES = (
    "Maya will send the revised proposal by Friday.",
    "We still need someone to check the pricing.",
    "Omar will update the onboarding guide.",
    "Leo suggested revisiting the launch date, but no decision was made.",
    "Nina will publish the release notes by Monday. We need someone to verify "
    "the dashboard. Ava suggested redesigning the homepage, but nobody agreed.",
    "We finished reviewing last week's work. No further actions were agreed.",
)

FINAL_NOTES = (
    "Rita will email the agenda by Tuesday. We need someone to book the room.",
    "Sam suggested replacing the logo, but the team made no decision.",
    "Jules will review the budget. We need someone to confirm the venue by Thursday.",
)
