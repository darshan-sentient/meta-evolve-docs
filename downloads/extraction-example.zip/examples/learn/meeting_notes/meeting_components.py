"""Configuration identity for comparisons and the registered fixture lesson."""

from hashlib import sha256
import json
from pathlib import Path

from meta_evolve.domain import ComponentRef

from extraction_evaluation import evaluate
from meeting_cases import DEVELOPMENT


def configuration(model="handwritten-meeting-responses-v1"):
    root = Path(__file__).parent
    files = ("meeting_inputs.py", "meeting_cases.py", "prompt_variants.py",
             "response_fixtures.py", "extraction_evaluation.py", "meeting_components.py")
    return {
        "model": model,
        "cases": [(c.name, c.notes, c.expected) for c in DEVELOPMENT],
        "sources": {name: sha256((root / name).read_bytes()).hexdigest() for name in files},
    }


def evaluator(model=None, *, model_name="handwritten-meeting-responses-v1"):
    def score(prompt):
        return evaluate(prompt) if model is None else evaluate(prompt, model=model)

    version = sha256(json.dumps(configuration(model_name), sort_keys=True).encode()).hexdigest()
    score.component = ComponentRef.configured_local(
        "evaluator", score, name="meeting-notes:development", version=version,
    )
    return score
