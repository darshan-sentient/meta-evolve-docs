"""Read actual fixture responses before looking at aggregate scores."""

import json

from meeting_inputs import NOTES
from prompt_variants import IMPROVED, SEED
from response_fixtures import respond

print("Notes:", NOTES[1])
for name, prompt in (("Seed response", SEED), ("Revised response", IMPROVED)):
    print(name + ":")
    print(json.dumps(json.loads(respond(prompt, NOTES[1]).candidate), indent=2))
