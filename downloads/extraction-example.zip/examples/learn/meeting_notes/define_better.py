import meta_evolve as meta

from meeting_cases import DEVELOPMENT
from meeting_components import evaluator
from prompt_variants import SEED, rewrite


task = meta.Task(
    evaluator=evaluator(),
    objectives=(meta.Maximize("score", satisfy=5 / 6),),
)
experiment = meta.Experiment(
    task=task,
    seed=SEED,
    proposer=rewrite,
    search=meta.Greedy(max_trials=2),
)
result = meta.run(experiment)

passed = round(result.best_trial().metrics["score"] * len(DEVELOPMENT))
print(f"Development cases passed: {passed}/{len(DEVELOPMENT)}")
print(f"Revision attempts: {result.usage().trials} of {experiment.search.max_trials} allowed")
print(f"Evaluations including seed: {result.usage().evaluations}")
