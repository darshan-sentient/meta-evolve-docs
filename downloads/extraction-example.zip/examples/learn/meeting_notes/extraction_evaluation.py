"""Grade model responses independently and retain the observations."""

from collections import Counter
import json

import meta_evolve as meta
from meta_evolve.domain import EvaluatorFailure

from meeting_cases import DEVELOPMENT
from response_fixtures import respond

CASE_EVIDENCE = "meeting-notes.case"


def normalize(value):
    return " ".join(value.split()).rstrip(".!?") if isinstance(value, str) else value


def grade(text, expected):
    """Exact fields, with whitespace/punctuation normalization and unordered rows."""
    try:
        rows = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return False, "response is not JSON"
    if not isinstance(rows, list):
        return False, "response must be an array"
    actual = []
    for row in rows:
        if not isinstance(row, dict) or set(row) != {"task", "owner", "deadline"}:
            return False, "each action needs task, owner, deadline"
        if not isinstance(row["task"], str) or not row["task"].strip():
            return False, "task must be nonempty text"
        if any(value is not None and not isinstance(value, str)
               for value in (row["owner"], row["deadline"])):
            return False, "owner and deadline must be text or null"
        actual.append(tuple(normalize(row[key]) for key in ("task", "owner", "deadline")))
    wanted = [tuple(normalize(value) for value in row) for row in expected]
    passed = Counter(actual) == Counter(wanted)
    return passed, "matches annotation" if passed else "actions or fields differ"


def evaluate(prompt, *, model=respond, cases=DEVELOPMENT):
    """One suite is one evaluation; each response is retained as evidence."""
    usage = meta.Resources()
    evidence = []
    passed = 0
    for case in cases:
        response = model(prompt, case.notes)
        usage += response.usage
        if response.failure is not None:
            return meta.EvaluationResult(
                failure=EvaluatorFailure(message=f"response failed for {case.name}",
                                         details={"reason": response.failure.kind}),
                evidence=tuple(evidence) + response.evidence, usage=usage,
            )
        if not isinstance(response.candidate, str):
            return meta.EvaluationResult(
                failure=EvaluatorFailure(message="model wrapper must return response text"),
                evidence=tuple(evidence) + response.evidence, usage=usage,
            )
        ok, reason = grade(response.candidate, case.expected)
        passed += ok
        evidence.extend(response.evidence)
        evidence.append(meta.EvidenceDraft(kind=CASE_EVIDENCE, data={
            "name": case.name, "notes": case.notes, "response": response.candidate,
            "expected": [list(row) for row in case.expected], "passed": ok, "reason": reason,
        }))
    return meta.EvaluationResult(metrics={"score": passed / len(cases)},
                                 evidence=tuple(evidence), usage=usage)
