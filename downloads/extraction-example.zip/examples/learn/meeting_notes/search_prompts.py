"""Same varied proposer, different parent selection. Choices are recorded."""

import meta_evolve as meta
from meta_evolve.domain import ComponentRef

from meeting_cases import DEVELOPMENT
from meeting_components import evaluator
from prompt_variants import COMPLETE, IMPROVED, REGRESSION, SEED, label


def propose(parent, context):
    alternatives = (IMPROVED, REGRESSION) if parent == SEED else (COMPLETE, REGRESSION)
    return context.rng.choice(alternatives)


propose.component = ComponentRef.configured_local(
    "proposer", propose, name="meeting-notes:varied-rewrites",
    version="handwritten-parent-alternatives-v1",
)


def run(search):
    return meta.run(meta.Experiment(
        task=meta.Task(evaluator=evaluator()), seed=SEED, proposer=propose,
        search=search, random_seed=0,
    ))


if __name__ == "__main__":
    greedy = run(meta.Greedy(max_trials=4))
    independent = run(meta.BestOfN(max_trials=4))
    for name, result in (("Greedy", greedy), ("BestOfN", independent)):
        passed = round(result.best_trial().metrics["score"] * len(DEVELOPMENT))
        print(f"{name}: best {passed}/{len(DEVELOPMENT)}")
        labels = {trial.artifact.id: label(trial.artifact.value) for trial in result.trials()}
        for trial in result.trials()[1:]:
            print(f"  {labels[trial.parent_ids[0]]} -> {label(trial.artifact.value)}")
        usage = result.usage()
        print(f"  Usage: {usage.trials} revision attempts, {usage.evaluations} evaluations")
    winner = greedy.compare(independent).winner
    names = {greedy.id: "Greedy", independent.id: "BestOfN"}
    print("Comparison winner:", names[winner.run_id] if winner is not None else "tie")
