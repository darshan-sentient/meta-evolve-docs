"""Handwritten prompt variants, not measured model-generated revisions."""

SEED = "Extract action items from the meeting notes as JSON."
IMPROVED = (
    "Extract agreed or explicitly needed action items as a JSON array. "
    "Use task phrases from the notes with fields task, owner, deadline. "
    "Use null for unstated owners or deadlines. Exclude unaccepted suggestions."
)
REGRESSION = IMPROVED + " Only include tasks with both an owner and a deadline."
COMPLETE = IMPROVED + " Include every needed task, including unassigned work in mixed notes."


def rewrite(parent):
    """A visible stand-in: the second revision introduces a regression."""
    if parent == SEED:
        return IMPROVED
    return REGRESSION


def label(prompt):
    return {SEED: "seed", IMPROVED: "improved", REGRESSION: "regression",
            COMPLETE: "complete"}[prompt]
