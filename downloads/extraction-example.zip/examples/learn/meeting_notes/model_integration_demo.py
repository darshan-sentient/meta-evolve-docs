"""Run both model boundaries offline with handwritten responses and synthetic usage."""

import meta_evolve as meta

from extraction_evaluation import evaluate
from meeting_cases import DEVELOPMENT, FINAL
from model_integration import experiment
from prompt_feedback import rewrite_with_report
from response_fixtures import respond as fixture_response

MODEL_CONFIGURATION = {
    "response_model": "handwritten-meeting-responses-v1",
    "rewrite_model": "handwritten-feedback-rewrites-v1",
    "wrapper_revision": "synthetic-telemetry-v1",
    "retries": 0,
}


class FakeClient:
    """Example-local stand-in for two user-owned wrappers, not a model SDK."""

    def __init__(self):
        self.requests = []

    def respond(self, prompt, notes):
        self.requests.append(("response", prompt, notes))
        # Replace this fixture lookup with your SDK request and exact telemetry.
        return meta.ProposalResult(
            candidate=fixture_response(prompt, notes).candidate,
            usage=meta.Resources(tokens=7, spend_micros=3, wall_seconds=0.25),
            evidence=(meta.EvidenceDraft(
                kind="synthetic-response", data={"synthetic": True},
            ),),
        )

    def rewrite(self, parent, report):
        self.requests.append(("rewrite", parent, report))
        # Your SDK receives the parent prompt and authorized failure report here.
        return meta.ProposalResult(
            candidate=rewrite_with_report(parent, report),
            usage=meta.Resources(tokens=11, spend_micros=5, wall_seconds=0.5),
            evidence=(meta.EvidenceDraft(
                kind="synthetic-rewrite", data={"synthetic": True, "report": report},
            ),),
        )


def main():
    print("All responses and telemetry are synthetic: no SDK requests or actual charges.")
    client = FakeClient()
    result = meta.run(experiment(
        client.respond, client.rewrite, model_configuration=MODEL_CONFIGURATION,
    ))
    print("Selected prompt:", result.best().value)
    passed = round(result.best_trial().metrics["score"] * len(DEVELOPMENT))
    print(f"Development result: {passed}/{len(DEVELOPMENT)}")
    responses = sum(kind == "response" for kind, _, _ in client.requests)
    rewrites = sum(kind == "rewrite" for kind, _, _ in client.requests)
    print(f"Development calls: {responses} responses + {rewrites} rewrites")
    usage = result.usage()
    print(f"Synthetic development usage: {usage.tokens} tokens, "
          f"{usage.spend_micros} spend-micros, {usage.wall_seconds:g} seconds")

    before = result.inspect()
    calls_before = len(client.requests)
    final = evaluate(result.best().value, model=client.respond, cases=FINAL)
    passed = round(final.metrics["score"] * len(FINAL))
    print(f"Separate reserved check: {passed}/{len(FINAL)}")
    print(f"Additional response calls: {len(client.requests) - calls_before}")
    usage = final.usage
    print(f"Synthetic reserved usage: {usage.tokens} tokens, "
          f"{usage.spend_micros} spend-micros, {usage.wall_seconds:g} seconds")
    print("Development history unchanged:", result.inspect() == before)
    return result, final, client


if __name__ == "__main__":
    main()
