"""A bad response is measurable; a failed measurement is not a score."""

import meta_evolve as meta
from meta_evolve.domain import EvaluatorFailure, ProposerFailure

from extraction_evaluation import evaluate
from prompt_variants import SEED, rewrite


def malformed_response(prompt, notes):
    return meta.ProposalResult(candidate="This is prose, not JSON.")


def bad_format(prompt):
    return evaluate(prompt, model=malformed_response)


def unavailable(prompt):
    return meta.EvaluationResult(failure=EvaluatorFailure(message="provider unavailable"))


def failed_rewrite(parent):
    return meta.ProposalResult(failure=ProposerFailure(message="rewrite request timed out"))


if __name__ == "__main__":
    poor = meta.improve(seed=SEED, proposer=rewrite, evaluator=bad_format, trials=0)
    print("Completed responses with bad format:", poor.best_trial().metrics["score"])

    failed = meta.improve(seed=SEED, proposer=rewrite, evaluator=unavailable, trials=0)
    print("Failed measurement:", failed.trials()[0].failure.kind)
    print("Inspection without a winner:", failed.inspect().overview.rankability)
    try:
        failed.best()
    except meta.NoSuccessfulEvaluation:
        print("No successfully measured candidate to select.")

    proposal = meta.improve(seed=SEED, proposer=failed_rewrite, evaluator=evaluate, trials=1)
    attempt = proposal.trials()[-1]
    print("Failed rewrite:", attempt.failure.kind)
    print("Failed rewrite has an artifact:", attempt.artifact is not None)
    if attempt.artifact is not None:
        print(attempt.artifact.value)
