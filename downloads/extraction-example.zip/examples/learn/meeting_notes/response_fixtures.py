"""Handwritten response fixtures, never live captures or a simulated LLM.

The table supplies response text only. It knows no expected answers or scores.
Unknown inputs fail explicitly rather than silently pretending to run a model.
"""

import json

import meta_evolve as meta

from meeting_inputs import FINAL_NOTES, NOTES
from prompt_variants import COMPLETE, IMPROVED, REGRESSION, SEED


def _json(*rows):
    return json.dumps([dict(zip(("task", "owner", "deadline"), row)) for row in rows])


_COMPLETE = (
    _json(("send the revised proposal", "Maya", "Friday")),
    _json(("check the pricing", None, None)),
    _json(("update the onboarding guide", "Omar", None)),
    _json(),
    _json(("publish the release notes", "Nina", "Monday"),
          ("verify the dashboard", None, None)),
    _json(),
)
_IMPROVED = (*_COMPLETE[:4], _json(("publish the release notes", "Nina", "Monday")),
             _COMPLETE[5])
_SEED = (
    _COMPLETE[0],
    _json(("check the pricing", "Maya", "Friday")),
    _json(("update the onboarding guide", "Omar", "today")),
    _json(("revisiting the launch date", "Leo", None)),
    _IMPROVED[4],
    _COMPLETE[5],
)
_REGRESSION = (_COMPLETE[0], _json(), _json(), _json(), _IMPROVED[4], _json())
_FINAL = (
    _json(("email the agenda", "Rita", "Tuesday"), ("book the room", None, None)),
    _json(),
    _json(("review the budget", "Jules", None), ("confirm the venue", None, "Thursday")),
)


def respond(prompt, notes):
    """Replacement point: return response text in a ProposalResult with usage."""
    responses = {SEED: _SEED, IMPROVED: _IMPROVED, REGRESSION: _REGRESSION,
                 COMPLETE: _COMPLETE}
    if notes in NOTES and prompt in responses:
        text = responses[prompt][NOTES.index(notes)]
    elif notes in FINAL_NOTES and prompt == COMPLETE:
        text = _FINAL[FINAL_NOTES.index(notes)]
    else:
        raise meta.CapabilityError("No handwritten response fixture for this input")
    return meta.ProposalResult(candidate=text)
