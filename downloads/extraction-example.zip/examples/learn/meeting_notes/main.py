import meta_evolve as meta

from extraction_evaluation import evaluate
from meeting_cases import DEVELOPMENT
from prompt_variants import SEED, rewrite


def rewrite_prompt(parent):
    return rewrite(parent)  # Handwritten revision; replace with your model call.


def evaluate_prompt(prompt):
    return evaluate(prompt)  # Grades fixture responses on six development cases.


result = meta.improve(
    seed=SEED,
    proposer=rewrite_prompt,
    evaluator=evaluate_prompt,
    trials=2,
)

print("Handwritten model fixtures; no live LLM calls.")
best = result.best()
print("\nPrompt          | Development cases passed")
print("----------------|-------------------------")
for index, attempt in enumerate(result.trials()):
    name = "Starting prompt" if index == 0 else f"Revision {index}"
    passed = round(attempt.metrics["score"] * len(DEVELOPMENT))
    selected = " — selected" if attempt.artifact.id == best.id else ""
    print(f"{name:<15} | {passed}/{len(DEVELOPMENT)}{selected}")
print("\nSelected prompt:")
print(best.value)
usage = result.usage()
attempt_word = "attempt" if usage.trials == 1 else "attempts"
print(f"\nUsage: {usage.trials} revision {attempt_word}, {usage.evaluations} evaluations")
