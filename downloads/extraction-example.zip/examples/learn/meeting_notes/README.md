# Case study: meeting-notes extraction

**Status: Shipped.** Improve a reusable extraction prompt with handwritten
revisions and independently graded JSON response fixtures. No model calls or
credentials are involved.

The [complete walkthrough](../../../docs/applications/meeting-notes.md) owns the
problem, setup, source, checked output, interpretation, companion exercises,
and model-integration explanation.

With Python 3.12+, from a repository checkout:

```bash
uv sync --locked
uv run python examples/learn/meeting_notes/main.py
```

The fixture scores 2/6 → 5/6 → 3/6 and keeps the first revision. These results
show the improvement loop, not model performance. The walkthrough also explains
`prompt_feedback.py` and its separate reserved final check.
