import json

import meta_evolve as meta

from extraction_evaluation import CASE_EVIDENCE, evaluate
from meeting_cases import DEVELOPMENT
from prompt_variants import SEED, label, rewrite

result = meta.improve(seed=SEED, proposer=rewrite, evaluator=evaluate, trials=2)

print("Selected:", label(result.best().value))
print("Selected prompt:", result.best().value)
passed = round(result.best_trial().metrics["score"] * len(DEVELOPMENT))
print(f"Cases passed: {passed}/{len(DEVELOPMENT)}")

mixed = next(
    item.data for item in result.best_trial().evidence
    if item.kind == CASE_EVIDENCE and item.data["name"] == "mixed"
)
print("Notes:", mixed["notes"])
print("Actual JSON:")
print(json.dumps(json.loads(mixed["response"]), indent=2))
print("Expected JSON:")
expected = [dict(zip(("task", "owner", "deadline"), row))
            for row in mixed["expected"]]
print(json.dumps(expected, indent=2))
print("Check:", mixed["reason"])

print("Measured attempts:")
for trial in result.trials():
    passed = round(trial.metrics["score"] * len(DEVELOPMENT))
    print(f"  {label(trial.artifact.value)}: {passed}/{len(DEVELOPMENT)}")
print("Winning lineage:", " -> ".join(label(t.artifact.value) for t in result.lineage()))

print(f"Usage: {result.usage().trials} attempts, {result.usage().evaluations} evaluations")
print(f"Fixture model tokens: {result.usage().tokens}")
