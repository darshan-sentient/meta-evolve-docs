"""Store, inspect, and actually continue an unfinished fixture run."""

from pathlib import Path
from tempfile import TemporaryDirectory

import meta_evolve as meta
from meta_evolve.registry import Registry

from extraction_evaluation import evaluate
from meeting_components import configuration
from prompt_variants import SEED, rewrite


def declaration():
    registry = Registry()
    config = configuration()
    proposer = registry.register_proposer(
        "meeting-notes:rewrite", "1", rewrite,
        deterministic=True, retry_safe=True, configuration=config,
    )
    evaluator = registry.register_evaluator(
        "meeting-notes:grade", "1", evaluate,
        deterministic=True, retry_safe=True, configuration=config,
    )
    return meta.Experiment(
        task=meta.Task(evaluator=evaluator), seed=SEED, proposer=proposer,
        search=meta.Greedy(max_trials=2), registry=registry,
    )


def demonstrate(root):
    # Ordinary local runs can be stored and reopened, without being resumable.
    with meta.Storage.durable(root / "saved") as storage:
        saved = meta.improve(seed=SEED, proposer=rewrite, evaluator=evaluate,
                             trials=2, storage=storage)
        saved_id = saved.id
        saved_prompt = saved.best().value
    with meta.Storage.read_only(root / "saved") as storage:
        version = storage.run_version(saved_id)
        reopened = meta.Run(saved_id, storage)
        assert reopened.best().value == saved_prompt
        assert storage.run_version(saved_id) == version

    experiment = declaration()
    with meta.Storage.durable(root / "reference") as storage:
        reference = meta.run(experiment, storage=storage, mode="durable-local")
        reference_events = storage.events.read(reference.id)
    with meta.Storage.durable(root / "continued") as storage:
        with meta.Session.start(experiment, storage=storage, mode="durable-local") as session:
            session.step()  # Commit one proposal; leave the second unperformed.
            run_id = session.run.id
            before = session.run.usage().trials
            assert not session.stopped
    with meta.Storage.durable(root / "continued") as storage:
        resumed = meta.resume(run_id, storage=storage, registry=declaration().registry)
        assert resumed.usage().trials > before
        assert storage.events.read(run_id) == reference_events
        print("Read-only reopen preserved the winner and event version.")
        print(f"Resume continued attempts: {before} -> {resumed.usage().trials}")
        print("Resumed history equals uninterrupted fixture history: True")
        return {"before": before, "after": resumed.usage().trials,
                "prompt": resumed.best().value}


if __name__ == "__main__":
    with TemporaryDirectory() as directory:
        demonstrate(Path(directory))
