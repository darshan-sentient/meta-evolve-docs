"""Only committed, explicitly pushed evidence reaches the rewriter."""

import json

import meta_evolve as meta

from extraction_evaluation import CASE_EVIDENCE, evaluate
from meeting_cases import DEVELOPMENT, FINAL
from meeting_components import evaluator
from prompt_variants import COMPLETE, IMPROVED, SEED, rewrite


def feedback_report(context):
    latest = {}
    for record in sorted(context.bundle.records, key=lambda item: item.logical_step):
        if record.kind == "evidence" and record.value.kind == CASE_EVIDENCE:
            latest[record.value.data["name"]] = dict(record.value.data)
    # JSON-friendly scalars/tuples; there is no evaluator-to-proposer side channel.
    return json.dumps([row for row in latest.values() if not row["passed"]], sort_keys=True)


def rewrite_with_report(parent, report):
    """Handwritten feedback fixture. A live rewriter reads the same report."""
    if parent == IMPROVED and any(row["name"] == "mixed" for row in json.loads(report)):
        return COMPLETE
    return rewrite(parent)


def propose(parent, *, context):
    return rewrite_with_report(parent, feedback_report(context))


def run(*, feedback=True):
    return meta.run(meta.Experiment(
        task=meta.Task(evaluator=evaluator()), seed=SEED, proposer=propose,
        search=meta.Greedy(max_trials=2),
        context=meta.AncestorsOnly(max_records=100) if feedback else None,
    ))


if __name__ == "__main__":
    without = run(feedback=False)
    with_feedback = run()
    for name, result in (("Without feedback", without), ("With feedback", with_feedback)):
        passed = round(result.best_trial().metrics["score"] * len(DEVELOPMENT))
        print(f"{name}: {passed}/{len(DEVELOPMENT)} development cases")
    final = evaluate(with_feedback.best().value, cases=FINAL)
    passed = round(final.metrics["score"] * len(FINAL))
    print(f"Separate final check after selection: {passed}/{len(FINAL)} reserved cases")
    print("Handwritten fixtures demonstrate separation, not generalization.")
