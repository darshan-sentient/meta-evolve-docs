"""Independent annotations. Neither model fixture nor proposer imports these."""

from dataclasses import dataclass

from meeting_inputs import FINAL_NOTES, NOTES


@dataclass(frozen=True)
class Case:
    name: str
    notes: str
    # task, owner, deadline; immutable annotations stay outside candidate authority.
    expected: tuple[tuple[str, str | None, str | None], ...]


DEVELOPMENT = (
    Case("assigned", NOTES[0], (("send the revised proposal", "Maya", "Friday"),)),
    Case("unassigned", NOTES[1], (("check the pricing", None, None),)),
    Case("no_deadline", NOTES[2], (("update the onboarding guide", "Omar", None),)),
    Case("suggestion", NOTES[3], ()),
    Case("mixed", NOTES[4], (("publish the release notes", "Nina", "Monday"),
                            ("verify the dashboard", None, None))),
    Case("no_actions", NOTES[5], ()),
)

FINAL = (
    Case("agenda", FINAL_NOTES[0], (("email the agenda", "Rita", "Tuesday"),
                                   ("book the room", None, None))),
    Case("logo", FINAL_NOTES[1], ()),
    Case("venue", FINAL_NOTES[2], (("review the budget", "Jules", None),
                                  ("confirm the venue", None, "Thursday"))),
)
