"""Private selection and matched held-out runs composed from the public API."""

from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import ComponentRef
from meta_evolve.harness import HarnessArtifact

from repair_cases import cases
from repair_evaluation import evaluate_repairs


LATER_BUDGET = meta.Budget(trials=0, evaluations=1, tokens=80000, wall_seconds=240)


def evaluator(model, split, root):
    def evaluate(harness):
        return evaluate_repairs(harness, split=split, model=model, root=root)

    directory = Path(__file__).parent
    identity = {"model": model, "split": split, "cases": [asdict(case) for case in cases(split)],
                "source": {name: sha256((directory / name).read_bytes()).hexdigest() for name in (
                    "repair_agents.py", "repair_execution.py", "repair_evaluation.py", "repair_cases.py")}}
    digest = sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    evaluate.component = ComponentRef.configured_local("evaluator", evaluate,
        name=f"meta-harness:{split}", version=digest)
    return evaluate


def unchanged(parent, *, context):
    return parent


def seed_run(harness, evaluate, destination):
    experiment = meta.Experiment(task=meta.Task(evaluator=evaluate, artifact=HarnessArtifact,
        objectives=(meta.Maximize("quality"),), budget=LATER_BUDGET), seed=harness,
        proposer=unchanged, search=meta.Greedy(max_trials=0), random_seed=0)
    return meta.run(experiment, storage=meta.Storage.durable(destination))


def confirm(run, *, seed, model, root):
    """Evaluate every rankable occurrence; ties retain the earliest occurrence."""
    private_evaluator = evaluator(model, "private", root)
    private = []
    for trial in run.trials():
        if trial.state != "evaluated" or "quality" not in trial.metrics:
            continue
        print(f"Private check · revision {trial.logical_step}", flush=True)
        checked = seed_run(trial.artifact.value, private_evaluator, root / f"private-{trial.logical_step}")
        private.append((trial, checked))
    rankable = [(trial, checked) for trial, checked in private
                if checked.summary().primary_score is not None]
    selected = max(rankable, key=lambda pair: (pair[1].summary().primary_score, -pair[0].logical_step))[0] if rankable else None
    # Freeze the selection before any held-out execution.
    selection = {"selected_step": selected.logical_step if selected else None,
        "selected_artifact": selected.artifact.id.value if selected else None,
        "private": [{"step": trial.logical_step, "score": checked.summary().primary_score,
                     "run_id": checked.id.value} for trial, checked in private]}
    (root / "selection.json").write_text(json.dumps(selection, indent=2) + "\n")
    baseline = candidate = comparison = exported = None
    if selected:
        held_out = evaluator(model, "held_out", root)
        print("Held out · starting harness", flush=True)
        baseline = seed_run(seed, held_out, root / "held-out-baseline")
        print("Held out · frozen selection", flush=True)
        candidate = seed_run(selected.artifact.value, held_out, root / "held-out-selected")
        comparison = meta.compare_harnesses(baseline, candidate)
        if comparison.promotion_eligible:
            exported = meta.export_harness(selected.artifact, root / "selected-harness")
    return {"private": private, "selected": selected, "baseline": baseline,
            "candidate": candidate, "comparison": comparison, "exported": exported}


def save_report(run, phases, root):
    runs = [run, *(checked for _, checked in phases["private"])]
    runs += [phases[key] for key in ("baseline", "candidate") if phases[key] is not None]
    receipts = [json.loads(path.read_text()) for path in sorted((root / "receipts").glob("*.json"))]
    known = [record for record in receipts if "resources" in record]
    tokens = sum(item.usage().tokens for item in runs)
    if tokens != sum(record["resources"]["tokens"] for record in known):
        raise RuntimeError("Run accounting differs from the retained SDK receipts")
    costs = [record["terminal"].get("total_cost_usd") for record in known]
    comparison, selected = phases["comparison"], phases["selected"]
    report = {"development": [{"step": trial.logical_step, "score": trial.metrics.get("quality"),
                "state": trial.state} for trial in run.trials()],
        "private": [{"step": trial.logical_step, "score": checked.summary().primary_score}
                    for trial, checked in phases["private"]],
        "selected_step": selected.logical_step if selected else None,
        "held_out_baseline": comparison.baseline.quality if comparison else None,
        "held_out_selected": comparison.candidate.quality if comparison else None,
        "verdict": comparison.verdict if comparison else "no selection",
        "sdk_calls": len(receipts), "tokens": tokens, "billed_spend": None,
        "estimated_cost_usd": sum(costs) if all(isinstance(value, (int, float)) for value in costs) else None,
        "exported": "selected-harness" if phases["exported"] else None,
        "resumable": False, "run_id": run.id.value,
        "usage": [{"run_id": item.id.value, **asdict(item.usage())} for item in runs]}
    (root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    return report
