"""Meta-Harness: improve a real repair agent through measured harness changes."""

# --8<-- [start:imports]
from pathlib import Path
import tempfile
from typing import Literal

from IPython.display import HTML, display
from pydantic import BaseModel, Field, StrictBool
import meta_evolve as meta
from meta_evolve.domain import ComponentRef
from meta_evolve.harness import HarnessArtifact, PolicyParam, TextParam

from repair_display import final_report, history, results
from repair_evaluation import evaluate_repairs, propose_revision, repair
from repair_execution import preflight
from repair_phases import confirm, save_report
# --8<-- [end:imports]


def lesson(root):
    preflight(root)
    # --8<-- [start:harness]
    WORKER_MODEL, PROPOSER_MODEL = "haiku", "sonnet"
    seed = HarnessArtifact(
        planner=TextParam(
            "planner", ComponentRef(role="planner", name="repair-worker", version="1"),
            "repair-instructions/v1",
            "Make a small, conservative repair. Preserve the public interface.",
        ),
        context_policy=PolicyParam(
            "context_policy",
            ComponentRef(role="context-policy", name="repository-contract", version="1"),
            "repository-contract/v1", {"include_spec": False},
        ),
    )

    class HarnessEdit(BaseModel):
        model_config = {"extra": "forbid"}
        surface: Literal["planner", "context_policy"]
        planner: str = Field(max_length=2000, description="New instructions, or empty for a context edit")
        include_spec: StrictBool = Field(description="Whether the worker receives the repository contract")
        diagnosis: str = Field(min_length=1, max_length=1000)
        prediction: str = Field(min_length=1, max_length=1000)

    print("Worker:", WORKER_MODEL, "· proposer:", PROPOSER_MODEL)
    print("Starting instructions:", seed.planner.value)
    print("Repository contract available:", seed.context_policy.configuration["include_spec"])
    # --8<-- [end:harness]

    # --8<-- [start:evaluate]
    def evaluate(harness):
        measured = evaluate_repairs(
            harness, split="development", model=WORKER_MODEL, root=root, worker=repair,
        )
        display(HTML(results(measured)))
        return measured
    # --8<-- [end:evaluate]

    # --8<-- [start:propose]
    def revise(harness, *, context):
        feedback = context.evidence.latest("meta-harness.development")
        return propose_revision(
            harness, feedback, model=PROPOSER_MODEL, root=root, schema=HarnessEdit,
        )
    # --8<-- [end:propose]

    # --8<-- [start:run]
    experiment = meta.Experiment(
        task=meta.Task(evaluator=evaluate, artifact=HarnessArtifact,
            objectives=(meta.Maximize("quality"),),
            budget=meta.Budget(trials=2, evaluations=3, tokens=400_000, wall_seconds=1800)),
        seed=seed, proposer=revise, search=meta.Greedy(max_trials=2),
        context=meta.RecentAncestors(max_records=12, max_chars=24000), random_seed=0,
    )
    run = meta.run(experiment, storage=meta.Storage.durable(root / "development"))
    # --8<-- [end:run]

    # --8<-- [start:inspect]
    display(HTML(history(run)))
    print("Search:", run.usage().trials, "proposals ·", run.usage().evaluations, "evaluations")
    print("Run folder:", root)
    # --8<-- [end:inspect]

    # --8<-- [start:confirm]
    phases = confirm(run, seed=seed, model=WORKER_MODEL, root=root)
    report = save_report(run, phases, root)
    display(HTML(final_report(report)))
    print("Report:", root / "report.json")
    print("Export:", root / report["exported"] if report["exported"] else "No eligible export")
    # --8<-- [end:confirm]
    return run, report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.output or Path(tempfile.mkdtemp(prefix="meta-harness-"))
    if args.output:
        root.mkdir(parents=True, exist_ok=False)
    lesson(root)
