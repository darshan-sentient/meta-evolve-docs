"""Small, escaped HTML views of retained measurements; never makes agent calls."""

from difflib import unified_diff
from html import escape
import json

from repair_evaluation import harness_text


STYLE = """<style>
.repair-story {font:15px/1.6 system-ui,sans-serif; color:inherit; margin:16px 0 28px}
.repair-story table {width:100%; border-collapse:collapse; font-size:14px}
.repair-story th,.repair-story td {text-align:left!important; padding:9px 12px; border-bottom:1px solid #8884}
.repair-story th {font-weight:600; opacity:.75}
.repair-story pre {padding:16px; border:1px solid #8884; border-radius:8px; overflow:auto; font:13px/1.6 monospace; white-space:pre}
.repair-story summary {cursor:pointer; padding:8px 0; font-weight:600}
.repair-story .pass {color:#16805e}.repair-story .fail {color:#c15242}
.repair-story .addition {background:rgba(36,157,103,.14)}
.repair-story .deletion {background:rgba(205,72,60,.14)}
.repair-story h3 {font-size:18px; margin:22px 0 10px}.repair-story .caption {opacity:.72; font-size:13px}
</style>"""


def table(headers, rows):
    head = "".join(f"<th>{escape(str(value))}</th>" for value in headers)
    def cell(value):
        style = "pass" if value == "Pass" else "fail" if value == "Fail" else ""
        return f'<td class="{style}">{escape(str(value))}</td>'
    body = "".join("<tr>" + "".join(cell(value) for value in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def diff_block(diff):
    lines = []
    for line in (diff or "Unchanged").splitlines():
        style = "addition" if line.startswith("+") else "deletion" if line.startswith("-") else ""
        lines.append(f'<span class="{style}">{escape(line)}</span>')
    return "<pre>" + "\n".join(lines) + "</pre>"


def results(evaluation):
    if not evaluation.evidence:
        return f"<p>{escape(str(evaluation.failure))}</p>"
    data = evaluation.evidence[0].data
    rows = [(row["case"], check["name"], "Pass" if check["passed"] else "Fail")
            for row in data["cases"] for check in row["checks"]]
    failures = "".join(f"<p>{escape(str(row['failure']))}</p>" for row in data["cases"] if row["failure"])
    summary = [(case["case"], f"{sum(check['passed'] for check in case['checks'])}/{len(case['checks'])}",
                "Failed to evaluate" if case["failure"] else "Measured") for case in data["cases"]]
    return STYLE + '<div class="repair-story">' + table(("Repair", "Checks passed", "Outcome"), summary) + (
        '<details><summary>See every independent check</summary>' +
        table(("Repair", "Independent check", "Result"), rows) + "</details>" + failures + "</div>")


def history(run):
    best = run.best_trial().id if run.summary().primary_score is not None else None
    rows, incumbent = [], None
    for trial in run.trials():
        score = trial.metrics.get("quality")
        if score is None:
            decision = "Unrankable"
        elif incumbent is None:
            decision, incumbent = "Starting harness", score
        elif score > incumbent:
            decision, incumbent = "Improved", score
        else:
            decision = "Tie; keep earlier" if score == incumbent else "Keep earlier"
        if trial.id == best:
            decision += " · selected"
        rows.append((trial.logical_step, f"{score:.1%}".replace(".0%", "%") if score is not None else "—",
                     "Measured" if score is not None else "Failed", decision))
    html = STYLE + '<div class="repair-story"><h3>Development history</h3>'
    html += table(("Revision", "Checks passed", "Outcome", "Decision"), rows)
    trials = [trial for trial in run.trials() if trial.artifact is not None]
    seed = trials[0].artifact.value if trials else None
    for trial in trials:
        if trial.logical_step:
            before = json.dumps(harness_text(seed), indent=2).splitlines()
            after = json.dumps(harness_text(trial.artifact.value), indent=2).splitlines()
            diff = "\n".join(unified_diff(before, after, fromfile="starting harness", tofile=f"revision {trial.logical_step}", lineterm=""))
            html += f"<h3>Revision {trial.logical_step} · harness change from the start</h3>" + diff_block(diff)
            if trial.hypothesis:
                html += f"<p><strong>Proposer diagnosis:</strong> {escape(trial.hypothesis)}</p>"
            if trial.predicted_outcomes.get("benefit"):
                html += f"<p><strong>Prediction:</strong> {escape(str(trial.predicted_outcomes['benefit']))}</p>"
        for evidence in trial.evidence:
            if evidence.kind != "meta-harness.development":
                continue
            for index, case in enumerate(evidence.data["cases"]):
                diff = "\n".join(unified_diff(case["before"].splitlines(), case["after"].splitlines(),
                    fromfile="original solution.py", tofile="worker repair", lineterm=""))
                opened = " open" if trial.id == best and index == 0 else ""
                html += f"<details{opened}><summary>Revision {trial.logical_step} · {escape(case['case'])} · repair</summary>" + diff_block(diff)
                html += table(("Check", "Result"), [(check["name"], "Pass" if check["passed"] else "Fail") for check in case["checks"]])
                trace = json.dumps(case["agent"]["trace"], indent=2, default=dict)
                html += f"<details><summary>Worker trace</summary><pre>{escape(trace)}</pre></details></details>"
        if trial.failure:
            html += f"<p>{escape(str(trial.failure))}</p>"
    return html + "</div>"


def final_report(report):
    score = lambda value: "Unavailable" if value is None else f"{value:.0%}"
    selected = (f"Private selection · revision {report['selected_step']}"
                if report["selected_step"] is not None else "No eligible private selection")
    rows = [("Starting harness", score(report["held_out_baseline"])),
            (selected, score(report["held_out_selected"]))]
    estimated = report["estimated_cost_usd"]
    cost = "unknown" if estimated is None else f"${estimated:.3f}"
    return STYLE + '<div class="repair-story"><h3>Fresh held-out comparison</h3>' + table(("Harness", "Checks passed"), rows) + (
        f"<p><strong>{escape(report['verdict'].capitalize())}</strong> · {report['sdk_calls']} SDK calls · "
        f"{report['tokens']:,} reported tokens · {cost} SDK estimate</p>"
        '<p class="caption">Billed spend is unknown. These four authored repair cases demonstrate the loop; '
        'they do not establish benchmark gains. Selection does not deploy the harness.</p></div>')
