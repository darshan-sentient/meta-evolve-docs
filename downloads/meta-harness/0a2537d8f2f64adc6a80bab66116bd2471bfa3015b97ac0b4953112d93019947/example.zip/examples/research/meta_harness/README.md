# Meta-Harness: improve a real repair agent

**Experimental/live-only.** A Claude SDK worker edits Python files. A separate
Claude SDK proposer reads development traces and revises its planner instructions
or whether repository contracts enter its context. Independent Python checks
measure the repairs; private selection precedes the frozen held-out comparison.

Use Python 3.12+ on macOS with working `sandbox-exec`, or Linux with Landlock ABI 3+.
Authenticate with `claude auth login` or `ANTHROPIC_API_KEY`, then run:

```bash
uv pip install -r examples/research/meta_harness/requirements.txt
uv run --no-sync python examples/research/meta_harness/main.py
```

The first operation verifies confinement. An enclosing sandbox may prevent it
from starting; a failed check stops before model calls. Run in a supported local
terminal. Hosted notebook platforms are unverified.

The notebook and documentation share seven executable cells. Setup automatically
fetches a checksum-verified example archive and matching package, with no checkout
or manual companion-file download. The archive includes the existing M8
confinement modules unchanged. Run cells in order in a fresh kernel.

One complete run makes at most 13 SDK calls: six development worker calls, two
proposals, three private checks, and two held-out calls. Each SDK session allows
eight turns and a $0.35 SDK-estimated budget; billed spend remains unknown.
The actual number can be smaller when an attempt fails. No automatic paid retries.

The two development tasks concern ledger amounts and customer labels. Private
selection uses warehouse counts; the held-out check uses shipping priorities.
These four authored cases demonstrate the mechanism, not benchmark gains.
The fixed worker model receives only its issue, source, and optional contract.
The proposer receives development evidence only. Hidden expected answers stay in
the grader's parent process. Completed wrong answers and raised task exceptions
fail checks; malformed Python, process failures and SDK errors remain unrankable.

`report.json`, SDK receipts, all phase stores and `selection.json` are retained.
An eligible held-out improvement exports `selected-harness`; export is not deployment.
These configured local SDK callables do not support resume. Start a new run in a
fresh directory; viewing retained results makes no model calls. The historical
deterministic study remains in `examples/research/harness_evolution/`.
