"""Run generated Python in a confined child; compare answers in the trusted parent."""

import ast
import json
from pathlib import Path
import sys

import meta_evolve as meta
from meta_evolve.adapters import DevelopmentSubprocessSandbox, DirectoryWorkspaces
from meta_evolve.domain import InfrastructureFailure, InvalidOutput, SourceTree

# The distribution includes these unchanged, tested M8 confinement modules.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "harness_evolution"))
import confinement_policy  # noqa: E402


RUNNER = '''import json, sys
from pathlib import Path
namespace = {}
exec(compile(Path("solution.py").read_text(), "solution.py", "exec"), namespace)
if not callable(namespace.get("parse")):
    raise TypeError("Repair must define callable parse(text)")
answers = []
for value in json.loads(sys.argv[1]):
    try:
        answers.append({"value": namespace["parse"](value)})
    except Exception as error:
        answers.append({"raised": type(error).__name__})
print(json.dumps(answers, allow_nan=False))
'''


def confined(source, arguments, output_root, *, script=RUNNER):
    workspaces = DirectoryWorkspaces()
    workspace = workspaces.materialize(SourceTree({"solution.py": source}))
    try:
        prefix = confinement_policy.launcher(workspace.root, output_root=output_root)
        # Keep the existing platform confinement, and block networking on macOS.
        if sys.platform == "darwin":
            prefix = (*prefix[:-1], prefix[-1] + "\n(deny network*)")
        return DevelopmentSubprocessSandbox().run(meta.ProcessSpec(
            argv=(*prefix, sys.executable, "-I", "-c", script, *arguments),
            timeout_seconds=3, stdout_limit=12000, stderr_limit=2000,
        ), workspace)
    finally:
        workspaces.dispose(workspace)


def preflight(root):
    """Prove a real child runs and cannot read or alter an existing protected file."""
    if sys.version_info < (3, 12) or sys.platform not in {"darwin", "linux"}:
        raise RuntimeError("Use local Python 3.12+ on macOS or Linux with confinement.")
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    canary = root / "protected-canary"
    canary.write_text("protected")
    script = '''from pathlib import Path
import sys
Path("local.txt").write_text("ok")
assert Path("local.txt").read_text() == "ok"
for mode in ("r", "a"):
    try:
        with open(sys.argv[1], mode) as target:
            target.read() if mode == "r" else target.write("leaked")
    except PermissionError:
        continue
    raise RuntimeError("Protected file was accessible")
print("ready")
'''
    try:
        result = confined("", [str(canary)], root, script=script)
        if result.failure or result.exit_code != 0 or result.stdout.strip() != "ready":
            raise RuntimeError(f"Confinement could not be verified: {result.failure or result.stderr}")
        if canary.read_text() != "protected":
            raise RuntimeError("The child changed a protected file")
    finally:
        canary.unlink()
    print("Ready · isolated Python checks · fresh agent sessions")


def check_repair(source, case, root):
    """Expected values are never copied into the candidate process or agent files."""
    try:
        ast.parse(source)
    except SyntaxError as error:
        return [], InvalidOutput(message=f"Repair is not valid Python: {error}"), 0.0
    try:
        result = confined(source, [json.dumps([row[1] for row in case.checks])], root)
    except (OSError, RuntimeError) as error:
        return [], InfrastructureFailure(message=str(error)), 0.0
    if result.failure:
        return [], result.failure, result.usage.wall_seconds
    if result.exit_code != 0:
        return [], InvalidOutput(message="Repair process failed", details={"stderr": result.stderr}), result.usage.wall_seconds
    try:
        answers = json.loads(result.stdout)
        if not isinstance(answers, list) or len(answers) != len(case.checks):
            raise ValueError("Wrong number of returned answers")
        rows = []
        for (name, value, expected), actual in zip(case.checks, answers):
            if not isinstance(actual, dict) or set(actual) not in ({"value"}, {"raised"}):
                raise ValueError("Invalid returned answer")
            passed = "value" in actual and actual["value"] == expected
            rows.append({"name": name, "input": value, "expected": expected, "actual": actual, "passed": passed})
        return rows, None, result.usage.wall_seconds
    except (TypeError, ValueError) as error:
        return [], InvalidOutput(message=f"Invalid repair output: {error}"), result.usage.wall_seconds
