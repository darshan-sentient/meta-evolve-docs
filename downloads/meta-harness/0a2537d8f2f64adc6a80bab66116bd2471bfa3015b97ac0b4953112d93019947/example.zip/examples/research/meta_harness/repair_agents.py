"""Fresh Claude SDK sessions, narrowly scoped file tools, and terminal receipts."""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, replace
import json
from pathlib import Path
import time
from uuid import uuid4

from claude_agent_sdk import (
    AssistantMessage, ClaudeAgentOptions, ClaudeSDKClient, HookMatcher,
    ResultMessage, TextBlock, ToolResultBlock, ToolUseBlock, UserMessage,
)
import meta_evolve as meta
from meta_evolve.errors import ExecutionAccountingUnknown


def scoped_options(workspace, *, model, instructions, write=False):
    """Only Read and, for the worker, Edit/Write on solution.py; no shell."""
    workspace = Path(workspace).resolve()
    names = ["Read", "Edit", "Write"] if write else ["Read"]

    async def check(event, tool_use_id, context):
        name, args = event["tool_name"], event["tool_input"]
        allowed = name == "StructuredOutput"
        if name in names:
            path = (workspace / args.get("file_path", "")).resolve()
            allowed = path.is_relative_to(workspace) and path.is_file()
            if name in {"Write", "Edit"}:
                allowed = allowed and path == workspace / "solution.py"
        if allowed:
            return {}
        return {"hookSpecificOutput": {"hookEventName": "PreToolUse",
            "permissionDecision": "deny", "permissionDecisionReason": "Outside this agent's files."}}

    return ClaudeAgentOptions(
        model=model, cwd=workspace, system_prompt=instructions, tools=names,
        allowed_tools=names, permission_mode="dontAsk", setting_sources=[], skills=[],
        strict_mcp_config=True, max_turns=8, max_budget_usd=0.35,
        hooks={"PreToolUse": [HookMatcher(hooks=[check])]},
    )


@dataclass(frozen=True)
class Reply:
    output: object
    usage: meta.Resources
    record: dict
    failure: str | None


def reported_tokens(result):
    if result.model_usage:
        keys = ("inputTokens", "outputTokens", "cacheReadInputTokens", "cacheCreationInputTokens")
        values = [row.get(key) for row in result.model_usage.values() for key in keys]
    else:
        if result.subtype == "error_max_budget_usd":
            raise ValueError("Budget exhaustion without cumulative usage")
        usage = result.usage or {}
        values = [usage.get("input_tokens"), usage.get("output_tokens"),
                  usage.get("cache_read_input_tokens", 0), usage.get("cache_creation_input_tokens", 0)]
    if any(type(value) is not int or value < 0 for value in values):
        raise ValueError("Missing or invalid cumulative token usage")
    return sum(values)


async def response(prompt, options, schema, receipt):
    started, terminal, error, trace = time.monotonic(), None, None, []
    if schema:
        options = replace(options, output_format={"type": "json_schema", "schema": schema.model_json_schema()})
    try:
        async with asyncio.timeout(180), ClaudeSDKClient(options=options) as client:
            await client.query(prompt)
            async for message in client.receive_response():
                if isinstance(message, (AssistantMessage, UserMessage)):
                    blocks = message.content if isinstance(message.content, list) else []
                    trace.append({"speaker": type(message).__name__, "blocks": [asdict(block)
                        for block in blocks if isinstance(block, (TextBlock, ToolUseBlock, ToolResultBlock))]})
                if isinstance(message, ResultMessage):
                    terminal = message
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    record = {"model": options.model, "instructions": options.system_prompt, "prompt": prompt,
              "tools": options.tools, "max_turns": options.max_turns,
              "max_budget_usd": options.max_budget_usd, "trace": trace,
              "terminal": asdict(terminal) if terminal else None, "error": error,
              "wall_seconds": time.monotonic() - started, "receipt": receipt.name}
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    try:
        if terminal is None or terminal.subtype == "error_during_execution":
            raise ValueError("No trustworthy terminal accounting")
        tokens = reported_tokens(terminal)
    except ValueError as exc:
        raise ExecutionAccountingUnknown(f"{exc}; stopped without retry. Receipt: {receipt}") from exc
    if terminal.is_error or terminal.subtype != "success":
        error = f"{terminal.subtype}: {terminal.errors or terminal.result or error}"
    output = terminal.result or ""
    if schema and not error:
        try:
            output = schema.model_validate(terminal.structured_output)
        except ValueError as exc:
            error = f"Invalid structured output: {exc}"
    usage = meta.Resources(tokens=tokens, spend_micros=None, wall_seconds=record["wall_seconds"])
    record.update(failure=error, resources=asdict(usage))
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    return Reply(output, usage, record, error)


def agent(prompt, options, receipts, *, schema=None):
    """The same synchronous callable works in Python and an active Jupyter kernel."""
    receipts = Path(receipts)
    receipts.mkdir(parents=True, exist_ok=True)
    receipt = receipts / f"{uuid4().hex}.json"
    with ThreadPoolExecutor(max_workers=1) as worker:
        return worker.submit(asyncio.run, response(prompt, options, schema, receipt)).result()
