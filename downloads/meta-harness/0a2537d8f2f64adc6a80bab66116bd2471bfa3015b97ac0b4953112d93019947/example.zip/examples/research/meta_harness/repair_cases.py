"""Small authored repository contracts; expected answers stay with the evaluator."""

from dataclasses import dataclass


@dataclass(frozen=True)
class RepairCase:
    name: str
    issue: str
    source: str
    specification: str
    checks: tuple


def cases(split):
    """Construct later splits only when their independent evaluation starts."""
    if split == "development":
        return (
            RepairCase("ledger amounts", "Fix parse() for our ledger import format.",
                "def parse(text):\n    return float(text)\n",
                "parse(text) returns a float. Strip whitespace, dollar signs and commas. "
                "Parentheses denote a negative amount; an em dash denotes zero.",
                (("plain amount", "12.5", 12.5), ("grouped dollars", "$1,250.50", 1250.5),
                 ("credit", "(42.00)", -42.0), ("empty ledger mark", "—", 0.0))),
            RepairCase("customer labels", "Fix parse() for customer label imports.",
                "def parse(text):\n    return text.split(',')\n",
                "parse(text) returns comma-separated labels, trimmed and nonempty. "
                "Deduplicate with Unicode casefold, preserving the first spelling and order.",
                (("trim", " Ada , Bo ", ["Ada", "Bo"]),
                 ("empty", ",Ada,,", ["Ada"]), ("duplicate", "Ada,ada,Bo", ["Ada", "Bo"]),
                 ("unicode duplicate", "Straße,STRASSE", ["Straße"]))),
        )
    if split == "private":
        return (RepairCase("warehouse counts", "Fix parse() for warehouse count imports.",
            "def parse(text):\n    return int(text)\n",
            "parse(text) returns an integer. Ignore commas and surrounding whitespace. "
            "A trailing minus indicates a negative count. The token n/a means zero.",
            (("plain", "12", 12), ("grouped", "1,200", 1200),
             ("trailing minus", "30-", -30), ("missing count", "n/a", 0))),)
    if split == "held_out":
        return (RepairCase("shipping priorities", "Fix parse() for shipping priority imports.",
            "def parse(text):\n    return text.lower()\n",
            "parse(text) returns a normalized priority. Strip whitespace and ignore case. "
            "Map express and next-day to urgent, standard and ground to normal. "
            "For any other value, including an empty string, return review.",
            (("express", " EXPRESS ", "urgent"), ("ground", "Ground", "normal"),
             ("alias", "next-day", "urgent"), ("unknown", "rush", "review"))),)
    raise ValueError(f"Unknown split: {split}")
