"""The fixed worker, independent grading, and development-only proposal evidence."""

from dataclasses import asdict
import json
from pathlib import Path
import tempfile

import meta_evolve as meta
from meta_evolve.domain import EvaluatorFailure, Failure, InvalidOutput, ProposerFailure

from repair_agents import agent, scoped_options
from repair_cases import cases
from repair_execution import check_repair


def harness_text(harness):
    return {"planner": harness.planner.value, "context_policy": dict(harness.context_policy.configuration)}


def validate_settings(harness):
    settings = dict(harness.context_policy.configuration)
    if set(settings) != {"include_spec"} or type(settings["include_spec"]) is not bool:
        return InvalidOutput(message="Context must contain only include_spec: true or false")
    if not harness.planner.value.strip() or len(harness.planner.value) > 2000:
        return InvalidOutput(message="Planner must contain 1–2000 characters")
    return None


def repair(harness, case, *, model, root):
    """One live worker edits one real file; snapshots and tests follow its SDK call."""
    with tempfile.TemporaryDirectory(prefix="meta-harness-worker-") as directory:
        workspace = Path(directory)
        target = workspace / "solution.py"
        target.write_text(case.source)
        (workspace / "issue.txt").write_text(case.issue)
        if harness.context_policy.configuration["include_spec"]:
            (workspace / "contract.md").write_text(case.specification)
        options = scoped_options(workspace, model=model, instructions=harness.planner.value, write=True)
        prompt = "Read issue.txt and solution.py. Repair parse(text) in solution.py using the available files."
        if (workspace / "contract.md").exists():
            prompt += " The repository contract is in contract.md."
        print(f"  {case.name} · worker running", flush=True)
        reply = agent(prompt, options, root / "receipts")
        source = target.read_text() if target.is_file() and not target.is_symlink() else ""
    rows, failure, elapsed = [], None, 0.0
    if reply.failure:
        failure = EvaluatorFailure(message=reply.failure)
    elif not source.strip() or len(source.encode()) > 32000:
        failure = InvalidOutput(message="Worker must leave a nonempty Python file under 32 KB")
    else:
        rows, failure, elapsed = check_repair(source, case, root)
    record = {"case": case.name, "issue": case.issue, "before": case.source, "after": source,
              "checks": rows, "failure": asdict(failure) if failure else None,
              "agent": reply.record}
    usage = meta.Resources(tokens=reply.usage.tokens, spend_micros=None,
                           wall_seconds=reply.usage.wall_seconds + elapsed)
    print(f"  {case.name} · " + ("failed" if failure else f"{sum(row['passed'] for row in rows)}/{len(rows)} checks"), flush=True)
    return record, usage, failure


def evaluate_repairs(harness, *, split, model, root, worker=repair):
    invalid = validate_settings(harness)
    if invalid:
        return meta.EvaluationResult(failure=invalid)
    rows, tokens, elapsed, failures = [], 0, 0.0, []
    for case in cases(split):
        record, usage, failure = worker(harness, case, model=model, root=root)
        rows.append(record)
        tokens += usage.tokens
        elapsed += usage.wall_seconds
        if failure:
            failures.append(failure)
    checks = [check for row in rows for check in row["checks"]]
    evidence = meta.EvidenceDraft(kind=f"meta-harness.{split}", data={
        "harness": harness_text(harness), "cases": rows, "split": split,
    })
    return meta.EvaluationResult(
        metrics={} if failures else {"quality": sum(row["passed"] for row in checks) / len(checks)},
        failure=failures[0] if failures else None, evidence=(evidence,),
        usage=meta.Resources(tokens=tokens, spend_micros=None, wall_seconds=elapsed),
    )


def development_view(evidence):
    """No expected answers or private/held-out observations enter the proposer workspace."""
    if evidence.data["split"] != "development":
        raise ValueError("Only development evidence may reach the proposer")
    return {"harness": dict(evidence.data["harness"]), "cases": [
        {"case": row["case"], "issue": row["issue"], "source": row["after"],
         "checks": [{"name": check["name"], "passed": check["passed"]} for check in row["checks"]],
         "failure": row["failure"], "trace": row["agent"]["trace"]}
        for row in evidence.data["cases"]]}


def propose_revision(parent, evidence, *, model, root, schema):
    with tempfile.TemporaryDirectory(prefix="meta-harness-proposer-") as directory:
        workspace = Path(directory)
        # The bounded context selection supplies this observation; no ambient run-directory access.
        (workspace / "development.json").write_text(json.dumps(development_view(evidence), default=dict))
        instructions = (
            "Improve the reusable harness for a fixed code-repair worker. Read development.json. "
            "Choose one edit: planner instructions, or context_policy with only include_spec (boolean). "
            "include_spec makes the repository contract available to the worker. "
            "Keep the method general; do not insert task answers or code. "
            "Give a diagnosis and one predicted benefit. Models, tools, tests and budgets are fixed."
        )
        print("  proposer · inspecting development evidence", flush=True)
        reply = agent("Diagnose the failures and propose one harness edit.",
            scoped_options(workspace, model=model, instructions=instructions), root / "receipts", schema=schema)
    retained = (meta.EvidenceDraft(kind="meta-harness.proposal", data=reply.record),)
    if reply.failure:
        return meta.ProposalResult(failure=ProposerFailure(message=reply.failure), usage=reply.usage, evidence=retained)
    output = reply.output
    value = output.planner if output.surface == "planner" else {"include_spec": output.include_spec}
    from meta_evolve.harness import HarnessMutation
    candidate = parent.apply(HarnessMutation(output.surface, value))
    failure = candidate if isinstance(candidate, Failure) else validate_settings(candidate)
    if failure:
        return meta.ProposalResult(failure=failure, usage=reply.usage, evidence=retained)
    return meta.ProposalResult(candidate=candidate, hypothesis=output.diagnosis,
        predicted_outcomes={"benefit": output.prediction}, usage=reply.usage,
        evidence=retained, derived_from=(evidence.ref,))
