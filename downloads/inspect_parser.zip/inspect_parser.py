"""Inspect the seed for free, or a saved parser run without executing it."""

import argparse
from pathlib import Path

import meta_evolve as meta
from meta_evolve.domain import RunId
from parser import SEED, evaluate


# --8<-- [start:inspect]
def inspect(result):
    for index, attempt in enumerate(result.trials()):
        score = f"{attempt.metrics['score']:.1%}" if attempt.metrics else "no score"
        failure = attempt.failure.kind if attempt.failure else "none"
        print(f"Attempt {index}: {score}; failure: {failure}")
    print("Rankability:", result.inspect().overview.rankability)
    print("Revisions / evaluations:", result.usage().trials, result.usage().evaluations)
    try:
        selected = result.best()
    except meta.NoSuccessfulEvaluation:
        print("No measured candidate to select")
        return
    print("Selected attempt:", result.trials().index(result.best_trial()))
    print("Selected source:\n" + selected.value.rstrip())
    print("Winning lineage:", len(result.lineage()))
    missed = next((item.data for item in result.best_trial().evidence
                   if item.kind == "duration-case" and not item.data["passed"]), None)
    if missed is not None:
        print(f"Missed: {missed['input']!r} -> {dict(missed['actual'])}; expected {missed['expected']}")
# --8<-- [end:inspect]


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("directory", nargs="?", type=Path, help="saved parser directory")
    cli.add_argument("--invalid-seed", action="store_true", help="demonstrate a syntax failure")
    args = cli.parse_args()
    if args.directory:
        if args.invalid_seed:
            cli.error("--invalid-seed is only for the unsaved seed check")
        with meta.Storage.read_only(args.directory / "history") as storage:
            run_id = RunId((args.directory / "run-id.txt").read_text().strip())
            inspect(meta.Run(run_id, storage))
    else:
        result = meta.improve(
            seed="def broken(" if args.invalid_seed else SEED,
            proposer=lambda source: source, evaluator=evaluate, trials=0,
        )  # Zero revisions: this proposer is never called.
        inspect(result)


if __name__ == "__main__":
    main()
